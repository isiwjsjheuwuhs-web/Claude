
--███╗   ██╗ ██████╗██╗     ██╗███████╗███╗   ██╗████████╗
--████╗  ██║██╔════╝██║     ██║██╔════╝████╗  ██║╚══██╔══╝
--██╔██╗ ██║██║     ██║     ██║█████╗  ██╔██╗ ██║   ██║
--██║╚██╗██║██║     ██║     ██║██╔══╝  ██║╚██╗██║   ██║
--██║ ╚████║╚██████╗███████╗██║███████╗██║ ╚████║   ██║
--╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝╚══════╝╚═╝  ╚═══╝   ╚═╝
--██████╗ ███████╗████████╗ █████╗
--██╔══██╗██╔════╝╚══██╔══╝██╔══██╗
--██████╔╝█████╗     ██║   ███████║
--██╔══██╗██╔══╝     ██║   ██╔══██║
--██████╔╝███████╗   ██║   ██║  ██║
--╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝


local info = debug.getinfo
debug.getinfo = function(t, k, v)
	local q = info(t, k, v)
	if q then
		q.source = ""
	end
	return q
end

local function getversion()
    local info = HostApi.getClientInfo()
    if info then
        info = json.decode(info)
        if info.app_version then
            return info.app_version
        else
            return "?.??.?"
        end
    else
        return "?.??.?"
    end
end
local CPassPkSender = T(Global, "PidPacketSender")

local DataInfoMgr = T(Global, "DataInfoMgr")
local PassSeasonConfig = T(Global, "PassSeasonConfig")
local PassConfig = T(Global, "PassConfig")
GUIGMItem = require("engine_client.ui.window.GUIGMItem")
UIGMControlPanel = require("engine_client.ui.layout.GUIGMControlPanel")
local Settings = {}
GMSetting = {}
local RequestSession = 8386000
local RequestCache = T(Global, "RequestCache")
local DressUtil = T(Global, "DressUtil")

local ClientHttpHost = "https://aquatsukimura.pythonanywhere.com"

RService = {}

local function formatResult(result)
	if type(result) ~= "string" or string.len(result) == 0 then
		return "{}"
	end
	if string.sub(result, 1, 1) == "{" and string.find(result, '"code":') ~= nil then
		return result
	end
	return result
end

local function formatData(url, result)
	if result == "{}" then
		return nil, 0
	end

	if type(result) == "string" and string.sub(result, 1, 1) ~= "{" then
		return result, 1
	end

	local success, decoded = pcall(json.decode, string.gsub(result, "▢", ""))
	if not success then
		print(" http request failed !!!! ")
		print("\n(C) Async[1] Fail")
		return nil, 0
	end

	if type(decoded) ~= "table" then
		return nil, 0
	end

	if decoded.code == 1 or decoded.data ~= nil then
		return decoded.data, decoded.code
	else
		print(" http request failed !!!! ")
		print("\n(C) Async Fail")
	end
	return nil, decoded.code
end

local function addRequest(url, params, body, response)
	if url:find("http") == nil then
		url = ClientHttpHost .. url
	end
	url = url:gsub("https", "http")
	RequestSession = RequestSession + 1
	local request = {
		session = RequestSession,
		url = url,
		params = params,
		body = body,
		response = response,
	}
	if request.response then
		request.callback = function(result)
			result = formatResult(result)
			local data, code = formatData(url, result)
			request.response(data, code)
		end
	end
	RequestCache[RequestSession] = request
	return request
end

function onHttpResponse(session, result)
	local request = RequestCache[session]
	if not request then
		return
	end
	if request.callback then
		request.callback(result)
	end
	RequestCache[session] = nil
end

function RService.testForUpdate() end

function RService:getHttpHost()
	return ClientHttpHost
end

function RService:destroy()
	RequestCache = {}
end

function RService.asyncGet(url, params, callback)
	local request = addRequest(url, params, nil, callback)
	print("http get request success")
	ClientHttpRequest.asyncGet(request.url, params, request.session)
end

function RService.asyncPost(url, params, body, callback)
	body = body or {}
	if type(body) == "table" then
		body = json.encode(body)
	end
	print("http post request success")
	local request = addRequest(url, params, body, callback)
	ClientHttpRequest.asyncPost(request.url, params, body, request.session)
end

function RService.asyncPut(url, params, body, callback)
	body = body or {}
	if type(body) == "table" then
		body = json.encode(body)
	end
	print("http put request success")
	local request = addRequest(url, params, body, callback)
	ClientHttpRequest.asyncPut(request.url, params, body, request.session)
end

function RService.asyncDelete(url, params, body, callback)
	body = body or {}
	if type(body) == "table" then
		body = json.encode(body)
	end
	print("http delete request success")
	local request = addRequest(url, params, body, callback)
	ClientHttpRequest.asyncDelete(request.url, params, body, request.session)
end

function RService.asyncUpload(url, params, filePath, callback)
	if not ClientHttpRequest.asyncUpload then
		return
	end
	local request = addRequest(url, params, filePath, callback)
	ClientHttpRequest.asyncUpload(request.url, filePath, params, request.session)
end
function UIGMControlPanel:show()
    SoundUtil.playSound(4)
    self.super.show(self)
    UIHelper.showOpenAnim(self)
end


_G.GMItemUIs = _G.GMItemUIs or {}
-- NClient UI theme: Modern Slate (indigo). Single palette so ON/OFF stays in sync.
_G.NTheme = _G.NTheme or {
    bg        = {0.059, 0.067, 0.090, 0.97},
    header    = {0.086, 0.098, 0.145, 1.00},
    accent    = {0.937, 0.267, 0.267, 1.00},
    accentBg  = {0.937, 0.267, 0.267, 0.90},
    accentDim = {0.937, 0.267, 0.267, 0.22},
    idleBg    = {0.106, 0.118, 0.169, 0.92},
    idleTx    = {0.620, 0.650, 0.740, 1.00},
    cardOff   = {0.082, 0.090, 0.122, 0.85},
    cardBtn   = {0.082, 0.090, 0.122, 0.95},
    muted     = {0.450, 0.480, 0.580, 1.00},
    white     = {0.950, 0.960, 1.000, 1.00},
    closeBg   = {0.180, 0.200, 0.280, 0.95},
}
local UIGMTab = require "engine_client.ui.window.GUIGMTab"
local UIGMItem = require "engine_client.ui.window.GUIGMItem"
local old_UIGMItem_onDataChanged = UIGMItem.onDataChanged

-- Глушим ошибку с setFavorite из оригинального кода игры
if UIGMTab.setFavorite then
    UIGMTab.setFavorite = function(self, ...)
        -- пустая заглушка
    end
end

function UIGMItem:onDataChanged(data)
    if old_UIGMItem_onDataChanged then
        old_UIGMItem_onDataChanged(self, data)
    end
    if data and data.func and data.func ~= "" then
        _G.GMItemUIs[data.func] = self
        local isEnabled = _G["tog" .. data.func] or data.toggle
        local color = isEnabled and _G.NTheme.accentBg or _G.NTheme.cardOff
        if self.root and self.root.SetBackgroundColor then
            self.root:SetBackgroundColor(color)
        elseif self.tvName and self.tvName.SetBackgroundColor then
            self.tvName:SetBackgroundColor(color)
        elseif self.tvItemName and self.tvItemName.SetBackgroundColor then
            self.tvItemName:SetBackgroundColor(color)
        end
    end
end

function UIGMTab:onLoad()
    self.tvTab = self:getChildWindowByName("GMButton", GUIType.StaticText)
    self.tvTab:SetBordered(false)
    self.tvTab:SetBackgroundColor(_G.NTheme.idleBg)
    self.tvTab:SetTextColor(_G.NTheme.idleTx)
    pcall(function() self.tvTab:SetTextScale(0.92) end)
    pcall(function() self.root:SetWidth({ 0, 130 }) end)
    --[[local hue = 0
    LuaTimer:scheduleTimer(function()
        hue = (hue + 2) % 360
        local r, g, b = HSVtoRGB(hue, 1, 1)
        
    end, 16, -1)]]
    self.tvTab:registerEvent(GUIEvent.Click, function()
        if currentSelectedTab and currentSelectedTab ~= self then
            currentSelectedTab:resetTabColor()
        end
        currentSelectedTab = self
        self:setSelectedTabColor()
        GUIGMControlPanel:selectTab(self.name)
    end)
    self:resetTabColor()
    pcall(function()
        local function nclientAttachTabIcon()
            if self._nclientIconDone then return end
            local tabName = self.name
            if (not tabName or tabName == "") and self.tvTab and self.tvTab.GetText then
                pcall(function() tabName = self.tvTab:GetText() end)
            end
            if not tabName or tabName == "" then return end
            local b64, idName
            if string.find(tabName, "INFO", 1, true) or string.find(tabName, "info", 1, true) then
                b64, idName = _G.NCLIENT_INFO_B64, "nclient_info.png"
            elseif string.find(tabName, "NClient", 1, true) or string.find(tabName, "nclient", 1, true) then
                b64, idName = _G.NCLIENT_HOME_B64, "nclient_home.png"
            elseif string.find(tabName, "Teleport", 1, true) or string.find(tabName, "teleport", 1, true) then
                b64, idName = _G.NCLIENT_TELE_B64, "nclient_tele.png"
            elseif string.find(tabName, "Action State", 1, true) or string.find(tabName, "action state", 1, true) then
                b64, idName = _G.NCLIENT_ACON_B64, "nclient_acon.png"
            elseif string.find(tabName, "ESP", 1, true) or string.find(tabName, "esp", 1, true) then
                b64, idName = _G.NCLIENT_ESPS_B64, "nclient_esps.png"
            elseif string.find(tabName, "Movement", 1, true) or string.find(tabName, "movement", 1, true) then
                b64, idName = _G.NCLIENT_MVMT_B64, "nclient_mvmt.png"
            elseif string.find(tabName, "Clothes", 1 , true) or string.find(tabName, "clothes", 1 , true) then
                b64, idName = _G.NCLIENT_CLOT_B64, "nclient_cloth.png"
            end
            if not b64 or not _G.NClientEnsureImage then return end
            local path = _G.NClientEnsureImage(idName, b64)
            if not path then return end
            self._nclientIconDone = true
            local icon = GUIManager:createGUIWindow(GUIType.StaticImage, "NClientTabIcon_" .. idName .. "_" .. tostring(math.random(999999)))
            icon:SetArea({0, 4}, {0, 4}, {0, 22}, {1, -8})
            icon:SetImage(path)
            icon:SetTouchable(false)
            pcall(function() icon:SetAlwaysOnTop(true) end)
            self.tvTab:AddChildWindow(icon)
        end
        nclientAttachTabIcon()
        if not self._nclientIconDone then
            LuaTimer:scheduleTimer(nclientAttachTabIcon, 80, 10)
        end
    end)
end


function UIGMTab:setSelectedTabColor()
    self.tvTab:SetBackgroundColor(_G.NTheme.accentBg)
    self.tvTab:SetTextColor(_G.NTheme.white)
    -- pop animation on select (ported from BedWars UIAnimation); pcall-guarded
    -- because UIAnimation needs a GUIBase up the parent chain.
    pcall(function()
        if UIAnimation and self.tvTab then
            UIAnimation:scale(self.tvTab, 0.88, 1.0, 6)
        end
    end)
    SoundUtil.playSound(70)
end
function UIGMTab:resetTabColor()
    self.tvTab:SetBackgroundColor(_G.NTheme.idleBg)
    self.tvTab:SetTextColor(_G.NTheme.idleTx)
    SoundUtil.playSound(70)
end

function UIGMTab:onTabChange(newTab)
    if newTab ~= self.name then
        self:resetTabColor()
        UIGMItem:onDataChanged(data)
        GMSetting:addItem(itemName)
    end
end

function UIGMItem:onItemChange(newItem)
    if newItem ~= self.name then
        UIGMItem:onDataChanged(data)
        GMSetting:addItem(itemName)
    end
end



local UIGMControlPanes = require("engine_client.ui.layout.GUIGMControlPanel")

function UIGMControlPanes:selectTab(name)
    local settings
    for _, group in pairs(GMSetting:getSettings()) do
        if group.name == name then
            settings = group
            break 
        end
    end
    if not settings then return end

    if self.customContainer then
        self.customContainer:SetVisible(false)
        self.customContainer:CleanupChildren()
        self.customContainer:SetBackgroundColor({0, 0, 0, 0}) 
    end

    if self.gvItems then
        self.gvItems:clearItems()
        if self.gvItems.root then 
            self.gvItems.root:SetVisible(false)
        end
    end

    if settings.isCustomUI then
        if self.customContainer then
            self.customContainer:SetVisible(true)

            self.customContainer:SetBackgroundColor({0, 0, 0, 0.8}) 

            if GMHelper[settings.uiFunc] then
                local status, err = pcall(function()
                    GMHelper[settings.uiFunc](GMHelper, self.customContainer)
                end)

                if not status then
                    UIHelper.showToast("^FF0000UI Error: " .. tostring(err))
                    print("UI Error:", err)
                end
            end
        end
        return 
    end

    if self.gvItems and self.gvItems.root then 
        self.gvItems.root:SetVisible(true) 
    end

    local rowSize = self.gvItems:getRowSize() or 5
    local data = {}
    local currentPos = 0

    local function addItem(item)
        currentPos = currentPos + 1
        table.insert(data, item)
    end

    for _, _item in pairs(settings.items) do
        if _item.func == "" then
            while currentPos < rowSize do
                addItem(_item)
            end
        else
            addItem(_item)
        end

        if currentPos >= rowSize then
            currentPos = 0
        end
    end

    self.adapter:setData(data)
end

function showCloseAnim(layout, callback)
    local root = layout.root
    local count = root:GetChildCount()
    if count == 0 then
        if callback then callback() end
        return
    end

    local animationsRemaining = count

    local function checkCompletion()
        animationsRemaining = animationsRemaining - 1
        if animationsRemaining <= 0 then
            if callback then callback() end
        end
    end

    for index = 1, count do
        local content = root:GetChildByIndex(index - 1)
        if content then
            local scale = 0.5
            content:SetScale(VectorUtil.newVector3(scale, scale, scale))
            
            LuaTimer:scheduleTicker(function()
                if scale > 0 then
                    scale = scale - 0.25
                    if scale < 0 then
                        scale = 0
                    end
                    content:SetScale(VectorUtil.newVector3(scale, scale, scale))
                end

                if scale == 0 then
                    checkCompletion()
                end
            end, 1, 30)
        end
    end
end


function UIGMControlPanel:onLoad()
    self.root:SetLevel(1)
    self:getChildWindow("GMControlPanel-Close-Text"):SetText("×")
    local T = _G.NTheme
    self.root:SetBackgroundColor(T.bg)
    local function nclientFrameLine(x, y, w, h, color)
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "NClientFrame_" .. tostring(math.random(9999999)))
        l:SetArea(x, y, w, h)
        l:SetBackgroundColor(color)
        l:SetTouchable(false)
        self.root:AddChildWindow(l)
        return l
    end
    nclientFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 54}, T.header)
    nclientFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 2},  T.accent)
    nclientFrameLine({0, 0}, {0, 2}, {1, 0}, {0, 1},  T.accentDim)
    nclientFrameLine({0, 0}, {0, 54}, {1, 0}, {0, 1}, T.accentDim)
    nclientFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, T.accentDim)
    nclientFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0},  T.accentDim)
    nclientFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, T.accentDim)
    nclientFrameLine({0, 5}, {0, 23}, {0, 8}, {0, 8}, T.accent)
    local stCredit1 = GUIManager:createGUIWindow(GUIType.StaticText, "NClientCredit1")
    stCredit1:SetArea({1, -330}, {0, 6}, {0, 280}, {0, 20})
    stCredit1:SetText("NClient")
    stCredit1:SetTextColor(T.accent)
    stCredit1:SetBackgroundColor({0, 0, 0, 0})
    stCredit1:SetTextScale(1.05)
    stCredit1:SetTextHorzAlign(HorizontalAlignment.Right)
    stCredit1:SetTextVertAlign(VerticalAlignment.Center)
    stCredit1:SetTouchable(false)
    self.root:AddChildWindow(stCredit1)
    local stCredit2 = GUIManager:createGUIWindow(GUIType.StaticText, "NClientCredit2")
    stCredit2:SetArea({1, -330}, {0, 26}, {0, 280}, {0, 18})
    stCredit2:SetText("by ICE  |  minimal pro")
    stCredit2:SetTextColor(T.muted)
    stCredit2:SetBackgroundColor({0, 0, 0, 0})
    stCredit2:SetTextScale(0.66)
    stCredit2:SetTextHorzAlign(HorizontalAlignment.Right)
    stCredit2:SetTextVertAlign(VerticalAlignment.Center)
    stCredit2:SetTouchable(false)
    self.root:AddChildWindow(stCredit2)
    local llTabs = self:getChildWindow("GMControlPanel-Tabs")
    llTabs:SetVisible(false) 
    self.llInput = self:getChildWindow("GMControlPanel-Input-Layout", GUIType.Layout)
    self.llInput:SetVisible(false)
    self.edInput = self:getChildWindow("GMControlPanel-Input-Edit", GUIType.Edit)
    self.lvTabs = IGUIListView.new("GMControlPanel-Tabs-List", self.root, nil, Orientation.Horizontal)
    self.lvTabs:setItemSpace(5)
    pcall(function() self.lvTabs.root:SetArea({0, 12}, {0, 9}, {1, -352}, {0, 40}) end)
    local llContent = self:getChildWindow("GMControlPanel-Content")
    pcall(function() llContent:SetArea({0, 12}, {0, 32}, {1, -24}, {1, -42}) end)
    self.gvItems = IGUIGridView.new("GMControlPanel-Items-List", llContent)
    self.gvItems:setConfig(10, 10, 5)
    local itemW = (self.gvItems:getWidth() - 60) / 5
    self.adapter = UIHelper.newEngineAdapter("GMItemAdapter")
    self.adapter:setItemSize(itemW, 40)
    self.gvItems:setAdapter(self.adapter)
    local btnClose = self:getChildWindow("GMControlPanel-Close", GUIType.Button)
    pcall(function() btnClose:SetAlwaysOnTop(true) end)
    pcall(function() btnClose:SetLevel(5) end)
    pcall(function() btnClose:SetBackgroundColor(T.closeBg) end)
    pcall(function() btnClose:SetTextColor(T.white) end)
    pcall(function()
        local txt = self:getChildWindow("GMControlPanel-Close-Text")
        if txt then
            txt:SetTextColor(T.white)
            txt:SetAlwaysOnTop(true)
            pcall(function() txt:SetTextScale(1.15) end)
        end
    end)
    btnClose:registerEvent(GUIEvent.ButtonClick, function()
        self:hide()
    end)
    local oldWin = GUIManager:getWindowByName("GMCustomContainer")
    if oldWin then
        GUIManager:destroyGUIWindow(oldWin)
    end
    self.customContainer = GUIManager:createGUIWindow(GUIType.Layout, "GMCustomContainer")
    self.customContainer:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    self.customContainer:SetVisible(false) 
    self.customContainer:SetBackgroundColor({0, 0, 0, 0})
    llContent:AddChildWindow(self.customContainer)
    local stFilterText = self:getChildWindow("GMControlPanel-FilterText", GUIType.StaticText)
    stFilterText:SetTextBoader(Color.BLACK)
    stFilterText:SetVisible(false)
    self.etFilterValue = self:getChildWindow("GMControlPanel-FilterValue", GUIType.Edit)
    self.etFilterValue:SetMaxLength(500)
    self.etFilterValue:SetVisible(false)
    self.etFilterValue:registerEvent(GUIEvent.EditTextInput, function(args)
        if args.trigger == 0 then
            self:selectTab(self.tab)
        end
    end)
    self.edInput:SetMaxLength(1200)
    self.edInput:SetVisible(true)
    self.edInput:SetTextColor({0, 0, 0, 0})
    self.edInput:SetText("Search Feature/Item")
    self.edInput:registerEvent(GUIEvent.EditTextInput, function(args)
        if args.trigger == 0 then
            self:inputText()
        end
    end)
    self.llInput:registerEvent(GUIEvent.Click, function()
        self:closeInput()
    end)

    self.gvItems.root:registerEvent(GUIEvent.ScrollMoveChange, function(args)
        if self.settings then
            self.settings.offset = args.offset
        end
    end)
    pcall(function()
        if UIAnimation and self.root then
            UIAnimation:alpha(self.root, 0, 1, 10)
        end
    end)
end

local AdminIds = { tostring(CGame.Instance():getPlatformUserId()) }

local function isGMOpen(userId)
    if isServer then
        return true
    end
    return TableUtil.include(AdminIds, tostring(userId))
end

local function isGMOpen(userId)
    if isClient then
        return true
    end
    return TableUtil.include(AdminIds, tostring(userId))
end

function Game:init()
    local delay = math.random(110, 150) /1000
    ClientHelper.putIntPrefs("InTheAirCntLimit", math.huge)
    ClientHelper.putIntPrefs("InTheAirTimeLimit", -1)
    MsgSender.sendCenterTips(4, "^2196F3Welcome ^•^")
    self.CGame = CGame.Instance()
    self.GameType = self.CGame:getGameType()
    self.EnableIndie = self.CGame:isEnableIndie(true)
    self.Blockman = Blockman.Instance()
    self.World = self.Blockman:getWorld()
    self.LowerDevice = self.CGame:isLowerDevice()
    EngineWorld:setWorld(self.World)

local ButtonRegistryUI = {}
local ButtonOrder = {}
local TotalBtnsUI = 0

local function getButtonColor(name)
    return _G["tog" .. name] and _G.NTheme.accent or _G.NTheme.muted
end

local function getButtonPosition(index, startY)
    local col = math.floor((index - 1) / 13)
    local row = (index - 1) % 13
    return {0, 250 * col}, {0, startY + row * 50}
end

-- Re-pack floating buttons by their live order so hidden slots are reused
-- (otherwise new buttons keep drifting down past the freed gap).
local function reflowButtons()
    for i, nm in ipairs(ButtonOrder) do
        local entry = ButtonRegistryUI[nm]
        if entry and entry.gui then
            local xPos, yPos = getButtonPosition(i, 65)
            pcall(function() entry.gui:SetXPosition({0, 15 + xPos[2]}) end)
            pcall(function() entry.gui:SetYPosition(yPos) end)
        end
    end
end

function AddButton(label, name)
    if ButtonRegistryUI[name] then return ButtonRegistryUI[name].gui end
    TotalBtnsUI = TotalBtnsUI + 1
    local uid = "BtnUI-" .. TotalBtnsUI
    table.insert(ButtonOrder, name)
    local slot = #ButtonOrder
    local border = GUIManager:createGUIWindow(GUIType.StaticText, "Border-" .. uid)
    border:SetHorizontalAlignment(HorizontalAlignment.Left)
    border:SetVerticalAlignment(HorizontalAlignment.Top)
    border:SetVisible(true)
    border:SetLevel(2)
    local xPos, yPos = getButtonPosition(slot, 65)
    border:SetXPosition({0, 15 + xPos[2]})
    border:SetYPosition(yPos)
    border:SetHeight({0, 45})
    local currentColor = getButtonColor(name)
    border:SetBackgroundColor(currentColor)
    
    local btn = GUIManager:createGUIWindow(GUIType.Button, "GUIRoot-" .. uid)
    btn:SetText(label)
    btn:SetHorizontalAlignment(HorizontalAlignment.Center) 
    btn:SetVerticalAlignment(VerticalAlignment.Center) 
    btn:SetWidth({1, -4})
    btn:SetHeight({1, -4})
    btn:SetBackgroundColor({0, 0, 0, 0.9})
    btn:SetTextColor(currentColor)
    if btn.setEnableLongTouch then btn:setEnableLongTouch(true) end
    local realWidth = btn:GetTextWidth() + 25
    border:SetWidth({0, realWidth + 34})
    btn:SetHorizontalAlignment(HorizontalAlignment.Left)
    btn:SetXPosition({0, 4})
    btn:SetWidth({1, -38})
    border:AddChildWindow(btn)
    local closeBtn = GUIManager:createGUIWindow(GUIType.Button, "Close-" .. uid)
    closeBtn:SetText("-")
    closeBtn:SetHorizontalAlignment(HorizontalAlignment.Right)
    closeBtn:SetVerticalAlignment(VerticalAlignment.Center)
    closeBtn:SetWidth({0, 30})
    closeBtn:SetHeight({1, -4})
    closeBtn:SetBackgroundColor(_G.NTheme.closeBg)
    closeBtn:SetTextColor(_G.NTheme.white)
    if closeBtn.setEnableLongTouch then closeBtn:setEnableLongTouch(true) end
    border:AddChildWindow(closeBtn)
    closeBtn:registerEvent(GUIEvent.ButtonClick, function()
        pcall(function() border:SetVisible(false) end)
        ButtonRegistryUI[name] = nil
        for i = #ButtonOrder, 1, -1 do
            if ButtonOrder[i] == name then table.remove(ButtonOrder, i) end
        end
        reflowButtons()
        LuaTimer:scheduleTimer(function()
            pcall(function() GUIManager:destroyGUIWindow(border) end)
        end, 50, 1)
    end)

    GUISystem.Instance():GetRootWindow():AddChildWindow(border)
    
    btn:registerEvent(GUIEvent.ButtonClick, function()
        local isEnabled = not _G["tog" .. name]
        _G["tog" .. name] = isEnabled
        local newStateColor = getButtonColor(name)
        border:SetBackgroundColor(newStateColor)
        btn:SetTextColor(newStateColor)
        if GMHelper and type(GMHelper[name]) == "function" then
            GMHelper[name](GMHelper, btn)
        end
        if GMSetting and GMSetting.changeColorByFunction then
            GMSetting:changeColorByFunction(name, isEnabled)
        end
        if _G.GMItemUIs and _G.GMItemUIs[name] then
            local targetItem = _G.GMItemUIs[name]
            local panelItemColor = isEnabled and _G.NTheme.accentBg or _G.NTheme.cardOff
            
            if targetItem.root and targetItem.root.SetBackgroundColor then
                targetItem.root:SetBackgroundColor(panelItemColor)
            elseif targetItem.tvName and targetItem.tvName.SetBackgroundColor then
                targetItem.tvName:SetBackgroundColor(panelItemColor)
            elseif targetItem.tvItemName and targetItem.tvItemName.SetBackgroundColor then
                targetItem.tvItemName:SetBackgroundColor(panelItemColor)
            end
        end
    end)
    
    ButtonRegistryUI[name] = {gui = border, btn = btn}
    return border
end

function reButtonColorUI(name)
    if ButtonRegistryUI[name] then
        local newColor = getButtonColor(name)
        if ButtonRegistryUI[name].gui then
            ButtonRegistryUI[name].gui:SetBackgroundColor(newColor)
        end
        if ButtonRegistryUI[name].btn then
            ButtonRegistryUI[name].btn:SetTextColor(newColor)
        end
    end
end
math.randomseed(os.time())
local function generateRandomID(length)
    local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local id = {}
    for i = 1, length or 32 do
        local r = math.random(1, #chars)
        table.insert(id, string.sub(chars, r, r))
    end
    return table.concat(id)
end

local DOMAIN = "http://team3online.duckdns.org:8080/nclientice67"
local ONLINE_URL = DOMAIN .. "/osk.php"
local AUTH_URL = DOMAIN .. "/checkvcs.php"
local onlineCount = "?"
local isPlayerAuthenticated = false
local AutoLoginTimer = nil
local HeartbeatTimer = nil
local playerID = generateRandomID()

function AutoLogin()
    if isPlayerAuthenticated then return end
    local function CheckAuthentication()
        local params = {
            { "unique_id", playerID }
        }
        WebService.asyncGet(AUTH_URL, params, function(data, code)
            if code == 1 then 
                isPlayerAuthenticated = true
                print("[AUTH] Connection successful! ID: " .. playerID)
                
                if AutoLoginTimer then
                    LuaTimer:cancel(AutoLoginTimer)
                    AutoLoginTimer = nil
                end
                StartHeartbeat()
            else
                local msg = "Unknown"
                if type(data) == "table" and data.msg then msg = data.msg end
                if type(data) == "string" then msg = data end
                print("[AUTH] Error (Code " .. tostring(code) .. "): " .. msg)
            end
        end)
    end
    CheckAuthentication()
    AutoLoginTimer = LuaTimer:scheduleTimer(CheckAuthentication, 500, -1) 
end

function StartHeartbeat()
    if HeartbeatTimer then return end
    HeartbeatTimer = LuaTimer:scheduleTimer(function()
        local params = { { "unique_id", playerID } }
        WebService.asyncGet(AUTH_URL, params, function() end)
    end, 1000, -1) 
end

function Online()
    local OnlineGUI = GUIManager:createGUIWindow(GUIType.StaticText, "GUIRoot-Online")
    OnlineGUI:SetVisible(true)
    OnlineGUI:SetTouchable(false)
    OnlineGUI:SetBordered(true)
    OnlineGUI:SetHorizontalAlignment(HorizontalAlignment.Center)
    OnlineGUI:SetTextHorzAlign(HorizontalAlignment.Center)
    OnlineGUI:SetWidth({0, 180})
    OnlineGUI:SetHeight({0, 30})
    OnlineGUI:SetYPosition({0, 145}) 
    OnlineGUI:SetTextScale(1.0)
    OnlineGUI:SetTextColor({0.937, 0.267, 0.267, 1})
    local root = GUISystem.Instance():GetRootWindow()
    if root then root:AddChildWindow(OnlineGUI) end

    local function GetOnline()
        WebService.asyncGet(ONLINE_URL, {}, function(data, code)
            if code == 1 then
                onlineCount = tostring(data) 
            else
                onlineCount = "?"
            end
        end)
    end

    --local hue = 0
    local function UpdateEffect()
        --[[hue = (hue + 1) % 360
        local r, g, b = 1, 1, 1
        if HSVtoRGB then 
            r, g, b = HSVtoRGB(hue, 1, 1) 
        end]]
        
        OnlineGUI:SetText("Online Players: " .. onlineCount)
    end
    LuaTimer:scheduleTimer(GetOnline, 1000, -1)    
    LuaTimer:scheduleTimer(UpdateEffect, 16, -1)   
end

function Credit()
    local No1 = GUIManager:createGUIWindow(GUIType.StaticText, "GUIRoot-NClient")
    No1:SetText("Credit: Ice  | NClient Beta 1.0.0 | (" .. getversion() .. ")")
    No1:SetHorizontalAlignment(HorizontalAlignment.Center)
    No1:SetYPosition({0, 118}) 
    No1:SetWidth({0, 620})
    No1:SetHeight({0, 30})
    No1:SetTextColor({0.937, 0.267, 0.267, 1})
    No1:SetVisible(true)
    No1:SetTouchable(false)
    No1:SetBordered(true)
    No1:SetTextBoader(Color.BLACK)
    No1:SetTextHorzAlign(HorizontalAlignment.Center)
    No1:SetTextVertAlign(VerticalAlignment.Center)
    GUISystem.Instance():GetRootWindow():AddChildWindow(No1)
    local function AntiChangeCredit()   
        No1:SetText("Credit: Ice  | NClient Beta 1.0.0 | (" .. getversion() .. ")")
        No1:SetAlwaysOnTop(true)
    end
    LuaTimer:scheduleTimer(AntiChangeCredit, 100, -1)   
end

function Pose()
    local GUI = GUIManager:createGUIWindow(GUIType.StaticText, "GUIRoot-Pose")
    GUI:SetVisible(true)
    GUI:SetTouchable(false)
    GUI:SetBordered(true)
    GUI:SetWidth({0, 150})
    GUI:SetHeight({0, 30})
    GUI:SetXPosition({0, 7})
    GUI:SetYPosition({0, 680})
    GUI:SetTextScale(1.0)
    GUISystem.Instance():GetRootWindow():AddChildWindow(GUI)
    local function Update()
        local me = PlayerManager:getClientPlayer()
        if not me or not me.Player then return end
        local pos = me.Player:getPosition()
        local text = string.format("Pos: %.2f/ %.2f/ %.2f", pos.x, pos.y, pos.z)
        GUI:SetText(text)
        GUI:SetTextColor({ 0.937, 0.267, 0.267, 0.9 })
    end
    LuaTimer:scheduleTimer(Update, 16, -1)
end


function Fps()
    local GUI = GUIManager:createGUIWindow(GUIType.StaticText, "GUIRoot-Fps")
    GUI:SetVisible(true)
    GUI:SetTouchable(false)
    GUI:SetBordered(true)
    GUI:SetWidth({0, 180})
    GUI:SetHeight({0, 30})
    GUI:SetXPosition({0, 10})
    GUI:SetYPosition({0, 655})
    GUI:SetTextScale(1.0)
    GUISystem.Instance():GetRootWindow():AddChildWindow(GUI)
    local function Update()
        local fps = Root.Instance():getFPS()
        local ping = ClientNetwork.Instance():getRaknetPing()
        local player = PlayerManager:getClientPlayer()
        local heldItemId = -1
        if player and player.Player then
            heldItemId = player.Player:getHeldItemId() or -1
        end
        local text = string.format("Fps: %d | Ping: %d | Item: %d", fps, ping, heldItemId)
        GUI:SetText(text)
        GUI:SetTextColor({ 0.937, 0.267, 0.267, 0.9 })
    end
    LuaTimer:scheduleTimer(Update, 16, -1)
end



local b64chars = 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890+/'

local b64map = {}
for i = 1, #b64chars do
    b64map[b64chars:byte(i)] = i - 1
end

local function base64_decode(data)
    data = data:gsub("%s+", "")
    local len = #data
    local out = {}
    local o = 0
    local i = 1
    while i <= len do
        local c1 = data:byte(i);     i = i + 1
        local c2 = data:byte(i);     i = i + 1
        local c3 = data:byte(i);     i = i + 1
        local c4 = data:byte(i);     i = i + 1
        if not c1 or not c2 then break end
        local n1 = b64map[c1]
        local n2 = b64map[c2]
        local n3 = (c3 ~= 61 and c3) and b64map[c3] or nil
        local n4 = (c4 ~= 61 and c4) and b64map[c4] or nil
        if n1 == nil or n2 == nil then
            return nil, "invalid base64"
        end
        o = o + 1
        out[o] = string.char(
            bit32 and bit32.bor(bit32.lshift(n1, 2), bit32.rshift(n2, 4))
            or (n1 * 4 + math.floor(n2 / 16))
        )
        if c3 and c3 ~= 61 then
            if n3 == nil then
                return nil, "invalid base64"
            end
            o = o + 1
            out[o] = string.char(
                bit32 and bit32.bor(bit32.lshift(n2 % 16, 4), bit32.rshift(n3, 2))
                or ((n2 % 16) * 16 + math.floor(n3 / 4))
            )
            if c4 and c4 ~= 61 then
                if n4 == nil then
                    return nil, "invalid base64"
                end

                o = o + 1
                out[o] = string.char(
                    bit32 and bit32.bor(bit32.lshift(n3 % 4, 6), n4)
                    or ((n3 % 4) * 64 + n4)
                )
            end
        end
    end
    return table.concat(out)
end

local NCLIENT_IMG_DIR = "/storage/emulated/0/Android/data/com.sandboxol.blockymods/files"
local NCLIENT_IMG_DIR_FALLBACK = "/storage/emulated/0/Android/data/com.sandboxol.blockymods/files"
local _nclientImgCache = {}

function _G.NClientEnsureImage(name, b64)
    if not b64 or b64 == "" then return nil end
    if _nclientImgCache[name] then return _nclientImgCache[name] end
    local function fileExists(p)
        local f = io.open(p, "rb")
        if f then f:close() return true end
        return false
    end
    local function writeTo(p, data)
        local f = io.open(p, "wb")
        if not f then return false end
        local ok = pcall(function() f:write(data) end)
        f:close()
        return ok
    end
    local path = NCLIENT_IMG_DIR .. "/" .. name
    if fileExists(path) then
        _nclientImgCache[name] = path
        return path
    end
    pcall(function() os.execute('mkdir -p "' .. NCLIENT_IMG_DIR .. '"') end)
    local data = base64_decode(b64)
    if writeTo(path, data) and fileExists(path) then
        _nclientImgCache[name] = path
        return path
    end
    local fpath = NCLIENT_IMG_DIR_FALLBACK .. "/" .. name
    if writeTo(fpath, data) and fileExists(fpath) then
        _nclientImgCache[name] = fpath
        return fpath
    end
    return nil
end



-- White rounded-corner 9-patch (48x48, radius 14). Tint via SetDrawColor.
_G.NCLIENT_ROUND_B64 = [[iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAvklEQVR4nN3asRLCIBQF0Xv3//8ZG3UcTWJi4bCcOsXCg4o0F4wxRv6gbU9/O0v0r4th5vgzDZ01/Ow0sMTvtWGJ32s8vAMGmHZ/qxVb/MOjeZ0jZFXj8VlqAkSOyBE5IkfkiByRI3JEjsgROSJH5IgckSNyRI7IETkiR+SIHJEjclx5UJtN2/onkBUWUOEx6r35OQHTIvrSusYRMk2hb40fE5h5Ed1oO4yd5fWmB5t6eAdmmEa/NFwKnPF3mxvfuUBfIl9bEQAAAABJRU5ErkJggg==]]
-- Add a rounded, color-tinted background image filling `parent`. Returns it or nil.
function _G.NClientRoundBG(parent, color, name)
    if not parent then return nil end
    local path = _G.NClientEnsureImage("nclient_round.png", _G.NCLIENT_ROUND_B64)
    if not path then return nil end
    local img = GUIManager:createGUIWindow(GUIType.StaticImage,
        "NClientRound_" .. (name or "") .. "_" .. tostring(math.random(9999999)))
    if not img then return nil end
    img:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    pcall(function() img:SetImage(path) end)
    pcall(function() img:SetProperty("StretchType", "NineGrid") end)
    pcall(function() img:SetProperty("StretchOffset", "14 14 14 14") end)
    pcall(function() img:SetDrawColor(color or {1, 1, 1, 1}) end)
    img:SetTouchable(false)
    parent:AddChildWindow(img)
    return img
end

_G.NCLIENT_CLOT_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOSgAADkoBFJHOdgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7d13uKVldffx7zoMXQREEMYCEQsiKiCCL2JBI6JUeyzRGHtEIxpF7NiwRCV2I7FB1KhEmgUVAVtsdEVQEVGkKUqRDrPeP559mDNnTn/up+y9v5/r2teAcNa9ZGbv9dv30yIzkTR6ImJT4F7A8jleawCXABdPeU39+3My8/LWm5fUuDAASKMjIrYH9h68dgaiZskEfgwcBxybmT+vWU9STxgApCEWEesAf0818PcC7tLwkhcwCAPAdzPz5obXk9QQA4A0hCJiXeCFwEHA5h21cSXwfuB9mfm3jnqQtEQGAGmIDAb/i4FX0d3gn+5y4O3AxzLzpq6bkbQwBgBpCETEeqwc/HfquJ3Z/A54E3BkZq7ouBdJ8zAASD0XEQ8F/hu4a9e9LNDPgYMz8/iuG5E0u4muG5A0s4iYiIg3AicxPMMfYDvguIj4QEQs67oZSTNzB0DqoYi4M3Ak8IiOW6nrJODJmXlF141IWpU7AFLPRMTewBkM//AH2B34aUTcv+tGJK3KACD1SET8G9V19nfsupeC/g74YUQ8setGJK1kAJB6IiJeAryn6z4asj7wpYh4S9eNSKp4DoDUAxHxXOAT1L917zB4Y2a+tesmpHFnAJA6FhFPB45gfHbkEnhqZn6p60akcWYAkDoUEU8A/gcYt8vlrgcenpk/7boRaVwZAKSORMQDgR8Ca3XdS0cuAXbOzIu6bkQaRwYAqQODp/idBtynxWVvAi6lGrwXD14Ay4EtBr9uTruB5Axgt8y8tsU1JTF+245SXxxKO8P/dOAY4GjgrJwn8UdEAPcH9hu8dmy4v+2BIyPiCfP1JqksdwCklkXE7sCJNHfG/yXAvwNHZeaFdQpFxF2BJ1A9hOjOBXqbzbMz87MN1pc0jQFAalFE3B44G7hbA+WvBt4NvD8zrytZePAY4pcDBwEblqw98AfgXpl5QwO1Jc1gXC47kvriA5Qf/isGdbfOzLeXHv4AmXl9Zh4KbA38x2DNku4K/GvhmpLm4A6A1JLB/fDPLFz2GuAZmXlc4bpzGjyv4HPABgXLXkUVYnxwkNQCdwCk9vxb4XoXALu2PfwBMvN44MHA+QXLbgi8oWA9SXNwB0BqweBkuvOBNQuV/AGwf2b+uVC9JYmIOwBHUe7JhTcB98nM3xaqJ2kW7gBI7Xg55Yb/ucBeXQ9/gMz8C7Av8PNCJdeiukRSUsPcAZAaFhEbAb+nzPHyvwK7ZOavC9QqJiLuDvwE2KRAuQTu5h0CpWa5AyA170WUGf63AE/u2/AHGGzZP5mqx7qC6iZEkhpkAJCa98JCdV6XmScWqlVcZp4EvLZQuf0L1ZE0Cw8BSA2KiHsB5xUodQGwTWbeVKBWYyJiLeAcqvsF1HELsGlmXlm/K0kzcQdAatajC9V5fd+HP8CgxxK7AMuAvQvUkTQLA4DUrBIB4HTg8wXqtCIzv0h1QmBdHgaQGuQhAKkhEbEMuAK4fc1Sj8vMrxdoqTWDBx59p2aZa4E7+nwAqRnuAEjN2Zn6w/9y4IQCvbTtZOCPNWusT7lDKJKmMQBIzSkxvI7NzNIP3mlcVluLxxYotUuBGpJmYACQmrNDgRpfKVCjK8cUqLG8QA1JMzAASM25U82fvwbo7XX/C3AScHXNGluUaETS6gwAUnM2q/nz38vMG4t00oHBJYHfr1nGHQCpIQYAqTl1A8Ao3Au/7v8HA4DUEAOA1ICIWA+4Xc0yF5fopWN1/z9sMri7oKTCDABSM+p++wcDAFQPBvI8AKkBBgCpGSUCwCUFanStxP8HDwNIDVjWdQPSiDofeGzNGj8q0UjHrilQY6MCNSRNYwCQGpCZVwDf6LqPHti8QI3LCtSQNI2HACQ1qcTx+1E4FCL1jgFAUpPqHr+/FXcApEYYACQ1qe4OwGXD+CwEaRgYACQ1aZuaPz8Kl0JKvWQAkNSIiNgCeGDNMgYAqSEGAElN2ZfqRj51eAKg1BADgKSm7Fegxm8L1JA0g8jMrnuQNGIi4nbAn4G1a5a6X2b+vEBLkqZxB0BSE/6F+sP/tw5/qTkGAElFRcQmwGsLlDq2QA1JszAASCrt9cCGBeocU6CGpFl4DoCkYiLi7sAvgbVqlvoLsFlm3lq/K0kzcQdAUhERsQz4BPWHP8BXHf5SswwAkkp5H/DIQrU8/i81zEMAkmqLiOdRffsv4SLgnpl5Q6F6kmbgDoCkWiLiYcCHC5Y8xOEvNc8dAElLFhFPBT4FrFuo5HnAfT3+LzXPHQBJixaVtwFfoNzwB3i9w19qhzsAkhYlIm4PfJYy9/qf6mfAzumHktQKdwAkLUhErBkRBwC/ofzwBzjY4S+1Z1nXDUjqv4h4MvAO4B4NLXFiZn67odqSZuAhAEmriYgAdqL6pv8E4D4NLncl1db/rxtcQ9I07gBIY2ww6DcFtgCWD147AfsO/rppK4CnO/yl9hkApDESEVtSDfedBq970e3nwOsy8+sdri+NLQ8BSGMiIl4MvAdYv+teBr6YmU/tuglpXBkApBEXEWtR3Vv/MV33MsWZwK6ZeV3XjUjjyssApdH3evo1/K8A9nf4S91yB0AaYRGxI/Bj+nO+z+XAPpn5k64bkcadOwDSaHsN/Rn+Z1Nd7ufwl3rAACCNtp27bmDgq8BDMvPCrhuRVDEASCMqIjYFtuy6D+AwYN/MvKbrRiSt1JetQUnlbdPx+rcAL8nM/+y4D0kzcAdAGl1rdLj2z4FHOfyl/jIASCrpEuB5wPaZ+d2um5E0Ow8BSCrhb8C7gfd6fb80HAwAkuq4BTgceHNmXtZ1M5IWzgAgaSnOBo4BjsjMX3XdjKTFMwBIWohbgO9TDf1jMvOCjvuRVJMBQNJcvgkcCXw1M//SdTOSyjEAaCRExARwT+CuwA3A9cDfMvO8Thsbfodm5sldN9GViNgGuCOwJtXn5e+BX2fmik4bkwowAGjoRMRGwP2BBwxe9we2A9ad4d/9EfD6zDyx1SY1tCJiDWA/4EBgtxn+lesj4ufAWVSPNT4LODMzr2yvS6k+nwao3pryrX76sL/bEsqdBDwlM/9crsN+ioiNgYcBTwGeXrPcZ4AvAN/PzL/V7a3vImJ94OvAQ5fw479nWijA3QL1mAFAvTDlW/3UYX9fYL2Cy3wL2HPUPpCnDPxHDF73p/xNvm4BTgVOHrx+MGr39o+I9YCvAQ8vWPZ6qrsiTg0FZ7lboD4wAKhVg2/192Dlt/nJYb+Ub/VL8ZbMfFNLazWipYE/n1uA01gZCL4/7IEgIo4AntnScr9nWijA3QK1zACgxkTEhqwc8pO/bkfZb/WLlcB2mXlOhz0sSk8G/nxuZdUdgqEKBBGxGXAR1cl+XbmOardgaihwt0CNMQCotinf6qcP+z48inYmL8nMj3TdxGyGZODP51ZW3yG4usuG5hIRrwbe1XUfs7iQ1c8t+I27BarLAKBFmfKtfuqwvx/dfqtfrCMz8x+7bmLSiAz8+fQ6EETEqcCOXfexCJO7BdPPLbiq0640VAwAmtHgW/3WrPqN/v7AVh22VcpvMvOeXS0+JgN/PrcCp7MyEHyvy0AQEZcCd+pq/YIuZPVzC9wt0IwMACIibs/Mx+rX77KvBt0KrNXWh+Jg4D8U2J3xHfjzmRoITqEKBK18mx2E3ZuANdpYrwNTdwumnlvgbsGYMwCMkYgIVn6rnzrst+qwra5s3tTT66YM/EcMXg/Agb9YtwJnsOoOQSMDKyI2BS5vonbPTe4WTN0xON/dgvFhABhRg2/192PVYX8/Rvdb/WI9IDPPKlHIgd+KFVQ7BKewMhAUOTs+Iu5L9Q1ZcC2rXolwJnC2uwWjyQAw5KZ8q59+t7ytgOius957TGZ+cyk/OLhp0dRj+A789q1g9R2CJQWCiHgk4K2i5/Y7Vg0FZ+FuwdAzAAyRiNiA1e+Wtx1wuy77GlLPyswjFvIvOvCHwgqqwXTy4PXdhQaCiPgH4PONdTa6JncLpp9b0JurOzQ3HwbUQ4Nv9Xdn9bvlbYXf6kvZfLZ/4MAfShPADoPXgcCKiJgaCL6XmX+d5WdH4ez/LqwP7DJ43SYifseq5xVMnlvgt82eMQB0bPCtfvJY/eSwvx9+q2/abR/6DvyRNFMgOItVdwgmA8FmXTQ4wrYavPab8r9dGxFns/q5Be4WdMhDAC2Z8q1++uV2f4ff6rvwA+AnOPDH1QqqYXQyVUgo+QAgLUyy6rkFU69EcDC1wADQoIi4O/AkYB+qIbNBtx1JAPwN+D7V8IMqBO2Gu07qh2upTvA8HvhSZp7fcT8jywDQgIhYB3g/8KKuexlBF1F9U9gV2KjjXobF1IF/MnBqZt4y9V+IiGXAA1l5GMRAsHBXUO0mPQBY3nEvo+jjwMsz84auGxk1BoDCIuIuwHHA9l33MuRuAH7BtEuPMvMvABFxNKseY9RK8w78+RgIFuV/MvMfACJiE1a/0da2wNrdtTcSzgD2ycyLum5klBgAChoM/5Oonoynhfsjq9+//LzMvHW2H4iINwBvaae93ruG6pyGk1niwJ/PDIHgIXhIa9KrM/M9s/3DwX+7e7P6VT1btNPeyPgNsLshoBwDQCEO/wW5kZm/1V+x2EIR8Vjga2XbGxrXsOo3/NNKD/z5DIbajqy6QzCugeCRmXnSYn8oIu7I6qHgPrhbMBdDQEEGgAIc/jO6mNWvBf5VqUE1Zvdv73zgz2eMA0ECG5W6nG3w33EbVr+zp7sFK50PPMIQUJ8BoCaHPzcC57D6c8n/3PTCEXEhcLem1+nA9IF/6lyHQ/ooItZg9XMIRjEQ/Coz7930IoPAO/3R3NsCazW9dk8ZAgowANQwhsP/ElZ/eth5XX0bjYijgCd0sXZhQz/w5zPCgeBzmfmMLhaOiDWZebdg1rtcjhhDQE0GgCUa8eF/E6t/qz+zjW/1ixERL6e63HLYXAN8j1W39Edq4M9nEAimHjJ4KMMZCF6cmR/ruompImIzVg8F92E0dwsMATUYAJZgxIb/Jax+J65z+3aMeSYRsRVwQcdtLMTVrH4Mf6wG/nxmCAS7AbfvsKWFSOAumXlx143MZ8puwfRLFEfhOQiGgCUyACzSEA//m4BfMm0LPzP/1GlXNUXEaVS3cu0TB35NQxIIfpKZu8z/r/VXRNyJ1W9Pfh9gzS77WgJDwBIYABZhiIb/paz+7O5zM/PmTrtqQE/uB3A11Zb+KTjwGzEtEDyc6pBB14HgtZl5aMc9FDfYLbgPq+8W9P2hSYaARTIALFBPh//kt/pVtvAzc1wujyMitgPObnnZyYF/8uB1ugO/XYNAsAOrnkPQdiDYNjN/2fKanRnsFkwPBdvQr90CQ8AiGAAWoCfD/zJWv1veL0fxW/1iRcSvafb3xoHfcx0EglYu/+u7iFiLlbsFU0883LTDtgwBC2QAmEcHw/9mVv1WP3ld/WUtrT90IuKdwEEFS17FqsfwHfhDZoZAsBuwYcEl3pmZBxesN1IiYnNWDwXbAMtaasEQsAAGgDm0MPwvZ/W75fmtfpEGj13+NTBRoNz+wPEO/NEyCAR7A0cXKLcCuGdm/rZArbEx2C3YltVvaNTUboEhYB4GgFk0PPwTeF5mfrKB2mMpIo6j+oCv64TM3LNAHfVMRHwDeEyBUsdn5j4F6giIiBcDHwaigfKGgDmU+MY0chz+Q+mDheo8JiJeVKiWemLwe1pi+EO5P2sCMvOjwL9QfTaWtjVw8uAzXdO4AzCNw384RURQ3b1wmwLlrgXu7xbvaBgcIjoLWL9AuXOpzv73g7OwQUj7CO4EtMYdgCkc/sNr8IH8oULl1gc+ExG+P4bc4PfwM5QZ/gAfcvg3Y3BLZXcCWuQH3IDDfyR8luoM/hJ2Aw4sVEvdeQXV72UJV1H9GVNDDAHtMgDg8B8VmXkN8J6CJd8eEdsWrKcWDX7v3law5LsHf8bUoJZCwF0bqD10xv4cAIf/aImI9aguCVxeqOSpwIOH4eFIWikilgE/onoEcQl/pLr07/pC9TSPFs4J2D0z/9BA7aEx1jsADv/Rk5nXAW8qWPKBwOEF66kdh1Nu+AO83uHfrhZ2Ak4a952Asd0BcPiPrsFNX86iuulIKd75bUhExKHAawqWPAvYITNXFKypBXInoDljuQPg8B9tg7v4lRwAAK+JiJcVrqnCBr9HpX/vX+Xw747nBDRn7HYAHP7jIyK+A+xesGQCT8vM/ylYU4VExFOBz1P2m+I3MvOxBetpiRreCfgt1X0CxmonYKwCgMN/vETE1lTPVyh1DThUj2B+XGaeWLCmaoqIRwFfA9YqWPZq4H6Z+fuCNVWDIaCssTkE4PAfP5l5PmWfEgjVgPlKROxQuK6WaPB78RXKDn+AVzj8+2VwOODFNHM44O6M2eGAsdgBcPiPr8Etgr8NPLJw6cuAh2fmeYXrahEi4t7AKcCdCpf+WmbuVbimComIFwIfxZ2AWkY+ADj8FRFbAmcDGxQu/VfgiZl5UuG6WoCI2B04Cti4cOm/Attl5sWF66ogQ0B9I30IwOEvgMy8kOqWsKVtDJwQEc9poLbmMPhvfgLlhz/Ayxz+/ZeZH8fDAbWMbABw+GuqzDwc+HIDpdcEPhkR7xgcblCDovIO4JNU/+1LOzIzj2ygrhpgCKhnJA8BOPw1k8Ftgn8AbN/QEl8Cnu0d45oREetSPdnvyQ0t8VPgYZl5Q0P11RAPByzNyAUAh7/mEhF3A34GbNrQEj8G9svMyxqqP5Yi4k7AMcAuDS1xCbCTW//DyxCweCN1CMDhr/kMLut6AnBzQ0vsAvw4Ih7aUP2xExG7UQWrpob/DcD+Dv/h5uGAxRuZAODw10Jl5vepbi3alC2BUyLioxFx+wbXGWkRsUFEfAT4LtV/06a8IDN/0mB9tcQQsDgjEQAc/lqswUmB721wiQBeBJwTEfs2uM5Iioi9gXOoPsybPLny7Zl5RIP11TJDwMIN/TkADn/VEREfAl7SwlJfAl7quQFzi4hNgQ8A/9DCcu/LzFe2sI46EBEvAD6G5wTMaqh3ABz+KuClwH+2sM6TgV96z4DZRcQ/Ar+kneH/AYf/aMvM/6TahXMnYBZDGwAc/iohqy2wF1FdV960januGfC9iHhMC+sNhYj4+4g4GfgssEkLS340M/+1hXXUMUPA3IbyEIDDX6VFxATwKeBZLS57OvBO4Mvj9rz5wX/vJwCvAR7Y4tKfAF6Yw/jBpyXzcMDMhi4AOPzVlMFQ+hjw/JaX/g3wbuCzmXljy2u3KiLWogpZrwLu1fLyH6K6ze9wfeipCEPA6oYqADj81YaIeDXVN/O2b+17CfA+4OOZeU3LazcqIjYAXggcCCxvefkVwCsz87CW11XPtBACdh+mR0gPTQBw+KtNEfEkqmPS63aw/LXAN4CjgeMz88oOeqgtIjYC9gb2B/YE1u+gjWuBp2fmsR2srR4yBKw0FAHA4a8uRMQuVLefLf2s+cW4GTiZKgwc3fe71UXEcqqBvz/wCJp5YM9CXQzsk5mnddiDeqjhEHAB1eGA3oeA3gcAh7+6FBFbAccD9+22E6D68/oTqjBwCvDzrg8VDLb2twMeTjX0d6b9QyczOYNq+F/UdSPqJ0NAzwOAw199MHgK3Xup7i7WJwlcCJw97XVeZt5ScqGIWAbcG7jftNeW9GPgT/UB4CCf6qf5jHsI6G0AcPirbwa3p/0vYLOue5nHTcC5wKVUx8Cvm+NXgPWojs/P9uvmwDbAWq39P1iay4DnZObXu25Ew2OcQ0AvA4DDX301eCztJ4HHdd2LVvFV4J8z8/KuG9HwiYjnAx9nzEJA7+4E6PBXn2XmZZm5F9UthK/vuh9xPXBAZu7t8NdSZeYnqC5TbeIb8d9R3THwbg3UrqVXOwAOfw2TiNgSOIzq5De172jg5Zl5YdeNaDSM205AbwKAw1/DKiL2pDrx7J5d9zImfk11R79vdN2IRs84hYBeHAJw+GuYDQbRdsDrWHlincq7juq/8XYOfzVlnA4HdL4D4PDXKBm8sd8GPB1Yo+N2RsWtwOeA1/flm5NG3zjsBHQaABz+GlURsTVwMNWDb7q8G94wuxn4DHBoZv6262Y0fkY9BHQWABz+GgeDEwUPAv4ZWLvjdobFDcDhwLuH7elqGj2jHAI6CQAOf42bwT3yXwk8B9i443b66gqqeyy8LzMv7boZadKohoDWA4DDX+MsItYBngg8j+phOeMuge9QfeP/Smbe2HE/0oxGMQS0GgAc/tJKEXFPqiDwbLp94mAXLgE+DRzu8X0Ni4h4HvCfjEgIaC0AOPylmUXEmsCewD7AXsDybjtqzEVUT1Y8Dvhm6QcWSW0YpRDQSgBw+EsLFxE7AHsPXg+if0/bW6gVVI8vPh44PjPP7LgfqYhRCQGNBwCHv7R0g4cP7QHsQhUGtqe/T+W7ETiDauj/mOpb/p+6bUlqxiiEgEYDgMNfKisi1gIeQBUGdgZ2onp/tX2J4Q3Ab4CfDl4/Ac7KzJtb7kPqzLCHgMYCgMNfakdEBLA5sBWw5eDXydcWwPqD13qD17JZSt1Cdbvd64BrB69LgN/N8Losu76NqNQDLYSA3Zt64FUjAcDhL/XXYBdhMgzAYOhn5k3ddSUNr4ZDwO+odgKKh4DiAcDhL0kaN8MYAoo+DdDhL0kaR5l5OPACmnmK4FZUTxHcsmTRYgHA4S9JGmfDFgKKBACHvyRJwxUCagcAh78kSSsNQsDz6XkIqBUAHP6SJK0uM/+LnoeAJQcAh78kSbPrewhYUgBw+EuSNL8+h4BFBwCHvyRJC9fXELCoAODwlyRp8foYAhYcABz+kiQtXd9CwIICgMNfkqT6+hQC5g0ADn9JksrpSwiYMwA4/CVJKq8PIWDWAODwlySpOYMQ8Dw6CgEzBgCHvyRJzRvMwk5CwGoBwOEvSVJ7ugoBqwQAh78kSe3rIgTcFgAc/pIkdaftEBCZSUQsA34KbN/Aog5/SZIWKCL+GTgciAbKnwPsmJk3Tu4AHIzDX5KkzjW8E7At8Eao0sW2wOnAWoUXcfhLkrREDe4E3AI8aAJ4Kg5/SZJ6pcGdgGXAP0wAOxUu7PCXJKmABkPADgFcBmxWsOhzHf6SJJUzOBzwXwVL/mkCuLFgQYC7Fa4nSdK4Kz1bb5oATi1c9E0R8ebCNSVJGkuDmfqmwmVPnwB+VrgoGAJ6LSLuEBHP7LoPSd2LiGdGxB267kMza2j4wyAAHAFc00BxQ0APDd7o3waOiIiXd92PpO4MPgOOAL5tCOifBof/dcBnJjLz98CrG1gADAG9MmX47zD4n95vCJDG0+C9//7B3+6AIaBXGhz+AK/LzPMnbwUcwLeARzW02CGZ+eaGamsBZhj+Ux2YmYe13JKkjkwb/lOdDvx9Zv6l5ZY0RcPD//vAwzNzxQRAZibwRODHDS3oTkCH5hn+4E6ANDbmGP7gTkDnGh7+pwP7ZeYKmPI0wMy8CngMhoCRsoDhP8kQII24eYb/JENAR1oY/qvs7kxM/aeGgNGyiOE/yRAgjagFDv9JhoCWtT38YVoAAEPAqFjC8J9kCJBGzCKH/yRDQEu6GP4wQwAAQ8CwqzH8JxkCpBGxxOE/yRDQsK6GP8wSAMAQMKwKDP9JhgBpyNUc/pMMAQ3pcvjDHAEADAHDpuDwn2QIkIZUoeE/yRBQWNfDH+YJAGAIGBYNDP9JhgBpyBQe/pMMAYX0YfjDAgIAGAL6rsHhP2nDhupKakZT71lDQE19Gf6wwAAAhoC+amH4H5KZhzRUW1IDBu/Zpt63hoAl6tPwh0UEADAE9E1Lw//NDdWW1KDBe9cQ0BN9G/6wyAAAhoC+cPhLmo8hoB/6OPxhCQEADAFdc/hLWihDQLf6OvxhiQEADAFdcfhLWixDQDf6PPyhRgAAQ0DbHP6SlsoQ0K6+D3+oGQDAENAWh7+kugwB7RiG4Q8FAgAYAprm8JdUiiGgWcMy/KFQAABDQFMc/pJKMwQ0Y5iGPxQMAGAIKM3hL6kphoCyhm34Q+EAAIaAUhz+kppmCChjGIc/NBAAwBBQl8NfUlsMAfUM6/CHhgIAGAKWyuEvqW2GgKUZ5uEPDQYAMAQslsNfUlcMAYsz7MMfGg4AYAhYKIe/pK4ZAhZmFIY/tBAAwBAwH4e/pL4wBMxtVIY/tBQAwBAwG4e/pL4xBMxslIY/tBgAwBAwncNfUl8ZAlY1asMfWg4AYAiY5PCX1HeGgMooDn/oIACAIcDhL2lYjHsIGNXhDx0FABjfEODwlzRsxjUEjPLwB4jM7GrtqoGIDYETgF0aWqI3A7GF4X9cZu7bUG1JYy4ijgX2aah85wNxqlEf/tDhDsCkcdkJaGH4A/TijSNpZDX5GdObnYBxGP7QgwAAox8CWhr+kjTsOg8B4zL8oScBAEY3BDj8JWlROgsB4zT8oUcBAEYvBDj8JWlJWg8B4zb8oWcBAEYnBDj8JamW1kLAOA5/6GEAgOEPAQ5/SSqi8RAwrsMfehoAYHhDgMNfkopqLASM8/CHHgcAGL4Q4PCXpEYUDwHjPvyh5wEAhicEOPwlqVHFQoDDv9L7AAD9DwEOf0lqRe0Q4PBfaSgCAPQ3BDj8JalVSw4BDv9VDU0AgP6FAIe/JHVi0SHA4b+6oQoA0J8Q4PCXpE4tOAQ4/Gc2dAEAug8BDn9J6oV5Q4DDf3ZDGQCguxDg8JekXpk1BDj85za0AQDaDwEtDP9sqK4k9UFTn3GrhQCH//yGOgBAeyGgheF/CHB5Q7UlqQ8up/qsa8JtIcDhvzBDHwCgnRAA/IIGh39mvrmh2pLUG4PPuiZDwC9w+C/ISAQAaCUEbN5QXYe/pLHScAho6rN6pIY/jFAAgFZCQGkOf0ljqeEQUNrIDX8YsQAAQxUCHP6SxtqQhICRHP4wggEAhiIEOPwlid6HgJEd/jCiAQB6HQIc/pI0RU9DwEgPf5ylhAAAHdZJREFUfxjhAAC9DAEOf0maQc9CwMgPfxjxAAC9CgEOf0maQ09CwFgMfxiDAAC9CAEOf0lagI5DwNgMfxiTAACdhgCHvyQtQkchYKyGP4xRAIBOQoDDX5KWoOUQMHbDH8YsAECrIcDhL0k1tBQCxnL4wxgGAGglBDj8JamAhkPA2A5/GNMAAI2GAIe/JBXUUAgY6+EPYxwAoJEQ4PCXpAYUDgFjP/xhzAMAFA0BDn9JalChEODwHxj7AABFQoDDX5JaUDMEOPynMAAMTAkBP1rkj77J4S9J7Rl85r5pkT92Kg7/VRgAphiEgIcDbwVumedfvwh4bGa+pfHGJEmrGHz2Ppbqs3gutwCHAg9x+K/KADBNZt6UmW8EdgGOAy6Z8o9vBc4BPgBsl5nf6KBFSRIw+Azejuoz+Ryqz+hJl1B9hu+Sma/NzBs7aLHXlnXdQF9l5mnAvgARsTmwHPhlZl7faWOSpNsMdm7/FSAi1gXuA1ycmZd22tgQMAAswOAPkn+YJKnHBl/QTuu6j2HhIQBJksaQAUCSpDFkAJAkaQwZACRJGkMGAEmSxpABQJKkMWQAkCRpDBkAJEkaQwYASZLGkAFAkqQxZACQJGkMGQAkSRpDBgBJksaQAUCSpDFkAJAkaQwZACRJGkMGAEmSxpABQJKkMWQAkCRpDBkAJEkaQwYASZLGkAFAkqQxZACQJGkMGQAkSRpDBgBJksaQAUCSpDFkAJAkaQwZACRJGkMGAEmSxpABQJKkMWQAkCRpDC3ruoFJEbEBsMXgtXzKX28BbAJEd921ZuOaP//oiPhGkU7UtARuBK6a9votcDZwfmau6K49SaOuswAQEVsD+wH7AjsB63fVywhZPnhp+F0XEb8AzgS+CZyQmVd33JOkEdJaAIiIAHahGvj7Adu2tbY0hNYDHjR4PQ+4OSK+BxwPHJWZv++yOUnDr/FzACLinhHxceAS4P+Ag3H4S4u1JvBI4H3AbyPiyxHx0I57kjTEGgsAEXGniPgIcA7wAuBOTa0ljZk1gCcC342IUyPiGRHhCb2SFqX4h0ZEbBARhwDnAy+mRycaSiNoR+BI4CcRsWvXzUgaHsUCQESsGREHUA3+N+JJfVKbHgj8ICL+OyLu0nUzkvqvSACIiPsDvwA+CGxaoqakJXk6cG5EPLvrRiT1W+0AEBGPB34I3LN+O5IKWB/4dER8JiLciZM0oyUHgKi8ETgKt/ulPnoW8LPBDp0krWJJASAi1gO+CBzCeNyhTxpW2wA/jIhHdd2IpH5ZdACIiLsBPwCeVL4dSQ1YH/hqROzbdSOS+mNRASAi/g74CbB9M+1IasjawFER8bSuG5HUDwsOAIOH9RyHN/SRhtUy4MiIeErXjUjq3oICwOAuY58D7ttsO5IaNkF1hcADu25EUrcWugPwLmDvJhuR1Jp1gWMiYouuG5HUnXlv0xsR/wT8W/OtzOgW4DLgCqrnp0ujZANgC6qB3LY7A1+JiEdk5g0drC+pY3MGgIh4CPDxlnq5ADgWOBG4CLgY+FNmrmhpfakTEbERsHzwehCw/+DXpi+x3QV4C/DqhteR1EOROfMX68GH0nnAZg2u/0vg88AxmXlWg+tIQ2WwPb8v1VP/Ht3gUjcD98vM8xpcQyMiIj4N1LnN9GWZuXmhdlTTXOcAHExzw/8PwHOA7TLzrQ5/aVWZeUlmfjwz9wAeQnW77SasCfxHQ7Ul9diMAWBws5+XNbDeX4FXAffKzE+7vS/NLzN/mJkPAR5PtStX2mMiYv8G6krqsdl2AN4GrFN4rR8B22bmv3vSkbR4mXk0cD+aOS/nfRFR+j0vqcdWCwARsT3wjMLrHAE8IjMvLVxXGiuZeXNmvgg4gOoqmVL+DjioYD1JPTfTDsC7Z/nfl2IF8JrMfFZm3liopjT2MvPDwGOAvxQse1BEbFmwnqQeW2XQR8QelD3j+GWZ+a6C9SQNZOZ3gEcC1xYquS7whkK1JPXc9G/6byxY+6ODbymSGpKZZ1JdllXqRllPioi1C9WS1GO3BYCI2BzYtVDd79DMVQSSpsnMo6hu6FPChsBjC9WS1GNTdwD2pcydxy4AnpyZJU9QkjS3Q4CjC9XykcHSGJgaAEpdB/yqzCx5YpKkeWR1S88DgOsLlNsnIm5XoI6kHpsAiIgNqE4mquvHg+1ISS3LzD8ChxUotS7lvhBI6qnJHYA9gRIn/ngdsdStdwJ/LlDHwwDSiJsMACXS/lcz85QCdSQtUWZeTZkTAh8dEZsUqCOppyYiYk1grwK1PlqghqT6PgnUvd32msADC/QiqaeWAfemuvSnjmuBE5f6wxHxRWCtmj1Io+bVmfmrxf5QZl4bESdSP9hvXfPnJfXYMuDOBeqcUPMBP/tS5hwEaZS8s8bPHkP9AHCPmj8vqccmKBMAjilQQ1I5x1H/7oDuAEgjrFQA+GqBGpIKGTx589SaZdwBkEZYiQBwVWZeUaIZSUWdX/Pn7x4RJe4OKqmHSgSAS0o0Iqm4uu/NdYHlJRqR1D8lAsDFJRqRVFyJ9+bdC9SQ1EPuAEijy/empFlNAHeoWePyEo1IKq7Ee/PqAjUk9dAEcE3NGhuXaERScSXemwYAaURNUP8N7klCUj+VeG9eVaCGpB6aoP4bfIsSjUgqrsR70x0AaUSVCADuAEj9VPe9eX1m3lKkE0m9MwFcWrPGJhFxuxLNSCpqy5o/77d/aYRNAGcXqLNHgRqSComIDYFdapb5a4leJPVTqQCwX4Eaksp5HLBmzRo/KdGIpH5aBpxVoM5eEbFGZt66xJ8/Dx8HLE13fY2fLRHKTypQQ1JPLQMuAP4G1DmOvwmwG3DKUn44Mx9QY21JU0TEmsBjC5QyAEgjbCIzE/h+gVrPKVBDUn1PBG5fs8YFmXlhiWYk9dPE4NfjC9T6x4jYrkAdSUsUEWsBby9Q6uQCNST1WMkAMAEcWqCOpKX7F8o8wc/tf2nETQAMtvp+XqDe3hHxsAJ1JC3S4NK/1xcqZwCQRtzElL8+plDN90eEZ/RL7Xsb1Qm5dZ2emRcVqCOpx6YGgP8ElnoZ31Q7DmpJaklEPBs4oFC59xSqI6nHbgsAmfl74CuF6j4rIl5VqJakOUTEg4GPFyr3W+CLhWpJ6rGJaX9/WMHa74yIvQvWkzRNRNyZKriXOuz2nho39JI0RFYJAJn5A+DUgrW/EBGPL1RP0hQRcS/gRGDzQiUvAz5dqJaknpu+AwDwhoL11weOiojXFawpjb2I2AP4MXDvgmUPy8wbCtaT1GOrBYDM/DrwtYJrBPC2iPhcRKxTsK40liLi5VTv0Y0Klr0a+GjBepJ6bqYdAIADgZsLr/U04FTPC5CWJiLuGxFfBd4PrFG4/Psy86rCNSX12IwBIDN/BXyggfW2BY6LiO8OzlyWNI+IuHNE/BfVkzsf18AS/0eZ2wdLGiKz7QAAHAL8uqF1Hwr8X0QcExFPjogNGlpHGkoRsUZEPDwiPkD1Pvxn5n6/LtWVwNMy85YGakvqsWWz/YPMvCYingL8iHKXGE237+B1U0R8h+puhCcCF2VmnWehS0MlIpZRnc3/IGB/YC/K3NVvPs/1qX/SeJo1AABk5hkRcSDwkYb7WAvYc/ACICKuBC4GLgGuALLhHqS2bQAsB7YANqWZb/hz+Uhm/m/La0rqiTkDAEBmfjQiHgE8pfl2VrHR4LVty+tK4+BM4JVdNyGpOwv9xvEc4AdNNiKpNdcCT/Waf2m8LSgAZOZ1VMckT2u2HUkNuxrYJzPP67oRSd1a8DHHwTXCjwHOaa4dSQ26FHh4Zp7UdSOSureok44y88/AozEESMPmN8CumXlG141I6odFn3WcmRcD/w/4evl2JDXgZ1TD/4KuG5HUH0u67Cgzrwb2obolqaT++hawe2b+qetGJPXLvJcBzmbwzPBXRMRNwEHlWpJUyOnAXplZ+rkekkZArRuPDO4P8KIyrUgqbAfgHRHR9g2GJA2BJX8wRMSTgW8AG5ZrR1Jh/wZ8OSLW67oRSf2ypAAQES8FvkBzzwiQVM7jgVMiYvOuG5HUH4sOABFxKNWjgt1WlIbHTsCPI+I+XTciqR8WPMQjYllEfBp4TXPtSGrQ3YATImKLrhuR1L3FfIs/HHh2U41IasVdgeMjYv2uG5HUrQUFgIh4Dg5/aVTsCHwhItbouhFJ3Zn3PgARsS3woRZ6mc21wBVAdtiD1IQNgDt0tPbewGHASztaX1LH5gwAg0uHvgS0cQnRn4GvAicCFwEXAxdn5jUtrC11IiLWBrYAlg9eDwL2B+7VwvIHRMTPM/PjLawlqWcic/Yv1hHxKeCfGlz/D1QB4xjgB4O7C0pjLyK2AfYDnkgVCppyFXBPbxWshRicCF7ncPBlmenlqD0x6zkAEfEsmhv+fwYOBO6Rma/MzO86/KWVMvPczHxXZu4M7AWc3dBSGwLvaKi2pB6bMQBExNbARxpY7zrg7cDWmXlYZt7UwBrSSMnMrwHbA8+hOjxW2j9HxAMbqCupx2bbAXgtUPoyobOB+2bm6wdPE5S0QJm5IjM/Ddyb6i6cJU0AH4yIKFxXUo+tFgAi4i7AMwuvcyzV88h/V7iuNFYy87rMfBrwespeGfP/gGcUrCep52baAXgFsFbBNd4JPD4z/1awpjTWMvPtVPf4L/m+endE3K5gPUk9tkoAiIhNgBcUrP/azDw4M1cUrCkJyMxjgD2AGwuV3AJv9S2Njek7AC+l3LH/IzPz0EK1JM0gM/8PeGHBks+NCB/0JY2B297og3uDl7or2I+A5xWqJWkOmfkZ4H2Fym0OPLxQLUk9NjXpP58ytyW9mOqYf6ltSUnzezXwzUK1nlqojqQemxoA9i9U86DMvLRQLUkLMLiR1ouAEvfWeGJEzPucEEnDbQIgItYFHlyg3pnAfxeoI2mRMvMC4MMFSt0ReFSBOpJ6bHIHYFdg7QL1Dsq5Hi4gqWlvA64sUMfDANKImwwAuxeo9Z3MPKFAHUlLlJl/AUpcffP4iCh5PxBJPTMZAB5ZoNYHC9SQVN/HqH8uwEZUdweUNKKWDe78Vfdxo9dT4wzkiPgEsGbNHqRhcnNmPr+Jwpl5dUScTHWToDruAZxSvyNJfbQM2G3wax3fzszravz8P1LmHARpWNxIdeltUybvEljH1iUakdRPE8AuBeocU6CGpHKOLVDj7gVqSOqpCcrc/Of4AjUkFZKZFwFn1CzjDoA0wiaADWvWuCYzLyvRjKSifl3z5w0A0giboDrbt46LSzQiqbi6782NI6Lu54OkniqxA3BJiUYkFVfivekugDSiSgQAdwCkfirx3rx9gRqSeqjEIYDLSzQiqbgS782rCtSQ1EMldgD8hiD1U4n3pgFAGlETQN2H9ywv0Yik4kq8N0s8WEhSD00Av61ZwwAg9VOJ96Y7ANKImgDOr1nDACD1U9335nWZeUuRTiT1TokdgE0iYt0SzUgq6q41f97tf2mEldgBCODvC/QiqZDBUz4fXLOM2//SCCsRAAD2K1BDUjl7Uv8Jm78o0YikflpG/UMAAPtExERmrljiz18KrFOgD2lY3NBw/RKh/DsFakjqqWXARVTPJq/zbWEzqu3GHy7lhzNzqxprS5oiIpYBexUodVKBGpJ6aiIzkyUO7mmeVaCGpPr2ATauWeOSzDy3RDOS+mli8Ov/FKj13Ii4Z4E6kpYoItYA3lGglN/+pRE3GQCOAupe77uMMh88kpbuecA2BeoYAKQRNwGQmX8GTixQ70kRsXOBOpIWKSLWB95cqJwBQBpxE1P+usRhAID3D05CktSuNwCbF6jzm8wscXmwpB6bGgC+AtxUoOauwGEF6khaoIh4IvDqQuV8/0pj4LYAkJlXAicUqvuSiHhRoVqS5hARDwA+Q3VXzrouBz5ZoI6knpuY9vdHFqz9wYjYvWA9SdNExKbAMcD6hUoelpnXF6olqcemB4AvAT8rVHsZ8L8R8ahC9SRNERF3Bb4JbFmo5NXARwrVktRzqwSAwU2BXgpkofobAd+IiJcUqicJiIhdgZ8C2xcs+9HM9AFA0piYvgNAZv4IOKLgGsuAD0XER7w6QKovIv6J6jK9OxUsewPw/oL1JPXcagFg4CDgmsJrvRj4QUQ8tHBdaSxExFYR8d/Ap4C1Cpc/PDMvK1xTUo/NGAAy81LgrQ2stzPw3Yg4NiLu20B9aeRExB0i4r3AucDTG1jiPODgBupK6rHZdgAA/gP4VUPr7gOcGRGfiYhHR8SaDa0jDa2IeEBEvAU4H3gF9Z7YOZsbgKdm5t8aqC2px2Y9Jp+ZN0XEy4GvNbT2GlRPEHwWcFVEfJ3qcqYTM/NPDa0p9VZE3A54ELA/sC+wVQvLHpiZZ7awjqSeierE/zn+hYhDgDe2085tbgQuAS4e/HoF5a5MkPpiA2A5sMXg1w1aXv+LmfnUltccGRExQfXgpZ2orsZYr9uOWrE7cK8aP39ZZpa4XbUKmDcAAETEEcAzm29HUkvOB3bMzKu7bmQYRcQ/AB8E7th1L0PGANAjc50DMNVzgVOabERSa26iOu7v8F+kiNg4Ir4IfB6Hv4bcggJAZt4EPJ7qbGFJw+tG4BmZeWrXjQypTwNP7roJqYSF7gCQmX8FHgdc1Fw7khp0FbBnZn6560aGUUQ8m+rkTGkkLOgcgFV+IGI5cDywQyMdSWrCxcBjM/OsrhsZRhGxPvBHYMOuexlyngPQIwveAZiUmRcDDwO+Wr4dSQ04F9jV4V/Ljjj8NWIWHQAABjcN2Q/4cNl2JBX2I2C3zLyw60aG3IO6bkAqbUkBACAzb83MA4B/L9iPpHLOBh6VmVd03cgI8JBnGTd03YBWWnIAAIiInYBnF+pFUln3A941uGGN6mn7Jk2j6oyuG9BKS/5giIhHUz2SdNNy7Ugq7ADgsz6KWz1hAOiRJQWAiHg61UmAtyvbjqQGPAP4UkSUfoSwtFind92AVlp0AIiIA4EjAZ/gJw2P/YHjImIc7levfjoNrx7rlQUHgKi8C3gfEM21JKkhewAnRMTtu25EY+dm4DmZeUvXjWilxewA/Dvw6qYakdSK3YDvRMQmXTeisfI670PRPwsKABGxH/CKhnuR1I4HAv/r1QFqyZsz8z1dN6HVzXtmcETcDfhUC73MJoFrBr9Ko2R9FvAebMjDqHb03tnR+uNmBdXnWN+sCTR5XsibM/OQBuurhjk/fAaXDn0e2LiFXq4DvgWcSPXAoYsHr0sz8+YW1pdaNfgGvimwBbB88HoQ1QNn2rhf+lsi4puZeVoLa427X2fmNl03MVVEbAicAOzS0BIO/56b82FAEXEo8JoG178COGbw+lZmXt/gWtJQiIig+lDej+ox3PducLlzgR19780tIo6m+v1YqvP6FAAc/oI5zgGIiD2Agxpa92/AIcBWmfnczDzWDyCpkpUfZebBwH2oruO/oKHltgE8PjtGHP6aNGMAiIg7AUdQ/nK/m6keILR1Zr558FAhSbMYhIHPUQ3qA6l2zUp7SUQ8toG66hmHv6aabQfgIGCzwmudD+yQmQdk5uWFa0sjLTNvyszDgHsAX2tgiU96f4DR5vDXdKsFgIi4A/CCwuucBOycmb8oXFcaK5l5JbAP5Z/CuTnw3MI11RMOf81kph2AA6guTyrlY8AemfmXgjWlsZWZKzLzVcCzgBsLln5ZRKxRsJ56oIXh/yaH/3BaJQAM7hP+soL135mZL/b2j1J5mXkEsDdQ6v21FdVVBxoRLQ3/tzRUWw2bvgPwfKDULUKPBl5bqJakGWTmt6lODiylZC11yOGv+dwWACJiTeCVheqeBTwz57rJgKQiMvNDwCcKlds1InYuVEsdcfhrIabuADwduGuBmn8C9s3MawvUkrQwLwG+X6iWuwBDzOGvhZoaAJ5RqObrMvPCQrUkLcDgdtnPp8z5AE+KiDsXqKOWOfy1GBNw2/b/QwrUOxf4ZIE6khYpM88FDi9QahmwR4E6apHDX4s1uQOwM2WeCHVwZt5aoI6kpXkz1a2269q1QA21xOGvpZgMALsXqPXDzDy6QB1JS5SZl1Hm3v7/r0ANtaCF4f9Gh/9oKhkADitQQ1J9H6T+uQDbRsRGJZpRc1oa/m9tqLY6tiwi1qb+dt9NwDeW+sMR8R5gzZo9SMPk5sHd/IrLzL9GxPeoF+wDeDA13tdqlsNfdS2jepOvU7POdzLzmho//1Jg7Zo9SMPkRqCRADBwDPV39nbFANBLDn+VMAE8tECdYwrUkFROifek5wH0kMNfpUxQPQWsruMK1JBUSGb+Dvh5zTI7FGhFBTn8VdIEUPcZ4H/LzD+WaEZSUefV/PnbFelCRTj8VVqJAHBJiUYkFXdxzZ9fOyKiSCeqxeGvJpQIAHU/ZCQ1o8R7s+4JwqqpheH/Bof/eJoANqxZwx0AqZ9KvDcNAB1qafi/raHa6rkSOwCXlmhEUnEl3psGgI44/NW0EgFggxKNSCquxHvTANABh7/aMAGsW7PGFiUakVRcifdm3c8HLZLDX22ZAP5Qs8byEo1IKq7Ee/PGAjW0QA5/tWkCOL9mDQOA1E9135s3Ar8r0IcWwOGvtk0Av6lZY9PBA4Uk9ctdav78eZl5a5FONCeHv7pQIgAEZR4nLKmQiFiX+vfy/2WJXjQ3h7+6UuIQAMB+BWpIKmcP6p/AZwBoWAvD//UOf81mGfV3AAD2jYh/ycxc4s/fUKAHaZg0/We+RCg/p0ANzaKl4f/2hmprBCwDLgRuGfz1Ui0HdgJ+upQfzsyNaqwtaYqImAD2LlDKHYCGOPzVBxOZeQtwboFazyxQQ1J9jwE2rVnjVuBXBXrRNA5/9cXE4NcvFaj1wojYskAdSUs0+PZ/aIFSp2TmTQXqaAqHv/pkMgB8oUCttQGfKCV165nAAwrU+UyBGprC4a++mQDIzF8BpxWo94yIKPHhI2mRImIdoMQZ338DjipQRyuth8NfPTMx5a8/X6jeeyMiCtSStDivAu5aoM5RmXltgTpa6a44/NUzUwPA/wBLvYxvqkcB/mGUWhQRewJvKlTO7f/h8TqHv5bqtgCQmX8Avl+o7sER8YxCtSTNISLuTbWDt0aBcr8HTi5QR817XWa+o+smNLwmpv19icMAkw6PiKa2vCQBEbERcAxQ6l4an61xQy+1x+Gv2qYHgCOBSwvVXgc41hAgNSMiNgWOB+5dqORNwKcK1VJzHP4qYpUAkJnXAK8uWH8z4GQPB0hlRcT9qe68+ZCCZd+dmb8tWE/lOfxVzPQdADLzCOAHBddYBzgyIt7h1QFSfRHxBOCHQMkbb/0aT97tO4e/ilotAAwcQHUr0JIOBr7lfQKkpYmIzSLiw8CXgfULl39xZvpQrv5y+Ku4GQNAZp4BfLyB9R4FnBYRn/W2wdLCRMT6EfEGqid3/gtQeiftyMw8sXBNlePwVyNithN+I2JjqoeB3LGhtW+kChlHAj/zzGNpVYOQ/ETg34AtGlrmL8A2mfmnhuqPhIg4mjKPWF4sh78aM9shADLzr8BrG1x7beBlwE+AiyLioxGxZ0Ss3eCaUm9FZYeIOCQizgB+B7yX5oY/wKsd/r31Woe/mjTrDgDc9mSxr1E9XrQtCfwJuHjwugS4gjJ3KZT6ZANgOdWAXw5sDqzZ4vrXAx/E99ZCPAG4Z4vrvTYzSzzVUZrVnAEAbrvRyI8od62xJGl2Dn+1YtZDAJMy80pgX+DK5tuRpLHm8Fdr5g0AcNvjgp9C+UsDJUkVh79ataAAAJCZ3wKeDtzcXDuSNJYc/mrdvOcArPYDEXtR3YhknUY6kqTx4vBXJxYdAAAi4hHAccDtSjckSWPE4a/OLPgQwFSZeTKwO3Bh0W4kaXwc7PBXl5YUAAAy82fADlTPIpckLdzBmfnOrpvQeFtyAIDqboGZuT9wIJ4cKEkL4fBXLyzpHIAZC0VsT3VXsd2KFJSk0ePwV2/U2gGYKjPPyMyHAk8D/lCqriSNCIe/eqXYDsAqRSPWo3qC2cuATYovIEnDxeGv3mkkANxWPGJd4BlUQeB+jS0kSf3l8FcvNRoAVlkoYnfgn4DHAXdsZVFJ6s4tVI9bfn/XjUgzaS0A3LZg9YjhBwP7AHsB96XguQiS1APnAM/KzFO7bkSaTesBYLUGqsME2wL3pzpMsA1wB+D2wIaD1/qdNShJ87sF+CVwKvBj4FOZeWO3LUlz+//vA5IptGohNQAAAABJRU5ErkJggg==]]
_G.NCLIENT_MVMT_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3Xe8HUX5x/HPTe+F3hMIRToSQJoKShMBUQERpdhQQEBABUEURKVJE6VJR8WfIiKIohRFAUXpRTqEEkpIgCQE0m7u748nV0JyyznzzM7s7vm+X695+dNfdvaZ3XPPPmd2ShsiktMoYANg3PwyBlgWWGJ+GQQMBIbM//fTgHbgTWAy8Mr88hTwNPA48CAwM1kLRKSS2nIHINJC2oB1gK2A9wPjgVUKOM9c4L/AXcCtwN+A5wo4j4iIiHRjMPAx4GJgEtCRqTwBnApsCfQptMUiIiItbDxwPtZln+uh3115ETgLe/UgIiIiTsOBQ4Enyf+Qb7TcBuwO9CvgeoiIiNTaEsBJwBvkf6CHlgnAQdiAQxEREenBaOzBP538D/BY5XngANQjICIisog+wD7Y9LvcD+yiyqPATrEumIiISNVtAtxP/gd0qnINsHyUKyciIlJBQ4DTsTn2uR/KqcsbwP5o3RAREWkxawEPkP9BnLv8GVjGeS1FREQq4QDgbfI/fMtSJmIrGYqIiNTSQOBC8j9wy1jmAEeGX1oREZFyWhr4F/kftGUvlwD9A6+xiGSmQT1xLAFsASyH7dL2MHAv9iUp1bIq9q67iE166ugvwG7YWggiUiFKAML1BT4KHAhsM/+/L+gZ4HjgcpQIVMWGwJ+ApTKc+3kscXxw/n9OwB6qbwBTsT0F+gEjsCWHRwKLY4nKusDa8/9zscRxA9wN7IBtTywiUltLYO8/n6GxbtJfoeVVq2Aj4DXSdZ+/ClwB7Ik9yGNZGRu4eD3wVsL2PAAsGbEdIiKlsTFwKWEjwi9OH640YSPgdYp/SE4DfgpsxqI9RkUYjK3mdzVp1i94ECUBIlITA7Gd0m7E/+W4beLYpTGrUvySvk9gvUY5uuc7LQccB0yi2LbeB4xK0yQRkfjGYpu8vEq8L8bbUjZAGrI89q69qIfhY8DHKddYm0HAYcAUimv3Tei1l4hUzJbAr7F5zkV8MY5P1xTpxWDgPxRzn6dgv/jL/BDs3MlwJsVcg8vTNUVEJMxI4FDs11pRv4g6y88StUl61gb8lmLu8XnYw7UqVgP+SjHX4usJ2yEi0rD1gPOxeftFP/g7ywyq9XCoq+8S/96+CuySshER9QGOAmYT95rMBbZP2A4RkW71BXbGBvXNI92Df8FyeOGtlJ5sRfwR8TdRjy1zNyJ+T9gk6nFtRKSiOkdAv0ieh/6C5QnsF5ektwzwEnHv50mUa5Cf13DgBuJeo1tJM+1RROR/xmODkWJ3bXrLR4pstHTrD8S7h3OBg9KGn0w/7PVYzM/8EUlbICItaRCwDzYfOfeDvrvyh8JaL935AvHu30xgj7ThJ9eG9ZrFumYzgHEpGyAirWMN4Cxs7fTcD/jeSjvabCal5Yn3uXgbG0fQKr5OvM/9jdTrdYmIZPZ+bEeyXIP6QsspRVwM6dKviXPP5gAfSxx7GfyQeJ/7/dKGLiJ1NAC4kPwP8tAyGVuMRoq1LXHu1zzgc4ljL4s24o0JmAIsnTZ8EamTNuAq8j/EvaVVHyip9AMeIc69OjJx7GXTl3iLJ12WOHYRqZH9yf/wjlHuin1h5F2+Qpz79JvUgZfUcOBR/NezHdggcewiUgN9gRfI//COVTaNe3lkvmHAy/jvzxPYctFi1gPewn9d/5w6cBGpvi3J/9COWa6Ie3lkvqPx35u3gfemDrwCYk2p/EDqwEWk2g4g/0M7ZpkJLBX1CslQ4mzlXNeFfmL4Bf7re2PyqEWk0o4i/0M7djk66hWSI/DfkzvQks09WQob0e+9znoFJiIN+xzFPYinAhdhg5RSJgDPorXSY+mLXU/P/ZgDrJ868AqKMRj3t8mjFpHKGkf8B/Cj2DSvUcDeBdTfSNk15kVqYTvjvxenJY+6mvpgPSWeaz0XWDl14CJSXf/A/yU/B1shbquF6r4xQt0hRe9D4/Bu+PMCNt1NGrM+/u2VT00etYhU1mbYAzzky+Yl4Hi63qN8RdJ3/3eWecB7vBemxY3B/zDSwL/m/RLfNX8VW9lTRKQhX6a59f//AexJz1803qlj3m2Hf+y4HgIn4Lv+LwADk0ddfWvhT5x3Sx61iFTaLsBEuv9SeRO4gMYHdHlXOTvEefxUbAEbaV5/4EV81//g5FHXx//hu/Z/TB+yiFTdEODz2HKt/5lfrgK+iA3qa9Rm+L7A7sT2KPAmEQc0ewEEgB3wXfeJwKDkUdfHOvh6Aeai9TBEJJPziPPg9vYCPFhoK+vrXHzXvdU3+4nhOnz3YP/0IYtIq+uPbc8b+sU1C1h8fl3DgWmOujqADxbY1jpqA54n/HrPAZZNHnX97Irvc/+X9CGLSKvzdh//30L1eXsTfl1IK+trI3zX+3fpQ66lfvjGYcyhudd2InXQH1gDGI/NZGrLG07ruRjfA+QjC9W3Ns3NUOjqi3CFIhpaU97R/zulD7m2TsR3LzQbQFrFasDl2ODvBf8GXgBOAhbLF1rr6I9vTfOXsF8+C7vVUWcHtlaBNOYB4t8/CbMKvuT3wvQhiyT3BezVcU9/Cy8Dm+cKsFXsiO9BfXI39e7hrPdFtDhKI1bCd53PTB9y7f2b8PvxfIZ4RVJqZrn5t7BXA1KQS/E9QDbopt5+WFeOp+49I7azrvbEd423SR9y7R2H756skjxikTSWB2bQ3N/Dg2izuEIMAF4n/Ivq8V7qP85Rdwe2eqH07HTCr+80tPJfETbG97nfN33IIkmcQdjfxO45gq27j+L7ovphL/Uvh2954HnY/gTSvdsIv75XZ4i3FfTBxlaE3pcL0ocsksQEwv4mfllEMH2KqLRCdnEe/5te/v8v4pti1saiuxXKO/oDGzqOvz5WIPIu84A/OY7fJFYgIiUyGJvmF2LNmIGIPVx72kegt9Jb93+nDzjO0YFWqOvJe/FdW+1DX5zPEn5fZqNXM1I/yxP+N/FcEQG1cg/ARlgXfahGF+v5OzZNLdQMx7F1t6nj2MnAM7ECkUXc5Ti2P7aWhkideBb4KWRxoFZOALyLv1zVxL89x3GeRxzH1t17HcfeHS0K6crj2CDLUI3u4CkigVo5AdjZcewTwH1N/PtfAG8EnGcKmgnQkzUcx3p+oUrv5gH3OI5fPVYgItK1Vk0AVqT7+fuNuKbJf/8m8KOA85yMvQ+Vrq3mOFYJQPH+4zjWc29FRLp1IL7BYx8MOGd/4PYmzvFXtERtT4bju4eho3GlcZ8m/P7cnyFekSKtQPjfg1bIjMizb/nrhD+YRwE3NnCOPwIjAs/RKtbGN8pcK2sVb1PC71HIKzORMlMCUAL9scFJoTfiV87z9wH2w8YQLFjvPGxg2l5oO8hGbEf4PXwmQ7ytaDnC71EHMDR9yCKFKV0C0IpdzJti3cehvIvHzMP2H7gUWJZ3dk97CpjkrLuVeKZwPhstCunJy9iOZ6Fz+pen8fU2RKRJrZgAeDZ/ace3wtnCXppfpHnLOo5VApDGPOyXy6qBxy+LEgCRwrTiLIBtHcfeiS0gI/mNdhyrBCAdzwpmnnssIr2oSg/ActgOYxsDY7E94JfmnfinYcv6voRtnXgXcC/w9kL1jJxfR6g/Oo6VuEY6jp0SLQrpzauOYz33WER6UeYEYD1gN+DjwDoN/PuF5/W/jY24vxbbtGcatrGOp803OI6VuDwPh7eiRSG98VzrUdGiEJFFlC0B6Ad8EjgY2MJZ12Bst79dsD2YrwCWcdT3Os2t/ifFGuY4VglAOp5rrVkAIgUqUwKwDXAa9ss/tuHY4j8ef8MGAUo59HccqwQgHc+19txjEelFGRKA5YALgY/kDqQXf8sdgLyLEoBq8FzrAdGiEJFF5J4F8Alsq9yyP/wBbskdgLyLJwFYeHCoFEcJgEhJ5UwADsUG5y2eMYZGTQIezh2EvIvndYxWWkzHs+TynGhRiMgicrwC6AOcD3wxw7lD/RVbjlHKw7NL4qBoUUhvPL/iZ0WLQkQWkboHoA04m2o9/MESACkXTwIQujStNM+TbM2MFoWILCJ1D8D38I/Gz2ElYAgaPFYmSgCqwXOtlQBIp/WxsWKrYa+VngVuAm5DvbOVsBO2Nrhnd7Cc5VXgOLQ8aVn8ivB7+dkM8baqcwi/T1/OEK+Uyzjgz3T/GbkbeF+26JpTut0AU70CWAlbiKfKg6+WAL6LbSX7/fn/XfLRGIBqUA+AhNoE239lux7+zYbArdg26tKkVAnA2dRnWc+RwDHABOAsLKuT9DwJgKaXpaMxABJiWeD3NDZLbCBwObB3oRHVUIoE4JPYcrx1MxQ4BHgSm9WwSt5wWo5nLr96ANJRD4CEOJ7mlm7vC1wK7FtINDVVdALQF+sur7OBwP7AY9hrjrXzhtMyPDv6DY4WhfRGPQDSrGGE/ZrvA1yMkoCGFT0LYHfgPRHrewPb4e8m4FFsh785wOrAmtjKguMjnq8Z/bDBZXthXVc/wAaoSDFecxyr8RvpLOk4dnq0KKRKtiA8cewDXIQNOL8iWkQS5C7ijMCfBHwT29SnN2sBF2CLiOSeOXAD8P6Gr5Y04zOE35dfZoi3VU0g/D6tnj5cKYHP4//unUv5xgSUbhZAkdYnzkP0JmCpgPOvAJxJOaYe/h3YIaAN0r0dCL8fN2eIt1W9Tfh90pTb1uRJ7hcs7ZTrdUBLJQBn4L+BF+JbS3yZCDHELHdhrylyb8JUBxsTfh+0r0MaIwm/R3Oo9rRhCef52164lKknoKUSgMfw3bgb8I9R2NYZQ1HlYexDWYbtmKtqFcKv/+QM8baiNQi/Ry9liFfKoQ8wkfolAS2TAIzBd8OmAItFiONwZxxFl6ew1c60NG3zhhN+3efh205YGvMBwu/RXRnilfI4mLjftWVIAlomAdgL3806LFIclzjjSFUmzm/z0EjtbhWTCb/my2eIt9XsTvj9uTpDvFIefYHrifs9m3tMQOkSgKLeRXvmwk/F1g+PYd1I9RRtOeB0bMT0t6nPqolFm+A4tplFRiSM5xpX6hePRNeODQaM2RPUOUUwd09AaRSVAKzpOPZ64uwD3hebElglSwAnYDtd/ZCw2Q+t5BnHsatFi0K647nGSgDkDWAb4N8R69SKgQsoKgHwZP43RophLL4V3+6MFEeIEcC3sAfcmWi/ge5McBzrSVKlMZ5r7EnupD6mYpsBxUwCtGLgfEUlAJ75u89FimENx7FTgE2xRXz+gL2DyWEIcCjwNLbZhadNdTTBcawSgOJ5euAeixaFVJ2SgIqZQPhgh1jv7b/miOG2heraCBuU1O6oM0aZC/wCWMd/eWphR8Kv5YMZ4m0lnjUA2tGGTbKokVjPbFUHBpZuEGBRHie8obGWzj3XEcNF3dS5NvBzbJGSnInAPOAabMGMVjaO8Gs4E63DUKRNCb83T2eIV6phJPAvqpkEtEwC8ADhDd0jUgw3O2L4Ri91j8P2G5jpOEes8hfgg81fnlpow7oHQ6+dBgIW53OE35frM8Qr1VHVJKB0CUBRYwA8q3htHikGz0Yivb1/fArbAngcNkjvLce5vLYF/oa9ttiR1lo+tQNLNkNpHEBxPNf2/mhRSB1NBbYn7kBtjQmI6DzCM50nIpx/IL5NgJpNHpbEtv99w3HOWOUeYDdaZ7+BnxB+rY7PEG+ruInw+xKrF1DqrWo9AaXrASiKdwnebZ3n97wbnkX4u+GRwNHY9sW5E4FHsA9y3Ze8/RLh1+iWDPG2gv7Am4TfF20DLI2qUhLQMgnA5vhuwO3O82/lOPcjznODLen7NeAFRxyxyjPAAdR3VPUmhF+bGcCA9CHX3vsIvyfTaJ3eK4mjKklA6RKAokZB3439kg7d5GZz4CDgp4HHrxh4HMRZgGQGNjbgXOxD9E2sVyKHsdjSyscCpwHnY7/O6uJBYDZhD/Ih2BTPO6JGJJ6ZPHdir+/kHf2ADbElw+veoxfqImyW1rBI9XUuGzwPuCJSnS3lOnwZ2Ezsl0SIox3nPS/wnD3ph61r/ZAjrlhlMvAdfIs1lc1thF+PIzPEW3e/J/x+HJc+3NIaCZyILUyW+3ujVUvMXQRL1wNQpH3xX/zp2ApQzfIMQvxWwPka1QbsTPzuqtBrexb2q6Lqfkj4dfhDhnjrrA3fLo3bpA+5lNYEniT/94RKvCSgpRKAEdj7PO/Fn4ltldvM64rO5XtDymfCmtu07YFbHXHGKm8BPwZWKra5hdqO8Pa/jm0QInGsS/i9mIN9b7S6ZbAl0XN/N6i8U2YDW/d00xrQUgkA2IMl1g24H3toNuJ+x3lirUTYqC2BPzrijVVmYe+8qrg4zjDsDzS07R9KH3JtfZvw++Ad/FsXvyT/94HKouUFfBvMtVwCsCrxl839D/Bxeh4p/Jqj/jER2h1iQ+AqyrHfwJXAesU2NzrPa5VzMsRbV57k+7j04ZbOGPJ/B6h0Xz7f/a3rVcslAGAj+Yu4EQ8Bn2XRVwPDHHXO6aK+1NbEdv4rw34D1xI+EDO1Ewhv68voNUAMa+D7zG2RPuTSOYi8f/cqPZeru791vWrJBGApil0hr3NZ3s4ph2s66nq2iAsQaGVsGmEZ9hu4Cf/7r6KNx9fGrZJHXD+e7v/XyZ98l8EZ5P97V+m+PNT9retVSyYAAPtR/I15GetC3MNRx7+Kab7LUli7yrLM8O6Uc7+BNiyBC23bT9KHXDueTcAuyxBvGRXVY6oSpzze/a3rVcsmAGDb16a4QXMdx15XWOv9lgC+h/1Syv1HcB+WaJVtxTbPoNOX0GsAD2/3/8fTh1xK3yL/37dK9+Wm7m9dr1o6ARhBORbC6alcWFjr4xkGHApMJP/1emp+LKErPsb2IXzt+UT6kGvjTMKv+wxsVUaBjcn/d63SffGsE9PSCQDYFDPPIiFFlxOLa3p0Q4BDKMd84QnY4CXPFJkY+uH7fP0jfci1MALbojX0uv9f+pBLqw34N/n/plUWLW8Cy3Z/63rV8gkAwAbAq+S/mV2VrxXY7qL0B/YBHiX/9ZuEjVcYVWSDe3EWvjZskj7kyjsM3zX/aPqQS+19lGPwr8q7yxE93bQGKAGYbwNs0F7uG7pwSbUKYBH6Ap/GNxArVpmCJQKLFdngbqzXZKwLl5+nD7nS+mKvgkKv98to9H9X9sQW58r9t6xi5eKeb1dDlAAsYEVs18DcN3bBsm2hLU6jDdgF21Ut9/WcBpyCLW2akqcLdRb12B8hlV3xfUbOSB9yZWyKLXyW+++41ctlxBnwXLoEIPd0riHA6dg8/tyxgPVM3J87iIi2AY4h/xz3mdgyw6eSZq2F/bFtj0OdRTVfB6XWhk2dDX1t0oFt4fpItIjqpw27vtti+3XkfL1WZm3Yq6TY45Aux1b/a49Q1wqEP8hfwLfNfaltCzxD/kxvTNENzWRzbIOkeeS9vrOBS7ApY0UagQ3Y8cS5esEx1sFn8X0ePFOqRDq14R/701W5krhTg0vXA1AmA7Bfbq+Q7wE1uvBW5rUultF61kqIUdqxNRc2LrCt3i+E3xcYWx0MxrfwUgfwseRRS91U5eEPSgAaMhLrtp5E+gdT/wTtK4M1sF/inh30YpR5WM/EZgW0cUyE9mmXwO59B9+1fQotvCQ+VXr4gxKApgzF3sO+QJqH0dtpmlUqY7ClR98mbyLQAdyCjVmI6TJnTPehh1RXlsP3iqUD+EryqKVOqvbwByUAQQZg89wfo9gH0KRUDSqhMu03cC92v2OMul0T/9aqnpW/6qgN2yXSc01fAgalDlxqo4oPf1AC4NIPG3RU1HLCT6VrSmkthiUCU8ifCDyAzYVu5g9yNLYOwNbY9LT98A8unY0WB1rQV/HfW++CKtK6qvrwByUAUfTBNg6JPT/2vpSNKLnhwDcpx2JNjwNfwHqCOo3GXhd8A/gFtp7EawXG8OT8a9Lq1sX/uuh58i8ZLdVU5Yc/KAGIbnvgVuJ8CLQO/KIGY7/4JpA/EXgOm9t/H/5u/ZByue9SVt5g4EH81/FzqQOXWqj6wx+UABTm/cCf8H0QbkwedXX0x764ix6HUfZykPdCVlQbtkSy9/o9gAZVSvPq8PAHJQCF+zLhF/iPGeKtmj7Ap7Bf4bkfxjlKO7CH+ypWzxn4r908bGyGSDPq8vAHJQCF24PwCxxr4ZdR2AC0I7EBdftSzyUctwHuIP9DOXWZjb16ahVHE+e6XZE6cKm8Ih/+OTagUgJQsL0Iv8C/dZ57KLavQVfzo9uBG4APOs9RRh/ClnTN/WBOWaZR7CqGZfEl4iwf/TqwdOLYpfqOJ/7f7mXkew2lBKBg+xJ+gX/lOO9ywH8bPM9twI6UY/OjmN4L/Jr8+w2kKtOBnaNcuXI6lHiDLfdLG7rUwLbE/y7J+fAHJQCF+wLhFzi0i3IgNrip2fPdA+xGnAVvymQdbMT8HPI/pIsuc7FZEnXSDziXeNfomrThS014tvTuquR++IMSgMLtT/gFviTwnEc5ztmBbYW6L/Xbh2A1bAvgWeR/UBddfkT+L5cYRmGzYWJdl1ewVSZFmrEKcf8+c73zX5gSgIIdSPgFviDgfH2w+ekxPqQTsG7Xui2SshJwNvAW+R/URZZ/Uvw2x0XaAfuSiXU95mLduCLN2p14n8OyPPxBCUDhvkL4BT4/4HwbOM7XXXkRWyp1WEA8ZbY0cBI2gC73w7qo8hZwONV6rTMC+Bnx37d+O2UjpFa+RJzP4OWUq2dOCUDBPK8ALgo43ycd5+utTMa2XB0dEFeZjcbaNZn8D+yiyu3AFrEuWEH6YLNmniV++6+lWkmQlMvH8X8Gy/bwByUAhfsi4Rf4soDz7eo4X6NlOjYXdrmA+MpsKPbKI9V2zznKjZRvI6E2bPbCvRTT5geAkclaI3W0HL4eqTJ1+y9ICUDB9iP8Av8y4HzrOs7XbHkL+DH2Tr1OBgEH4N+1r6xlHnAdsBN5v5SGY8s530NxbX0N2BIbxNVTWRnrCRpN+X6lSTncTNhnsIy//DuVLgGo21z0fQj7JQ/wG5pf5rUNGwS4QuA5Q8zG1mU/CXgi4XmL1h/rkj4KeI+jninY1s4TsZ3r3sTGHYC9714cS6JWw0a9p/Qylmhehv1SLlpfbPndfYFPAEMSnDPEbGASNv7lFezePYHNkHkMGyA7L1dwksUm2Ku0ZpLmK7Akt72QiPxWIPxB/gL1XFE2qs8QnmH9LvCcRzjO6Slzsa6u9QLjLqs+2PoIjfxSfQHbDvgQYFOaGy/RhiUB+wFX0fUKjkWW57EvrC8A45qIuyd9sAWZDsPew7+RuE1FlenAX4EfAh/DkjipvwNp/FXApZT3l38n9QAUbHdsNboQfyBsZbf+2FbC7ws8r1cHFvsPgDszxVCENmy/gX2BzbA/nunYlrQ3A9fzzqZEMYyYf65DifdAbsZrwJPzyxNYL8ZbwFQsOZmB/RoaMr+Mwt61r4olMqvOL2X9lR9TO3AX8GdsF9A7ifc5kHLZEziH7pP7mdieK6dQ/s+AegAKthPhGdafHOddEvtCyv1L6Sa045rXAODr2IM39/1Uaaw8iy3GtFEX91OqbzTwTawX6AXgJSzp+z7VeiiWrgegbrYh/ALf4jz3IGx623RHDLHKHVgyVLcenpRWAx4m/71Uaa48gC3PnHp8h0hvlAAUbAvCL/C/I8WwONYlNcURS8wvw30o55SYKhiOrWWf+z6qNF9mYF3HOV7niHRFCUDBxhN+gR+JHMsw7H3yREdMscpT82MZGLmNraAN25a0VXY5rFuZi+30WeVlmqUelAAUbC3CL/ALBcU0EPsV/qQjtljlWSwRaIWBYrHtjE1Ty30PVcLKHOCnaHMiyUcJQMFWIvwCv1FwbP2xROARR4yxyiTsNYXekzZnFLZnRO77pxJe3sTW0KjbXhtSfkoACjaK8As8lzSD5vpgvybLMGtgKvZluFihLa6fHYm7c55K+vI8tpS3SCpKAArWB5sjHHqRhyaOdxtsG9ncX4ad+w0sX2xza2UkcCI22Cz3/VMJL1dQvw23pJyUACTgmb+9dIZ4wdZPv67BGIsss7C1tFcttrm1siTWizKT/PdPJay8jHoDpHhKABLwbG+6eoZ4F/RebCXD3CPOZ2OJwJrFNrdWVsXW+FciUN1yLpopI8VRApDAA4Rf5LLs4b4u9gCeS94vxHasZ2LjYptbK0sBR1Lf3Q3rXu4CxixyV0X8SpcA1HGluFuBDwQe+wnCNwUqwhrY7nifwWYR5NIB/BHbb+CfGeMItQbWxbsmNk7kBWzlx1sobpe5vthqjPsA25N+fEl3ZmFrU+TUHxuFPxhbQbNsXsF2Bv177kCkVrQXQAJXEZ5lfTlDvI0Yg81hfpv8v5BuwQYvVsHW2P4I3bXlEeCDCeIYDOwCXIRNwUx9z14ELgQ+Tjmnvy0OrI/NjjkIG5D6d/LuxzAL24hGJJbS9QDU0bmEX+RvZ4i3GcsAp1KO/Qb+hT3UytiLtCO2l3gj7ZgLfD5hbH2AdbBtgC/Edjf0zFxZuMzBdkn8GfAlbLvoMt6jRrRh43K+DPyG9Mtrt2NbTYvEULoEoKpfDD35HnBs4LFnU40/+MWwOA8m/xz+B7HpcL/GvjBz6YN18x8DbNjkse3Ah8jX5TsEWHmBMhabkjkU6yIfjQ1Oa8d+mU7DtgqegXUNPju/PAM8jfUU1VFfbJzOnsBu2AyMFG7DBndKOc3BFnh6A3t98xjwKJYIz80Y18L0CiCBgwnPsq7MEK/HcGybzJfJ3yPwOPardkChLV5UX2yMxEOO2DuwRKaOCXFd9cVeGdxA3B4UlfqU6djYpa8CS5Bf6XoA6mhPwi/yzRnijWEw9u50Avn/6J7DkrDBRTYY2+FwP+CJiLFvWXDMUozVgPOw3pHcn3+VcpZZwNXA5uSjBCCBDxF+kR/KEG9MrbDfQB9gd6yLL3bMZR8DIj1bEdsCeA75P/8q5S03k2dqsxKABNYg/CJPzRBvEfqZqkKrAAAgAElEQVQAn8LegeX+Y3sNG5exeIR2bQncU2CsP4sQo+S3Jtb1m/uzr1Le0g78BFvSOxUlAAkMxffBSPmBKFobNhe9LPsN/AhYNqAdywO/pPgVEs8OiE3Ka3fgVfJ/9lXKW54DNiUNJQCJvE74hV4vQ7wplG2/gdUaiLkNe6WRavrXAQ3EJNWyDPB78n/uVcpbZgJfpHhKABJ5kPALvVOGeFPaFLiW/PsNzMHWzu9uv4Ex2Lu6VPHMxabgST3ti00Vy/2wUSlnmYetulokJQCJ/InwC31ghnhzWA/4FeXYb+A32EZInXbD14sTUn4eeiGlMtanHDNlVMpbjqM4SgASuZDwC31ShnhzWh24GNsBMOcf3jxs4NYlGc79HHEGKUr5LQX8g/wPGpXylqJeBygBSOQYwi/0LzPEWwYrYYPg3iL/H2DK8jiwSoTrJ9UxkHKMh1EpZ5mDTSePTQlAInsRfqFvzxBvmSwNnIwtN5v7D7HIMg04geIXLJJyGoAtDJP7c6hSzjKR+L2CSgAS2ZTwCz0pQ7xlNALb134y+f8YY5Zp2Gue3HsoSH4DsKWEc38mVcpZriIuJQCJLIXvxuvh8I6hwKHYZhS5/yA95VWKWZlQqm0Q6glQ6b5sRzxKABLybJm7WYZ4y24ANif/cfL/UTZTXsZ6MobEvyRSI7sDd5B/eqxKucqD2L4jMZQuAajz7mf3E76oz+eAS+OFUiv9sTEWRwHvyRxLT57BxjJcii0+JNKIJbFBocNzByING4ytMLoCsD22zn/MZ9unsSnTXtoOOKGrCM+2TswQb9X0wbZj/Tf5s/QFy6vYL/6BxTVdREpseeAs4u0OeWekuErXA1BnJxB+sa/OEG+VbUnaVfu6KtOxwX0jCm6riFTDasC9xPl+2SRCPEoAEvoM4Rf74Qzx1kGu/Qauw/64REQWNIw430k/ihCLEoCExhN+sWcRb+BHK9oA2/CnnWIf/C9jAxNFRLozEOvG93zXPB0hDiUACQ3FN6J3nfQh1866FLsv+/vTNUVEKmxF/LuKjnPGULoEoE8RlZbEDGzkZKgNYgXSwh4BRhZY//EF1i0i9fE8cKqzjvfFCKRM6pwAADzkOHb9aFG0rpOAzQusf2ts50ARkd78BOsFCLVxrEDKou4JwAOOY9UD4PMR4PAE5zkdLfIjIr17E7jecfzKsQIpi7onAPc7jn1v7/9EurECNggwxUJTKwLfSHAeEam+Gx3HaiGeilkL36APTS0L8weKG/jXVXkLGJuiYSJSaRsQ/j3znPPcGgSY2GPA247j9RqgeZ8BPpr4nIOxZX9FRHryuuPY2k0Nr3sC0A7813G8EoDmLIa9k89hD2CrTOcWkWqY7ThWCUAF3ec4Nsbyj63kR9hWzLn8hBr+kYpINGMdx86IFURZtEIC8B/HsZtR7x0TY/oAsF/mGNYG9s8cg4iU1xqOYydFi0KS2RDfALPV04dcOX2Js+lGjKWDJwOLF9tcEamoawj/brnGeW4NAszgQXwDATeLFUiNfZE44yUOBf7lrGNx4HsRYhGRelkSW58klDaJq6g7CM+8zssQb5WMAF7C/8v9D9jrlvH4ewLmopUcReTdzsP3vbK78/yl6wFoFWcRfuE9iwm1gtPwP/yf593d9hdHqPOvxTRXRCpoM/w/LLwLASkByOQz+H5NjkgfciWsim2d7H1Y77JQvUsBb0Sod4/oLRaRqlkFfy9ljB+CSgAyGYvv5m+TPOJqiLHV72+7qfvrEep+HtsWWkRa05rAE/i/S34QIRYlABk9T/jF/36GeMvuI/j/qKbR/XLLA4BHI5zjuFgNFpHKaAP2Aabj/w6ZR5zZYEoAMrqS8It/R4Z4y6w/cR7OX+/lPNtGOIf2CRBpHQOBXYF78H93dJabI8VWugSglVZNux3YM/DYjYHhWDYpcDC+BTUAngLO7uXf3IjNDtjJcZ7BwKn4R/BKXMtjm3WNyh2IVFobsDSwDLAO8GHiv/Y7NXJ9koFnF6gO0m9wU1ZLYhtqeLPqnRs83zhgZoTzbRfcYonpw1gyPo94v9BUVIoqfyee0vUAtJK++EaWn5Y+5FI6H/8f1U1NnvOkCOd8GHt1IXm0Yb+kcn+hq6g0WtqB9xGPEoDMfk/4Dbg3Q7xlsz42LdLzRzUH66prxjBgovO8HcBXm26xxPI98n+hq6g0U84kLiUAmR1K+A1oB5ZIH3Kp/BX/H9WPA8+9d4RzT0FrOuQwHn/iqKKSsjxK/LEESgAyWwffh6KVB5Lthv+PajKwWOD52/At6dxZDg88v4T7Jfm/0FVUGi3TsPUDYlMCkFkb8DLhN+GS9CGXwiDgGfx/WAc649gI/3KetzhjkOa0EWdVRxWVFGUOjQ9QbpYSgBLw/Bp5mdbYQXFhx+D/w3qAONNOL3TGMTFCDNK4lcj/pa6i0kiZC3ya4igBKIEv4PuQxBgVugzwXeCf2BrVL83/v4/F5rSWyfLEWU0r1jS8pfBNQ3wlUhzSmDHk/2JXUemtvE34OjGNUgJQAivgm4Ps3Wv+QODNHuqfDhzgPEdMl+P/4/pd5Ji+6YjlkcixSM9Gkf/LXUWlpzIJ2ILiKQEoifsJvxH3OM57fBPnOc5xnlg2xb9gyyxgtchx7eeI58+RY5HeTSP/l7yKSlflL8BypFG6BKAV32cD/Mlx7AZ0v4FNT3bAuvgb9R1g+4DzxNIGnDX/Pz1Ow3bjismzL7cy6fReyB2AyEKmAAdh37EvZo4lGyUAzWsDdgw45mSae5i2Aac0eZ6Y9gE2cdbxCraKX2whCVgnJQDp6ZpLWczAFvhZHTgH+3Xdslo1AbgDmOo4vtlpItsA6wWcZz1g3YDjvIYBP4xQz5FY929s6gGoFl1zye1ZbOD1WOAw4LWs0ZREK+0GuKA52Hr0nww8fltgJI0nEQcFngfsPfyDjuNDHI3/vdjdwBURYumKEoBq0TWX1Nqx5dtvBa7GZlm19K/9rrRqAgBwLeEJwEBgFxp7wI3Bt51t6uWHV8EyZI8O4GvYAMIi6BVAtXjGALwK/C1SHFJPr2Nd+9OBJ7ExR/+lmN5HqYlRwGzCR2Ve2+B5TnScowPY39XK5l3tjLeD4n75g72e8MQ2rMDYpGvbEX6/HsoQr0gRSjcLoNXdTPgNmYm9BujJQGwgnOeBNT5GQxu0tTPWDiwTX6nAGNd0xKb3fnl47tkbGeIVKULpEoBWHQTY6RrHsZ2vAXqyB7ZyXahn8a070Iy+xNn+8kTguQj1dEfv/6vH8wpgJDA8ViAi8o5WTwA6u7tD9bY7oHf/+fPxxdeMLxM2U2FBzwOnR4ilJ0oAqmc6vl/ynjEfItKNVk8AJuL7hb0d3b8G2AjfPPpZwEWO45sxGlul0Otw4K0I9fRECUA1ea69EgCRArR6AgDwG8exA4Fdu/n/eab+gcU1yVlHo47DP9vgduC3/lB6pRkA1eS59stHi0JE/kcJAFyJr5t9ny7+t8Xx7yz1E+fxjVoT/+ZD7djrjhSvKzwJgJakzcdz7T29PiLSDSUANmDt347jtwZWXuh/+yIwyFHnvcCdjuObcTrQ31nHhcB9EWJphGeGgRKAfNQDIFIySgDM/zmObQM+s8B/74MNqPNI9et/J2yTIo+p2MZFKSyGLawUqmU3/SgBT/KlMQAiUpjlsG7s0DmaT/DORj87O+rpnKs+pMC2dhoAPOaMtQP/qoHNONsZq6aT5bMt4fctVe+SSJFKtw5AXSwN7I1t9vAd4LPAkk3W8Xd8D5ct5tfzJ2c9pzYZd6hvOOPsTHwGJIp3LXwrN3o2fxK/tQm/d5MzxCsSmxKAyJYFLgPmsugFaweuw7q4G3nVsX8XdTRTLgBWw9eT0I6txV+0pbB52d4EoNltkT1ucMb634SxyqJGEX7v5gGD04csEpUSgIg2wObxN3LxnsDmqI/uob5RwNsN1tdVeQM413F8B/AHx/Voxs+ccXYAf0kUK8DHIsR7Y8J4pWtvEn7/Vs0Qr0hMSgAiWQYbVNTsRZyBPfw26KbeXwXUuWCZ5zz+I66r0pj30nWPSTNlDtalm0KssQqXJopXuvc44fdvq/ThikSlBCCSGL9g78K6/RecrvfRCPWGlidJMyvj1gixnpYgzk5HRoi3A/hBwpila38l/P7tnSFekZiUAETg3cZ34fIScAI217jf/P+eIwE4IuZF6saeEeKchN2DFJYmzliFDuDARDFL935B+P07KkO8IjGVLgGo4joAH8a/cM2ClgG+DUzAXgE8FrHuRr0FXFzwOQYDJ0Wo51jSbdF6Ir1vudyoiZHqkXCee6C1AEQi65c7gABjC6q3H/DJguruzZXA6wWf45v4FtEBuB9b9S+F9wL7RqxPCUB+noWYlACIRFbFHoB5uQMowLkF178CNu/f62vYVMWitQFnEffzqVUA8/MkYctFi0JEgGomAE/nDiCyO4C7Cz7HKcBQZx2/Af7mD6UhnwbeH7G+duCViPVJGCUAIuIyHN98/bKVveJenkVshn964tsU9+plYYOx8Rgxr7E2ASqHsYTfwzlA3+QRi8RTukGAVXUW+R/cMcokYGDka7OgPthOh944TygwxoUdHyHehUuqnRWlZwPwJaPLpg9ZJBolAJGMxlb3y/0AL/uD9fMRYnwBGFZwnJ1WwLdaXHfl6kTxS+8mEX4fx2eIVySW0iUAVRwDADZifkcsCaiqudj+AUUZDnw/Qj1HYQ/lFH6Ef6xCVzQDoDw892L5aFGISGUTALCH/ybYqnQzM8cS4lqK7db5Nv4u039hi7eksDmwR0F1KwEoD89sDL0CEImoygkA2II0X8e+GL4GPJM3nKb8pMC6xwGHOuvomF9Hhz+cXvXBxnW0FVS/EoDy0EwAkZKoegLQ6Q3sAbIqsC02ZS3FfPVQj1DslLrT8Q8uvBwbQJjC54GNCqxfCUB5eHoAlACISENWxZa+nUz+wX4LlyLXpf9QhPimk+7Ldjj2UCjyeq+RqC3Suy8Rfh//mCFekVhKNwiwFQwC9gHuJf+DvwOYBowoqK19gQcixPitguLryqkR4u2tDE/WGunNjoTfx/syxCsSixKAzMYD55N3IaGzC2zfwRHie4p3b5FcpHHYAM4ir/fURG2RxmxA+L2clCFekViUAJTE0tg+88+SPgFYp6A2jSbO646PFxRfV66LEG9v5ZFkrZFGLEn4vZxHsQtniRRJCUDJ9AV2Bm7Ev1xuI+XmAtvykwjx3VJgfAv7cIR4Gyk3pWqQNKQNX6/PmPQhi0ShBKDE1sAGDb5OcQ+jTxQU+1rAbGdsc4H1CopvYf2AB53xNlouS9QmadwzhN/PzTLEKxKDEoAKGA7sT/wH1ESgf0Ex3xAhvp8WFFtXOtcXSFF+mKhN0rjbCb+fn8wQr0gMSgAqpA3YBvgd9uvY+yA6rKA4d40Q22vAEgXFt7DFSDs186A0zZIm/Jrw+3lwhnhFYlACUFErYb8kXyHs5j1IMYOXBgCPB8a0YDmkgNi6c06EeJspu6ZpljThTMLv54kZ4hWJQQlAxQ0EPoutkd/ojXsOWKWgeI5sIo7uyn8p7tXEwtbC9nVPmQBsnKRl0oxvEH4/NaZDqkoJQI2MBy4G3qL7m/Y7bMphEZbB5rh7H5A7FBRfV26KEG+zZYUkLZNm7EX4/bwxQ7wiMSgBqKHFgM8Bl2CD8a4GjscWPCnSxfgfjtcWHOOCPhEh3mZLOzbjQMplK8Lv6cPpwxWJQgmARLEh9nDzPBxnAasnijfWWIVmy8spGidNW43we/p6hnhFYihdAlCX3QBbSRs2iMp7787CHsopHIF96aemBKCcPLszjgKGxgpERKRKPO9PO8srwMhE8S5NnLEKIeVPCdonYTwLbq2cIV4RL/UAiMtg4ixscwzpNsk5meJ2P+yNegDK60XHsW3RohBpYUoAquUo/Guh34sNWExhPLB3onN1RQlAeT0aeFw7uq8iUSgBqI6VsPnTHh3YMrzt/nB61YZtfZzzM6YHRXn9I/C4u7CptyIiLeP/8L8TvzJhvJ+NEO/LWI9F6PF7FN5KCbUE8CbN39N9cwQrEkHpxgBINWyOf7vit0i3leoQ4FlnvB3Y+gqPOo7/QNENFZdmN4X6B+q1lOpSAiBN6wP8B//D9LiEMZ8QId57sLa/4agjx9RDac5PaexePkxxq2qKpKAEQJr2JfwP0+dJN3d6RWCGM955wPuBQc56hhfcVoljf+BVur6Hc4ELSTdtVaQoSgCkKcOBl/AnAJ9OGPNvIsT7i/l1jXHU8WahrZTYhgF7Yj0CV2Gb/hyGDX4VqQMlANKUH+F/mN5BunnTWxB3rML7HPU8UWRDRUSapARAGjYOmInvYdpOuu1w+2BTtLwJy3cXqHMXRz2h08xERIpQugRAI2rL60xgoLOOS7EBhCl8CVv4x+MFrNejk2fQ10vOWERERJLbBv8v6WnAsoniHUGcsQqfWqjeYx11/biIhoqIBFIPgPSqH3BGhHq+T7pfwccByzjruAP49UL/m6cHQKsAiohIpTS7OEpX5Un8rw8atSowyxlvO7BRF3V7ZhR8LnZDRUQcStcDIOWyGDAZfwKwS8KYr48Q78+6qfsfjjp3jNpKEREfJQDSo3PwP0xvThjvthHi7WmswuOOelPNfhARaYQSAOnW2sAcfA/TucC6ieLtBzzkjLcD+HoP55jqqHdMrIaKiESgBEC69Rf8D9OUI98PixBvT2MVBjvrHhKxrSIiXkoApEufwP8wfQ1YPFG8iwFTIsS8Uw/nWNlR7/RYDRURiUQJgCxiEPAU/ofpVxPGfF6EeP/cyzk8ywA/E6WVIiLxKAGQRRyN/2H6MNA/UbzrY2MNPPHOAdbp5Tw7Oer/V4yGSlYDsM/IeGCpzLGIxKAEQN5laXwD3TrL9glj/muEeM9s4Dz7Oeq/zttIyWZL4FoWHRD7MNbLlSrRFYlNCYC8y2X4H6a/SxjvbhHinUJjYxW+4TjHRd6GSnJtwOn0vpvkXWiLYKkmJQDyP+OxFfA8D9NZwGqJ4h0EPO2MtwM4oMHzneQ4x0mehkoWZ9H4/X2CdANeRWJRAiCA/drxrHLXWU5MGPO3I8T7MLZ+QCMucpznCE9DJbnt6P2X/8LliiyRioRTAiAA7I3/YfoytgtfCstjU+u8MW/XxDl/7zjP3qENlSxupfl73A6MzRCrSCglAMIQ4Fn8D9OUm91cESHe3zZ5ztsd50o5KFJ8Fqf5X/+d5bAM8YqEUgIgfB//w/Ru0m3lvCnhX9CdJWSsgmcfgA1DGipZbEX4fb40ebQi4ZQAtLgVgRn4HqbzgPcnircNm1PvTVh+GHDu1xznWyHgfJLH9oTf5xsyxCsSaknCP+tPZohXIvPsb99Zfp4w3n0jxBsyVqEfvl6HQQFtlTw+QPh9vjNDvCKh+mC9oSGf9VszxCsRbYm/K/0t0s2BHgZMdMbbgSURzVracb6pAeeTfNYh/F4/kSFeEY+bCPusH58jWImjL3Av/ofpdxLG/IMI8f6bsLEKazvOqa6yalme8Hs9JUO8Ih6fpvnP+Wxg1RzBShxfwf8wfY50W9yuDLztjHce1usRYivHebUPQLV4tn1uJ91gWJEY+gC30dzn/NQskUoUI7D34N4EYI+EMf82QryehVo8Sw7/yXFeycOTbI7OEK+IxzLAYzT2+b6OxhdPkxI6Hf/D9DZsRH4KW0eIdwa+sQoHOM79S8d5JY8XCb/f4zLEK+I1Gvuu6m5c2FvYe/++uQIUvzWw9zeeh2k76ea19wXud8bbgS0b7OHZIvkc57klvYcIv98bZ4hXJJa1ge9im7rdDFwJHAIsm+Lk6loo1hn4ty+9CLgnQiyN+DKwnrOO57FeDw9Pt+5rznNLep57plcAUmUPzy9ZaABNcT4KfMRZx3TSjfwfTZypJodj3VceIx3Hvu48t6TnuWeLRYtCpMUoAShGf+C0CPUcjw0gTOG7wBLOOm6n+TX/uzLKcawSgOrx9AAoARAJpASgGAdj7/89ngR+EiGWRqwJHOisYx5wKPZe1ksJQGtRD4BIBkoA4lsSODZCPV/Dlo1M4XT8YxV+hm1SFINeAbQWzz3TGAARKY3z8Y+ivzFhvDtHiHcqNrc1lkbnyHZV1o8Yh6RxEOH3++IM8YqILGIDYC6+h+kcbH30FAbge9h2ltj7sr/iiCXVXgkSz16E3+9rMsQrIrKIW/A/TM9MGO8REeJ9FEskYvKsDNfszoOS3w6E3++/Z4hXRORdtsX/MJ0CLJ4o3qWANyLEvGPkuDxrw88h3YqJEs/7CL/nD2WIV0TkXf6F/2F6QMJ4L4gQ7x8LiGsZRzyvFhCPFG81wu/5xAzxioj8z5b4H6YPkW5lxlhjFdYuILb3OGJ6vIB4pHhLEH7Pp2aIV0Tkfy7DnwBsmzDev0WIN8ZCR13Z1BHTnQXFJMXqR/ebojSSiIqIZDEU2/3O8zCNsXpeo/ZwxtoBTMK3WE9PtnfElXL6pMT1FuH33buGhUhL0kJAflsDQxzHzwS+ESmW3gwGTolQz7HYAMIieEbxz4gWhaTmuXeDo0Uh0kKUAPjt4Dz+dODpGIE04JvAGGcd9wMXRoilO4Mcx74ZLQpJzZMAeBJwkZalBMBvc8ex04jzi7wRKxCnp+FrQHuEeroz0HGsegCqSwmASGJKAHz6YqPWQ11AulHMJ2PjFTx+gw0gLJISgNbk6b3RKwCRAEoAfMbh+/K5NFIcvdkc+LSzjpnAkRFi6Y0SgNakHgCRxJQA+CzrOPZ14JFYgfSgD3AG/hXyfgQ84w+nV54xAEoAqsvTA6AEQCSAEgAfz1ak92Jzn4u2D7CJs46J2CuEFDz7CsyMFoWk5tn6Wq8ARAIoAfAZ5jg2xa/V4cAPI9TzLdKNsPe8ApgbLQpJzbOgj3oARAIoAfDx/GpJ8bA6Bt9rCrA9Dn4eIZZGeRIArQpXXUoARBJTAuDjSQC88/F7Mw6bsufRMb+ODn84DfOMAVAPQHV57p1eAYgEUALg49l9bm2KXcL0NHy/pgEuJ/36+uoBaE2zHcduHC0KkRaiBMDHs4LfQGCLWIEsZBvgY8463gSOjhBLszQGoDV5krd9gOViBSLSKpQA+EwCpjuO/1KsQBbQD5v253Ui8GKEeprlma6oz3N1TXYcOxA4PFYgIiKNupHwXcxmYu/qYzrCEU9neRrfu3iPKxqMsauyX/pwJZK98H1m3wQWTx61SIXpF5Pf7Y5jB2Ib63gX6em0DvD9CPUcQb459Z61EfpFi0JS+wO+z9xQ4JBIsYiINGRL/L+4j4sQxwrAExFiuSVCLB4XEx77ARnilXgux/fZfQ1b+0JEJIk+wPP4H7zHOmJYFVum1xvDXGA9RxwxXEh4/PoFWG1rYjtNej7D30wetYi0tNPwP3w7gGuAZZo4bx/gq9i2wjHOf07zTY/uAsLj10Cw6rsa32f4ZbQugIgktBr+Xy6dZQq2fO/KPZxvGPBl4IFI5+zAuk+X8F2GKM4jvA0pdiuUYr0XGwfi+SwfmDxqEWlpvyXew7gDSygeBn4FnAScir0fvxtbNCXmuTqAQ+NfkiDnEN6GYzLEK/H9Gd9n+Tl8m0qJiDRlQ+L1AqQu/6XYVQmbcTbh7TgufbhSgK3wf6b3TR20SNVoGmA89wAX5Q4iwDzsdUJZltH1LAnbN1oUktPf8E2vBTgKfb+J9Eh/IHEdg29FsxxOB/6RO4gFeDZYUrdvfZzoPP49wMdjBCIi0qid8Q9iStn1n2vFv+58l/D2nJYhXinO3fg+3/cSb5EtkdpRD0B81wFn5g6iAVOwX0i5VvzrjqcHQCsB1sspzuM3ALaPEYiISKP6AleR/xd+d+VtbAXDMjqc8Hb9NEO8Upy+wGP4Puu3Jo9apCLUA1CMdmBv4O+5A+nCXCy223IH0g1Pj4TGANRLO/5egA9Q3mRXRGpsIPHXB/CU6cBHC22x3xcJb9/FGeKVYvUHJuD73F+fOmgREbD30ueS/+H/ArB+wW2NYW/C2/jzDPFK8Q7B//kfnzxqEZH5PgVMJc/D/7fA0sU3MYrdCG/n7zLEK8UbBLyE72/g18mjFhFZwEqkHRz4KrBnkpbFsz3h7b0pQ7ySxtH4/hbagbWSRy0ispBtsZXOinrwTwG+A4xK1aCINie83f/KEK+kMQJ4Hd/fhcaIiEhpbI51z8fa3OchbD/04SkbEdm6hLf/4QzxSjo/wPf3MRsYkzxqEZEejAL2wt5TNvOu801sOt/3gHWSR12MsYR/wT+XPlxJaHFsJosnCTg7edQiJaVlMstpaWA9YGVgNDASW7NhGtYNOhlbxvdR7N1mnSyBjV0I8QZ2vaS+zsS3dfVMYBUs0RYRkRIZSPivu7LsaCjFWQFbLtrTC+DdaEhERAri+YIv2+ZGEt+F+BKAqainSESklKYQ/uW+ZIZ4Ja1xWG+PJwn4dvKoRUSkVxMI/2JfJX24ksGV+BKAycCw5FGLlIg2A5IyetNxbJWnQErjTsQe5KEWB74UKRaRStL+6VJG0x3HtkoCMAZbR2ID7H32KOzd9kTgEeBm7FduXT2AbfKzk6OOI4BzsDEnIiJSAn8hvGv3IxniTWUk8FXgPnq/Du3YGhF7UN9EfzN8rwE6UC+AiEipeLZQ3j1DvEXrA3wBmETYNXkc2Dp51Gncgi8BeBLomzxqERHp0qWEf6F/Pn24hRoN3Ij/l+484Czq97DbFv+12St51CIi0qWzCf8y96wSVzZjgcfwP+AWLFdTv7US/o3vmjyAVkWVFqRZAFJGnkGAI6NFkddI4Dpg9cj1fhybQlenB553Zb91gZ1jBCIiIj5HEv5r7qwM8cbWhm8gZCPlqGStKV4bthOm53poK2kRkRL4IuFf5D/PEG9sn6PYh38HNktgi1QNSmBv/NfkQ8mjFhGRd9mV8C/xP2eIN6ah2G6IRScAHcZh9zEAABqNSURBVNiOknUZD9APeArf9bgpedQiIvIuWxL+JX53hnhj+gppHv6d5dQ0zUoixrXbPHnUIiLyP+8h/Av82QzxxnQ3aROAudTnVcBAbCVEz/X4ffKoRUTkf5Yg/Av8rQzxxrIkNl8/ZQLQgXWd12VjnK/juxbzsFkBIiKSQR/sl2nol/iQ9CFH8QnSP/w7Sx1mT4AlMpPxXYtfJI9aRET+xzMQbqUM8cZwFPkSgHZgq8JbmMZ38V2LucBqyaMWSUwLAUlZeXayWyJaFGktnvHcfYBLqMduimfjW0yqL/YqQaTWlABIWbViAuBZxfDxCOcfC5wcoZ7cXgPOc9axL7B8hFhESksJgJRVKyYAnuV5zwDuihDDV4DtI9ST22nA247jBwKHR4pFpJSUAEhZTXEcW9UEwGMu9qt1prOeNuAiYJQ7orxewXaV9PgyNjNDpJaUAEhZeXoAcr5Lz+m/wAkR6lkeOCVCPbmdBMxxHD8UODhSLCKlowRAyko9AGFOAe6MUM+XgI9EqCen57CdDz0OoT47TIq8ixIAKatWHAMQw1xgP3zvvztdCIyOUE9OJ2KL+4QaiY2LEKkdJQBSVq86jm3197aPYnPhvZYDTo9QT06PAtc46zgMGBwhFpFSUQIgZeV5BbBMtCiq6zTgHxHq2Q/4eIR6cvo+tsBPqKWBz0eKRUREerEK4Su5vZEh3hh+Rnibv9hFfatgC+J4Vwl8EVgscltT+zO+a/AcMCB51CIFUg+AlNWLhP9qG0l9NrfxeBo4NkI9y2Kr61XZD53HrwjsFSMQERHp3RTCf7GtniFer9g9AGBJ/t8c9S5YdovX1Cz+ga/9j6IfTVIj+jBLmU10HLtctCiqbR7wOXxr43c6F1gqQj25nOQ8fg1sx0aRWlACIGX2ouNYJQDveAb4VoR6lgDOj1BPLtcD9zjrOAbfks0ipaEEQMrM0wOgjVze7RxsIJzXrsCnItSTi3ezow2ox14JIkoApNTUAxBPB7a2/bQIdf2U6k61vAp4zFnHd2IEIpKbEgApMyUAcT1LnH3uF6e6rwLm4d/nYDPg/RFiEclKCYCUmScB0CuArv0M+FOEenYBPhuhnhyuwJIhjxhjKkSyUgIgZaZZAMX4IvB6hHrOBlaIUE9qc/AvcfwRYHyEWESyUQIgZeZ9BaDR2l17ETg8Qj2jgPMi1JPDBcBLzjqOjBGIiIgsqi+2u13owi1V2xWwiIWAenK143wLls8FnLsMvoWv3e3A2smjFhFpERMJ/4JeL0O8HqkTgGXxrbbYWd4AVgo4f24jsFchnrZfkjxqkUj0CkDKTmsBFOcl4JAI9YwELqZ6r1ymYVMaPT4DjPWHIpKeEgApO00FLNYvgN9GqOfDwJci1JPaGcCbjuP7A0dEikUkKSUAUnaeBGDFaFHU2wHApAj1nA6Mi1BPSlOAi5x1fBF7nSJSKUoApOw8rwBWjhZFvb2KrRLoNRQbx1C1VwE/AmY7jh8EHBopFpFklABI2XkWbBkTLYr6uwb4dYR6tgYOjFBPSi8AlzvrOBAYHSEWkWSUAEjZTXAcOzZSDK3iIODlCPWcAqwWoZ6UTsKmnIYaDnw1UiwiSSgBkLKb4Dh2BWyQljRmMnFeBQwBLsXWcaiKp7CNgjwOBYZFiEUkCSUAUnYvArMCj+1LNZeqzelabGaA1+bAwRHqSelEbG5/qMWp5kwIEZHSeoLwhVq2zhBvqNQLAXVnFPC8I5bO8jawVsS4UrgWX5tfxAYFipSeegCkCjwDAcfGCqKFvAF8JUI9g7ApdlV6FfAD5/HLAvvECESkaEoApAomOI7VTIAw12Pv8b02Jc7GQ6ncCfzVWceRQL8IsYgUSgmAVIF6APL4GvBchHpOANaJUE8qJzqPXwXYI0YgIkVSAiBVMMFx7NhIMbSiqcAX8A2MAxgIXEZ1ZmTcCPzTWccx6PtVSk4fUKmCCY5jx0aKoVXdBFwYoZ4NgW9EqCeVU5zHrwXsFCMQEZFWtiLho7LnUp33sWWZBbCwocCTjtg6yyyqs0VzG/AgvvbemTxqkSaoB0CqYCLha7VrLQC/GcD++F8FDKA6rwI6gJOddWyC7ZIoUkpKAKQK5mHz0kONjRRHK7sFODdCPRsAR0eoJ4UrsZ4Pj2/FCESkCEoApComOI5dJVYQLe6b+B+IAN8GNopQT9HasZ0CPT6MrYooUjpKAKQqJjiOrdrGNGU1A9gP65Hx6Ie9CqjCinmX4tuSGmxdAJHSUQIgVfG041glAPHcDpwdoZ61sJ6AspsFnOGsY2dg3QixiIi0pD0IH419X4Z4Q5R1FsDChgCPOWLtLHOwgXJlNxR4FV9bY2ywJBKVegCkKh53HLsqNq1L4ngLexXQ7qynKq8CZgA/cdbxKdQTJSWjBECqonMeeoih2CYtEs8/8XeNA7wHOD5CPUU7E1sZMVRf4OuRYhERaTkvEt4F+8EM8TarKq8AOg0EHgqMd8HSDmyZOPYQJ+Nr52xgpeRRi3RDPQBSJU84jlX3a3yzsK1v5zjr6YMtNzzYHVGxTgfedhzfH9tgSaQUlABIlSgBKJ978M+VB1gD+EGEeor0CnCJs44vA0tGiEXETQmAVIkSgHI6Dls33+tQyv+q5mR8PR5DgIMjxSLiogRAqkQJQDnNJt6rgEuAYe6IivMctkSwxyHAyAixiLgoAZAq8SQA49DnvUj3ASdGqGflSPUU6UR8qyGOBL4SKRYRkZYwGBsxHjoKe8X0ITelarMAFtYPuAv/rIB5wHaJY2/WVfja+ArlH/QoNadfRFIlb2NTAUPpNUCx5mKvAmY662kDzgeGuyMqzvcJX5cCYCngC5FiEQmiBECqxvMaYPVoUUh3/kuc0fxjgVMj1FOU+4C/OOv4JjAgQiwiQZQASNV4EoD3RItCenIS8J8I9ewP7BChnqL80Hn8isBeMQIRCaEEQKrGkwCsFS0K6clcYF/ivAq4EBjtjqgYfwduc9ZxFPoelkz0wZOqedRx7JrRopDePIKtD+C1PHEWGiqKd8bCGsAnYwQiIlJ34/CNLi/z/OuqzwJYWB/gH/hnBXQAuyaOvRnemQ/3od0qJQP1AEjVPEP4euxt2C8uSWMelph41s/vdA6wWIR6inCK8/j1KfdYB6kpJQBSNfOAxx3HaxxAWo8B345Qz7LYlrxldBU2+8Hj2BiBiDRDCYBU0SOOYzUOIL0zsQFzXntTzvfl8/CPU9gMeH+EWEQapgRAqkgJQLXMA/YD3oxQ17nYIjpl83PgWWcdR8cIRKRRSgCkijzdrXoFkMczxHnALQmcFaGe2OYApznr2AHYKEIsIiK1tTbhI67bKe8a7HWbBbCwNuDPxJkVsHvi2BsxCFuq2tOu3ySPWlqWegCkip7AFpsJ0QctCZxLB/BlYHqEus4Blo5QT0wzgR876/gEluCKFE4JgFTRbOApx/F6DZDPBGwNfK8lsA2DyuYc4HXH8X2Ab0SKRaRHSgCkqjQQsLrOB26IUM/HgE9HqCemacBPnXXshW2GJFIoJQBSVZ6BgOtEi0JCdI5Z8PxS7nQOtlxwmZyJb8ZDf+DrkWIR6ZYSAKkqTw/AutGikFATidPVPQo4L0I9MU3BNjHy+AK2+JGIiCxkQ3wzAYamD7lXdZ8F0JXriTMrYJ/UgfdiBWxQoKdNJyWPWkSkAgZic69Dv1zflz7kXrViArAc9ovZmwC8AayYOPbeXICvTdMo71bIUgN6BSBVNQt40nG8XgOUw4vAYRHqGQlcRLl21TuJ8OmqAMOBgyPFIrIIJQBSZQ84jlUCUB6XA1dHqGdb4PMR6onlafwL+xwKDIsQi8gilABIlT3oOHa9aFFIDF8BJkWo53RgpQj1xPJ9bC+EUIsB+0eKReRdlABIlSkBqI9Xga9FqGcEcAnleRXwX2ygo8c3sGWGRURkvpXxDbIq2/zxVhwEuLBfE2dWwAGpA+/BJvjbo14AEZEFtAFTCf9S3SF9yD1SAmBL/L6M/4H5JrBq4th7cjO+9jwF9EsetdSaXgFIlXUADzmO12uA8pmMbRjkNRS4lPJ8x53oPH4V4FMxAhHpVJY/DpFQnnEAmglQTr8HroxQzxbAVyPUE8NNwD+ddRyDvrMlIn2YpOo8CUCZuojl3Q7GXgV4nQisFqGeGE52Hr8msHOMQERACYBUn2ctgMWiRSGxTSHOwLchwGVA3wh1eV2LL2EFODpGICKgBECq70FsLECIyTEDkeiuwxYJ8tqMOFMMvTrw9wJsAmwTIRYRkVq4n7CR1T/OEWwPNAtgUSOB5/DPCpgJrJ049q70BR7H15abk0cttaQeAKmD0AFjv4wahRRhKrY1bmgvT6eB2F4BuV8FtAOnOev4ELB5hFhERCpvBM3/Soyx9nxs6gHo3oX4ewE6gKNSB96FgcAL+Nrx++RRi4iU1ObAdBr78nyUcg4AVALQvRHAs8R5FVCG6Z+H42vHPOC9yaMWESmpTbAtgnv64vwzttpcGSkB6NmHsQefNwm4B+ifOPaFDcU2P/K0Q6+wREQWMAhbSe5G7At2DtbdeiXlW/p3YUoAencu/gSgAzg2deBd+A6+NsylPGsciIiIgxKA3g0FnsCfAMwBxieOfWEjgTfwteOC5FFLbWgWgIhUyQxgP+xVgEc/bFbAAG9ADlOB85117Aes5A9FWpESABGpmtuBn0aoZ31sff2cTgfedhzfHzgsUiwiIpKJXgE0bgj+BXU6XwVsnDj2hf0EXxtmAEsmj1oqTz0AIlJFbwH7YgvrePTD9goY5I4o3MnAbMfxQ4BDIsUiLUQJgIhU1T+BsyLUsyY2Ij+X5/Fvf3wwMCpCLCIikoFeATRvIPAQ/lcB7cCWiWNf0Hvmx+BpQxlWOZQKUQ+AiFTZLGyvAO+rgD7YcsOD3RGFeRT4nbOOw7DXASINUQIgIlV3J/CjCPWsAXwvQj2hvo/9kg+1FJYMiYhIxegVQLiBwAPEeRXwgcSxL+hP3cTVaHmOvGsbSIWoB0BE6mAWNitgjrOePsAlwDB3RGFOdB6/IvCZGIFI/eXeG1tE3rELsGHgsddhm9xUxQrAp7CH1S7ABtjDe6KjzpexX7/eX/CjsQTgBmc9IZ7FNj0a46jjPbyzZ0LZjQf2wT4L2wHjgMnYEskiIi2jFV4BjMYG282h63bcC7zfUf8A4L5u6m72VcAHHXF4fKTBGHsqeySPujnjgTvo/tpfCSybLToRqa027J1x2dQ9AVgFeIze2zIb+JzjPBvMr8P7EH2KPK8C2oC7A+JdOJFqSx14g3bFFnLqrQ3PY8s1i4i4LIYt9nIPMBP7gnkVuIrybBNc5wRgHDZArdH2zAG2dpzPu9VuZznHEYPHbk3E2F3ZMXnUvRtPYw//zjIZS+hERILsCkyh5y+a67Du6ZzqmgA0+/DvLP8lfJxSf/y/ojuwXQe3CYzBow/wSEC8C5bbkkfdu9tpvh1KAkQkyJ40vsLa3eQb/Q31TABCH/6dZTvHudfhnd4eT5kAjHDEEWq/JuPsqnwwddA92JDwdigJEJGmjAWm09wXzQU5Ap2vbgmA9+HfAZzijOFbzvN3lp854wjRH0s+PHHnmMnQnSPxtUVJgIg0LOSBOhdYNUew1CsBiPHw78C/SU4/bKVAbxzzyDNW5KDAeBcs45NH3bWz8bdFSUBEWghI6qof8MmA4/pic5Il3Djgr9iiNF7ehX3mYl3pM531tGEJWuod9y4GXnHWcXSMQCLw3kuAxYGbUBIQhRIAqatVCB/Ul2PQV13EfPgDPBGhjkeAYyPUswJwZoR6mvE2cIazjl2xLY9zezJSPUoCRKRH7yO8m3EGedZTr/orgFjd/guW0JURF9aXsBHoXZWdI8XUqBHAa86YL0scc1fG4t/yWK8DRKRXY/F9uWyaPOJqJwBjgGeI+/CPPYBtFZofFNpVeRH7FZrSCc6YZwMrJ465K78k7mfkdWCjpC0QkdLrC0wl/IvlG+lDrmwCUMQv/8nYAzu2QyPF94sCYuvJEsCbzphzLWq0oGUo5rOingAReZcbCP9SuSZDvFVMAIp4+E8Htiwo3j7A3yLF+YmCYuzO6c5438YewLmth63CqSRARArjWQ72VdKvpV61BGAM8bv93wS2KjjulYFpEWJ9FVi64FgXtPz/t3enMXcVdRzHv11ZSmXTAKWmwAsUEOICNZSIKFVDCC0xqbyASAkppY8LWlk0NnAxxY0XNgQUlAAJ4AsgskhqKEuEAIFgoGwqhBZjyiK0UnbtA72+GK429d773Hvmf+Y/c+7vk8zLzvM7J6cz/3POPTPEL2z0s4R5+6mjCNDrABH5ry8SN6Ck/uV0SQVAqZN/x5hR5tRPin4dmfct0v9+oRcVASJSmxn03nZ2kLYkcd5SCoDSJ38IT3diXhFt21KuG3EAcdd0m/BkLBcqAkSkNo9QfSBJ/elUCQVAEyb/jtmEySI2/0bSvlu/PjLvJmBmwrwTUREgIrVYRfVBZF3irLkXAE2a/DuWdMlUpd2WMPPBxH9P/72EeQehIkBEzC0ibhCZnTBrzgVAEyf/jtXYHM8pCTPfGpn1JWDHhHkHoSJAREzNIm4A+VrCrLkWAE2e/CFcI7Er7XUmm1QF41yDvEsTZR2GigARMbWe6oPHJQlz5lgAlPadf1WLsTm22xNmvisy6zrCplm50ToBImLiMOAdqg8cdyfMmlsBMIdm3/lv73fYHONpifIea5A15WuLYehJgIhE2Y2wA1nMoPHXhHlzKgBG5c5/W/sQfiEfe5ybsdsNcSIPRWZ9ivQLXg1KTwJqluPjHxELk4CrCRNZjM0GWUpjvaVvx1WESXaRcb+W/gCcHNnHroRPSH8VH2dCjxF2vqzqEGAFaQvdYVwO/BC7IqWzlfB8YK1RnyKSmeXY3DFcmTBzDk8A6rjzV1PLrelJAGFjDJGmmQf81Kivm4z6KUFdd/4iuek8CRjpIkAFgDTNHoQ9x6cZ9PUAcIdBPyXYnfA9vCZ/GRV7El75pFzrIysqAKRJJhMm/zkGfb3N/1aJGwUXAwd6hxBJbG/gUu8QXlQASJOsAL5i1NeZwF+M+srdvsCp3iFEnCwEPuEdwoMKAGmKY7Hb5ewK4DqjvkpwPPoiSEbbAu8AHlQASBPsDVwLTDHo6wnguwb9lORj3gFEnI3k/wEVAFK6qcANhO/LY70OfBV416CvkuzgHUDE2U7eATyoAJDSXQR8zqCfNmEJ19RbAOfgRe8AIs42eAfwoAJASnY8cI5RX78AbjbqqzT3eAcQcZZyz49sqACQUu1HeO9vsUTog8D3Dfop1cPAo94hRJysB+70DuFBBYCUaDJwDWHxmlgbgZOAcYO+StUGzmK0z4GMpjbwHWCLdxAPKgCkRMuAzxv0s5WwHepIvv/bzv3AGKOz8JEIhLVDfu8dwosKACnNDOBCo75WMjpL/Q7iSmApoTASaboW8GPvEJ60+IeUZhlhDe9YdwM/MuinaX5D2EfhUuz3iV9NWGK5CaYCJxJ/jtrArdi/fjkEOLjiv32KfFbBnA6cgP3N6oXY3UiISCLrid8K9AVgr9TBB5DDdsAdY4QnAZZbsN5LeILTFJdhc15aNWS7OiLPWA15qphOKI6stwJuJTwGETHyKeL/848DR6cOPqCcCgBQETCRGcBzxJ+TLYRr29IzEXkWGmepYjpwC5r8ReQDK4gfAM5LnnpwuRUAUF8RsEtNeVM7Gnif+HPyOGHSs3BUZJbDjXJUpclfRP7PDcQNALdh/17bUo4FAKgImMgqbM7JSoMsk4D7IjJswfcJjSZ/EenqSaoPAM9js25AnXItAEBFQD87E/fIvdPGCXfvMc6NzPBg5N+PoclfRHp6keqDQAnbfeZcAICKgH7mAe8Rfz42AB+tmGGM+NcRP6n4t2Np8heRvjZSfSD4sEPeYeVeAICKgH4uxuZ8PAMcMMTfnUaYuC3+9pEVjjuWJn8RmdDLVB8MTnDIO6wSCgBQEdDLjsCfsTkfm4DF9P/+fQqwCFhr9DefiDz+KjT5i8hA/kT1AeEFYD52v7SuQykFAKgI6GUu4V2+1TlZR9jyehFh2+tjgFOBXwJ/N/w7beCb9qejL03+IjKwm7AfLJrSUhcAoCKgl4vwvx6GbS8DM+s4GT1o8heRoSzHf6DMtXkUAABLsPkOftt2P2knI2vTCd/1e18Tw7SltZyJ7qYBN9dwDBckPAYRSeyT+A+UuTavAgDqeRKwhrL3Kvk04Zt67+tikPY06c71JOC3NRxDK1F+EXEyibBJifeAmWPzLACgniKg9M1aLsD/upio/Rs4oq4T0MW3ajiGVsL8IuLoLPwHzRybdwEA9kXAW8BHkh6BrSnAH/G/Nvq15XUdfBc7A68Y528lzC8iznbFfhBpQsuhAAD7IuD0tPHNzQL+gf/10a3dSNqlsRca528lzC4imTgD/8Ezt5ZLAQC2RcDlibPX4QjgTfyvkW3bGmCHOg+6i5VG2dto8hcZWZMJvxT3HkRzaotjTmgNrIqAG1MHr8mXgH/hf520CZsFeWz4c1nFvNu3VuLcIpKZWcTtDdC0dlzc6ayFRRHQhCcAHccAr+F7nVxL+jv/DosnAK3UoUUkT58FNuM/+Xq394G9Is9lXWKLgNJ/A7C9Q4HnSH+NjAM/wHc77AVdcmnyF5HKPkPcJkFNaGuiz2K9qhYBpX8F0MtMwp14qutjLWFdAm8xXwG00scVkRLsBzyA/0Ts0cZJ+x13VVWKgJZH0IS+jN3mQd3aq8A5hJX3cvENNPmLiLGpwHnAP/GflFO2b1ucvESWMfiywXdQ9kqAg5oGfB27Hf3ahFcMZ5PncsrDrgR4vk9MESnR7oQ7hr/hPznX2V4nTBylWUDY6rbXcW0FrsDvh2qe5gGrgOcZ/npYB1wCfIH+WwjnYArwc+A9eh/PG5R5fRfF8wchInWaDBxF+OX1XOBAYI8PWu4DZC+bCXd3txO2g33VN05luwFnEoqBjwM7ARuAewiT/6N+0bIxGziScN3uD3yIcN62EibHTYRC4VngYeAln5hRDiK8GpoPzCHsnfAssJrwyWCp13cx/gMj7ZIswZVe/wAAAABJRU5ErkJggg==]]
_G.NCLIENT_ESPS_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAAA3NCSVQICAjb4U/gAAAACXBIWXMAABftAAAX7QEQf4TsAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAv1QTFRF////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMtkj8AAAAP50Uk5TAAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8gISIjJCUmJygpKissLS4vMDEyMzQ1Njc4OTo7PD0+P0BBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWlxdXl9gYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXp7fH1+f4CBgoOEhYaHiImKi4yNjo+QkZKTlJWWl5iZmpucnZ6foKGio6SlpqeoqaqrrK2ur7CxsrO0tba3uLm6u7y9vr/AwcLDxMXGx8jJysvMzc7P0NHS09TV1tfY2drb3N3e3+Dh4uPk5ebn6Onq6+zt7u/w8fLz9PX29/j5+vv8/f6RiRioAAAcz0lEQVQYGe3BD5yUdb0v8M/sH/4sf1zjX7Al3Q4hN5FAgq3TRUAM5FjxoMufQJQ82HbB6qCQsGEInkxMGTluN9aUWPpDRSSQ3DWoCMn1SCYoK0PLLonaLt5dYNFdd5fZ+bzuIQ6J7MzveWbm95t5nme+7zeQMboVjJhYVFzyyMYtO57ZU/nioerX6k81h8PNp+pfqz70YuWeZ3Zs2fhISXHRxBEF3SD8InvwhPmrNu166Xgz49B8/KVdm1bNnzA4G8Kj+hfOXla2q6adSWmv2VW2bHZhfwjv6FG4YN2eRmrVuGfdgsIeEO6WNeSmlVurIzQkUr115U1DsiDcaGDR2spmpkBz5dqigRAukjWieFMtU6p2U/GILIj063HdiorTTIvTFSuu6wGRPoFrSvaFmVbhfSXXBCDSIH/mhjq6Qt2GmfkQqRQYtfzZMF0k/OzyUQGIlOg67ck6ulDdk9O6QhiWe2N5E12rqfzGXAhjcqY8cZIud/KJKTkQBmRPWt9AT2hYPykbQq/C0hP0kBOlhRDa5C86SM85uCgfQodx5S30pJbycRBJ6rv4MD3s8OK+EAkLTNrcRo9r2zwpAJGIvIXV9IXqhXkQ8RqwuoG+0bB6AEQ8hj3eSl9pfXwYhFPjd0ToO5Ed4yEcyJ61nz61f1Y2hFruHcfoY8fuyIWILfu2Wvpc7W3ZENFlzTnCDHBkThZEZ4GiKmaIqqIAxCWmHWAGOTAN4mJT9zPD7J8KccHw3cxAu4dDnNOnNMyMFC7tA5Fz50lmrJN35iDDTa5iRquajEw2ZDsz3vYhyFS917RRsG1Nb2SkGXUUf1c3A5mnYBvFP2wrQGYJFDdRXKSpOIAMcuVeikvsvRKZIreklaKT1pJcZISxL1NE9fJY+F/e2g6KGDrW5sHnRh2mUDg8Cn4WWNJGodS2JADfGrSbwtbuQfCp6Q0UDjRMhx/llVE4VJYH3xl9hMKxI6PhL4Gl7RRxaF8agI9cvpMiTjsvh2+MrKWIW+1I+MS8FooEtMyDH3QppUhQaRd4XsFzFAl7rgAeN76eIgn14+Fpi89SJOXsYnhX980USdvcHR7Vr5JCg8p+8KShNRRa1AyFB41rpNCkcRw8Z3YrhTats+ExyyIUGkWWwUtyyig0K8uBZ/SqoNCuohc8YuABCgMODIQnDD5KYcTRwfCAoccpDDk+FK53dT2FMfVXw+XGNFIY1DgGrnbtGQqjzlwLF5vSQmFYyxS41vQ2CuPapsOl5oYpUiA8F640t4MiJTrmwoWmhylSJDwdrjOljSJl2qbAZa5toUihlmvhKmPOUKTUmTFwkasbKVKs8Wq4xtB6ipSrHwqXGHycIg2OD4YrDDxKkRZHB8IFeh2gSJMDvZB2ORUUaVORg3Qro0ijMqTZMoq0Woa0mh2hSKvIbKTRuFaKNGsdh7QZ2kiRdo1DkSb9aihcoKYf0qJ7JYUrVHZHOmymcInNSIPFFK6xGCk3/iyFa5wdjxQrqKdwkfoCpFSX5yhc5bkuSKVSCpcpRQrNo3CdeUiZkS0UrtMyEilyeS2FC9VejpQI7KRwpZ0BpMJSCpdaihQY3U7hUu2jYVzeEQrXOpIH08ooXKwMhk2ncLXpMGpQA4WrNQyCQYHdFC63OwBzllC43hIYM6qNwvXaRsGQvMMUHnA4D2aspfCEtTBibAeFJ3SMhQG5L1N4xMu50K+EwjNKoN2VrRSe0XolNAvspfCQvQHoVUzhKcXQqqCJwlOaCqDTNgqP2QaNZlB4zgxo07uOwnPqekOXNRQetAaaDGmj8KC2IdBjO4UnbYcWkyk8ajI0yKmi8KiqHCTvTgrPuhNJ63OSwrNO9kGySik8rBRJGh6m8LDwcCRnN4Wn7UZSplJ43FQkYz+Fx+1HEqZReN40JCxwgMLzDgSQqCIKHyhCgrKqKHygKguJmUPhC3OQkOwjFL5wJBuJuI3CJ25DAnJrKXyiNhfxu4PCN+5A3LKPUfjGsWzEaxaFj8xCvPZT+Mh+xGk8ha+MR3x2UPjKDsRlWITCVyLDEI/HKXzmccRhQCuFz7QOgHOrKXxnNRzLa6DwnYY8OLWQwocWwqFANYUPVQfgzCQKX5oEZzZT+NJmONK3jcKX2vrCicUUPrUYThym8KnDcGAchW+Ng71yCt8qh638FgrfasmHnUUUPrYIdg5S+NhB2Cik8LVCqJVS+FoplLJPUPjaiWyoTKLwuUlQWU/hc+uhkNNA4XMNOYhtCoXvTUFsT1D43hOIKfckhe+dzEUsN1JkgBsRSzlFBihHDF2bKDJAU1dEN40iI0xDdE9SZIQnEVWgjiIj1AUQzSiKDDEK0SynyBDLEc2zFBniWUSRH6bIEOF8dDaTImPMRGcbKDLGBnQSqGMmOVv1h1/9YM09C26eOOJDeV36f2zM9UX/etfqdeXb/vA6M0BdAJe6hhnj1M6SCXmIqd/ke372lwiTc+YvlXue2b7lxxu+/+hD99/7ja//79vnzpw29bobZtz+9XsfWv+TX//hpaNvtTF9rsGlSmjUu79/+BYrafOWlh5lUo5u/PLwAOz1Gve1H77CODX95dlfPLbijmmFH+kOB7KG3LRya02E6VCCS+2jSc99DLpc9Qsm6sUvDUA8PvVrOnX42+M+0g2J6PnpL5c+e5optg+X6BGmQQ9nQ6PZDUxA248+jbiN/EUHHWiZiySN/O7fmErhHni/62jQC9nQ6oPbGK/Xv9kfCZkVoa0T1yB52VN+9A5T5zq83wqa0/Zx6FbOuPz+5hwk6m7amgM9es7b1cEUWYH3q6A5f4R2+W/QuepxSMY62vgd9Bm05E2mRAXeJ+s0zQlCvyl0KhLMQ1KytlPtduiU980zTIHTWbjYCBp0CwxYT2eOjkOyCqk2Gnr1Lw3TvBG4WDENsmDAZa10IPJoHpIWeI1KXaHbp47SuGJcbBMNsmDC07R39Fro8DCVoF/PJ2naJlyslgZZMOErtLWnB7QopBJMKGqmWbW4yECaZMGE62lnX0/oEWikCowY+xbNGoj3FNEkCyZcRRvP94YuNVSBGR+roVFFeM9ammTBhCuo9mI+tDlEFRgyIEST1uI9lTTJggmfpNLBD0Cft6gCUwb/jQZV4h+ymmmSBRM+T5WqftDng1SCMZ9oojnNWbhgCI2yYML9VHjrg9BoKpVgzqQwzRmCC26iURZMeIUKt0Knx6gEg+6jOTfhgpU0yoIBn6TCH6BTt1NUgkE5z9OYlbhgK42yoF/XQ4yt/ePQ6VaqwaQhb9OUrbigmkZZ0G8NFb4DnS77G9Vg1FdpSjX+W48IjbKg3f/qYGx/zYNOj9MGjMqtpiGRHjivkGZZ0G1IDRW+AI1y1tMOzJpBUwpx3gKaZUGvwKJmKlRAo14VtAVbfccvWLJq7Q9+9vTeP/1+6xPfLbllWADOPU9DFuC8dTTLglYf+R2VZsKhPp/9xk9/+6fqE2+/eejZ7RuD3/rqLWO74f0+dJD2oDbrtyfYyenfPjAODk2mIetw3h6aZUGf7PGPvk2ld/LgxPAHatjZ2QM/+MrYbjgvb+Yv36UDUAsyhqqv5sOJQDXN2IPzGmmWBbXHnnLqd6+eoZ3NcOCLBxjb2QM/Kpn7pTt/8g6dgVqQMbU82hMO3E0zGvF3/WmYBbUQdZoOWyP3UieoBalw7DrY69NKM/rjnEIaZkEtRI3OdIOdL4epFdSCVIl8Lxe2fkIzCnHObBpmQS1EjTbBzkpqBrUg1X6aBTtzaMZsnLOMhllQC1Gjz8HGQuoGtSBtrIedvh00YhnOKaNhFtRC1OedLlD7p3eoG9SCtLMadl6gEWU4ZxcNs6AWoj6vwsZOage1IO2Er4KNVTRiF86poWEW1ELU5zdQu6KD2kEtSFu/gY3JNKIG/yW7nYZZUAtRnyehVkL9oBakvc9BrYBGtGcDGEzTLKiFqM9qqG2nflAL0t4+2DhFIwYDmEDTLKiFqM+XoXaA+kEtSHsd/aC2j0ZMADCfpllQC1GfG6FWT/2gFqQD86G2nkbMB7CKpllQC1GfkVB7hfpBLUgHfgW1b9GIVQA20TQLaiHq0xdqv6Z+UAvSgUao/RuN2ARgF02zoBaiPl2hto76QS1IJ3KhdDuN2AXgJZpmQS1Efa6A2meoH9SCdKIASkU04iUAx2maBbUQ9RkLG69QO6gF6cQ1UJpMI44DaKZpFtRC1OcLsHErtYNakE7cAKUbaUQz0I3GWVALUZ87YOeH1A1qQToxHkrzaUY3FNA4C2oh6nMv7HT/MzWDWpBODIPSN2hGAUbQOAtqIerzPdj6wG+pF9SCdCIfSg/TjBGYSOMsqIWozw7Yy/kPagW1IB1ohdommjERRTTOglqI+rzdFQ7cXE2NoBakA69BrYJmFKGYxllQC1Gjf4ETuQvrqQ3UgnRgM9T+TDOKUULjLKiFqFEZnOn5rbepCdSCdOCLUHuDZpTgERpnQS1EjeoCcKj/Y+3UAmpB2mu/DGptNOMRbKRxFtRC1OnTcGxIeSs1gFqQ9n4DtctpyEZsoXEW1ELU6UHEoe+SaiYNakHauxVqk2nIFuygcRbUQtTp9W6IR+CzvzzL5EAtSFt/yoLaIzRkB56hcRbUFtzjyP1P7HqXDnwDcRq44jiTAbUg7UQ+BRtVNOQZ7KFxFnTpcdOfaet0H8Qr+/NPdzBhUAvSzgbY+DBN2YNKGmdBn9z7ztLOWiRg8LdPMEFQC9JGbX/Y+FeaUokXaZwFnUYfoo22jyIRXebsY0KgFqTaG/8Ddn5BU17EIRpnQauu+2jjp0jQiP/zNuMHtSCVTgyDnexTNOUQqmmcBb2GNFMt8jkkqvfCKsYLakGqvPkJ2PpnGlON12icBc0W0caZq5CwwKyjjA/UglQoz4e9VTTmNdTTOAuaBX5LGzV9kLjchScYD6gFGVPdF+BAXj2NqccpGmdBt4/Tzu9zkYSeK9+mc1ALMoa/fvMDcGIpzTmFZhpnQbtXaef7SEr/x9rpFNSCjObsU1Oz4EivBprTjDCNs6Ddg7R1F5Iz6lU6BLXVEV7i3T9+9+b+cGoFDQojTOMsaHc77T0UQFK6/wedgY1uV1l3P/To9zf8eMvm9Q8u+8oXC7sgDvmnaFAYzTTOgnb/Qgd+2R3JmVpHJ2DU/TSpGadonAXtxtOJ/xyA5PR9ig7ApL5v06RTqKdxFrSbSUeOfRxJ+mqEtmBSkEbV4zUaZ0G7r9GZ00VI0q0dtAODZkRo1GuopnEWtPsZndo6EMmZdZY2YM7oFppVjUM0zoJuXZro2KnbkRyrjWowZtCbNOwQXqRxFnSby3js/iiSckMLlWBK9/007UVU0jgLmg1oYFya7+6KZNwYoQoMCfycxlViD42zoNlWxuuNRV2RhIeoAkPuo3l78AyNs6DXHCbgjUVdkbDcF6gAM77OFHgGO2icBa3GNDIhbyzqikR9tImxwYTcx5kKO7CFxlnQqOsDYSbqjSX9kaDZjA0G9NvLlNiCjTTOgj6fPMRktG+ZkoWEbGRM0G/EMabGRjxC4yxo0mvmT84yWX+990NIwOCzjAW6dflWG1PkEZTQOAtqj1c4sr+ug1qEfz0tG3ErZyzQ7J+rmDIlKKZxFtRCTLnX7x2EOA2PMAZo1bs0wtQpRhGNs6AWYhqc/eX1AcRlB2OARpetOMlUKsJEGmdBLcT0+MtdfRCHzzAGaHP5faeYWhMxgsZZUAsxXd4t/zScq2R00GTYg01MtREooHEW1EJMo+cnwKlvMjro0GfhC0yDAnSjcRbUQkyrnSPgzGcYHZJWMO9X7UyLbkAzTbOgFmJ6dazvCSdy32FUSEq+9dhhpkszgOM0zYJaiOl29FNw4v8yKiRq8OdLNr/awTQ6DuAlmmZBLcS0Cy+HA0sZFdS+sPLfvnTzZ8de+cHuQG6/j42dMqv4ngfLfr7rT01Mu5cA7KJpFtRCdIE1sPdJRgW1IC9ob6bL7AKwiaZZUAvRDR6Gra6MCmpButcmAKtomgW1EF1hPmydYTRQC9K9VgGYT9MsqIXoCqcGwU4to4FakO41H8AEmmZBLUR3+DnsvMBooBake00AMJimWVAL0R3O9oWNnYwGakG612AA2e00zIJaiC6xEDbKGQ3UgnSt9mz8lxoaZkEtRJeogI2HGQ3UgnStGpyzi4ZZUAvRJapg4zuMBmpButYunFNGwyyohegSp2Djh4wGakG6VhnOWUbDLKiF6BKRLKj9htFALUjXWoZzZtMwC2ohusQJ2HiF0UAtSNeajXMKaZgFtRBd4k+w0cBooBakaxXinP40zIJaiC7xS6h1YVRQC9K1+uPvGmmWBbUQXeJLULuCUUEtSLdqxHl7aJYFtRDd4d3eUCtkVFAL0q324Lx1NMuCWoju8GPYuIlRQS1It1qH8xbQLAtqIbrCyUGwsY5RQS1It1qA8wpplgW1EF3hi7AReJ1RQS1ItyrEeT0iNMqCWohu8DDsjGV0UAvSpSI98N+qaZQFtRDTL7IEth5gdFAL0qWqccFWGmVBLUQDOl75wb0lK352jI68NRv2jjA6qAXpUltxwUoaZUEtRO3eWN4X5w2c+djBCNXe/U5v2LuKMUAtSJdaiQtuolEW1JYF41D+u9doJ3x/Li52+efXPN/OWF699wo4sYIxQC1Il7oJFwyhURb0uqqkgSonPoXO8ibd99TBM7xEXcWqq+HQS4wBakG61BBckNVMkyzo1n8rYztzDWLq88kZxXev/O73f/TE2vvuWnB9Pzh3A2OBWpDu1JyFf6ikSRb0+2IjY7kBJuSGGAvUgnSnSrxnLU2yYMCAI4xuE4y4mzFBLUh3Wov3FNEkCyZ8uoPRvDMAJnywiTFBLUh3KsJ7BtIkC0Y8xGh+BCM2MDaoBelOA3GRWhpkwYhuIUZxA0wYG2FsUAvSlWpxsU00yIIZ49nZO7kwIPCfVIBakK60CRcrpkEWDDnOTl6ACYupArUgXakYFxtBgywY8hg72QwDPtdBFagF6UojcLGs0zTHgiHz2cnD0O8Tb1PpMihtoBudzsL7VNAcC4ZMZiePQbsPv061YVCqoBtV4P1W0BwLhnyCnWyEbv90jDYmQukg3WgF3u86mmPBkAns5GVo9vE3aecuqPR8l250Hd6vR5jGWDBkLjsbDq1G/z/a+iNUZtCNwj1wiX00xoIhD7CzB6DT7e/SXmQgFH5KN9qHS5XQGAuGHGJnfw1Am+4b6Mi/I7YPv0s3KsGlrqExFsz4n4xmInS5+mU60zwIMW2gK12DSwXqaMp8GBH4PaM5Pgha9HrkLJ16ErGM6qAb1QXQyQaaUgojvsro/twTGsx+k3G4FdF9oIautAGdzaQpL8CEjzUzhqezkaTA559jXFoLEU32brrTTHSWH6Yh4ULo13UfY9rUA8nImfsK43VyMjq77Gm6UzgfUTxLU0LdoduYKiocm4KEXbH8r0xA+C5caliILvUsollOY37aE1p1+XaYai9//cNIQM/bfhdhgio/g4vlr2mlWy1HNKNoTs046NN9+iE6UPfU8usvg3M9ryt5upnJ2D77MpwXGPvvDXSvUYgmUEeDan62tFiHex7d3kzHIoc3LhzTBbaG3PK9A2Emr33Phm9/raR0ax3drC6AqJ6kP7U+v+5L11/ZA9F0GTBs4j3b3mJGeRLRTaOvNR749fqH71/+9S/fcvOchSse2fDUH155o5mZaBqi69pEkQGauiKGcooMUI5YbqTIADciltyTFL53MhcxPUHhe08gtikUvjcFseU0UPhcQw4U1lP43HqoTKLwuUlQyT5B4WsnsqFUSuFrpVArpPC1Qtg4SOFjB2FnEYWPLYKd/BYK32rJh61yCt8qh71xFL41Dg4cpvCpw3BiMYVPLYYTfdsofKmtLxzZTOFLm+HMJApfmgRnAtUUPlQdgEMLKXxoIZzKa6DwnYY8OLaawndWw7kBrRQ+0zoAcXicwmceRzyGRSh8JTIMcdlB4Ss7EJ/xFL4yHnHaT+Ej+xGvWRQ+Mgvxyj5G4RvHshG3Oyh84w7EL7eWwidqc5GA2yh84jYkIvsIhS8cyUZC5lD4whwkJquKwgeqspCgIgofKEKiAgcoPO9AAAmbRuF505CE/RQetx/JmErhcVORlN0UnrYbyRkepvCw8HAkqZTCw0qRrD4nKTzrZB8k7U4Kz7oTycupovCoqhxoMJnCoyZDi+0UnrQdegxpo/CgtiHQZA2FB62BLr3rKDynrje0mUHhOTOg0TYKj9kGnQqaKDylqQBaFVN4SjH0Cuyl8JC9AWh2ZSuFZ7ReCe1KKDyjBPrlvkzhES/nwoCxHRSe0DEWRqyl8IS1MCPvMIUHHM6DIaPaKFyvbRSMWULhektgTmA3hcvtDsCgQQ0UrtYwCEZNp3C16TCsjMLFymBa3hEK1zqSB+NGt1O4VPtopMBSCpdailQI7KRwpZ0BpMTltRQuVHs5UmRkC4XrtIxEysyjcJ15SKFSCpcpRSp1eY7CVZ7rgpQqqKdwkfoCpNj4sxSucXY8Um4xhWssRhpspnCJzUiH7pUUrlDZHWnRr4bCBWr6IU2GNlKkXeNQpM24Voo0ax2HNJodoUiryGyk1TKKtFqGNCujSKMypFtOBUXaVOQg7XodoEiTA73gAgOPUqTF0YFwhcHHKdLg+GC4xNB6ipSrHwrXuLqRIsUar4aLjDlDkVJnxsBVrm2hSKGWa+EyU9ooUqZtClxnepgiRcLT4UJzOyhSomMuXGlumCIFwnPhUtPbKIxrmw7XmtJCYVjLFLjYtWcojDpzLVxtTCOFQY1j4HJX11MYU381XG/ocQpDjg+FBww+SmHE0cHwhIEHKAw4MBAe0auCQruKXvCMnDIKzcpy4CXLIhQaRZbBY2a3UmjTOhueM66RQpPGcfCgoTUUWtQMhSf1q6TQoLIfPKr7Zoqkbe4O71p8liIpZxfD08bXUyShfjw8ruA5ioQ9VwDP61JKkaDSLvCDeS0UCWiZB58YWUsRt9qR8I3Ld1LEaefl8JHA0naKOLQvDcBfRh+hcOzIaPhOXhmFQ2V58KPpDRQONEyHTw3aTWFr9yD4VmBJG4VS25IA/GzUYQqFw6Pgc3lrOyhi6FibB/8b+zJFVC+PRUbILWml6KS1JBeZ4sq9FJfYeyUySKC4ieIiTcUBZJaCbRT/sK0AmWdGHcXf1c1ARuq9po2CbWt6I1MN2c6Mt30IMtnkKma0qsnIcDl3nmTGOnlnDkSf0jAzUri0D8Q5w3czA+0eDnHB1P3MMPunQlxs2gFmkAPTIC4RKKpihqgqCkB0ljXnCDPAkTlZENFl31ZLn6u9LRsittw7jtHHjt2RC6GWPWs/fWr/rGwIB8bviNB3IjvGQzg17PFW+krr48Mg4jFgdQN9o2H1AIh45S2spi9UL8yDSERg0uY2elzb5kkBiIT1XXyYHnZ4cV+IJI0rb6EntZSPg9Ahf9FBes7BRfkQ2hSWnqCHnCgthNAre9L6BnpCw/pJ2RAG5Ex54iRd7uQTU3IgjMm9sbyJrtVUfmMuhGFdpz1ZRxeqe3JaV4iUCIxa/myYLhJ+dvmoAEQq5c/cUEdXqNswMx8iDQLXlOwLM63C+0quCUCkT4/rVlScZlqcrlhxXQ+I9MsaUbyplilVu6l4RBaEiwwsWlvZzBRorlxbNBDCjbKG3LRya3WEhkSqt668aUgWhLv1KFywbk8jtWrcs25BYQ8I7+hfOHtZ2a6adialvWZX2bLZhf0hPCp78IT5qzbteul4M+PQfPylXZtWzZ8wOBvCL7oVjJhYVFzyyMYtO57ZU/nioerX6k81h8PNp+pfqz70YuWeZ3Zs2fhISXHRxBEF3ZAx/j/aBu6xP+2WLgAAAABJRU5ErkJggg==]]
_G.NCLIENT_ACON_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAEuXAABLlwHuxW8gAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzt3Xe4JUWd//H3ZZIzgIQBhQFkCAMIIiBBBQRUsoyKmNMa2TWsqCuirj/FxIJhlcWwLK76wwwKKiKIgCAIgoAJEJUkCEMaYJhh8lx+fxT3xzBzz70ndPe3uvv9ep7Pow8P3FNd1aequk93FUiSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJEmSJElSiwxFF0CSlK01gI2BLYDpK2UisM5K/94iYDGwAJgL3AvcAdz66D9XhpwASJIANgKeBewE7PhoZgKTB/y7c4AbgD89miuB64AVA/5dDcgJgCS103TgAOBgYG9gqwo/+yHgcuAC4FzSxECSJJVkXeCtwK+A5cAjmeQ24NOkuw6SJKkAE4D9gVNJv9FHD/bj5TrgGNJPEpIkqUfrAR8B7iZ+UO8ny4EzgT2KrhhJkppoQ+BY4AHiB/Gicikwu8A6kiSpMWYAJwELiR+wy5wIHFRUhUmSVGcTgaOAecQP0FXlLNLaBJIktdLewB+JH5AjspD0U8eUQStRkqS62AD4OjBM/EAcnRuA5w1WnZIk5W8P4BbiB96cMgycCEwaoF4lScrSEOm3/qXED7i55grS8sWSJDXCBsDPiB9g65D7gBf0V82SJOVjJ+AfxA+sdcowaREkSZJqaV/gQeIH1Lrma6TXJCVJqo0X0uxFfarKmcDUHutekqQQ/wQsI37wbEp+CazTUwtIklSxd+D7/WXkSmCtHtpBkqTKHE7aBS96sGxqLsCVAyVJmXkesJj4QbLp+S6wRpdtIklSqXYDHiJ+cGxLvtxdszTbhOgCSFLLzQQuAtaLLUar7E56w+Ky6IJIktppEmkQir4ibmOW4yZCkqQgnyd+IGxz5gAbjdtKkiQV6DB83S+HnENLHwr0GQBJqt5mwLnAtOiCiK2BJcCl0QWRJDXbEGlluugrX/NYlpE2XWqVoegCSCrdEPB8YDbwNNKSqPOAPwFnAReSOkFV43XAqdGF0GquBJ5N+llGkmpvD+C3jH31cyXptSiV74nAncRf8ZrR8+bOTSdJ9fEaul9ZbhHw2phitsoXiR/kTOfMBTbo2HqSVAP/BKygt85vGPi3iMK2xDNwnf865ORODShJuXsFgw00x1df5FYYedbC5J0VpGdlJKlWXk4x+8h/iZa+G12SZxE/sJnu863Rm1GS8vRSihn8V+4EJ1V6BM11NvGDmuk+y4FZo7akJGXmCIod/EdyFjC1wuNoop1wxb865pTRGlOScvISYCnldYQXkV5fU39OJ34wM71nKbD5KO0pSVk4hO5f9Rskv8XXo/qxNb2/jWHyyX+u3qSSFO9gqhn8R3I9sGklR9YcHyd+EDP95x58DkZSZg4iLd5TdYd4Cz4c1a0h4CbiBzEzWA5btWElKcqBxAz+I5lDCzdO6cM+xA9eZvB8f9WGlaQIBwALie8U7wf2LPlY6+4U4tvJDJ5FwLpIUqDnAAuI7xBHsoB0N0KrewLwAPFtZIrJW5GkIHsD84nvCFfNEtICRHq82cS3jSku5yJJAfYiz8F/JMtxG9VVfZn4djHFZREwDUmq0J7AQ8R3gOPFnQQf72bi28QUm0ORpIo8m3oM/ivHnQTT6nHR7WCKz6dpGHf7kvL0DNIGMmtHF6RHx+BOgntFF0Cl2Du6AJKabxdgLvFXPIOkzTsJnkR8/Zvis5j0dkdjtHmWLuVoZ+B8YP3oggzoNcAPaedOgrtGF0ClmALsEF2IIjkBkPKxE80Y/EfMBs6hXTsJDtGwQUKPs2N0AYrkBEDKw9NJg//06IIUbF/gAtqzk+BM2jXhaRsnAJIKtR1wHs0dJHcDfkU7dhJ0o6Rm2zq6AEVyAiDF2g74JfDk6IKU7KnAJTR/gNwiugAqVaPa1wmAFGdb4EJgo+iCVGQm6U5Ak3cS3Dy6ACqVEwBJA9uGNPhvHF2Qim1EuuPR1J0E2zKZa6u1Hk0jOAGQqjeLNAjOiC5IkPVIzzw0cSfBpj7Hocc05kFdJwBStbam3YP/iDWBs2jeToJNeYVTnTVmkucEQKrO5sAvgE2iC5KJycD3aNZOgo25PayO1owuQFGcAEjVeArpyn9mcDlyMwE4hebsJDg5ugAq3ZToAhTFCYBUvs1Ig3+jniAu0BDwWZqxk6ATgOZzAiCpK5uSBv8towtSA8cAX6Te/dJQdAGkbtX5iyblbmTw3yq6IDXyDuBU6ruT4LLoAqh0S6ILUBQnAFI5nkx61a1RS4dWpM47CS6NLoBK5wRAUkdPIi3y89TogtTYbOBn1G9jncXRBVDpFkYXoChOAKRijQz+20cXpAH2o347Cc6NLoBKd290AYriBEAqzoakAcv94ItTt50EGzM4qKPGTPKcAEjF2IA0+D8tuiANNLKTYB2ep3AC0GwPAwuiC1EUJwDS4NYFzgV2jC5Ig80kTQKeHlyO8dweXQCV6pboAhTJCYA0mHVJy/vuGl2QFtgIuIi8dxK8KboAKpUTAEkArEN61W+36IK0SO47Cf4tugAq1Y3RBSiSEwCpPyOD/+7RBWmhnHcSvAXXAmiya6MLUCQnAFLvngj8HNgjuiAtNrKT4JuiC7KKJcB10YVQaf4QXYAiOQGQejNy9fnM6IKICcBXyW8nwauiC6BSLAWujy5EkZwASN2bBpwN7BNdEP1/Oe4keHV0AVSKa4BF0YUokhMAqTvTgJ8C+0YXRKPKaSfBi6MLoFJcGl2AouXwZZFyN4102/+50QXRmEZ2EpwYXI4bgDuCy6DiNW5i5wRAGttU4CfA86ILoq68BjiD+J0Efxn8+SrWEtIaFI3iBEDqbApwOvD86IKoJznsJHh24GereBfToCWARzgBkEY3GfgB8ILogqgv+xG7k+BPcWvgJjkjugBlcAIgrW5k8D8suiAayMhOgpsEfPYC4PyAz1XxlpL6g8ZxAiA93mTSbf/Z0QVRIZ5Keno7YifB7wd8pop3Fg3aAljS6CYBZwKPmMZlDtXvJDgVeKCAspvYvHDVhm0K7wBIyQTSK2Qvji6ISjGyk+CzK/zMRcB3K/w8FW8uaavvRnICIKXB/5vAK6MLolKtR9q6ucqdBE+p8LNUvG/h5k5SY00gfcmjbzOa6rKEancSvKCk4zDlZikwc/XmlNQEI1f+0R2NqT7LqW4nwYMrOiZTbP53tMaUVH9rkH7zj+5kTFyGgfdSviHg9wHHZ/rPcmCb0RpTUr0NAScT38mYPFLFToIvCDw+03u+M3ozSqqzIeArxHcwJq9UsZPghRkcpxk/K4AdO7ShpJoaAr5MfAdj8sy3KHcnwZ1Jg0v0cZqx45sbUsMMAV8ivnMxeecnwBMoz3cyOEbTOXOBDTu2nqTaGQJOIr5zMfXILylvJ8EtgIUZHKMZPW/t3HSS6ugE4jsWU6/8lvJ2EnxPBsdnVs+VuDie1CjHE9+xmHrmesrZSXAN0i6F0cdnHssyYJexGk1SvRxHfMdi6p1bKGcnwS2A+Rkcn0n58NjNJalOPkl8p2KakbJ2EnxHBsdm0uuZE8ZpK0k18QniOxXTrNxP8TsJDpHeOog+tjbnTuBJ4zWUpHr4GPGdimlm5gPPo1hrA9dmcGxtzApg//GbSFIdvJ/4TsU0O0uAIyjWLNIdhuhja1s+2E3jSMrf+4jvUEw7UsZOggeQnkSPPra25L+7axZJuXsv8R2KaVfK2EnwqAyOqw05HR/6A6wE1d97gP+MLoRaZwg4CJgKnF/Q37wCWAAcWNDf0+ouIv2Esyy4HFlwAqA6ezfw+ehCqNX2Jq0dfy7p6nJQl5MmF/sV8Lf0eL8DDgYeji6IpMG8i3QbNvp2ojGPAN+k2J0EXcei2PwGmN5TC0jK0ltx8Df5peidBD+VwTE1IT8m/VQjqeZehYO/yTe/ANaiOG8ClmZwXHXNNyj2zoykIDuTfr+L7lSMGStXUuxOgvsDD2RwXHXKMGlF0KE+6ltSZqYBfyW+YzGmm1xHsTsJzgL+ksFx1SHzgJf1V82ScvR54jsWY3rJjaRd/4oyHTgjg+PKOb8BNu+3giXl56m4SpqpZ8rYSfD1uJXwqhkGTgQmD1CvkjL0U+I7GGP6zX3A7hRrFmnhoOhjyyE3khZlktQwO+JT/6b+WUBa779Ik4AP0N67AYuAYyn21UtJGfkG8R2NMUVkEfBCircxcDJpe9voY6wqFwDbFVF5kvK0JunKKbqzMaaoLAfeSDmeSXoILvoYy8xvgdlFVZikfL2W+A7HmKIzTNrEqgxDwIuByzI4ziLzK/ydX2qV7xDf8RhTVo6nXM8BzqK+z9CsIG2ytE/RFSMpf3cQ3wkZU2ZOAtagXDsAbwDOph6v0/4Z+Hd8n19qrc2I74iMqSJfo7qt2TcA3ka6pZ7TnYG7SJOhPco7dK3KdZKVq4OBc6ILIVXkJ8ArgMUVfuYM4HnAvqTb7NtU+NkPkiYhFz6aa0kTAVXICYBy9U7SFYHUFr8ADidteBVhBmkysBtpMjCLtJTxoKvrzQNuAP5IGugvB64h/cavQE4AlKtjgY9GFyIjy4AfARcBVwP3PvrPNwN2JT0hfQB+p+vucuAFpN3/cjCB9Fv8LNLPB2sC6wBTSRt0rUMayEde1527Uu4AbgHur7zUkmrtC8T/LplDlgOfIy32Mp5ZwLczKLMZLH8ANkKSWupE4jvi6NxKepWrV0eQfmONLr/pP38DZiKVqOzXT6R+DUcXINhvSE9EX9LHf/tD4FDifkvW4LYGLgW2jy6ImssJgHLV5t8Nf0B6OvueAf7GZcBL8EGrOtsEuJj0UJ5UOCcAytXd0QUIcgLwctLGMYM6D/hgAX9HcTYgbXyzX3A5JKkyzyX+d9gqs4y0QEvRhoDvZ3B8ZrAsJt3RkaTG24D4TreqPET6zb4sa/HYQiumvllOWtJXkhrvRuI73bLzD2DnoipsDLPwzYAmZBh4N1IBqlp/WurHU2n2A1BXkh72u7GCz7ofuI603KyLBdXXEGmZ7KnA+cFlUc05AVDuXh1dgJKcAbyIald8+ytpWVe3V62/vYG1ScsHS1LjTCK9Chd927XofIa4N3DWIG2yFF0Hpph8FS/kJDXUZ4jvZIvKMuCfi62evqwP3Ex8fZhicjqDb9gjSdnZBFhCfCc7aOaTNnnJxdNJKwVG14spJheSfhKQpEb5CvEd7CD5O7Bj4bUyuNcRXzemuFwGrIckNciGpIflojvYfvJ7YNPiq6QwJxFfR6a4XEe6ayZJjfEO4jvXXnMmaf/0nE0ibToTXVemuNwIbIEkNcQQcDbxnWu3OZH67LXxZNKCRNF1ZorLHNJzHpLUCE8m/Z4e3bmOlWXA28uqgBLtBSwlvv5McbmPtKW0JDXC9uS7pO184LDyDr107yS+Dk2xWQAciCQ1xPNJHVt057pybgd2KvOgK3Iq8XVpis1i4MVIq3BNcNXVc0jPBOTw7vM1wGzgzuiCFGAq8Gtgl+iCqFDLgbcA/ze6IA30JNL25buQNvbaFJjBY69kLiL9HHMX8BfSzpyXAb8h/WQoqQ9PI61vH3l19RPyf9K/V1sAc4m/cjXFZhg4ChVhQ+B9wBXACvprj/mkVRxnAxOrLb7UDOuQvkRVd6aLSB1AXZ7079VB9N+xmbzzMdSvbYBvUvzqpHcA76V5FxNSJQ4nfYmq6EB/BexQzWGF+nfiBytTTv4LfwLuxXTgFNIt+zLb5R7gzdg2Us/WBN4P3Es5X85radfDVEOkxYyiBytTTk7FW8/deDlwN9W2zWXAVlUcnNQ0a5Fm0Zcx+BdxMXAG6c2DNs7Kv0D8QGXKy4+BJ6DRTCJ2qex5wCtKP0qpwTYnbcF7OnAT6UGosb50y0jr959Cmvnn8JZBlCZtxWw6x50EVzed9FNfdNsMAx8u6yDbeEWjdnsi8BRgA9KTvCPuIr3G9w/SAz5t9xnSQ45qh6uAQ0ivq7Xd1sDPgFnRBVnJSaQ3OB6JLoikZvPKv525nrx3rqzCnpT3DNGgOb7E45YkjiO+ozNxuZX0qlsbHQEsJL4NxsoHSzt6Sa3mlb95hPRzWBOWte7F+xn/+aBc8uqS6kBSS3nlb1bOA6QdIptuAvAl4uu7lywgbYomSQPzyt+MloeBg2mutYFziK/nfvJ7XMNB0oC88jdjZQnpddimmQFcTXz9DpL3Fl4rklrDK3/TTZYDb6U5diK97htdr4PmIeDJg1TEhEH+Y0m1dRxwTHQhVAtrAIeRVsX8dXBZBnUA6bb/huP9izUwhbRh1/nRBZFUH175m37zH9R3AbkjKX8zn6ozD1ivyEqS1Fz+5m8GzTeo1wNoQ8CxxNdbWXl7YTUlqbEc/E1ROZN0Czp3U4BvE19fZabuP8tIKpm3/U3R+RkwjXxtQBoco+up7AzjEs6SOvDK35SVK0g75+VmK+AG4uunqry2mGqT1CRe+Zuy8zsGfB2tYHuTdjWMrpcq89VCak5SY3jlb6rKTaSr7mgvJf8NfcrIlUVUnqRmcPA3VedOYEfiHEV6Lz66HiLyYAH1J6kBvO1vonIPsCvVmgicUkDZ6571e624Mhd0mAzsTNpbOucnRatwH3A3cC1p4QYl2wAzgY2AJ8QWpTBLSK8dLQ/6/ONwz3DFWgAcTjUr1K0FfA94QQWflbstgFujC3EQcCppO8noGVFuWQL8HHgj9VpIo0hbAZ8j/WYY3R5FZzFpydQo3vY3uWQx8BLKNQO4JoNjzSU7DFadg9mRNOOLroS65C/Ai/uq6XpaHziJNAmKrvsyspjYqxBv+5vcspTyXk/bBbgjg2PMKdsPVKMDeD2psaMroI45mebfDZhFs9/JXQK8sLDa6p1X/ibXDAPvoVgHkn5KjT623NLzMwBF+CCpkaMPvs75IWnHrSbag2Z/WRcBhxRWW73zyt/UIf+HYryN5m3oU0SWELBJ08sKKLhJOaHHuq+DjYHbia/bsrIEmF1YbfXOK39Tp5xE/xc6Td/QZ9D8oc967dvWNPvKLiJNe5L1IuLrtKwsAg4urKZ655W/qWO+D6xNb9YFzsig7Dnn1B7rdGCnFVRw81j+THOeB3gR8fVZVqKf9nfwN3XODXR3sTNE6kduy6DMueedXdRnYbYiveccfdBNzKt7aIec/Z74uiwjC0kPIUVx8DdNydWkZ8ieSVoLZPKj/7sn8CHgugzKWJdsSYVOKOkgDPyoh3bI1Szi67GM+KqfMSa3XE+f+n0g4zn9fqDGdQD1XzmxiesbLCI98Hd20OcfB7wv6LMl5avv3//7mQBMAZ7R7wdqXNNIV9B1tnN0AQq2iPSe/y+CPt/lfSWNZinw9X7/434mADNJkwCVZ0Z0AQZU9/KvbGTwr2Jd89F8Bgd/SaP7Lmmfmb70MwGY2u+HqWvTowswoJAVqUqwkHTbP2rw97a/pE6WAh8f5A/088rZwkE+UF2ZG12AAd0fXYACLCRd+V8Q9PmfwcFfUmdfAm4e5A/0cwfgVtIKaCrPHdEFGNCd0QUYUPTg75W/pLHcCnxk0D/SzwRgKfCnQT9YHS0CbowuxIDqfH48TFrkJ/LK39/8JXUyDLwJWDDoH+r3NcALB/1gdXQ+9f+Z5cfRBejTyJX/L4M+3yt/SeP5EHF9FJDeBHAlwHLy+u6bIWt1W8VrAbBvKTXRHRf5McaMl28SsOvfaL5DfGU0LTfQnL0A6rRT5MPAc8uphq64q58xZrz8AJhEJp5Eev8wulKalMN7aoG8DQGXE1+n42U+sE9JddANr/yNMePlNDIa/EccSnooMLpympAv9Vj3dbA5cA/xddspC/DK3xiTd75BxneGj8BJwKA5jwxndwXZj/RwXXQdr5r5wN7lHfa4HPyNMePlRDL5zX8sB5DeXY+urDrmq6RtMJtsZ+DvxNf1SBaQJiZRHPyNMWNlGHg/NbI+aVOCZcRXXh1yB/CGfiq6pmaQHhwdJrbeHwL2KvlYx+Lgb4wZK8uBt1BTM4EvALcQX5E55mrgaGDNPuu37nYlvcpyP9XX/Txgz/IPsSMHf2PMWFkMvJSKlP3bwjbALsCTgQ1p7u/cY1lGelviduB3wG2xxcnGROCZwJbAxlSzgdCZwBUVfM5oXNtf0lgeAl4EXFTVB2b/cIHUAMfh8r6SOruf9FZdpRcoTgCkcjn4SxrL34GDgL9U/cFOAKTyOPhLGsufSYP/7REf3u9mQJLG5uAvaSy/Ja1CGjL4gxMAqQwO/pLG8kvg+cB9kYVwAiAVy8Ff0lh+RHrgb350QZwASMVx8Jc0lm+QdkpdHFwOwAmAVBQHf0ljOQF4E2mlvyxku8OQVCOfwsFf0ugeIa3r/9nogqzK1wClwXwK+FB0ISRlaQVwJPC16IKMxgmA1D8Hf0mdLAFeDZwRXZBOnABI/XHwl9TJAuBw4PzogozFCYDUOwd/SZ3cDRxC2vwta04ApN44+Evq5O/AgcBfowvSDV8DlLrn4C+pk+uBvanJ4A/eAZC69Wng6OhCSMrS5cBhpG19a8M7ANL4PoODv6TR/Rw4gJoN/uAEQBrPccD7ogshKUtnAi8CHo4uSD+cAEiducKfpE6+AryU9L5/LTkBkEbnA3+SOjkBeDswHF2QQbgXgLS6T+LgL2l1j5CeB/pcdEGK4FsA0uN9Evj36EJIyk7W6/r3wzsA0mM+gYO/pNUtAV5FeuivMbwDICWfAD4cXQhJ2XkQeCFwSXRBiuZDgFK67e/gr6pcFV0Ade0uYD8aOPiDEwDp43jbX9U5AdgdeCYNHVQa5FZgH+APweWQVIKPkZ7qNaaKHM/qZpPWjo8um3l8rgM2GaW9JDWAg7+pMh+ls0mkp8vvyqCcBq4Apo/RXpJq7FjiOxnTnnyU7qxFOjcXZlDmtub8R9tBUgMdS3wnY9qTj9C7TYGTgeUZlL9N+Q7pboykBjqG+E7GtCf9DP4r2wH4aQbH0YZ8CR+KlxrLwd9Umf9DcfYHfp/BMTU1oz2cKakh3k98J2PakyIH/xFrAC8jvZoWfXxNyTDw3h7aQFLNOPibKlP2glLTSHez5mVwrHXOMuANvVW9pDo5mviOxrQnVa4muQHp1vWSEo6j6XkYOLT3Km+eOu0FMBl40qP/q/wtAO4J/PyjgU8Hfr7a5cPApwI+d1vSPhYvC/jsOnqQtPjSpdEF0dg2Ad4BnAfcTfys0XSfOcBTV2/SyryvQ7mMKSMfIt6zSINadF3knDnAzv1WsKoxnXRrazHxJ4zpPXeRXl+K4uBvqkwOg/+IIdKdgBuJr5fccjOwdf9VqyocDDxA/Mli+sudwHartWp1/q1DuYwpIx8kTyNLC99DfB3lkGtxXf/svRNXvqpzHPxNm5Lr4L+y9Uh3UxcRX19R+Q2u65+9l5DeyYw+WUx/uQvYfrVWrc57O5TLmDLyAeplM9LSwiuIr7sq81PSa5PK2I6k1zKiTxbTX+4AtlmtVavj4G+qTN0G/5XtBlxIfB1WkW/juv618AviTxbTX+YQe+X/ng7lMqboDANH0Qz7A38kvk7LyhdxXf9aOJD4k8X0l38As1Zv0so4+Juq0qTBf8QawOtJz+5E12+RcV3/GjmN+BPG9J7o9/zf3aFcxhSdYeBdNNeapKWFHyK+rgdtp3cXXDcq0RTqf9K1MbcT+z6tg7+pKk0f/Fe2IXAiaY386HrvNUuAVxZfJSrTnsSfOKa3OPibtmQY+FfaZzvqdWf2YeCQUmpCpXo58SeP6T63ETv4H4WvippqMkxal6TNngdcTXxbjJX7gb3KqgCV6yjiTyDTXW4Dthq9GSvxzzj4m2ri4P+YkaWFbya+XVbNHGCn8g5dZXsb8SeRGT/Rg/+/4uBvqsvDuGzsqp4AvJ98lmn/G7BFqUes0r2I+BPJjJ3owf9IHPxN9fkuGs36xG/U9idgRtkHqvLtRPwX3XTOrcTOsh38TWSeizp5CnAq1X8/LwbWqeD4VIEh0lPl0V90s3r+DmzZuelK91Yc/E1srsOlZMezO2lQrqI9zgKmVnNYqsqXiP+im8fnFmDmGG1WNgd/k0tcWKY7+5O23C2rHb6Fk7FG2hZYSvwX3aR45W/MY3kI2Bh1YxLpZ7u7KLYNTsJ1/RvtK8R/0U0a/CN/838L7duu1OSfb6BerEVaWng+g9e96/q3wHTgRuK/6G3OzcDm4zVUiRz8Ta4ZBvZBvdoEOBlYTu91vpy09odaYjvgQeK/7G3Mrfi0vzFj5RpgAurHTsB5dF/XC4CXhpRUoXYnbTEb/WVvU24ivdITxd/8TV3ydjSIgxh/aeFfAjtEFbCNhqILsIoZwDdJ61CrXDeR3nW+Pejz30K6RegDPqqDB4BtgPuiC1Jz+wCHAduT3ul/EPgD8CPgqsByKSOHkk6G6Fl/U3MjsFnXrVG8N+Fv/qZ++R+kBsntDsCqtiQtGbwz6XWcGbgYxKDuA44g/dwS4U3AKXjlr/oZJm1jfkV0QaQi5D4BULO8EfgqDv6qr6uBPUiTAanWfLJVVXHwVxPMIN09uya6INKgvAOgKrwB+F8c/NUMc0mrmM6NLog0CO8AqGxvwMFfzTINWBP4WXRBpEF4B0BleiVpIw8nmmqaFcBuwO+jCyL1y6sylcXBX002gbSbqRdRqi07Z5XhFaTBf2J0QaQSbUbaR+MP0QWR+uHsVUVz8Feb3E16IHBedEGkXnkHQEV6OfBtHPzVHmsBU4CfRxdE6pV3AFQUB3+11XJgV+CP0QWReuFDgCqCg7/abCLwRbygUs34E4AG5eAvwebAn4HrogsidcsZqwbxMuA7OPhLAHcA2wELogsidcM7AOqXg7/0eE/UWWPrAAAPTElEQVQk/ax6QXRBpG54B0D9eCnwXRz8pVUtBXYCboguiDQeHwJUrxz8pc4mAydFF0Lqhj8BqBcO/tL4tiS9EuhdAGXNnwDUrSNIg/+k6IJINXAbsD3wcHRBpE68A6BuOPhLvVmHtEDQRcHlkDryDoDG8xLgezj4S71aAuwI/C26INJofAhQY3Hwl/o3BfhcdCGkTpwAqBMH/+a4BfgQsCK6IC00G3hBdCEkqVsvABYDj5ja5zRgvUfb9cgMytPG3Ag8ASkzPgSoVR0KnEG6fan6mge8BfgIaTIHcDWwJrBXVKFaan3S8wC/ii6IJHVyKF75NyHnA5syuiHg1AzK2LYsBGZ2aBNJCnUIDv51z2LgGMZ/tmcyaZIQXd625QfjtIskVc7Bv/65Fth51YYdwzqk1eqiy922HNxN40hSFRz8651h4GRg2qoN24VNgdszOIY25a/4fI2kDBwMLCK+UzT9ZQ5pAjeIZwDzMziWNuXorlpGkkri4F/v/ACYvlqr9ucQYFkGx9SWzAc26aplJKlgDv71zTzS+/xFe3MGx9amfLu7ZpGk4jj41zeXA1uv3qSF+WQGx9imPLe7ZpGkwR2Eg38dsww4lvIX7hoCvhF0jG3MtbjUtqQKOPjXMzcBe47SnmWZBJxXwnGY0XNUd80iSf05EAf/OuZU0tK9VXsi8Ps+ymt6zzxg4+6aRZJ64+Bfv9wNvHC0xqzQDOA24uuiDfl6l20iFWoougA9GgJ2JXWO25Nmzk8i322NLyU9Xb086PMPBH6MO5HVyc+BN5Le8Y+2A+kcXje6IA33CLAvcEl0QaQcTSANpLcSP1vvNr8C1iqhLrp1AGkDkuh6MN1lIen34Nwm5fvhSpFV5BrcnVVazdNIT8tGf0F7iYO/6SW/BbYdtSXz8CrSksPR9dT0vK3bBpHaYDbwEPFfzF5yMQ7+prssB44n7c6Xu48QX19Nz/3Aht02iNRk+1O/5UkvAdYuozK6tA+wYJRymfxy66PtVSdfJr7emp6Tu24NqaFmkWbD0V/GXnIRMa9sjXDwr09Oo54P1k0gPVQaXX9Nzgpgj24bRGqiui1EEv2b/3NwR7c65AHg1R3asC7WJj2wFl2XTc5vyffNJqlUBxL/BewlDv6mm5wPbNqhDetmY+r1Rk4d8+ZuG0Nqkp8R/+XrNhcA08qphq44+OefRcAxNO+Kbnvq9zNdnXIfxW33LNXC2tTnnePop/33xsE/91wL7NypARtgH+rzfa1jTuq+KaT6ezHxX7pucj6xV/4O/nlnGDgRmNKpARvkFaQH16LrvIlZTrMnkNLjvJf4L914uZjYp/0d/PPOHOCQjq3XTB8gvt6bmkvJb3VIqRSfIf4LN1bOA6aWdvTj24v6LYzUppxOe3+3PYn4+m9qXttDO0i1dSLxX7ZO+TkO/mb0zAOO7Nx0rTABOJP4tmhi7gLW6b4ppHrK9Vaig7/plMuBrTo3XatMJdVHdJs0MZ/toR2kWnot8V+0VXMusdvp7omDf45ZBhyLO7itagPgr8S3T9OyDNixh3aQamcT8tp1LHrw98o/z/wZ2HWMdmu7bUnvsUe3U9NyTi+NINXRVcR/0R7Bwd+snmHShjiRr4DWxV6kRZCi26xpeUYvjSDVzb8Q/yX7Gd72N4/PXcChYzWaVvNSXCOg6BzXUwtINTMRuJ64L9g5xA7+zyY9VR7d0ZjHci5p/Xv1rg5re9Qp5/ZW/VL9HEhaBavqL9dPiV29zcE/rywEjsKFWAb1BeLbsim5qse6l2rpaKr9YkXf9n8WDv455Qpg1pgtpm6tAfyQ+DZtQi7pse6l2jqear5UZxF75f9M4MFRymWqz3Lg46SfolScqcBlxLdv3fM/vVa8VGevI92KLesL9RNgcmVHszoH/3xyE+kBTJXDNQIGz+E917pUc5sCJ1P8cwFnE3vlvwcO/rnka6TtqFWubYl5vqcJuQWY1HuVS82wOfAu0na8dzLYK0Y/IvbKf3fggVHKZarNfcAR47SVivMe4tu8rnlJH/UtdVT3p5snAE/s8799iDSBiLA7aWfBdYM+X8l5wBtJk0mVb3PgOmK3066rrwBvjy6EpMHsAswl/mqizVkEHEN6Ol3V+QnxbV/HXEzs3UpJBXDwj8+1wE7jNZQK90ri276OuYn08KSkGnPwj80wcCKxD3221TrAHcSfA3XLPGCHPupbUkZ2xt3RIjMHOHjcVlJZ/of4c6BuWQbs309lS8qHg39sTgfWH7eVVJbnkNcW33WJD/xJNefgH5d5wJHjN5FKNJn01H/0uVC3nNRPZUvKh4N/XC4Dthq/iVSyY4k/F+qW83AZaqnWdsLBPyLLSIPOhHFbSGXbhvS6ZfQ5UafcAKzXT2VLysNOwL3EdyZty5+BXbtoH5VvCLiA+HOiTpmLu09KtebgX32GSftEuLpcPo4k/ryoU5YCz++rpiVlwcG/+twNzO6mcVSZjYD7iT836pR/6aumJWXh6Tj4V51zgI27aRxV6vvEnxt1yuf7q2ZJOXDwrzYLgaO6ahlV7RDiz4865Vx84l+qraeSVpmL7kjakitJT5crP9OAm4k/R+qSP+NuoFJtbYeDf1VZDhyPO6Ll7D+JP0/qkrnA1v1Vs6RoDv7V5RbScrLK106kNRiiz5U6ZCnw3P6qWVK0HUhPn0d3JG3I/wJrd9csCjIRuJr4c6UueXN/1Swp2lbAncR3Ik3PA8CrumwTxXof8edLXfLZPutYUrAnAzcR34k0PT8HZnTZJoo1E1hA/DlTh/wUl6iWamkN0iYd0Z1Ik7MIOObRulY9nEX8eVOHXA+s02cdSwr2ceI7kSbnd6RnK1QfryL+vKlD7gG26LOOJQV7GunJ3eiOpIkZBk4EpnTdGsrB+sBdxJ8/uWcpsF9/VSwp2hDwa+I7kibmNnwdqq6+Svz5U4e8oc/6lZSBFxLfiTQxp5GuIlU/+5Du3ESfQ7nn+H4rWFIeriK+I2lSHgRe01MLKCdTgBuIP49yz4/xYVap1vYiviNpUi4jraOg+vJh2PFzHT7xL9Xe14jvTJqQZcCx+A503W0LLCb+fMo59wJb9lvBkvIwiXS7OrpDqXuuB3bpse6VnzWAS4g/n3LOImDPfitYUj72Jb5DqXOGgZOBNXuteGXpX4g/p3LP6/quXUlZ+QTxHUpdMwc4uPcqV6Y2Ju3NEH1e5Zzj+q5dSdk5m/hOpY45B9ioj/pWvk4n/rzKOWfgE/9So9xOfMdSp8wH3tJXTStnhxF/buWc3+HPXFKjTARWEN+51CVXANv0VdPK2ZrAzcSfX7lmDrBZ37UrKUubEN+51CHLSKudTeqvmpW5LxB/juWaRcCz+q9aSbnajvgOJvfciB1gk+0OLCf+PMsxw6SdECU10PbEdzI551Rg7b5rV7mbCFxN/HmWaz7ef9VKyt22xHcyOeZe4PAB6lX1cDTx51quOZ20Q6ikhppOfEeTW35BejZCzbY5sID48y3HXINP/EuNNwQsJb7DySELgX/Fq562OJf4cy7H3IETYKk1riO+04nOn4CnD1qRqo3XEH/O5ZhFwDMHqFdJNfNd4jueqAwDJ5L2flc7rA/cTfy5l1t84l9qofcQ3/lE5O/AfoNXn2rGra9Hz0cHqVRJ9bQD8Z1P1TmNdCWodtmXdKUbff7lFp/4l1qsLcugPgC8uqA6U71MAq4n/hzMLVcCUweoV0k19zHiO6KycxmwZVEVptpp609dY+UOYNNBKlVS/W1BczcFWgK8H7cxbbN1SHd/os/FnPIw8IxBKlVSc3yP+E6p6FyPnZzgA8SfizllGHjlQDUqqVF2oDl3AYaB/8LfNgWTSbe6o8/JnPLhgWpUUiOdTHznNGjuAg4rumJUWy8i/pzMKafhE/+SRrEe9V4k5Qxgg8JrRXV2GvHnZS65Cpg2WHVKarLZ1O9d6fnAm8uoDNXaZNLDbtHnZw65DdhosOqU1AafJr7D6jZXALPKqQbV3HOIPz9zyEJgtwHrUlJLTCTdTo/uuMbKMtLypRNLqgPV34eJP0+jswJ48aAVKaldJgPnEN+BjZZbgL3LO3Q1xA+IP1ej84GBa1FSK60J/IT4TmzlnAKsVeZBqzGuJf58jcypg1ehpDabQNoyN7ozuxdvZao3i4g/b6Pya9zmWlJBXgXMJaYzOwefYFZvphE/CEflVuBJA9egJK1kBvBjquvI7gVejwuXqHebED8QR+Qh4OkF1J8kjWof0u56ZXViDwP/QVqYSOrHU4gfjKvOCtI6HpJUuv2A7wCLKaYDuwn4IDC9wmNQM21M/IBcdY4upOYkqQfTgVcD3wTm0H2HtRS4EjgOeDbe6ldx1iF+QK4yXy+m2qRmcnCpzgbA04AtSZODJwKTgCXAg8A/gJtJr2ktCSqjmm8B6VXWprsE2J80oZYkqfVuIP7KvOzcDGxYVIVJTbVGdAEkVer66AKUbD5pu+N7owsi5c4JgNQu10QXoETDwGuAP0UXRJKk3BxA/C36svKeAutJkqRGmUK6TR49WBedrxVZSZIkNdGPiB+wi8xFpJ06JUnSGF5G/KBdVHziX5KkLk0G7iZ+8B40D5HW1pDUhwnRBZBUuRWkVQH3iS7IAFYAh5P235AkSV1aF3iA+Kv4fvOu4qtEkqR2+CjxA3k/+e8yKkOSpLaYQv2WBr4Yn/iXJGlgB5JW0Ise2LvJX4H1y6kGSZLa53PED+7jZR6wQ1kVIElSG00CLiV+kO+UZaQljCVJUsE2JM/nAYaBt5R43JIktd7mwO3ED/or54OlHrEkSQLSJCCHOwHDwIdKPlZJkrSSDYBfEzf4LwXeWPpRSpKk1UwEjiUtuVvl4H8rsGfpRydJksa0H3Ad5Q/8K0gr/K1TyVFJkqRxTQLeAfydcgb/i4DdqjoYSZLUm8nAa4ALGXz1wCXAD4BnVXoEkiRpIJsBRwI/BP5Bd4P+XODHwFuB9aovsqSVDUUXQFIjbATMAmY++v+nAVOB+4EbSa8W3kC6cyBJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJklSt/wc0AUB0E9tMcgAAAABJRU5ErkJggg==]]
_G.NCLIENT_TELE_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAIABJREFUeJzs3Xd8XNWVOPBz7ntv+qj3OpJGI9lyL7gCBuNgSAgQAukh2ZBeCAkhGMvZWWyWkLoppO1myRISNr3sL5sNTqHEgAFTDAarWMW9qdnSaDTz3ru/PyjBtsoc6Y5mRjrfz4d88pHffe/amnnvvHvPPReAMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxjIbproDLHM0NNziH5GO9ShhCSDUAKATpbRshCNCwvPSlH/t7LyjO9X9ZHTB4KZCE/VrAOzliOiTttwjQfxPd/vWZ1LdNzZ1weCmQlPo6wXIRVJCBSA6UEpLgjyFiF0A4olc/9GHd+36QTzVfWXThwMANqFA/W2LAMQtCHANADgmOHwnSPx2Z/ve+wF+YU1H/9jUBOq3fARBfhkAfGf9kQSAn8Yd+qcO7gn3pqBrbIqqQ7ddJqT4NACsBwBtgsNPgsR7hdTu2rcvfHwausdSjAMANqaKpnCeEY9vBYkfholvHmeQAHs0AZ/a17Ltr0nqHlMgENz8aUT8+rgHSehGgdd2tG59cpq6xaaotnHLfGnJbwPABZNoPiQlbO1q178MELZV942lDw4A2KgCweZ1iPBzACicwmkkAn6jqlz73IMPhk1VfWNq1DZuCklLexESC+5GUMJNHe3bvpvsfrGpCdQ334gAdwGAc2pnkn+xdfme7pf+9YiSjrG0wwEAO0dtffP7JcD3YOLh/gTh/4wMaW8/fDgcUXM+pkJNffM3AeCTxGY/ibijHz62+ytDyegTm4qwqK03vyYBblR40k4L9Uv2t4Y7FJ6TpQmR6g6w9FJTv7lZAvwnKHv4AwDIKxw+c3tFUzhP3TmZAudNos273MOunYHQpkblvWGT1tQUdtQEzZ8qfvgDANTo0nyYf98zEwcA7DWB+i0fAcCtyTg3SlhtjJh/KisLe5JxfkaHABWTbNeEUnsiENr8NtV9YpOCkbh1HyAk5fchAcpRag/U1NxWnIzzs9ThAIABAEBNsPnNCPJbSb0IwjKH1/wxQJg/d2lATu3770eJ/11Tv/n7TU1hhaNFjKomuGUbSHltki9TCbr4TTD4ySnmFbB0wjdiBsHgliZA+G8A0JN9LQR4SyBobkv2ddh0wQ9FYuZDdXWbK1Pdk9moJrTlvYDytmm63CoTszkJdAbhAGCWCwTCLgvlTwHAPV3XRIRNNcHmN0/X9VjSrbQFPl0TbH5Dqjsym9TV3TYPpPzBdF4TAd5fW7/5mum8JkseDgBmOTTMLwHAgmm/sIDvlzduyp/267JkKQCE/6sNNX+Rp3iSb926sG6juAemvNSPTgJ+r64uXDTd12Xq8Rd1FqsNfWE9AHwiJReXUGJY2jdTcm2WLCglfL4mZP6Bg7vk6j5kbgKEZSm6fIEU5jdSdG2mEKm6G5s5mprCjrhl/R4mU+gHUWYtWPRU8SXr25xFxQeGDx3Kl5ZFTgRDgPnZBefvHuh5ZC+5D2zKcvMv+CwA+JNw6qAmxdtz8i98rL/34UNJOP+sVtNw2wKQeB9M4v6Nmh7PX716Z+H5a/eBpp8YOXasDCZXD2ZedsHaJwZ6HmmfRFuWJrgQ0CxVU9/8OQD4ErWdcDgHaz/+iZeM7Ozlr/5M2rLn8K9/0X3qhReWkDsioVuaemNXVzhKbsumpKa++TAAlCbxEjFA/Gxn69ZvJ/Eas05NffPfAGAdtZ2rvKIt8E83GKiJwKs/i/X37uy6+7vzrPiIdxJdeaGzrWUR7/mRuXgEYBaqCG0u1wB/DsT5Q9T1aP1nb+7Qfb7FZ/wc0ZM1t6nIikSeiB46RFtbjpCDmn2qv/fhR0nt2JQlcQTgVRoAXJ6Tf0FDeenFfzpx4sFYEq81K9QEN18BiJuo7TzVgZeqP/CBchTijLl7zeWuyFm67KW+p57IlpZlEE9blJdX2N3X+zDvGJmhOAdgFjJs/GeYxI2/5gM3PKW53PPG+GOt5PI3LvYFgy9Moku38ZzxzIUA74jEzCeq65vnpLovmWzdurAOiHdR2xl5uYerrn9/EQKevdsjAABoXs/CwIc+/AwgSnKnUN7Oxb0yFwcAs0ygMRwAhPdR2xWtv+QRZ2nZ2gkOc1a84925mts9QDx9jtPStlD7xDLKHAHwRG395nekuiOZquuQdQMA0IIoIczaD32sBwWOG2A7CwpXF23Y+Ai1TxKg3OUzVZcfZtOEA4BZBs34ZgAgDfU5srOP5q89P6H5fdREefX173+e2i8J8JHKhnAZtR3LKD4J+NOaYPO3uXogTVNT2CFANlPblV559Q7hcs5P5Nj81auWOQuLuqjXkBI+XVFx07TVEWHqcAAwi1Q3NNcA4vXUdhXveW8HICacJOQsKVnjb2jYTbyMU7fNTxPbsOnVq+QsCB+PxMyHa2vDVUrONwsMj1jvlgDllDaOnNxDOQsXUpYKeqrf/099xK4BABTpbu97J9GOpRgHALMI2vA5IL79+0INzzkLCldRL1V2zbVORLSJ7T4cCIRziG3YNEGEtyHAfys63QqpmU8H6po3KjrfDBYWEuXN1FaV73nPfgAgZfdrHs/i3PNWPE69FgLcxAWgMk/Sa7+z9FBVdWsuApCj9LJr3uqASSwXFQ5HQ97qNY/27Pj7akKzLOEwPwoAd1Kvl2yBuuaNiPA+RJwvwXaluj+KkKq52bYc7Gq/4x01oS07QMqvwtS3jM5HAX+oDW3Z1tGq/QtAmBowzgqBYPwKACTN/Xurq/c68gtWTuZ6xZddVt6/66kYsbZHQyAYv6KrHX43mWuy1OAAYJbQnPoNQHwbyF6w8CnN6Zx0tbHCiy8p633sUUvadsLLTaWEGwOB8NfTpS5A8YKbve5h170I8BYAAAkSZnv5jM7Wrd8O1G95EkH+HACmOowvpJRfqKk3V2py07vb2+88oaKPM4rAW4CYn1927XVDMMkPKqKoLLzo4keO/3n7+bR2eDMABwCZhIdsZoF168I6TKLkb/Fll03pDQ81EchbsWon9bJCj6fLZiPoGXb99NWHP/uHrratOw3UlwLIPyk65Rss1HZVB7dQp5tmtOrgbUtQAmUUDTzllXt1n59elOt18lavCQnDMUJstjZQf9uiqVyXTS8OAGaB7oPmVUB8U/PVh3Zrbs+UNwkquPiiAkDai4hE/OBUr6tCdWjzVQDAuxaOobU1fLKzzbhcSggDgIrh+0qB8sFA/eZPKTjXjKBN4rtQctVVfTDFYSoUojj//AueILcD8U9TuS6bXhwAzAYCPkBtUvrmNyup2iYMR8jfOIdaKeyCQGhTo4rrT4WQyDezCYXtrvZt/wISLgOAkwpO6EDAb9SEmn/W0HBLMqsUpr2mprBPAr6L0sbIyz3sLCw8T8X181etKp9EcaB3BoOfnPYdCtnkcAAww1WENpeDhA2UNo78/AO6P2tKQ4ivV3TJeup8PqLUyUFLEixNdQcyRWf7tgc0qS+WCGpKOku4LmY5n6pt3JLQGvaZKBI33wHEip1F69/QBopKvKNh1GbNX/gUsVm+BVk8apYhOACY4QyA64F4QyjauLEDFH42HPmFS3Wvj7iGXL4vDd4kuFjN66AQw+P9eXt7+KDX0C8CgG+puaAMSUs+VhvcTHoLnjEkkIb/UQjLP2duvcouFF+6gX4fEDxylik4AJjZECS+j9RCaDF/MKR6+N1RcNFF1OqABXGRdbniflB1pPj66cREM9Y10UF79oRjnW3bPiVRvh0ATiu4rlci3heob/5OGgSE0yYY3NIEAMsnPPB1sucveAYFKq2mqXv9SxwFBQdJjSRsCAbDtE3BWEpwADCD1TVsWQ0ApDeCvOXLngbEYtV9yV60qIqaDChApLRuPEr561ReP73Iv3R03JXwHg9drXf8TKJ1ngTYo+LqCPBRC7MfqanZXK3ifOnOQng7tU3BuouSUUcBiy65pJ3YRrOF+Z4k9IUpxgHADGbb8m3UNvnnX5CUYW+hGzXeujraKICUb2xqCo+6g9l0MLT43QBwIFXXTyNxFECuQ9/VeufeYXd0BQD8RFE/loOOT9eGmlM9MjQNaN9d3e8/YeTmLp74SDpfaM5cEJpJaSMlXJeMvjC1OACYscICAEjr6R05OYd1nz9p63iL12+g7hLoGR6JX5mUziSgpeVLpyXYbwaAY6nqQxqIA+INHS13UJPBAADg2O6vDHW2bXs3SvgYAFDXlY8mT0r4n5r6LVsBrlWS7JZuahs2LwPiyF3x+g0vArHMd6JQYFH2ggXUlTyLqkLh2mT0h6nDAcAMVVMfXwsApPnAvLUXtEESPxPOkpLFwuEYN5HsbBKRPBSqUlfbvz4bR7kUQf4IACKp7Ms0swDkXwDl2s7WrfdO9WQd7du+i4jng4RuBX0TALK5pj70p7q6MKmccSaQFv0z75/XlNQ59/y1a+PUNpqMcwGtNMelgGcqiddRS4FkzZ+f3Jspojdr/vwn+nftoqxTfkNV1a25+/d/cTK7lClxsPWOQwDw/oqKmz7mdLrrpKYXA9gztx4wyv6YbnQc3BNWs/vfKzpatz5Z3rhpqWFp9yKAgmF8XC+F+XRd3ebr9u27Q83yw9RDQNrwubOoqBN1oy5ZHQIAcBYULkKHY0jGYgmXE5eIVwPAV5LYLTZFM/cmNquFRU3IPAQSShJt4czP31/7yRsrIcmfieHjR//e9Z3vrCU1kviezvat9yWpS2zahUVNffw2AAyDmjXrcSnlLV3td3wDgFo1P73UNmxeJm18ktKm7C3XPJy9YOEFyerTq45v376jZ8cjawhNbFPolQdawoeT1ik2JTwFMAMFgvHzKA9/AICCCy7shGkICF1FxfNR04nDifJNyekNS42w3dl2xzZE2AgAxxWc0EDEr9fUN/88GAxnKThf6khxBbWJr6GxMBldOVvueSuoCcLCsKyrktIZpgQHADMQwiRuInPmkgKGyULAbN+cObuJjS5ragpzUZ4ZpqN125/jKJeAhB2KTvlWC82nahpum/IeFqkipSQlvRp5eUc0p3NaymYb2VkLhNNFqu0g0eY8gDTGAcBMhLQ3ZmdhUZdwOBqS1Z2z5a1cSU2myxqOm0kf4mTT72DrHYfyso9fhID/BmqG7+vBFo8FQltSmjw6GXV1mysBgBS8FKxe0w7TN5XrzF685AVaE7ywqurW3OR0h00VBwAzTG1tuAqIN5G8latUZGYnzF1W0YhCkIqWSInkUQ2WGXbt+kG8o23rTfDy2vFTCk7pQSl/UhPcnFHFaCSKK4D4MM+a25STpO6MKnfZMmqQputO7eKkdIZNGQcAM42wyPPlvsbG7GR0ZSwosNBbGyS+SdicBzDDdbZv+yVq1nKQQC0bPRoBiHdXhDaXKzjXtJBCkoJc3e8/ITyeucnqz2gcBfkLUNeJO4UiaTMyNn04AJhhJMrLKMcLp+u07vU2Jas/Y8lfvZK4rA9ra2ublW50wtJPx947W0ci+kqQMOXaAwDgNzJkS+dAIOwCCRdS2uQuP68FFO38lygE9GXNbSLl8EiANySrP2xqOACYQdatC+sAQJorz164cA8kqYLYeFyVVaXkRgIuSUJXWJo5fDgc6Wzfdj0gXg8ApMJRo8iI3BHhMNcCgJvSJqupKSWVEHOWLh0iNqmpqwsHk9IZNiUcAMwg3YetVQBAWgaVu3gxqca3KsJw1OtZ/hOUNjZyADCbdLZuvRcRvzzF0xQo6UyS2YDrKccjom3k5oeS1Z/xeCoqqqhtJFo8CpCGOACYQRCID0hE6SguSdWwOmbPX9RKagBw8Uyt/87OtHTph4xAqPlrUsotUzmPBMiIIjRoS9J311NV1YoC85PVn3Fpeo0jv4C4SZbkPIA0xAHADCKlJEXZ3orKFhRC+da/icqeP5+aUZxTEwotTUpnWNqoCG0u7x0o+htKuAmmuMQNAf5PUbeSpqrq1lxAIO3kl7NkaUo3qMpZvLiLcrxEWL906YemfaqRjY8DgBmitvbz2QCwjNIme/l5R5PUnYQ4ioro84KSM4pnstrQF9YbEp8GBErJ2VEhwCG04iqSCZPqlWVypJEtT7B+WlfunM0/r4lamMvfP1hM2QOETQMOAGYKTVsLxM2dfMG6lN5EUIgSZ0lJB6WNlMBrimcmrKnf3Cyl/ScAULEp1ZAt8V0dHXdRt6CedhJpn2nhcAzrXu+0VP8biyM7dy4IQcofsizaNAdLPg4AZgyNlO2Mmj6iebzTVv1vLLmLl5LmEhFhBQ8lziwVTeG8QH3z/wPAraBmWdtBKeUlXe1bH1JwruSz8XzK4d5Qw4sA4EpSbxKD6PdUV7XQmsgpj+owtTgAmCEkSFIA4K2r2wsAniR1J2H+xkbS0icA8PaeLiTNl7L0VR28bYkRiz+pZntgAAB4UMb15V3tdzyu6HxJ9cr8P6kOR87ihYPJ6g9F9oLFJ2ktcNUrS5VZmuBfxgxQvOBmLwwDKTkue8HCiQrxDNsjIx1WdCQiXE6f5nTWQxI+L1p21lwQehxsk/BWj+cDwBOq+8KmV22w+aMS4esA4FRwOhsA7uhsa/kXgF9YCs43LXSnvkYSX8Q8lYGkbdwlLbvLig71AAjUPJ4AIuaNdawvWOclnt7XedCaDwDPTK2XTBUOAGYAb9SzUoJNGhb31taMNf8/1P/MrqeO/elPi+1o9LU3E83nO1nxlrfs8dQG14LC6mMI6PNUV+2JdHYk/BaENqwFgK+q6gObXsULbvZ6hl3flwDvUnTKHhvt93S3/usfFZ1v+iCspWyBpLndA8LhUL501xw8vevgT+/3Dx8+GAKAAAAACmHlLF6ys/jyy8tQ0yvP6Yvf3whCmGDbCT9HhIA1wAFA2uAAYEawSXOIqBsjmmeUJCIJ/d0/+uGRSHf3OSVJrcHBgu57770we/HSJ8quvHIxKKwemDW36WSkM/FcQPlyhjiCmt3jElZd3zwHERcisdhSxrHtYSFh3759rTtVv00HQpsaYVj7JQBt2HscT4Ipr+3u/Ndp3dBKFRvgfMo6R199qA2Iq30mEunY91D3j++9AKQ8oyvStrW+XU+tOPXSnv7gpz/zonA4z9h34B/Be1fiwbuUawDg24q6zqaIA4AZQAKsoBzvravdCwALz/758Qf+96VId/eq8doOPLPrPF9tzYNZ8xeso/VyvP7UUZcUFVbXNzd2t217SVUfxhOo37ICQX4TAM4DOa0xR2oggo0ANfUNB0Fu2dTZvvU+FaetCW65DqT8DwDwqzgfoPyOZp/6THvnt0aUnG+aVVTc5EZJe5j7GhuVzv9bQ5HnRnv4n3FMZDin4zt3R4I33nQaEM/43eUsWHQi0tmV8PUkTH15J1OHkwAzH4KE5ZQGOQvPnf+X8Xhrz+M7VybS/vDvfrsSJPRTrjkeIyc3QG2jSRw3UFGltv62NyLIhwBgNq5hrgCUP66pb942lZM0NYUdNfVbvgEofwZqHv5DKOW7O1vv+Hh7e2Y+/AEAHB7PUgAgBb+e6oDS0afDv/8NjPfwf1W8v79ssGPf02f/3FtbR00krnxly3KWBjgAyHDBYHMtAJBKgnoC587/Rzr3HU7kRgAAIE3TNXziKHE737GhwFJHTg6tZCvKpD+Qq+fcVipB3A9qktQy2eba+uZJbcdcV7e5MhIzHwKQn1LTFdyrSVzR0X7HT9ScL6VIn2EUwtI9HnXz/1KeHGxtXZDo4X07d+ac/TPNn1UHiLRhMc1aSzqeJQ0HABnOJj4IEdHS3J5zKvBFjx0nJfYNvfAi5fAJ+ec0dVGOl9PwRi5McROoGq7OcBLgC9Q2NcHmN9gCnwaAhEaWEujEzxxi5Lz29q17lJwvxaSNpM+wq6x839lD8FMR7+trTzToBwAYOXninBcNFJjvyC/solxXSrmacjxLHg4AMpyNSBr+d5aWdYx2ExFut005T/8LuwOU4yfia2yIE5vMq6i4iVpDgOqyJJ8/kywLBjcVJnZoWASCzf8MCH8ENbvxxQDgU53t297e0vKl0wrOlx5Qkr67/jlzlJbuHmxrjVGOFy5XdLSf++fMOUS6sIIyz0wNDgAyHNq0N2F/4+g3EU9FJWkEIN7bWyFt+yClzXicJaXU8q+G0+tbour6o0IoT+r5MwvGAc9ZCna2UChcUBMy/4AIYVBzfzkgpbyws23btxScK22EQuECAKyltPHWB5XuhDnw3G5SPQFfTe3x0X7uD4VILw8wPcE7SwAHABls3bqwTt1FzFsfHHXIz1lUMOHN/Wyx48e7qG3Gojmd9cLhiFDaWJZNeoMis+FUUs+fYRBw3IS1QP2WFXFp7gIJGxVd8gED9SWZUtWPwgSTPIXlyqd/R8ckoT965BBpMy7/nLmj1v53FhdTdxTVDY9nPrENSwIOADLYK1W1SFm4zsLC0aN+oVcb2VmkLUZPv6g0D0D31NS0kVogbQ6VSiI8mszzzyQ1oS0fQpAPA4CKDG+JCHd1trVc3toaJpabzRikz67m850ETVeWPR8/NdAqpSTd/13FxRWj/Vw4HEHhcJCmZtBG3tY7DXAAkMGEkKQ1xMLhHBS6UTPWn/vmzCPtzDfwwvPVlOMnkjVn3kTlic+AMrk3EU3g3ck8/0zQ1BT21dY33w9Sfh+IS9rGcFJKcVlH67ZbM6mkL5WUtNLdWQ2N+1Ref7CtbZhyvO73n0BjzHuH5quta6ecT4JM7vQdSwgHAJnMpq3/9wVr22GcMr7Zc+eSkoJivT2V0pajzgtOhjtQSZsXRBksKwsnbUOjfS1bd7xSq56Noiq4aW4kZj4hAd6u6JQ70dKXdrXf/idF50tfEkhD4L5QaNQEvMk69fzuBBM6X5bd1NQOL1ffHJUnGCJtu4yIHACkAQ4AMhnShhG9DXPH/ZK6SkvLqF0wTw10UtuMxcjOoV5fOH3xeaquP5quVv1mANgKANRVCjNabf3md2io7QSAOUpOKOW3PQ79go6O8H4l50tjgUA4B5A2VeIqK6NuvDMmCXIwcmB/iNLG39Q07uffE6gijf5IgHlNTWEVI0ZsCrgUcIZ6+c3XJNVT9waqxn3DRsMIGm5PX3w4kpvoOYe6u6M5OefUB5kURFGhedwDVmR4rI2KRiEWQFJ3BgzbnW3whapQ+EeajL8TABcCgJq/cOqdD8QiR01NYUdkxPyaBPi4oj4MSsQPdrVt+29F50t7whGfJyVStgAAzetTlgBoDUVawbZJb+DO0rJxg3Nnbm4psRuOwZHYPAA4p7ogmz4cAGQoh9eaD8Tfn+7PnuitA72Nc9r6n9mV8MjC0IsvZucsPGdbgclCd2VV12BLS+InJA6lTtb+1nAHAEypJG66qalvPgQACY+6IIiqSMz8BnXkaezz4YsWyLd2t26dlj0d0oYtFgCheJ7m851AIaiZ9mMaPnSQtLpFc7sHhG7UjX+QHhAu1yk7Gk24VLEQYilwAJBSPAWQoRBpDz7d6+tFISZc95s1v4m0FO90x756ABh1edBk+IIh4h4DMuFSpmyKUN4HiiowSoD73Q5txXRt6JRW0KbN/9fWKp0WGdq3j7b/QG1dB4wz//8K9FYHSEnEKDkRMNV4BCBDoZTzKAW4PYFAFwDkTXScu7ySlBwk4zGvHY+1CsNBmlMci6uaVpAIYHpGABgAqNkCOgYIn+lq3TZrV1jYiAso1fM9dfVKdwAcam8bdTnfWLIa5yQ0YuCtb+g/3bI34fNK4ETAVOMRgEyFtDdfb21dQut0hdNZB0InJbzFTvSQ6geMx5mbR60ImF8R2swV+zLDQVvius5Z/PAHAEQJpMRVT0W5umQ5Cf2x3l5SPoG7avzcoVd5a6qoAeKCpUs/pCKoZJPEAUCGkhJJNxFXRXmiXzSXq6yUlNk/1NVF2w1sHMJw1KBukLZ41XgaIP0h/F9MsxZ1t299LNVdSaXqhuYAAJC29HXk5JBK9o7HGh7qpGwABABgZGWNXu9DylPm6VNPnd6798Hj27fvOPSrX1HzFFw9A0W31Ya2LF+3Lsyj0SnA/+gZKBAIlwCYpKF6Z15+wsf7a+qORw8eSHhIf6ijLTd/9SpKd8ZjuEtL90YO7G9MtAFKnA8Af1TVAaaUJaW8vavN2AawjVozfsYRFsyfcDb9ddDhGAJNV1Zwa/gwLQHQyM45AoivZfjLeLxtsK31UO+jj5YOHzoYlJJWjOxsiBCWUoa7D5mRmvrNO1Dib2JC/v5g6x20DYbYpHAAkIHQoCURoW6MoGEEEj3eUxew4JHEzx/p3l8LADYoGlFy1wVPRg4knveEgDwCkJ5OAIh3dbXfvj3VHUkbKBdMnE/3D56qqg5QmOcSISYA+kKhbpDgjnTse+74Aw9UDh87Ug8A9ar68zoeANwgETYYEu+uqW/eARK/L03tl11dYaVFkNg/cACQgVDa8yiDeJ7Ski4AaEj0eGdxScJ1AABeTgQEy+wETR+zzDCFNxCwe0gdAA4A0s9jmtSva28PK9sxckZAnA+ECTNvXZBUHnsip9vbSfkyQx37ylvu3OqwY/ELVfZjAggAawHlWjTMfwsEm38Q162vHtp7J+m2wCbGOQAZyEZJmv931wZJG6poLncdIpKGa0f6+o9Qjh+Pq7iIVmgHoYGriqUT/KbHoa/jh/8oJG20yhMIqLszoutPAAAgAElEQVRHS+iPnewhJQDGenoq7Vg8aeW2E5CPCJscltZZU79layAQnilFuNICBwAZCAFJQ4LemhraOn1Er6OgkLT2ePjAAWWlcjWXuwaQslAKHBEzlnDOAEua0yDxbZ1tW2/csydM2ldiNqiouMkNIEnD5878/AmX7ibKHI50URMA04gfQDajw3wpENqiau+JWY8DgIwTFgBAKgHsLCS+UQOAL1h/mHJ8pLNDWa1yQPQbWVlHSW0sjacBUkgC7AEByzvbt/481X1JV06nby6MsxnXORClMBzKEgDjJ0+SNuxJSxJKUMr7a0LNf6xuaFYy5TibcQCQYWprzToAIA3JCa+HXEfcUxcgvdFH9neTNxIaj7uikjSlIEHOVXl9RoBw37A7uqKzZVtLqruSzmyNFrg7Xs7AVxZYRw4eytS3/3NJ2ChseLa2fvM1qe5KJuMAIMNYOm3+X/P5TmICFQDP5iqt8FOOjw8MlIKUpCVG416/opJU/QwxKZnJbHwjEvCjna3b3nNs91eGUt2ZtCdpn1FnRYWyvBoAgOj+LtJ3OgNkScBf1AS3fJXrCEwOBwAZRrMTz+YHAHCXlU9mPe3Q8e3bLVILKdEaiSqrWe4pL6cWF+IAgEpOZYtj2YVCru1q2/o9dR2a4SRt/t9bWaW2BPDBA6QSwBkCAeVnug+Z24PBMKnAEuMAIOPYiKSa+57KStJbubRlT/d//ahr4Nmnl9N6BhDv7VW2ZMlRkE/9MgeBssCaASB0T6aZBPjfuMNY2tFyx1OquzSjCQhSDneXlSn7PEuAXmtwkFQ8LMOss4T511AoXJDqjmQSDgAyDEogBQDu8vKEl/NJgIH99/ywN9LZQZqrfNXwocPKKr0Jl5uaU+CtbAhT9ySf1RDxQWITCwCau9q2vengnnBvEro0sxGnAPR8chA8Jns4ckDVuRKBiDIr293/6n8Op578Yj4SlprSeqiyIaw0H2km43mTTEOc63YUFiaWRCTlqf0/uudw5MD+OZPqFwBEujv9ucvJAwejQiGKqfuLa5ZVDwCk1QuzmR3TvouG+RkA8CVw+HFE8c6O1tv/kux+zUQ1NbcVA3EPAI0eBI8pdrInaSsAcnI8vWvXzWlfd1HjcOPciqysLHeeposSADhj9ZGUcsg0rRMnj58+2rL3cPSv2/dkPfLw3rmxEdOlqi8S5FzNNh+orf38mo6OuzJ/1UOScQCQQV4ugmGSdsvTfL5ENugwD/3qF+2R7q4pbc85fGC/0l35XKVlByijEQgyCAAPqezDTNbVFT5aE2x+FyD8BsYbDZSwIy7k2w623s712ScJDayXhKwWze0eQIHUnTHHFD2s9lfn8TgHr3nbiueuffsKZ36BfxEAnDdRG0T0GobuLS3PDZSW58K69U0ACJHjRwae+PF//d3+/W+eWmLGrSkX9EKAJqnpv2pqCl/O9SjGx1MAGQQdcdLwv3A4hhHFhA/lnkcfe/TUCy9MeW/u+KnTRQCgLBvcXVlJyilAwYmAVJ3t234vJV4MIDtG+eNhANial338It6cZYokkj6brtJypUP2Q12diYzyTCgn19P71W+/+6Htj2zGj3zikjX5Bf5lMJUXSQmeopLs8z77+Teu/NujXzh9+53XPejzuxSsJsL1kZj5g6mfZ2bjEYAMgjbUU+p4OQuKDgCMnzMQPX50x/EH/njBFLv2MilRxuOH0DBIgcpYvBUVJqX4t02cY2Uv62rf+hDAtaHaUMNFUspFiOiTNrbHdPOPh/be2UPaG5qNSkoMAqG4pbuyUunw9fChg1NaAeB2G5EvbLvmifMvnLMMEZOyL4AQmL/+DfPWXbxhXv8ffrfroS/f+YfVpmkmuo35aK6vCW35e2fr1v9Q1skZhgOATCJECAjjiJ7q6pMwTgAgLfNA9w//c6GKrr0qPnS6z5GjpnqpUVxEmhtEoGVZs9f7hdXRCn8GgD+nuiczkoB6yiZArooyWvnucUiQA+bLo3OTsnxl8IUv/9s7fYahr1PVp/EgQs6brlp64YaNC1pvvvEn8aefmlxSMgAASPn12trmhzo6trUp7OKMwVMAmURK0pu1q7JivPkv++D9Px2wR6JKhgZfFes5qSzb1/D5qTctXgrI0hOxBoCrqMSt7NIj8UlN3wiB9l1fe+eD/3b3e+cYhh5Q1Z9EOV1G6Fvff1/oc5ve/BDS9gZ5PZ/U4CdLl35oKiMJMxYHABlEElcAuIqLnGP92fCBA38fbG8nVRVMxMiRE8o+U6jplSB0SrEaT0VoMy8BYukGgTg6pXu9yhIAzcEB8nSC02VEf/abG59Ye2HjOqDsX6CecdVbl13437+58XHDYYxM8hzL+waKPqG0VzMEBwCZhFgDQPdnjz4WL+XJA/ffl5TNc6JHDqnbFAjAcBcWkpKhdJuWbMVYsr1SnyLxkTahx1HXlVXti/f0kB6c2Tmevt/98ea2soq8lar6MFUVlXmrfvOHz+zxuB2TSjKWCF/gIkHn4gAgQ1TPua0UAEi1vIVhjPo23PfEzhetyHBS9tWOHjmitNqYUVxMyQPklQAs7eh2nPT278jPOQIK87Mih4+R3uCvedvKPf4sN2nL8emQm+dd8qs/fKZ9kkWFcuIQ/xflncpwHABkCGFpxCFEXy8gnhMw2LZ9+Nj27SvU9exM8f6+MgBQtvbWXVoaoRyPEjkRkKUX6hLAopKTKi8/cuQQ6cUhFCqm7QMyjbKyPQt//LNPPCME0quOSvxQMNhcl4RuZSwOADIHae9rR1HRqDuJ9e18vF2a8TFzA6ZK2rYmTVNZNT5XMXlAgUcAWFqhjko5i0uU7qwYPXqUlE9QGShI64S5isq8VVu/eO3Dk2iqWwg3Ku9QBuMAIENI2w5QjneXlp5bTENCf89f/7ZUVZ/GYg1HlL3BGDl5pGBFgiQFSowlmyQG7+5SpW/gUfPUQAmlQWGBL+131Vu3ft4F51/Y+Pwkmr6/qurWXOUdylAcAGQKxADlcGdJ6TmJP4P7Wp+z4iOkJD0h0M4v9J+gtIn39ZKG7ce9vs9HzVWoUnVtxpSQtM+knps/5XK4r106Hj8spSTd590el7IVCEkk7vjy23OcbscwsZ1POLUPJqVHGYgDgAwhUAYoxzsL8s9J/Dn+17+Sa/W/94aLHr34DfPbKW2ix05Mds3uOTTDQXp7AYC8hoZbSHOejCVZNeVgw+/PVnVhMxIhJdE63Y5hITAjtg3WNFHZHL56J70lvld9bzITBwAZQkoMUI43cnLOWHZkm/GWkcOHSQlyHrdj6AMfvLA+WFdMSuobPnTQQzl+XAg5mttNWsc8bGmVyq7P2BS8UoAmkQ25XiMcDtLx44n39ZFG46qrCw5DBhXTunhD03nFpdlHKW0QoKkquGlusvqUSTgAyAjXagBAWhcsXO4zovjBl14aNSlwPJ/67GVPCYHF1QFaad/o0SP51GuNx1lQSOq7AIMDAJYWTg4WVQDhPqsZziFAVPb9GTl2jHR8sL64V9W1p4UEzy2b3tRCbSZAuzYZ3ck0HABkgJqaUAUAJJ6ZK/Q4ClH6+h/1Pfkk6a1C04R52RWL6wEAiotzSGVJYydPlgEAfZnOGJxFxf2U41HYnAfA0gJaSJv/L8w/AgrfwIePHCaNxtWHSqlz6im3YnVoic/nGqS0QYS3JKs/mYQDgAwgNRGgHO/Iyz0CryvfKaXsHT6wv4FyjqvfuvwpXRdlAADZOR5SIp40TZe0JWlYbjzO0jJa4Q8JPALA0gIC7bPoKiombYE9kZFjx0j5BHX1hcryd6YLIvrf/b7znyE2mxcIhJNSDC2TcACQCQRtCaCrpPiMZXjmQH8rNRP4be9c9dr/dzp18pykPTxMWjkwHldxAfVzyiMALD0QR6PcpWrfwGP9vaSM/rKKPNIOnOniTVcuoZYgF9IRWzXxYTMbBwCZwMYA5XBXSfkZhUQiXftJb9ButxEpq8j7RylQxGyvz3VuXYFxmMNDyoqZ6Fm5pCkIySMALE0g8bPoLFT3Bi5BDtrDUdJbbl4uedltWsjN8y7My/OR8heEFBwApLoDbGLkJYAlBWfMvw+1t5KWxV14UdMeADgjoq6qzidlE8X7+yi7+I1L97pJWYiIkkcAWFqwgZYDYOQpfAM3TVoGIAA4nHqm7qaprbu4qY3WBBclpyuZgwOADCABA5Tjjey8MwqJRA4fIg3hr72w4ZylQ4FAESkRL95H3oF0TKgbZUDaDxwrIYOWMrGZizoCoHm9yqrUWdEo6Tubk+PtwVH2D8kUa9bVEzcJ4qqhHABkAElMJNJ93te/vZvx/n5SMZ35CyvP2bq0tr6QNDc5cuK4yv0G3LrfR8kpcAYCYWVrqRmbNKTlowjdoBa+GpN56hSpBkCgppA8YpBOGhsrqAWUamCWvyhwAJD+EAFIFfyEy/XaW4S07GNg26StRXPyfOfchAI1haRlffHensT3P0+AI7eAtL+AcFicB8BSqrb289kAkPBDSbhcpwFRWR3+WG8faU+Bhrkl6obtUsCX5aJWMPTW1YUzouphsnAAkOaCwU0FAJD4vCCiRBSvZf5KyySuj0Wpa6Lg7J+XV+aR6pPHTp6kVQ+agLMg/zSpgeRaACzFHA7a/H9OjrKVMwAAsePHSYF/bW3JOfuHZBJdE8WaJkhBj5SmsrLLmYgDgDRnCVpSju7z9QDAa8Pv0jJJX+rcPO8Z7V9VkO8jzQ3GTg0WgsJiQEZBAakcMUha8hVjytmSNArlyM1X+gYePXGCVASopCzjn4V6draH9G8odVRXtjwDcQCQ5hAkafjfmZN7xlC5tCxSNr7LbYz6oHW5XOeMCozLNg1pS2XbAjty80iRvS14KSBLLZsYhDoK8tXWAOg5QUooLCzOUrYLYarohmZSjrdt4ACApS8JSNoDwCgoOHOoHIm/Ynv0ZHtNxyJd10nBhB2Pk3YiG48jO5s0nEnNvmZMNQRJ+u46C/JJD6+JxPv7SImw2VnejH8Y6oYg/RsKAaT7ykzDAUCaoyYAOoqKzlgKg0iLAGw5ZlasVlpG23XLjg7T5u3Hofl9pGJAAKAsm5qxSUHaZ9DIyVVXBEhCjx2Lkx7oXp8jI4sAvV5kcIRUR0FKS9k9KhNxAJDmJHEK4Jyhcl0nDev19AzlAcCoN6KS8lzSumLr1CniutyxaU4XMTtacgDAUksi6TOo+9UNwUszRh5903Ut0zPirVOnhklBjC4FBwAsjUnaMKKRm3PGroFC00lfiHgs7rRtOerNo7wsl7SuONbfpywJEAyDuEUqch0AllpIC0J1j1vZ0lk7OkIq3e1xOwYRkVpPP63Ytuy1bdqeJ1LqszoAmNXzH5kBSSMAhj/rjGE/1AR5b/HhaOy41+McZSlgPmlFQezESWWfLwTIE4YRtePxRIf4/MULbvYe2/2VSe1JEAiEc6QjtkqTokQiJr4VM5tWUkIMpTzsceqP7tkTJi15TToJpCAUHU5lS2etoUHS6FtpWe4JAFBau2O6DfRHDgIAZRQjsm9fWOnSy0zDAUC6QygffUB+dMLpOHstj0vP8h83T51OeFewzvbjJ+ctODeHrqQ0m/RGP9J7UmlSkZ6VdSLW05Nwcp8/4io5BrCPco1AIJyDuvklQPN9KIUhAQBkxu2QOmvgK/8TiZnRmuCW74xEtC2HD4dJI1VJggCEAABRoji3/sZkxU6dIiXDlVfmZXQRIACAffuOkkY9QMI+GGO6c7bgKYA0VrzgZi9IIC3lQaGdc9Nxl1ceopzj7w/tHTUwLCrOJn1eYid7lS4sNnLzSXulSylJb2DB4KZCNKzHAOGDAMBv/ZnFBSg/4/Saf2tqCqf8TTYUCucD4TOke7x9MEr9jcmKD5wilbgtr8xTtntnqjz693ZSDoVEIG4eNPNwAJDGfEO+Usrxmts9AKPM47mrqknzXH/ZvqcaRomM8wu8pBtUrL9XaVKRq5B2k5KCloRlg/gvANlI6xVLM+cNx+LfSnUnbNsiBZ9Gdq6ymhkAAGZvLymAraxUuwQxBewH/vc50ncXAfYkqzOZggOANCa1OG0Z0Rg3EW9djUY5z+FDveWDQyMvnf3zLL+LlCRkR6NZIKWyNwsjr5BYDTDxIdia0ObzJOJl5E6xtCMB31vd0JzSnd5sYvDpKMhTmowW6+sjLZstr1S3BDEVhoZGXuzrHSSNlkopdiSrP5mCA4B0RkwicuRmj3oTceYXBaiX3v6/u89JjnG5neQhfWlZypJsjFzi5Qk3YQS8nNoflraEZqU4mLMtWgCQr7YKYLy/l7RsNtOrAP6/3z7dS2xi6SAeS0pnMggHAGlMIu0tQsvOHfUmgpooN/LyDlLOde89DzUCwBk1BTSdvqJAmnFlbzZGTi5pWFNKO+F/PwlAWm7J0lvKS0ELYvCeX0AqdT2R+MAAaUVBhlcBjP7ohw8uoDRAgOfa28O0pMEZiAOAdEYcAXDm5oxZqjd/xSpSNvzxY6eK9+07+vhZ/fF4PE7SUitrJKbszUbzEG9SKBL+90OJs3o98EwjQKb05i6JRYAcObQE2wmMWNEoqf6H13fO6qGM0fLSoSdPDdAKANlS/i5Z/ckkHACkM0krJapnZ425TC97wQLS/BgAwJbP/6IcAM5IDiosziIlK9mRIdq8/Tg0B7FUqUy8EIuUMOuHA2cS28ZHU9oBYhlgzedXVwXQlj0gJWkVgK5rCS8TTjPx8OZfBqiNbLB/mYS+ZBwOANIZ0kYANH/WmMl+wu2eZ2RnHaOcr7vzRKC9/ejO1/+stDSX9GYVHzqtbGgTiVUNKQFUPDr4PwBwgNonlpZ2d7Vrj6S0B8TRO+FyKqvCJ80YqWR3JlcBfPGFg4/v7068NggAAAK+uL/9zheT1adMwgFAeqOtAvB6x3uLEPlrL9xL7cDnPnlfUEp4LcGmrIJWDtg8rbAmC0I2CMJuX4QA6uDBrw8DiA/AWSMeLOMMo5AfAAirK0M9OaTvrjAMv6oL28NR0jSd02WMAICykbrpYtuy53M33tdEbSdR/mcy+pOJOABIZ8S3CM3lGneOPGfJ4loUgvRGfvz4qeK7/+2B1wKHioo80o0iNjBAWoI4AdS9XkoxIFcgEE541KCz7fbtNtpvBoBZXR40g+0XAjd0tNzxVKo7AsQAAIWubA7eHDpNKtnd1zeU/+c/7U7tlMkkfP/uP+/t749QyydHrKjJAcAruBRwOiNOAQjDGPcmgppembN02eN9Tz6xknLe++/7++qr3rrssYrKvFXUcsDWwIDS5UWa3z9gnj6dcIEhdJrFAJDwkGh367/+saHhlroR2/kuAHkB0mqLs1RAOCIl/tUcHvzZyyM5qbVuXVjvPmQmXtZXCBMQlAUA1uAgedrt9i2/XrtqTf3zXp97vqp+JFN7+9Ed9/3okTXkhhJ+sn//F0kVRWcyDgDSVFXVrbkAQNvbWtPyJsr8KbpkQ1bfk0+Q+3P92++e/z/bb3m+sGjsPIPRxE8PkAqSTMTwZw2NwOHEG0gsAoAWyjVaWr50GgC+98p/jJF0d8fyQRcJj67qXm8/ACjcB4Bee8uybP3d13676Ff/77PHhJb46plUiEbj7R+9/oeLJtHURN36ivIOZTCeAkhTmlsnZeWirkcRcMIa6MLpnOufM/cZan+i0bjvbVd9ozgSGSG9XZgDp5TNbQIAGFlZpDc8CZJcu4CxqbB1QRqW1v1+pRvxWAP9k3qxO378dPHHP3RPr5SpXUI5HtO0D7/72m95ItGRSSQtyv/s2Htnq/peZS4OANKUACS9EehZ/oQrYZVf89YsUjLdK3p7Bos2feb+5ZQ25tCg2g2BsrLGrHUwGmGjsi1WGUuEhrSgU/dnKd3GOHb69KSn3XY/2z3n5ht/0ikVlvBWxbbl8X9653dHjhzuL5tE84gpjH9R3qkMxwFAmrIsmxQAGP7shN8iUNfrii65dFJJP5HhGG0/gOHhbDirouBU6Nk5pHNJ4s2YsamybSB95ozs7KjK65uDp6Y07fb4jtaFn/jgPd22LZVuUDQVpmkeeM913xrZt+/YJPd4kHceaAkT5g5nBw4A0hRSRwCyc0hvEfmrVs3XPR5q/WwyKaWQtiStSx6P4fOSCpxI5BEANr0E8TNnZGUpXYJnnjo15e2Qn32ma+67rv1WJBqJkZcOq3ZqIPLc1Zd/zd3VeXKy5Z2fy8s6cZfSTs0QHACkKUlMCnLk5tJuIgi5NR/+aCcgJn8XMMtUNscpvF7S/CbaPALAphc178TIzlFas8A6PUTaCGgs+7tOVl224a7q55/d/xCMsj34NLAe/MsLD75pw5fm9fYMTjZJ0hQ2fmDXrh+Qpg5nCw4A0hQibQTAmZtLntPXs7OXFl962cPUdlS2GVc2x2m4PaT5TYm04VjGpkpK2giA5nOTRrUmYFsjtLr444lF4+6PfOA/Lrzl0z/ZHRuJk/YTmYqhweEXPnbDD1s33/LzdZZlT76WCMp/3rdv6y6FXZtROABIUwi0HADhm9xmXnkrV65wl1UkNTPWGomqW5s9QbGjsyEATwGwaYXEvBPNS1taOy4JA9KewgNzDDseaVl4yfl3BO7594cesSw7aSWzYyNm+3e/sX3Hpeu+2PTcM91zpnQyxN91tt5xp6KuzUgcAKQpScwB0DyeyX7pXdU33JBl5OSQ9gmgsCMRZXOcQhO04U3JIwBsutFGAHS3y6nqytK2lS4pfD3LsrX/+N5fzr9o1e1lX73rD4/3nDz9FKgpnR07dnTgyW1f+M2TF6/ZWnffvY+skcTNjEbRgmbsekjN1EXG4EJA6YuWBOjyTPp3iUKU1H7ik+3tX/uK24oMK5k/fD1raEjdhkBCow1v8hQAm2aIMp/y/BJO5+SG70ajcLptLJZla7/++c6Vv/75TsjL8/W8+eplL1186VwMBIqqNE1UAMCEf3nLsg90d5/c/9BfX7J/cf9j8wb6I6TlxeNBgEOWgMu62+5KWjA0U3AAkLZkQQLfo9eg0zmlkrtCN4K1n7jx2favfaVRmiapAuFEYgOn1W01huhDTYtJy0r078tTAGxaSYmkoBMVbgRkRkemtRRyb+9g/o9++ODaH/3wQQAA8Hicg6GG0gPllfmny8pzR7RXxiVjURN7egeNzn3Hs9vbjlVEIiOVADDZrP7x9AiJl3a0bO1MwrlnHA4A0hZtCgB1Y8old3WPZ1Hwps8+u++b36izR6LKbkrWwCmlGwJpXm+feepUouVKXcULbvYe2/2VtCtswmYsWtCJmKvqwlZU3XTbZEQiI75nn+ma8+wzXam4/EkU8rL2lm17UnHxTMQ5AGkpLACANBQvHPqU1/4CAOhe76L6z33umCM7+6iK8wEAmJFBQ9W5AAB0n59UqtQ35ORRADadEh4BQN0YSaSEd6LsoaFZup217AIBa9NkJ8iMwQFAGgoEIAuIvxsEoewmInQjWPupG+OukjIly36swSFlSU4AAI7sLNLbvCW4FgCbHhUVN7kBIOHRON3rVlYkCwDAHBqefUlvEp6ScWNVZ8s20qZfjAOA9OQCUqIbIkpA2ojBhOfU9Mqaj3ykvOjSjY9P9VxmNKI0ANA9PtJ+5wJ1DgDYtHC5solLAH1Kk/asyCDpnp6zeOkTrorKzN0gR8LdGgys7eoKKxuxnE04AEhHVowWADidpwFA+dpfAHDlr1q9svYTn3pUuFyT3iHMigwr3RJY83hJVb2kbfEUAJsWlhYjLgF0K90HID40RLqn+0LB4ZobPlhdesWVj+J0VAVVpx8kXNvZvu0T7e3fIr0QsH/gACAdSUEKAHSPN6nbdzoLClaHbrk1mn/+hY9NpnSwNTKsbBEAAIDm85BKp/J+AGy62CZttElze5UGAPbQECnfRnN7AQCcOUuXrq7/3C3POktKOlT2J0l+Aqbd2Nm+7Zep7kim41UA6UhADqV8he71JT3DHYUoKlq/vqhw7dqX9t//Uy3S1RlKtK0djaoNADy0AAAkbUqFsclCzc6mfHc1r1tpjXpzKEJaDqy5XK+NHGoe7+Laj3wsPtje+tChX/5ysR2NKq8JMkUvIIpPd7Te/pdUd2Sm4BGANETdw17zeSPJ6svZ0OmcU/Xe60mFS+xY3ANqKoa93AeXk1QlDBGULWlkbHwym3I0ur1Ks/at4SFSDQ/hcp49YmD4gqELQ7duEhXvetdDmsfTp7B7kyIB9gDi9Z1tLYv44a8WjwCkIRvsLCQUAdL9/mld+4so6G/0EgYB1byJ6y4PtUxour3JsBkKQfgp1WcN6mjWBKj5NsLhGHXEAAF9/vqGC/2f+/zpoe7uh48/8KfS6OFD9Wp6SYDwf12t+hsBwkr/ndjLOABIQ0JgjiRNAdCS4qZsEm/U0raHUKPlNozl9cOWiV0cSG9ljE2enUWp4Kl7PUoT78zhCC0414zxRwwQ/d5A4IKaD30Y7JGRPQO7d5/s3fl4IHbyRPVU+pkwCSY//JOHA4B0RJyz1n1+ZbX2E72kcBiRV4b2E2NbEdDUzDgJh4OU6IQ8AsCmCQJmUZ7o6JpSBe9z2FFaBU/N0BP+Dgunsyl3+XLIXb4cpGV2RA8dPHi6vV2LtLSVDh8/WgNT38BnNDx9l0QcAKQhCbQAQPO6x77nSDkkpewDab92DArNAYg5ADDp9fnC5RqkBADSMqNoqCkIiA6D1G+bAwA2TWwJWZSnoHB5VOZhxaj7eEhA32Se2qjpte6qQK27KgBw8SUAABFpxo+YQ8O95sDAsDkSkTI6Im0zjqjpUvO4Ubg9In7suHX4979dl/B1OABIKg4A0hFiDhDmAHSvV0jbPhjr7dkf6eqOR/bv90QPHyqK9/eXSDPuBYBRhwWFy3XKVVx60F1R3u+pCcQ95ZW5wu0OAcCENxHN6Y6YcDrhPtrx+IhwqSkHgBotAOARADZdqJ81zUmczhqHtOVpIJQhBgBAgaoesB7UjVmGFGMAACAASURBVDoj26gzssf+JzCzs0mleqVUVyaZnYsDgHQkJWkEYP+Pf7zcjsXcAFBBaWdHo1mR7s65ke5O6NnxdwAAQE2L+RvnPJ234rxBZ0VVUAhRNlpbzeMm7Tpmx2LK8hSEhsTtU5EDADZNMIuSBKg5DGVzACitIaDsQ6BpMZByBBDVzkOMQ+g67VooeQQgiTgASE+k3cFeefgrIS3LcWrPC0tO7XkBAAA81dUvFVx08QlPVaARBRa9epzu8ZCqb9kjI8qWO0nUaIlOfBNh04a2DFAYo2fhT4Zl2aTlwNKyHHvv2Caz5s9/Mm/V6pirsHA+YJKDZaFRpx35u5tEHACkIwnZhETipIp0d8/Z/6N75iCi5Qk1PFFw/vkD7vLKJZrHSwsAolFlmbwoyMOCvAqATRfaA0vXSHP245GmSa4qKM24c+CZp5cPPPM0oK5HcxYu2pm7apXlKChYoHKXwlcJTVBfVrwv747KKwGSgQOANFLeuCnfsPUNIGVhqvtyNimlNtSy97yhlr2Auh4VDkfClQABAMxoVOVyJyfqxog044m+TXjWrQvrDz4YnqVbpbLpI7MpywBR19WN3sViU6qJL03T1bfrqRV9u54C1I3hrPkLHstfvTruKCxYoioYkEgOeLChIeJtaSEkHLGEcQCQUtdq1cHG8zQBG6WUl4IFywBkMjb1UUqapssiZhtbkajSMQ3N5Rw0BxMOAKD9BGQBQK/KPjB2LuIQ+mSKao3BjEWV5dlIM+4eeGbXqoFndoFwGJHcpec9mrd2rUv3ehfBFCrIIo6ekDyeCHj8ABwAJAMHANMsGAxXWGBeCgIvBZCXgJS5lKI/mcoaGlQa2Ai3awgGBxNOeNItDgDYtCAFAAigbph9ZCQpw+R2LO7peWzH6p7HdoCRndNdvOGSvb658+ahEOXkkyF6ANEGKRMOInQwOQ8gSTgASLJAIOwSDnOttGEjIFxqgTkPAICyzG8mMIeHlQYAussTodQ/RhnjlQAsqQKBsAvATDipTxhGFBJYcpsoOx5P+jx5fKC/+uAvf1kN4rfx3KVLHi+6eL1HuN0LCKdANIyIjMUSHglA4CTeZOEAIAlqGzeFbEtsBMBLEcx1UoInXZL6UsWO0LYpnYhG3EcdJS8FZMmlaZBFeQILl2sQVAYAI1NKASBezDT6nnxiZd+TT4AvGNpdevWVcd3rX5pIU83lHDIJAYBtcS2AZOEAQIGGhlv8I9KxXkh5qQS8VFpQM8uf9+cwI0OTrjo4GuH1ETdA4gCAJR3pMyacriEAKFB1cVvdSluSwfbWBW1f/jL4587dVXbVW3zC4WgY73jhdJBqiPAIQPJwADA5WB3cskgD+1KJuDFmw2oEMORsf80fz0hM6QiA7nGT7nbS5rcIllyWiPmQkB+nu2nFtCZim7GU3oBOv/ji0taXXrILN2x8OH/VyqWAOOpbvu5wR0nTdyg4AEgSDgASFAxuKrRR3yBRbgQJbwCQxZnywHe7jYjh0GMAAGbMMiLDiQ+/qWLFTaUBgHA6SRsgSQRi9UDGaKTU3IiJ5/ag06V0F097ZCTlNyQppTj+wB8v6Hty56HABz7Qovv8S84+Bt0u0ugdf3eThwOAMaxbF9b3H46vlBI3goRLLYQlAFIQqnxOOyHQDjaUdqy9oPHoqtVBWVtbXOh06+WI6Ac440tkWqZ9qKd38PiLz+8f+vP2F7P+/lBLUzyW+LI6Kjs+orTcKOoO0m9CSL6JsOTSBHokIblXGIbSMXtrZETlxkJTEu/rLW/76lfKyq68+q/ZixZdCACvJQHrLjdt+k5KZbUS2Jk4AHid2tpwldTNS6WEjd2HzPUA+HIFuZTH1WMrKc058qarlrZvuHS+Xl6RNwcRggAQnKCZrumiuqgoq7po/TxYt34eSCkHD+7vefpn9z+Of/j904tiI7R1/hORZlxpACAcBikAkGhzAMCSStqWBzDxm4VwOtRO2sdG0quGiJR4+Le/vniwrfXpsmuvCyBAHgCA8HhIIx8SOABIllkdAFRU3OTWXf4LQNiXooSNEsw5INP6eQ+aJqIrVtc/f811ywcXLg4Uu92OOQBQOtXzIqKvsrpg1c23vgk+e+sbh7u7Tjz5kx/t0B744+4FpmlN+XNixxNfHpUIzemiBQA8AsCSTArwEGYAQDgcpGmsiZjREdL39C3XrXj82JF+92M7WufbduLr8qlO7XlhSfTY0a7aj36sHzW9VrhctMBHIgcASTLrAoCqULhWA+sSALgEpNwIYPvTeVgfAKCqOv/A5Vcs7rroknl6eUXuPERcnszrIaA7EChavjl8Ndz2z1f3dXQcf/Gef3/Q/eCf9yyWUk4qPiKU7U2sjwb1foVKRzQYO5uwhVcSIgDhVBsA2CO0AODa686TVTWFC21b9nZ2nnjpnn9/0P3QX/YsSkYwEDt5MtD21a/01X38U89pbjetXoHg726yzPgAoLb289mgGeslyEtB4qUgzepU92kibpdjcM2FDc9dceWSoUVLa2p1XQQBoDIVfUGE3Lq6ojXbvngdWKY88swznR0//a+/F+18rL2ech4ZVzulIIibqOEYGcmMqSKFdFNeJoRBy2OZiB2Pke7nhksXAABCYN7rv+PPPtvZ+sPv/a3ouWe656jsnxWJ5LZ9/ased0lJF6Ud8uhd0szIAKC8cVO+w9SuQpDXSMT1AOAAwLQd20dEOX9BZcuV1yw/umpNfW52jmcuAKxJdb/OpulYumx5bemy5bUwFIntecP525oSbStfLv0ZAwAlUwFCN2i/Tck5ACzJiA8qNJxKK/dJ4lJbQ9fOuf9rOpYuXVZbuvQ/amEkGu/4vz/uPvrvd/95Tl/fEGmL8jH7aMadkYMHxq0TcG4jzgFIlhkVAATqb1uEID4NFrwdEJzpvEwvN9fbs+Gy+S9ddvmieDBU2ig0bASAxlT3K1Eet0EfkZByBBCVBACo6aRhSonIAQBLKinBQ8gBBI2YyDoRayRG+m5pujZu0qDTZdReefXS2iuvXhrt6jyx487bf1vwwm7iw1sFoa5aIjvTjAgAqoNbFguUXwKAS1Ldl7FomjAXLKx6/s3XLDuxZm2o2OtzzQeAtanu12Th5B7kI0DdL30MwuEgBQC8DJAlm0D0SMIcgHA4lQYAMjZCyrNxGCLR+78rUFO45vv3fBB6Tp5+avPnfuZ7fvf+6XtZkcAjAEmS0QFAIBAuQcP8IoB8D0xhi8pkKSzMOnjFVUvaN75pkaO8PLcJEBenuk8KOQFAAmFixZYyJiivSONAbfy3l7NxMRGWbFLapGWAaKi9/drERFshzp0CmEh+gX/Z9+65wd637+iOT3/03obenkFlpYzHxqsAkiVjA4Dq0OarUZo/AIW1tKfK6XYMrz0/9MKbrlh8auHSQInTacwFgIpU9ytJUNe1mGlaCY8EoG3HQCiK0zSduuaZAwCWVBLBQwlvNYeudI7SjsVIQ+WahpOtzinq6krW/P5Pt/R+75vbd9x37yNJzVeSnAOQNBkXAASDn3RakP0tkPDBVPcFAKA6UND+pquXdl10cZOztCxnMQAkdYleOnEYtAAApCRu4DM2YdBGAJADAJZkAtBDGdNHg5jIOgHbpK20EdrU8nEQIe+jN25Ys+HyBY99+H0/WByNxpMyV4/IUwDJklEBQFXVrbkW6r8GgHWp6oPH5RxacX59yzXXLR+cv6C67pUlehNV3puRHE49FhlO/JluSxlXVaoMhSC9vUjgJECWXJIYZKLmUBkAxMG2Sd8JgUJJQm6wvnjV77d/fs873vKNop4TpwtVnPMsnASYJBkTANTVba60BW4HgGnNQhUC7fkLKvdecfWyo6vXhLKycz0LAOCcDS5mI4fLoL3RW6apaBUgSKERhy8lBwAs2WgBgIM8jTU2KaMAQPpOoFATAAAAeD2Opt/84bMHbnjvD/a17j1cp+q8L+McgGTJiACgri5cZAtz2h7+efm+42/YuOCljZcvsIKh0rkocC4AzJ2Oa2cS5ys7DCZK2pay2udCkOcvUxIAVDc012g2LJaIk85VQSlPmqg/u7813DGVvjQ1hR1DI9YqFFAN/FZ1BikhJvD/s3fe4XFU5xp/z8xsUZdl2ZZlSVaXZbkbQnMjhOBQQodAgEBCGrlAKAnFMtnENi2UJHBvciG0JECAUBKSQCAYY2xjio2brF4tq1pd2jpzzv3DONc2lrTf7pnVSszveXjujXZOsbQz852vvJ9o9ruHNjc3Pxxam16BGErlsUJMZB1xaQEvyBU2wiFTHEVVlcwn//T9wZ+vennH2//atUDaxFYOgGlEvQGQne1K5or+Fkx8+auqEpi/IGvXRZee2Hv8SfnpsbH2WQCmmrXeRMHpsNGaeuhcnvQpvQzRtE6HxyI/f3WJDvEbxvFlAQCELnFHIwCoQkdu4ap3Fa5cX1Ozpow4BcvNL/2x26+vYgyTo136eixgOPgnssXEDeYWlj44KaFj3bZtj1Hb9dKy8IlaFiMjfNQRjDHp9wRjLN5190UlMzImbXr6iffklDlbOQCmEe0GAGM24w8A5sueODNrctNZ5y6u//LpJVp6evJcxthi2WtMdOwOjXSiF3pAogFAdl9KbUY0Enl5q042mHiTSdI8OIQQ7FSDiQ9yC1edWVe1blOQw1hOYekfhMAVMvcygYkXAj/r7p9y4uLF3zuHZAQw4nfsGEp8IWMYJG+cpmkGDmvRKxnbd6877ZTpM1Leu+cXry6XMJ9lAJhEVBsAOQWldwLiHBlzaZoWWHFa8a4LLzl+aPacrCxNU7IBZMmY+4uKM4bWzpTrujTpU0Y3AEIteSKRn+9KNBT9ZQi5L//DSBCCvZybe1thXd19faNdnFO4+kcQwnr5k2FndPdNcwFYRRhjB8G9wpSghXhGhXOaB8BuU3wwNyzGzj534fK09KTNP/7hMyeH2kTsM2Kz8u+Y3VRzz15pu7MAEIXiOYfIK1p9CoCfhztPfmFa3f8+/b2NG7beNfTzuy9ePG9B9rLPXv4WYeJ02sbMAAAju/SVxYu/Z7oRYLDA9yCQZvIyU7li+8Hol12sAoLwArM4AiZuys93JQY/gJOMUnoi6/AwbpDCFU6n3Str7ZE47vjcU556/gdbVVUJx/unqkx9N3fW6rnSNmYBIEoNgJISl11wPIYwXFSZWZP3/fnl6z945vnrcubMzVjGGJIlbtECgN1po93UMg0AwAlG6b4ONAcSTQ8DMIYzzV4j2HVyC2ctioAxMpGJ0RE4NfjLaXkpISSyDosQtPwam1Oh5jeETEHB9JP+/MoNH2s2NRwdkKnCEOuzC+6Ul1xoEZ0GgNuv3yYgQsq6Z4yJH954xrt/fvXGlMzsKSchansAjn+cdpoBwAPSdIAAQGEqrQrB0auZbgAIrswwe43PGLUZE4eI1F4mLExhFCVPao9qad9HwTnJGHY67FJvxtFIz0g58eXXb9rlcNrC8TykMqaszy1c/YURWzObqDMAZhaV5gC4M5Sxjhi758+v3vjhFVedcioAq/+7yThjaQYA42Gkwh9rPgWk9VVVXt3z8Ih+89cAAIwa/1cZIrWXiQsn/T1pIQCmSNQBAMm75oyJrAEAAKlTEo975fWbq2Jj7e6QJxGYJIR4+7MQ8YRh2rxb4zIKV83IKnTl5ubelhSpdaMuCVDh7JeAINcox8bYh15785a6uPiYE83Yl8XncTrspIcO8ZASBIy0vqrazU8EZPgAwHHmryO2jHaJCAS2QbX5EcEKiImGodg2Ey4n/Z6ZxAOYIBrXMcQSXlkkp8TNe+lvN++4+JyHCtwef6iHtCTOxZvZ+aXnNNSs3SBzf2ayYoVLa2rSc7iGEoWLWeL/9WVy4cGkg1fpEKoNOQWlPgDlAmI7mPI29wb+1dR0b4/sPUWVATAz765TAX4hdZxmU/0v/u2mqrj4mInUbS/qiXFqtJi+MOSGY4iJRX7F/BehIYzfqUy9DuaVWAGAoRjit6NdVFd3X19OYekfIfAdE/cyYRHAP4niSzQDgElqjQmAKjSh2VWZ+TgkkifFLnjtzVt2n3/WwzOHBr2EJMsjiGcM/8jJLz2/vmbtW1I3GCYlJS67xzCKhI5iAVHMFMwGR3Hjfr0IKuxMAIKx0QpGHAAWMLAFEOLbqkPzZReUvgKwXzdUr/lQ1l6jyAC4WFUU/qtQRj7yu6u3TkqJWyZ7RxYjY3dqtCO9kBsCUJhiUJ5iTOimiwE11dyzN6dw1V0QbJ2Jy/y8tvbuPcFc6FeM2+yGcirAck3cz0SkE6r2o+AvdymATn2eSlQC5KQXuqIoY2YAAEBcfMzcV9+4peKScx7mvb3uUBO0Y8Hwt9yC0ovqqtf+XeoGg2DavFvj4odiZnGGYgExW2FslhAocfv1XAAa2GcJaKSm6cPiYMBlgLgsp2D160zVb62ruKcq3EmjxgDILpj1XUDMo447/+IvbZ23YKb18h8DVI1mAAguOSGTWAWgSEy6Gon6qnV35xau8grB1kKuiIkHDKvrq9Y+GOyA/RX3dOXnu5briv4CEzhZ4l4mLgK7oeLihgpXQ7BDsrPp3iXBmCLthiCGAFRVGXM9yLhYx6yX/35L5YXnPMh7e9wpIU7jEMDLuQWrLq+rXvey1A1+Rna2K1loRrECMRuMzWKClwiGYnjYTK4c1DdgAAREhFLOxTnCUL+SW7iqtK5q3cOgiE8cRVQYAFlZt09iEGuo4+Linf033XpmtglbsggCVaG9gLkhTwgQAKDQQgAsgrHwuqp1D2UUrnpBE/gmE2wRGCaHPJlAl2BiuyZsz9VUu5qpw2tqXM0AlmTnlZ7BGM4GY9kHdeAtDsGECAiGfZzhzcbqqr8BL5G+W5oGO/XbzQQUWS8MwQ2qATCmHoBDOGNsRa/+45a6Sy74tdHZ1h9qJ0G7APtzbsGqq+qq1z0f6l7y8lxTdfASlfFZAmI2GIoBNhvQp///n0kcdN+PPTFCsAdzClafHGtXry4rcw2GMklUGACaQ/uZAMjNUu576PJPVU2RITU5Fhi6ru/v6/V09HQPeQEga+bk6XaHLRfjpHRRVWk5TIqQ+8yhujEZVao1TJqr1u0HcH8k1xwB0VC79k0Ab471RiYiigI77RUMAEKVdaszQTsFahrNeDcTu8OW+9JrP66/9Pxf8fbW/mkhTqMJsD9mF6x2NFSveXqkC3NzXVlC0WcJiNns4Eu+GMBsDn2ygkPH6XHxCAYgLnT79Rm5ubetDEYZ9GjG3ACYWVBaLIDrqOPyC9PqFi7OjnqXpqGLlv4Bd3tLc/dgTVU737t3f0z57uYpjU0HZugBIwtHyREvOi637N6HLhNxcY45Y7TloKEaAJwUsR8dwWhVALoemRCAxRcPD4OdmBEDyM0BIK3OlLEPARyOzablvPjazQ3fOP9XLa0tvekhTqMyiCeyC0odDdWVv8/PL8o2IGYLhmIFKBZgJQBmCegJAMDGzUt+VE4Uqu3NjIybvkztZDnmBoDC8BAEXaf9oUeu7AYQFYlNnIuuoUFvS3trb19NTYdeXtbs3Fu2P6W+tj3D4wmkAwj6C739k7qSs0+/z/vCaz/+eOrUxKgWvFCIEUwBLjkHgOYBUBiPSD8Aiy8emj9gg0b8esusAiAa16o6dlUAw6FpSvafX/vx/isverS5qekARYDpcBQG/DanoOhXBuA89JqPKmvHHE60OeOeAvANyqAxNQBy8ledA4GV1HFnfX3xR5NTE75kxp5GwOv3BfZ3dAx07Gvs9NdUtyuVlW1xu3Y0ZnZ1DkwBwojxHoXfpzuvvOTRojfeub1dUZVQXWKmo6rE5xeXex8yYg6CENEnfGUxMTBsNlUVpNYYwBh6AFQ1ekIAh6Opyow//eX6/Vde8mhjY0PnzBCnYQDIWjLjHoZLc/JL366vWftEsEPGzAAoKXHZ3T7jAaptptlU/0/uPGuqSdvy+LyBfV0HBrqbGjq9ZXtbtb27mxOrKlvSu7sGUwHkffaf6QwOeBPfenP39pVnzY9aA0Cx0ZyeXNelegAYU0l5V4pqGQAW5mDnOgtB5UKeAUCuAlCj0gAAAFVlM/744o86v3PFYw3VVS3ZY72fcQXDwzOL7/xnY/ndrcFcPmYGgDugXw+GQuq4m39y1gc2myYl8c/rCVRuWL+39f0N5UmVFS3T2lr7pgshyHsyi7+8+FH6yrPmj/U2hkUlezDDagn6ORSiG1NwYaY4j8UXGM6hhPA6l2eQElU2yd67CKOqypQnn/0+vnvV/9ZVlLdERah3nJCgBJSfA/heMBePyYkoL881FQKrqeNSJscf+PoFi2Wo/fmefHzDpq8sXVu45q6XV2xYv3dha0tvepg9q6XT3toTam1sRKAmAUJyGaBQaPrnIgp7X1hMDISN+N06qGEhTwaA1gwwasoAR0JR2JTH//D9xOI5GdVjvZdxBcM1+fmuoHIoxsQDwFlgHcDIDQ8e+PU3yxljS8NcXty79q87X39125Iw5zGdhISYIYRQHhkpNOK3hximHB1G9AAolgFgYQ6cQyF9uRgzIPH5K4guACUKhICCQVFY6mNPfVf50bVPVOza2TRrrPcjA7tD8xYWTW8smZfVtWBhpj83L805dWrCFLtdSwVjTr8vsG/37n37f/Pgm5k1VW2heD80A8YPAawa9cIQJg+LmfmrF4KJb1PHzZ2XVVFUPCPsDlDle5s3vf7qtnCNiIhw8pKi/QBCTYSJALQDDOdyqwAUYhKgaiUBWpiETTDFIHwdGbGEdTQUmhIwNG383AqKwlL+54nvaLfe8OyurVuqyGqxY0VcnHOgqDi9acGCrJ6SeTOM3Ly0mJTUuDRN0zIAFA03zu6w5S8+Ljf/meev0z/YVPnebTc/v8QwOC3AxMRliEIDgClM/Bp0V6y4/1eX+0IYd+QkAr0/ueHZ2eHMEUnOu+i4qL5LFWIckRmSmwERhYCsKgALs+AaSM2pmUpLYB11fWIIgI1xLwAqjLHEBx+5Iu+uO//yyTv/2mV+t00Cycmx3cUlGc3zF2b1zZmXxbNyJickJ8anqRpLB1ASxtTaSUuKlj/38g0fXHbBr0/gXFCeXzk5RXfOq6+8e9eIC4SxOTLZhasugQD59H3pFadsTUyKPSnc9V9+4cOdPT1D40I5MDbWMZSRmRK9GYAAVJrTk9qyfHQUaghAYv91C4vD4IahMoJ9KSSXppOVAOV1IYgkcb+4+6K5iYnOra++9FHE275Pm57UNntOZsu8eVmDs+dmICMjJTExKSZTUdhkAKbla2Vkppx0++pzN9z989dWUMYxQ10CIDoMgIyMm2KYYGRZVEeM3XPd9adnjX7lyPh9gbpHHv5X1CsHHuL8i47fCUR38xZyEiCXm2TJFNpDT7E8ABYmIQQUSlEMY7Q+FqNB7bOhadFbBjgKjltvP/v4SZPitjz52LtmPB/5tLSkfSXzstoXLsoenD0nXU2fPik2ISk2mzGkAUgzYc1ROfOchcf/9jdv9/T0DE0KehDjowrJRcwA0JyxP8FRsrfBsOpn532kSdD7X+d6rVfX9XFTTnLRpSeMuUrjaDC6FLDsEIAlBGQRFagqI7W6YCqTagBQE2ypjbxMQtd13g4GoanKdASvi6B+5/unnhQfH/Pebx76Z0jvBk3TAtk5U/bNXZDZMXdelrdo9nT7tKlJKTFx9iwIzESU5V4xxuIu/ebJ23736NtBd74VjM0d7ZqIvGTy8lZlcsZuo45Lm57cctrpc8KO97Tu7/nw32/tPiHceSJFQmJM79S0pKh2/wOAShUC4HJzABixCgBWFYCFSVCNSwWSpXipFTZU751EDF20PP34u3XPP7t5kccTmAEcTJi78polO7551ZLCINVP2aXfPHF5ybyMjTf98OlFbo8//lgXHZ5xP39+pj+v4LOMe4ctCwel5I88FEaDWTQMK04t1n736NvBDxAoBlwK4Br2uxYRA8BQ2H0MiKWOe/iRKxsBhBv7999645+mhzlHMHBANAGoBkO1EKxKMF7FwBKZYH+mTHTJ5SftARD1ZYpUKXMm2QOgEGuZLQ+AhVkITgsBcKKGxejrE6sAxqgMcKDfs+vic381c6Dfc8TzbWjIm/C7R/+99MXntna98Ncfl8fG2ouDmW/O3Ixlb72/qr+2qm3T7l3NBgCkTU9EXv5/Mu5nYISM+/HEtOlJ1PBDbFYhspuqUDfcBaYbAHlFq0/hXJAaFADAcSfm78rKmRJ2oseWjZVbGuo7V4Q7z2G0AqiCENWCoVowVNu4UgX01tTUPOI7+uKcgtW/pJqV5164mGwsjQWqSsskkl0GSO3LbeUAWJiFKqBQvt1MkZsDwIjetbFQAuRctH/jgl9nDPR7htWA6e4enHz5hb82Xv3nT3oZQ3Iw8zLGEvOLpi/JL4rEOW/ssDtsmZpN9esBI+iupioPlABjZgC4FG7ov6L2XVQUxu/+5aUawlTK4lx0uEpfDqWjnhvALghUgYlqCKWKA9XxDrW6rMw1SJiHAeISysIpKfFdk1MSxk2t63hCSJYitrCwCJ6/vvJJRW+Pe9SYfWfHwNS33ti14Ywz562IwLbGE7aCwrTq8rL9BcEOYAfLEF8f7nNTDYDcfONqwUCO4V/zvVO3xMU6wnaBP/7b9VVDQ17yPEyw6+tq1jwZ7vp5RatP5lyQEh8v/9aSvQC9VHIsMAyi+pjkHuSM1v8EgslNvLKwOITBaL2uBScKu4w2H2j3lmFEPAIQePy37wR9sPnjUxuzzzjTOgcdzbyF2Z0UA0AobEQdAtNcovn5rkShiHXUcbGxjoGrv7M86H/gcAwN+fb88amNdOVAgU/qatSnw10fALjByaGPs85ZmChj7UjAiT3IheTEI25wovqqbCECC4uDMGJMX+Fyn72M6NLXZVfkjMKBzv4dfb3uoEvYGhs6swCKtNIXgwULM/2U65nAiMJ3TXhpggAAIABJREFUphkAnBmrIOg1k2vuv3i7orBwW+Dy229+noXQ3EcoQtw4UtZk8FysQmEXUUZMTUtqS0yKGbV0I1rgZA+AXPlTIQxiHaJlAFiYA9W45CB+d0dbn1qSq0f2VvjLCx+RXlyKohqQ2C55olBQNN1JuV4AxcDFw/4eTTEA8vJc+QLiRuq4mdmTG088qTDsxL+aytYt2z+pC0WC8bna2nVbwl0fAHILi1dQDaCrv728CuOoY52hE92ITPL9TEwqtDwAFmZhGBQVAEAYkltTM9pjQ5ctyz0y3lde/Ijkz58zN6PGrM2MZ1JTE6iH6pi8vJKc4T40JQeAK/qDABzUcQ8/elUHwhRgEEIM/uTHz4YSQhgMMEHWKhh2H5xfSk1hPG3l3Kjt/HcsdKL+OCSLjwhO+w1zywCwMAmqcSmE3BwAheoBkKzKORKt+3t2DA15SQe7C79xQjuAoEoBJzBDbre/qbW1u7u6oj2we2dTzI5PG8necYMFSgAc06CSbgDkFt51mhD869RxK06b/em06ZNCydg/gn/8dfu2jo5+ujoUE/c0V63bH+76ALB48fds3f24gDImM2vyvvg4x7j6wnNqIpFkA4AZOukhyqwQgIVJMIUWYGJhVjgdc0YCgQjmALzw/Afk+37J0sKw5d/HDUL0uT2BltbW3u6Kvfv16spW+64dTVOrK1tzOBdhvxMUhc0G8NdjfSbVAFixwqU1NusPU7/aqqroq39x4TGVnCjout70wH3/DCGEIOqE3/ZQuOsfoqc/9asAJlPGXH3tiloAmbL2EAmo4mMK5OqP03M8aG5aC4tgUXRwSkqqMAy5VQAkGSIAROGgMBj6x6ufktz/c+dlVdgdtllmbWisEAK9gwOeffuaunrr6zv5ju2NsXt2Nqbta+rOEEIMq40gYd1hw+FSDYDG/foPwUBOYrv+ppVbnE5b0BrHw3H/2r+3BfwBsuXIGW5tbHB5w13/EIIpl1IlJVd8uThd1vqRQtdpIQDyQ2oUqG5MKwfAwix0RSFl9QlBau06Kgoxvybgl5uEOByNjZ073V4fqWnPKcsKOwGMVwNA6Abf39s92FZf1zFUtrtF+XRHQ3LV3v2Z/X2eZCA4cSPJmG8AzJh1x2QYcFHHJSXHdl/0jRPnhLt+d9fAp/94ffuX6CPFO41V614Nd/1DZGe7nBD6uZQx+QXT65wx9kJZe4gUOjGTmMluQEKsArByACzMQiGGACAkJwGqtOk4UUMjVF740wfkf+fvHv33Uo/bv/m71502jzGWYMa+JKAHAvq+zo7+job6Ts/ObU223bubUqrL27LcXl8GgIyx3uBhZA/3gTQDwK6rPwej90S+7+Fv7mEM4Z7+9Vtu+FMolpWucPHjMNc+AsWmnykAUi3/Vd9Zug9HN6UYB3CDeAJX5IYAGLGW2soBsDALFgAnvdIPhq8EJOUCMIU2jx4w3wMghOh/4x87Qmpq9syTG095952yff/z+2trJ6XELZC9NwJer8ff1Nne11VV1e7bvavJsXNH05S6mvYsPWDkABg2wz6KGPY9L8UAyMu7cw5n+D51XOGs9Oq58zLD7un8yYe1m6sqWumJf0L8rrb27j3hrn/ElAxk9/+y5bOiyVoMGoMYAqCWKo0GN2gPMSsEYGEWigJqTQwAcEiqdWfEEIARgSTA2tr23X6fThdj+4ymxq7Mc756f8Y131m+6ervnpqnasw0sX8hxKDb429qbe7prqxsNXZub4rZs6tpWvO+rgzD4OPOO3sEDJXDfSTFAOAK+1Uocz346BV94e6Bc3Gg9PYXQ7EQuwIO28/CWftoSkpc8W6/fjZpzNzMKptdG5dfME5uQSr3mSNAUwKEZQBYmERABaf1pgRwUOlOigHAifk1kTAAnntmM7kU/GiEEOzJ329Y8qc/bvL+4Eenbzz/ouPT7Q4tP9T5OBfdgwOefc37uvvKy1rFzp0N8Xt375ve2tKbDoysmjdeEUK8ONxnYRsA2YWl50HgNOq48y48/sOUSfEnhLv+H558v3yg30PWzmeC3dVc5uoOd/3D8fgD5wCM1Mnv29cuawEwLg0Aag4AIFkHgCgFLIQSkLm+hcUhFL/g0MjvVGlSt8QIAAyTdQCEQPc7b5WF5P4/Fn6f7vzNQ28s+81Db2D+wpnlF1x8Qvvi43MSk5JjMxSFTT3qcl3XeXtf/1D7vsaugT079ym7dzYllu1uzujpGZoM0EPV4xdR54nx/fdwn4ZlAOTnX+/QBR6gjtNsmu+mn34tXLlfeIb8lU8+tj4Uvf/ddTUV/xvu+p+blimXgpZcI447MW/cxf4PYRB7ASjERKVREVQDgFsGgIUp6HZbQOM6bZAQApIKY5hCbM2tm5sDUFHeXKbruilNzXZ+2li889PG/9TH2x2aNzk5ts/ptPl7e90JQ4O+eMPgMwDMMGP9cYNAI1R2ZvuuB4aGuyQ89zsSb2JAHnXc7avP3appGj1mfyTirjtf8hvEUyAAcKHcCLwktdFEdrYrGUJfSRlz3Jfy9mqaFopkcVTAiT3ImdwqQDBiKZUqBEmP3MIiWGIE/CFYl9KeQdQSW4OYwEvlD09uClvXJVj8Pt3Z0d5P0sif0DC0QeCPAYd272he7pANgJnFd04XOruTOi41NaF95ZnzFoW67iEaGzu3bNlUGUKCCXu5sfYX74a7/uewGeeBKH/8rW8v6ZK+jwgSCNDiiILJDQFwkvQKIFQrBGBhDpzDT8/nl9eeWlFo3jVdNy8HgHPRsXljhdXL13z6AFQIYC8DyhlQrjNtb1OVqx4ILhU9ZANA0ZV7AJBrNB989MpqxtiSUNf9DM+t1z+bHcI4r1DVW8Nc+5gwiMso1ysK4/MX5ozL2P8hqC1FmewQgGGQvr+CGT65G7CwOIiuw89stDGCQdpbWBDdawbReKawa2djuWHwcD28Fodg6AFQB2Cv4ChjEHsNxVZGedEPR0gGQF7e6sUc4krquPkLZ5bnF6SFXfb373/t+bBlf/eKEIb+sqHC1RDu+kdTWOhKDQj9y5QxJy8p3K1qirQkmbGA2lKUqYrcJEBiDTXnlgfAwhwaGuDPIbYgY0LwMcsBMLEK4OknNn6BkuwkwtADjr1gokyA7VUYygyVlzWW391q1pKhGACMK+IRENvWMsbE/Q9/008ddzS6wVvuWfNaKNUDze4Y733hrD0cfmFcxIi/yyuuXtJvxl4iCbWlqOwcABBzADSuWQaAhUm4OFCqg/YckBYCoDYXMnRzPACGLlo+2VobtrLrBMYQQAMD28uAcg6UM8b3qtxWUVPtivg7gWwA5OSvugLASdRxV1y9dEt8gjNkUYhD/PqBN5q8Hj9ZN59B/HSkbMhwYBDfoFyvqopeMjdrXHX+OxZkLX6b3OaTnBoCELCSAC3MxA/CM1UIQfXcD0+U6AB8/HF1tRBi3PU1MYEAIPYBbC9jOHiiN1A2GOepMOs9FAqkB2h6uisWTF9LXSQmxua+9gdfDlsysad7aMcrL35I7vYnGLbUV637c7jrH4uZxXdOhw5STsOpXynZqShssRn7iSTUlqJMk6sExCBIWYWcWwaAhan4AQStAyIgLweAMVoIQOdymxEd4g9PvH90Tf5Ex8/AagQ7GJsXXJQpQqkzDLWsQWKDObMgGQCOOOMOAORue3etvfAjTVNWUMcdhfGTm54jiex8BlcNdgPCTJYYDqYrl4Co5vXNK0/xmLGXSCN0WghA0cIWBjtyfU77vQecPisEYGEmJAOTCW6EGRH9/7moSYBEGe2g5tR54+H1+ROMXgDlYNgLISo4E2VgSkVj5doGmPRuiQRBGwB5easyOcTN1AWmpye3LDt19pfC/RXt2tG4uXzPPnrTIIEnamvXbAtv9eFhAMn9r9lUf8Gs9HFb+384Ho9OywPR6FJpI8CFodspA+KFYXkALMyE9v3iIiBHCBgQCq3Rhs8TINYsjM7mTRX1AGbKnjeiHJ6IJ1idzIz7aCRoA4CryoMQgnwC/9X/XN0EgbBiQkKgd9WtL4SSWNKnCK00nLVHInuWKxuGTkpIXHnm/J2M4Xiz9hRJvB4fyYOkqKrMU4eX+n30+WItD4CFiQg/JRePC+GXVRjLFIVmAPgCJOM5GJ75/UazlPcCANwAkiTNJyDQBCYqIJQyKKJCYWyvT1PLZcvDRztBPcCz81cvhxAXUyc/6ZSCHRmZKWHr/b/43Ac7u3sGyXWljIlf1Na6OsJdf1h0/VIwWvbtZVedMmFeQm63n5bVZ9PkGQACPhDircDBUi1p61tYfA7FTzkkMm5IexYwRSHdi36vLjUe5/cF6irKW4iFkEHTVl9dmZNbVLhQcKwA2FKAFQIiG8BICoD9AtinCFRzhVUwzvcyFeUxmq2irMw1aNJexxVBfGkuVhkTv6JOrCjM+MW9lzoQZr9rvy9Q+9+//lco1QOVMTbbo+GsPRqM4VLK9c4Yu2fmzNRxXft/OB6iAaAo8jwAQnDqy5zn5RkLgdWytmARIoZN7YpT0VJW5grJIJs279a4GK8tUzW0uFDGC5s+4B/07mtuflhyLg5NalpwavOAEVA0kkvf6wlINQA2bihvAmBWXxMv8JJRV4lPAHwC/H//mcwiV7pdN45oExxguidGNfZVVt4/YNJ+JgyjPsBzCmd9B0KQ2+3+4EenfxAbaw9X8Q9rfvZqv2Fwcv0YZ/ymUB8wwZBTVFoEjoWUMeect3AnY4xcxRCteHx+mhtRlSgFSDcAFK6IT6StbxEyzNDhNjCYk1/6itC0nwUrzpWdv3o5Y3w1PGwFAJWHqitlqLDFxPlzCla/zRTuqqtcJ+d7IWhywELX5ekAqIx0L/oCAana+U89vjFb5nxHIDBsNv2+SlcLgBbT1p7gjHgiO9jgRpDL/uLjnX2XXXVKUejbOkjL/p6t69/eQ3rJHoT9o7Hq7jfCXX8khCFIp38AuOQbZPmEqMbr9pFOHUwlCpaPhNXYZ7wTD4armKF/mp2/etTwXk5h6S2MifUAOw3EqpthsAPiLMHZluyC1VdLmA8ASFLTwjAkNiRTSCd6w+AqDsbWw8bt9pc31Hdky5jrmDBMiKqpaGRkl6xdvwvAFOqkdz9w6Q5FYeRxR+G79YY/ZYQwzs9UnVytQEVhCskAiI11DKZnpEwY9z8AeHy0LHymatIMAG5YBsAEIZkp4tX8fNew93p2/qpzIfBLyKqZOxIbg3g8t3BV2N5KMOGmXC50Q1oIgCmM7NIXQkjpjfHu23vaZcwzAlFfTz9eGfaGys0tLWAC/0WdML8grX7x8Xlh6/1v3LD3g8aGzhAMAPabuop7qsJdfyRyiu6cJyBmU8ZceMmXdgGIMWlLY4KfGEekJiqNOJeQl0BlMcYITOIssGqYTxlj7JcIM5doFDTB2b1hz8IUkgHAA8RmGiMg2IjJcMceM4JrnTLNM09uNCv57xCWAWASw1vUqrgZALlWdMGime0iTPesofO2NateDaVUrl0V6ppw1g4KQyW7/8+/+EvS627HGr/XoJ06mDwDQGoClcWYI8AuwjFe8jPzVy8AYPYLBmA4OaNwVVhlbEwIkqtaGH5pdeUMjGwAcB6+F21o0LNnf3M36fem2hxUKVzLADCJYQ0AAXZGKBP+5YUPT7zgzAcHa6raNgEIycL979+8We/2+sgZvkywO2tqTG+owASjxf8Tk2J6p6UlTSj3P0BPJGKMblAOBw/IjJ9aRAGpM2bd8bkucgp4foTWZxpXwlqLgxgCCARkCstoUGjdLkOopPkcb/x9F7luPmH+3DLSAGHlAJjFSDG1kMV7Ojr6p33rsv9Zcv13n6oYGvTspoytqWzd9MKzW+nZcgKf1NWoT5PHEcktXH0cA/IoYy65/OTdAKQLb4wx/s8SiYKGKUxeNyBDXga1RXRwLKVGobCIhXpUwcNaiwmQDADDr0tVllM0jRTTN/SwDQD+7B82kaR/tcSE9rjcXNLvCczyAJjFSAZA2IpI27fXzz5jxb1zHn34rS2GLkYt1di7p/n9b1/5v6GkygtFiBsPtuQ0FyFwCXXM1y9YFFK9cjQTSgKRYKo0D4DcDGqLsUYAtceq2xYMOyO0hYBh2PaGMwEj5gCIQEBqXoNit5NelAYXYRk8vT3unR3tfaTmP1OWrqgURNudWSEA0xjeAGBsk4wFhBDs+T9tOvmMFWuTX/3Lx+/pur7vqEt4V9fAttLbX9z+3W89tpR6qvyM52pr122Rsd9REfg65fKUyfEHJqckTDj3vxC0kqfPkOYF4X6/6caeReRgEE8f6+eNlWvrAbwXgQ282tDg6g1nCi5oIQDul1vIomg20j2pB8KrQvj7X7eR1fQS582bzD0eajWHZQCYxLAuWQb+m+ESc0LB4wnEPnDP68sfuOd1pKcnt6SlTeoFgIry/TPdHn84rXEHA0zcJmOPo5GbW1ogmCikjLn8W0v2AqA3MYpyOKd7ABiTZwAIQ14GtcXYwsD2DsV4Hx7+AnYjhNgCovQzgW6haGE/QxijhgDkegCY3UEzAPSwKmn0F577gNTUzJ4yuVlxOGYHPN7NlHGcMSsHwCSGtcTqqtZtwmGSizJpaelN3769fvb27fWz3R5/eO5xJu5prlq3X9LWRkbB2dQhZ5+zMNmMrYw1QnC6B4AxeSEA3aoCnCDshKF+rX3XA8NmhtdXrdnJmPJ1MPSYsH4rmPhasGqEI0I0AETAJ1XXQLXbSC4FfyD0PJoDnf07ursGP5e0ORJTli+vBcC410vz8nJheQBMYsSkrPrqtbflFK7qhWAuhFASaD6iRvhtD0VqNQ6cTTHZp01PaktIjAmli2HUY+i0MjymKAZGbtxBW99PLqHyWopiUYKAH0AVE3g+xqE9EYxkd13VL97Jz7+jyID2YzBxFoAMsBCFgQQMMDRCiNeYoT9SV3dfX0jzHAUTcFO+lNzvl2oAMKeDZBUHvKF70V596WPySzm+uCQNALjXQ00GtgwAkxjtDyHqq9bdnV14xysKVx4SjH0tIrsKDqEo7Pu1Da6IfDlKSlzxbr++lDLmwotPrAaQZtKWxhSDWEPM7HY3gARZ64sANXzJHqivWmN1AhrH1NTc0wlg1Wf/RR2cCTcThHbAkg0AxWYjGQB+f8geAN/LL300lzLAMXVavWK3FQEA99LaiIPR9BUsgieoL2BD1T0VdTXrzuSMnwmwCrM3FQwM7Ne1lWvXR2o9d8BYCKIX5KtfmzOhlP8OJ+CnxQ9Vh51W+jMKhs9Pip8KcKszmIWpME4LAXC/X15vDACKw0l6oXt9oXkAWvf37Bjo9yRRxqQuX9506P83fG6ahLhgVOEgiyAhWaCNVXe/kZLYPk8IcZNJ8bhg2TApsf2nkVxQCLGIcn1MjM09ZVoSSS54PKETO5kpdqdUK54TE6gUoVj9vy1MhSkqzQDw0dppj4Zit5PuSZ8vNCXCl178iOw5SCgq+o+su+ELkAwAoQjr3jUJsgtq27bHAg01635lg1YogN8CiHQ99keq0M7dtu2xiGaBMQGSAXDKslnlEKZlLY85VPeh5qRlKI+G0C0PgEV0YXBiGWAgINcAcNAMAK8nBCVCBvfrL39MKmuOSc+sYprtP+Jp3Osh5QIplgfANEKOQVVVuQ40VK+9jqlsISDekbmpEXiLGYGvRkDu9/MwmgGwdHnxhLZaA8ROZswRI9UA4D4fyX3KFUzov4fF2KMoxCoAn1dqYrVqd5Bc+l6fTi5DbG44sINauTXl1GVHiMAJv58UGuXCunfNIuwklLqKNbvrq9d9RTCcL4BaGZs6BpyB3T9zhnaWrIxdCiUlLjuAWZQxc+dlTtj4PwD43LTTgxobI1X1RB8aIj08FaFaDxELU1EMlXRS1T0eqc8IhWgAuAfpNvmfn99KfWeIuLy8nCN+4KMZAIpqhQDMQloWakPV2tc00VciIG4DEJai1uEwYLuisGV11Wtu27DBNSYd4LzewDSMXjFxBFOmJsw0aTtRgdvrp4UAYmOkhmy4200yAIQwrBCAhdmQPJPc55UqEa44HCSjvL/fS3r+CyEG/vn6pwsoY2Jzc8uhaIc/C4WhB0ihUS64ZQCYhNQylJqaR3wN1evuD9i1PCFwD4CuMKb7mEFcXletHV9buYakHCUbrmI65frYGLtbUZVpZu0nGujrGSI9bJgjRqpyn+F2k+KIqrBOERbmYhhEA8DrjZe5PrPTIgq9vUOkMFpdXcdOn5fWATR16ZIDR/3IDUGolQSgcYd175qE1CSUQzSXuboB3Jmd7foF7IFzmWDnAPgyMOKLNACBnQB7iwN/aaxZ86kZewsJztIogsjT0pM7AUxoD8BAP819qMXGSE0W1b0e2imCM8sDYGEqDQ0ub05BqQ+AI5jr+cF22n5I6pGh2G2kF2tPFy2M9tzTm4P6dx2CMcZjZ+YeKZ0uhAcAyfOh61YOgFmYYgAcouGgSM8Ln/2H7GxXGrMFChkwhUNJYIIPMSbcjKPRMOw1DRES9SGjsDSI4A+8WVmTezDBDYCenkFaK2BnjNTWp9zjIT1E/A7LjWgREfoBTAn2YgEMMoAkqTscijOW5NHt7R0K+oUuBHr//fYekvs/Lr9gD1OUeUfMA7qoz+TJLUMNDdRRFsFgqgFwNA0NrjYAbZFcUwaM8xTBgjeu09KTJrxyVU+vh2QAqA5pfYAAAIbXR3KfJquOgcg0jLD4IiOAfkYwACD4EJgixQBQHQ7S87yvL/hyvIry5t16gKaEmrps+edywYRhUDMPfZEu+f4iITUHYKIiGCM2sFalnnajkd5umvuQOUnew9HwCUOnTOgPRm/ewiJcGDERUOi6tMOC6nSQ7smBPnfQYbQ/Pb2JnK9gS0lJBHDks9AgNxGzPHcmElEPwHiFMWEQ81YmPD29g6RkIM3ukGZsCi4GEWSc9TOs+L9FpKAaAF7Y5HjHFJuNZGX3DwQXRuNcdLy/oWLe6FceSfUv71ug2B2D8QUFVQmzZw/EZuckCN0g5gIJ6941EcsACAIhGMkFxb8A1sIAwX0IAMzukKZ7zoQxBGBy8COsh4hFpGD9Rx96R0IEAn5IUgNgmo000+CAN6jmXLt3NZYbBl8eyp643xffX7ZnUX/ZnoM/YIzkHRWwVADNxAoBBAETIOkPdLb2Smt7G6309QTvPgQAxWaTpnrGDZrkKsCk6VJYWIyMIHkADH9AXmhKUUmJsYbBNbDR1QtfefFjeeWKxMMRs0IApmIZAEHAFUZqfNTQcGCSWXuJFgYGaTXMTNOkGQAiEKDGES0DwCIiCGIIwPB5pZXHMoZE6hhujO4d2/5J/ZhVNAkGY8UKl+WpNgnrFxsMnDeAUAXQ0tIzDQf9gBM1FCDcQ7QsfMWmSSsD4Drx1MRYxOWjLb6YKAz9hIphcK9bnkAWY7FQFAOcBx1uMwzDrSgjvwYMI/j5ZMMETm7cr/fkFJRuZQybhVA22xXv1srK+62wngQsAyAYdFsDbMFHAfzeQIyh80ZVUyakFoAQYsgwOM0DoNLckyOu7/fTDAAhLA+ARUQQEP0Uu194pRanMNXpGDDcnuRgB/gDhsdmG/k1UFiUvv/jD2vG0qsZD+ArQuArAIef243cgtKdAtgsmNisA5uaq9ZZVb4hYBkAQdDQ4GrPKSh1A8G3962tbttXWJw+IQ0AbohBHLwpg0dRg0o4Cmp9L81tKhi6Za1tYTEigqY4qbvlSoYozphBkgHg1X1xsSMXD1z57SVdH39YE/beJKIKYBGARUyw620AcgpKW8HYJiHEZpWzTbW16qeAS6r8+ETEMgCCQwCoAzAn2AEbN1SywuJ083Y0hhiGQc7MZYxJMwACXg/pxlaIcVkLi5BhrI+iGhoYounxj4YtJnYoQLB3vR6/bzRl3sXH5x6flzetvra2PWfEC8eW6RDiYgZczBWBnAK9V6B0C2NiMwQ2BTzuj5ubH57wAm1UrCTAIGEAqSHR3//2SQFAqx4YLwR0TrqRmN0xBEBeEqCXphjNuRUCsIgMglgFwN1DUg9halwc6d4cGvKN/owSiH3i2e+z9Bkp48nNnsyAMyHYOoC9Z4uJ68spKN2Sk1/6QHZh6XmFha7Usd5gNGAZAEHCGdtAub6zY2BqZ0ffDpO2M6Z4fX5SFr4tNlZqEp7hdtO+t0yxDACLyMBpFSfc7ZFmGAOAGhdPSioYHAounGazadkv/fXG+DtWn/ve5CkJnaHtbkyxATgJDLcwgVcDQm/LKSh9P7tg1U8zClfNGOvNjRVWCCBIhGq8x3Tae+e5P27Rb7zlaybtaOzwDNGy8JW4OKliHsYg1QCwPAAWkYGpvBs8+K+n4RmSqhmixseRRMv6+9zBxysYSzr7vMXLzz5vMQIBo7m+tr1l8/tVeG99eWZ1VSupZXoUoAJYwsCW2ATW5hSWvsAUdn9dxZrdY72xSGIZAEHSWH53a07B6gpAzAp2zCsvfbToRz8+o1lTlQwz9xZp3INBuA0PQ4uPJwr3jIzhpvUhoJ7KLCxCJSBYF+XLqXtoipqjocbGkRJk+/t8IZUq22xqRuGs9IzCWem45rsrYBi8o72td//HH9V7Nvy7bOr2TxpydF0fs/JBIjYIXCEMcVlOfunvDL++uqnpXpL2y3jFMgAoCLwChjuDvVwPGPanH3uv8dofnjqhDID+flrtsi0+XmqbZ31wkNZZiHHLALCIDG53N2KCr3g1hgblqewBsMXHke7N3p5BKWFgVVWmps9ImXru+Sk49/zFEEIM9fW6G/fsauxdv748Yct7lfkDA15JosemoYLhR6pTu3Bm3l2XN9b+4t2x3pDZWDkABBgXT4Mi9A3gD0+9d6LfF6g1Z0djQ/+Al/Q7UOMTpCZD+vv7aJoCqt0yACwiwmeZ5kF7vPTBoUkgPlNGQolxkk70PT1uUw6BjLG45Elxs5csn33yXT+/cO6bG+60v7OptP53T1z7wTcvob04AAAgAElEQVS/tfST6emTDpixrhQE0hSFv52bv+r2sd6K2VgGAIG6urXVADZRxhgGV396y/NuTKCKgP5eD+khY4uPlyZ3CgD60ABN8tRrhQAsIkrQdXjCMOwQQprevRITS3qm93QPSk1CHAHVGWPPmbsg66Trbjj9uL+8flPqex+6Gp55/rpN1/7wtPfzC9PqGLFRkMmogrF7cgpW/xoTV9HVCgFQYcBTAlhKGfPxBzVz1/+7bMOXv1KywqRtRZSOjj5SbE+Nj5V5YwtjyE1RJTMaGiwdAIuI0gUg6LCf4EYvUzUpOhma00F6pnd2DIyZW17TlOz8wrTs/MI0XHPtcgiBge4D/XXbt9UPrX+nPGnr5qoCv0+XJiEeGuKG3IJSR1312h+M7T7MwTIAiHiHtBcc8frdEEijjHPd+dKSE07M3R0XHzPXrL1FivbWPlIMXouLk2ZBC4h+YRhJhCFdliKYRSRhTHRTmt5xg/erktLlFIeT9MLs7OgjNxAyC8aQMHlK4vzTV87H6SvnA0DAPeSrLN/b3PXuOxXOd9/endvb6w5a5VAWAvh+dn5pa0PN2p9Hem2zsUIARFpaXG6AraOOMwyuXXbBI1N1ndebsa9I0t7WS2oFzBxOaYYmMwySpgADi95Yo8WERAjWRRrg9UqrklFsGqmqoKtzIJo7l9pi4xxFi4/PO/nW289a9I93bk/esPVnzU8/d92H3/3hlz8sKJoeMWEixuDKLlz9jUitFyksD0AIxNrUx9x+/WYAJGnMrq7BaVde8si+Z/9yQ7uisGkmbc90Otr7SacG1RkrLc7IdYOktS4gaA9jC4uwEd2UsHHA4/ariXIO4kzRSC59t8cfD8ADINoz9AEcLD8sKErLKChKw9XXrgDnoqOtra/5kw/rPBve2TNl27aGPN1vTvkhE+Kx3Fl3bK+ruKfKjPnHAssDEAJlZS4/GHOFMrapsSvze1c/1i/E+E1M6+keTKFcrzoc0mqdDa+PdFqyPAAWkYbqAeBDQ/IShEPIJTB0MW5r3hWFTU1PT1709fMXnfLQo1cVbtiy2vfPd24vu+/hyzavPHvhzviEGJkiZAlCV59dscI1YQ7OE+YfEmnqqyqezSko+gGAk6hjy8v2F/zg249X/s/j13pUjY03BS2P2+MnleExVZHWClj3uUkyxEIIywCwiChMQRelsC8wOCQtSZYpbBIYEyAkIfj9gf4YzT4hOpcxxmKTkmNLliwrxpJlxQCgD7l95VXlrR3vvL3H8c+/75jv8/hD93YwHNe4X78JwC9l7XkssTwAIfOSwQx8C0BIFuaeXfuKLjrnAWVoyLdX8sZMRdc5vbWuqkkTOxHE05IALAPAIqIwQWs/rff1ynRZa2qMk5Qn4/b6pEp1RxlaXKyjeOHi7OW33n72ie+8v8r4/R+/936Y/QxcmUWuCWEwWQZAGNTVra0WYLeGOr6jY2DauWfcn11T2UrSFhhL/H6dXFLHFEbJ2h+RwADtWaUolgfAIrIIAVIIINDfL7UWX4tLIIUXB/qI7TXHMYyx+OLZGUv/9sat9iuuWkrq8HoYsSrXS6VubIywDIAwaahe878CeCXU8R5PIPZbl/92yS/vfn0r9cExFnjctNOCGhvTB4Am3TsCgd4+0ndWQLEMAIuIwhRB8gAE+vqkJuBpSYmkRNmuroEJI1IWNIwl/fDG0092rbsoJCOAAdfm55fmyd5WpLEMgPARnhjvVQzYHs4kr7388YkXnPmA3tDQuQUSpUFl09fvIcXgtbgkqQlGel8vqc6ZwfIAWEQWg5gEqPcPyO0HkJDkoVx/oGMwap83JsNOXznvlBtu+drGEMbaDAUu2RuKNJYBIIH2XQ8M+Zn4OgPCqkvt6Oif9s0LHzn5+u89tWvI7YvKtpTdnbTTgi05iXQaGY1Afz/ptCQsA8AiwijEPJnAYL+0EBkAqElJpHbdHe1ScxDGHZdeftJJJ51SuIs8UODyvDxXvglbihiWASCJ5qp1+yFAFgg6Ftu31c9fufzukt889M8PvB5/VNWcHjhAOy3YJiVLTTDSB2inJZUTRVksLMJk5kx7F4Cg1Se5251MuX40nMnJpN4bba19Yyy3O+bY7n348tTYGDtVkEnhivF9U3YUISwDQCIcyJQ2FxfKC89uPekrS9cV3P3zv37U3+feKWvucGhrpfUBsE2aFJC5fmCQJkLEecDyAFhElA0bXDqAoLPMBecaBEiZ+yOhJsSTjPS2Vrk5COMRTVXSf7buoo/oI8U12dkuaTonkcYyAGTCUCR7SiEE+8fftn3pa1++d/6Vl/x33YcfVK/nfOzU7dpaaTF4W2KSTB1+YbhJjYD8dXX3WY2ALMaCdsrFwtClGQBabBytIVB7n5RGROOdJctnnZQ+I4Uaxp0Me+BSUzYUASwDQC7SDYDDqattz735v/745RUn/jzhpzc9++HuHY3rORekB024tLbT+gDYkpLktdIU6AXnlIdbB6I4odJiQtNGuVjoAWm5MkpsLKnq5kDXgNQchHGM464159dQBzHBrjZhLxHBUgKUxsUqAyKSEGIY3L55Y+UJmzdWQlUVY/EJubvPOntR1+LjcxInTY6bBQHSS5rCgfZ+0mlBi4+TF1/kei+A4D0AgvYQtrCQhkAbpYu84fW5FaccT7zidJLyZPr7PMkAdFjvA8ydP/OEKdMSOzvb+6cQhi3NznalNTS4xt3z5gv/B5dFVmHJTAhdWr17sBgGVz/aUjP3oy0HDVdN0wILF2fvOe5LOT0LFueInJzJKbFxzhzGmBQ53u6uAVI7TtXplCYDbHh8tP4JzDIALMYIRgsBGAMDPluynE63is1OmkgIoXAuuhSFUV56ExXnDTd/bevq215YQRijMrt+IYD/NmlPpmEZAJJg8BdFQ0RF13Xbxx/WzPn4wyM9WYnJsftL5ma2zV8wc7CocJqemT3FPmVKQppmU3MBBJvYFxjo95LchYrdIa3feMA9RMvSFWJcGAC5RauO4wbOZAwzxnovFqOheJnATt0feLWp6d5hNS4YE20EOX74e/u4M1NODjFTWCpjTAjCBvSA0Wd3aJYBAGDZqcUFisI45yL4B7rARbAMgC8ujLMiissv0vT3umd88H7ljA/erzzi55qm+dIzJtUWzkpvX7hwpq94Tro2PS05Lj4xJuvolsXc4N1CCFobY8ZInQNHwhjopVUUMCWqDYD8/Dum6Ex9WnCcyaL4u2NxOAKCAapDezA3f/UtdTVrnjz2ZUobJf3E23VAk2YpAzY1JqZbd7uDvvfcbv+g3WG9DgBAU5UZy1bM2r5hffkiwrBTcnNvS6qru09aMmcksP7iklAYisZjtpmu646mhs7CpobOwn+/eWSlYfKk2O7C4vT9c+Zm9WVmpegJ8Q4GIGgDgGmaF4xJyzD2d/fRXpMsej0AWVm3TzKYtpFBzBrrvViERLJg4onc/NKkupq1D3/uU8baIYJ/IujdXVJLybTkSV0UA+CB+/7OV35t3oaZ2amOKVMTU5yx9kwzc4minWu+f6pnw/pyyhCbULSvAnjJpC2ZgmUAyIKhiJJvftkVS7Z0tPc633l7D8XKjCi9Pe6Uj7bUpBzKL6CiJSZ0A5DWNSvQ1UmTAY7iEIDq1H4JYb38xzuC4f7swjveaKi6p+LwnytctBkEc9XX3S3RAQDYUyYNeFuCr2h79+09i959e88RP0tMjt1fMiejff6CmYOFhWl6Zk6qPTU1Idlu1/IBjNva92DIz5s2R9NUXdeNoN+RgrGvwTIAvpgIwUglgGeeu0Dk5k5d9F83r/z4tpueS6mqaBn3jSWOxpaQ3AuJBoD3QBcpoZAp0RkCyChxpcCvXzXW+7CQgsagXA/gR4f/0KPpbXYjeM0svbsrVeambJNSSP0AjkV/r3vGB5uqZnyw6UgxUlVVAjMyJtcXzEprLy6eMTBnboaamZWaFJ/knKKpSgaiIRkqXBhLWrKs6NMN6/cuDHoIcMbB/zN+So8tA0ACRUU/TfBzTKeMmZaWlAIAU6cmHv/Usz/gLS292113vphctrs515xdRh7bpElSZYD93V0UESAwIzo9AHa/frIApLaAtRg7hGDLj/7Z/op7unMKSv0AgvJa6R7PJABeSDpZ21Mmm9bhzzC4ramxM6epsTPnnX8d2bLEZtcG8/KnNc2bn9VbWDzDk583haVNT46PT4zJZgxTzdqTGVx8+Yn9G9bvpQxJzylcPa++ak1UqLYGg2UASCAAWxFASwGMjbFnHPY/lfT05EWPPf093rK/+8NHHvqXY+OG8gVydxl5tORkUufAURB6P6k2FwOx3qg0AIQQk2Bl/U0YGHCsWLvAQSGqjGN8doyrBROCdzKmSCkFsCdJjSgETcCvx1fs3T+7Yu/nww8pk+MPFM1KbymZl9k3a1Yan5kzxZmamjjZ7tAyIbFluCzmzssiH8YEFysBWAbAFwquFFK8PlOnJrYzxo6VTKekz0g54Z4HL4PX46986c9bO/70zKb5gwPesbmbwyRmSiqpKclICIFuoeuTCUMG2nc9INUDIQ8WUfVGC9M5tqF5UAwoOAMAgPD5epkzRooBoCYmRp2HqbtrMPWDzVWpH2z+XH8zY1paUlPJvIyOouKMgVmF0/SMmamO1NSE6cQyZamoqpKZlzetvra2PSfYMYxhJYD7TNyWVCwDQAbEBMBZs2e0YpRsemeMvejKa5YVXXnNMk9DfefmZ36/0bH+32XzdV2Puht7OLSUFHk3rh7oAkAxAKLy9A8A7ljv5liP0w18cbOsJxKM4a1hPminHAx0t2fQLkkNUIuLkybAFQHU9ra+rPa2vqz1b5Ud8YHNbvPl5k+pLynJ7Prqynm+krkzihRVoZUih8G5F36p6aH7Xw/aAABwSn6+K7GmxjUuepCM/2SNKEBwQUoAnD1nBkX3OyY7Z8opP1t34XEbtt419MwL120+78LjP4yLc0rTDjcLW2KStC5jhtdLvaGi1gBo3/XAkGDsN2O9DwspDAWYduy/JbEMVe/v90vZEQDFbpemvzGWBPwBR+XelvxXXvrwhB985/FlZyy/O+HT7fUbI7X+itNmUQ0pW0AJnGbKZkzAMgBkQOwCWDxnRkgd8hhDcn5+2ik/ufOcE97aeGfMm+/esXvd/ZdsWHHa7E9jYx2DocxpJqrdTkraGwl9oJ+W1czQKmttM9B4rwtAxB5kFqagQ+DqfZWulmN+SuxF4e8ZVliQDFO1aYyxcZONHixujz/2v7771LKtm6vei8R6k1MT5jhj7KRnjyKw0qz9yMYKAYQPA1BIGZA1c4oM16+WkBgzd8Vpc7DitDkAYPi8garG+gPtu3c18+2f1Cbu2tGU1d09SHGby8WmScv6DfT10vIJOGuWtbYZ1NQ84svOdp3BbPr9AH4AqypgfCFYFVPYdXXVv3hn2EuAfZRUT3/3AZnPY7saH9+pDwxMSHnfn/z42aXvbCqttTtsZpdPO5efWvzJv/6587jghzDLAPiikJvryhTQSS/0lJRYM2JYqsNpKywsnl5YWDwdF156PABACPS6Pb62zo6BgeqKFt+e3c22qoqW1OqK9gyP12da5q3idPYzMGnJi77uHpK3SoDvk7W2WTQ0uLwAbsjLc60VLHC6YMhhjJE6uVlEDs7BwdAOwXY01FRsAl4a0SgVjDcxgpy8/0CX1JwQe8rkAxPVAOBcKC88t7XlymuWmq6f8vULFg/965+kxP6srPw7ZjfV3EOqIRwLLAMgTITKSe5/zab6NU2TJo4zGowhOS7WkRyX7UB2dipOXznv0EfcMPi+3t6hjtdf/dT9+G//vVTmuvaUlA4A0gwAvaubZKwoDFFvAByittbVAeDZsd6HhVw0A/s4wWzVu3tIjbZGw5Ga2u9ubJA5ZVTxwrNbZl95zVIOk0PZJXMyZlLHaIqyEkDUGwBWDkC4ME5y/+fmTduH6DC8FFVVMidPTlhsxuSO1ClSm2L4ug6QegqIcWQAWExMGLM3Ua739fZIPa07pk4l6XCosTF9Wlxcl8w9mElPz9Bkt9dfOfqV4WGzadkzsyeTnidinOQBRMOLaHwjaAmAs0tmHAAQTbK/gZee31Iie1J76hRa695R8PfQpFK5KiwDwGJMqalx9ecUlPYCSA7meu7zJkCIfjA5oTPb5EmkJMC43LzaGRddsggCvdzv2+/v6+n1t3cEvPubHZ7m/SnejrZM7g9EVenqtq21HUtXFBebvc45Fxxf/+hDbxI0GtiyafNujYteLZKDWAZA2IhZFBHAkvlZYWt0y6S9rW9Hb6/7eNnzOiSKAAHw6AODlNORv7HcbontWIw9AvvAgjMAAIDrgTbFZpdjACSnkBJLve2tB+8xhmTF4Uh2Tk2Dc2oaEufO+/+LBHq5z7PP29XVq3d2cm9bq32oqWmqt61tJjiP+Pvkr69sm7R0henvf5x2Wonz0YfepAxxxHnsKwD8w5wdycEyAMJFsEKKCHBB/tSoyvZ+5aWPpNUeH45t0iRp/06hB1ogBMVrsh9whVRqaWEhFcaaADE32Mv1ocEee7KcEn4tLo6UUOrv6p0OQMdI7wWGZMUZkxw7IwOYkYFE/KdXjl8Yep3eP9Dp6+r0elvaFG/zvgR3876ZhtstrRz4aD7aWjNbCNHPJHlNhmNqWlKJzW7zBfyBoHORhGArEeUGgJUDEAYZGTfFgIEk3Zk+I1lqok+YeF97+eOgH04UbImJ0lyF+pCnmziEFHu1sDALRqxG0bt7vLLWVpxO2ouXG5rgPFQBLTtTtVzbpEknxOcXLk9dtmxpxuXfXDD96183VRffMLjW2tJbbuYanxF3ytICWlIfY2eZtBdpWAZAGNhi4wtB/B3GxsVErAJgNFqau3eY1WdAsTvkiQD1dVNFgKz4v0VUQE1G9bR3SOsSxZgyjTFG8oRxr6dT1voA4Os4QJUD3weA5JV8562yAHGNkDj3wuOoic05ubmlBaZsRhKWARAOnJYAmDwptpuxY3YOGxNe/PNW05TCmCZPBMjbcYC2T84sD4BFdMAVWiVAe5s0+WwAdi0piaZG2NsjNWnN27qfKqX7uAD+TRnw11c+ikhS9YIF2UE3djqEUKO7GsAyAMKB0XoAFBanf75H5hghhHD/47Xt882YW42N7YHERjf+1lZSj3QGEdUqgBZfIBinGQAd7VIPCI5p00gnel9nl8zkXfg7OkjVO0yIOkD8izKmtaV3ut8XqKftjI7doeWnp086tuzzMAhYBsBEhmQAzJmbJbU2PhwaGw586vb4TSnpcUyZKrURj7e9LegsagDkh66FhVkI1Ub6LvoPdE4HpYXgKDimkxqPwd/WZpe1NgDd19MznTKAA7VMYSQDAAD27GqKSNjv7PMW11KuZ8CpGRk3yfTqSMUyAMKBqAFQUjJdqnUdDs/9YYtp1QgxGRnyupoA8HUdSKNcLxQrB8AiOpgc17IfQND3PfcHYiGENDGemGlTdcr1ntYWeUnKnLeAc9JzRgOvra9cWwmIOsq411/7NCLtj7+6ci71uRljc8ZJVVmViWUAhAOjNQHKzp0aHZagEH1vvbnLFPc/ADinp8tLyhHoNTwe0kPJ8ER/HwCLLwbbtj0WYMTW1Nzvl6Zh4UidQnphBTo6Scb2SBhezwHikIGamns6AYABb1EGvvdexWwApmuspKUnl2iaRnq+CSV6wwCWARAiM4vvnA6i1v3k1ARSPMwsqiradlHqWanYpqZSM3+HxQj4qeGE7qame6V6ICwswkGA5pEKDAxICxWqCfEk4zngHkyBEKSwwbBz0RMK/3Pq54wWBvB5/DFdXQOma+8zxhJOOCmPtA6LYllgywAIERZQSO5/VVV0m00jZ5GawZ+e2WSqnKcjcZI0NyIfHOwlDiHF6CwsTIfRdCkCPQekedAUu5PceZQHdFKi23D4OrtJ4QcG9h8DwMH87wAg/R42rq+IiOzueRccRz1gFGfPcmWbsZdwsQyAUGG0+H/mzNRmADITbEKCc9G1YX2Zae5/AFAcdlLiz0j4eg6QGpowywCwiDIYQMpQ97Z2SHsuM4VNYXY76cVoDA1Qje5j4mtrJXkZxWH3bmXl/QMAtlDG//XVTyJywFp0fA79+WYYUekFsAyAUCEaALNLZkgV2AiVPbuaygzDPM1uxeEcAGPSQh2+jgMkYRRhGQAWUYbgqKZc72tvk5rQ5khNbaVcH+jplqJG6G1vJYVID5YAHva/GUhhgOrK1lzd4FK8FyPhjLEXTp2WSMrTUIQ4w6z9hINlAIQIE4yUADhnbqbU7nih8senNpkqRRwzdapUrQNvK00YhQlGyh62sDAdJkgGgLejTWqukHPadJKUtqddjgfC29FBCj9wKEfcuwZnpO47AFBd2RqJAwA7+5xFpL+pYDitpMQ15h7go7EMgJDhRBGgtDH/XXODt2/dUmWK9v8hnBnpUhPwAu3tkynXc8sDYBFlcI1mABzWlEcKMRkZpOx4X2tL2DlCAqLPGCR18IQqlCPu3caaNTvAaBUUb/xtR0ResmecOY/6PE8Y9PJTTNlMGIz5S2k8kp9/vQNgOZQxM2ZMNrVbVTBs/6S+nHNh6t/cMT2DFLMfhYCns5PUbEmDahkAFlFFY/ndbQAGgx7AdRsMXVopq3M67fDhbQ3fAyF8fqoap5Gc3NJ49DTgtHLAN9/YWQxi8mAozMhKna2qCknXRVVE1OUBWAZACPgRnweAVOoWn+Ac8yZAz/x+I0mfn2k2nxofT6rldU6Z8n/t3Xl8G3eZP/DPdyTZsXM4d9LYiS1bdq42vUtLz6XLsWW77FJYdjmW/nYX2AXKubAQO7y02EkLy7GlsJSyUHpB26S0pemRtmmTJk3TJI5zObYlWZKPHD7jU7KlmXl+f6SBktqOHmlGkp3n/Wc835lvbGnmme/xPJatL6B4vA2mztnHPBIIwPY5QCGYCECA0yA+ONRp1cVdc3i7ckZ7uosApBTIx/v7uCOBrbW1973jwa1ArABgeGhk1uBA1PbqgEph9mVXlrKuQ5AAYEpQGm8L4IyZ0wY0TbGGw6ym63pbXV14JafNzFWrDxmRCCsNr3N2gWUjHfHhQdbCydPbiLys6mdCpIVSvHUAXR3WlQXOzStkNTBNh6nHUxqBGO3oYE5hjJ35z6m5tgBgfad37wqkJQ/I3374cm6iozVlZZWsEU27SQCQBAezCmDF8iUZz0z35q5AMxGxVtTPLC+PwOTtGNBy8yzLJBbv6mLNXRIzfej5oNiz9jJ3ReVad3nlL9yeyntKyytvW7LEa2seCDEG7k6AtmOWJdNSmprnystnLQTU+/u5D7c/E2lr5yUaG2fxrs/n7QZQyznV07/fw859kIwrr/GwK56aSr3Pjr4kSwKAZDC3AK6+qMiSfbWpuP9XO1hTEA5X7nDu/Hmsm5DKyRlWFo50DLe1sdKYSg6AP3G71y5yV6x7XFNaLUitB9RnodQXCWrTtOm6r6SsKuuGI6cyUrwAYLi9bY6V188pXMKakx/pSG0EInqsjVXVcOLtu7ysgAfrWitMk1IKYBIxPT93xdx5M3h1G1R2ZQWUACAJBMWsAlhk+6KUicTjerDhSBtr2+Lsq648GDvFy+SVd0FhCwDWKMNEoi28myApxZpnnapKKyqvg1PbD6KPjvVzAgqVhmfdnspb092385WmTNZnc/TEcUuT2kwrWjbAOT7S2pZKqnAz1tXJGupWE4zeKWWyAgDTJK21tdvHaZMk7ZYPXtrIbPOXN93ktS0PC5cEAMnhFgFi1bO32o7tTezyuHOuutIZbW1l3QTy3G7WMOO5jJw8YdlN5DyhSisqv0akXgVwrhEfDUo96PF4M7475XxAcd5WQCMaLQCRZUWBpi9dwqsK2Naa9E4AMswTZizOm2bStHEf2MuWuHYDYI2ibnn2IOvyyXr/reykqrNbj8evtqMvyZAAgKmiwjsfAGtv+vwFM1nHW+2BX20v5hyv5U4bcBXMWTPc2soazp9evNSyBXhkmifN0ZGZnDaGgu2rf7OVx+Od5S5ft5FI/RBAom8Ys3UVv93Gbom3hEIbOgCw3sL1SISVwW8iOfMXsR7Iox0dy8AoY/x2xsgwt4CXGY8MjRsAbNvm1QG1lXPCZ5+pq8Dp3Re2KilZsFLTFOu+R6SyZhpAAgAmQxms4X9NU+a0aa6MFQGKRmKNAd9JVs6CeVddfQiAY7STtwc/d+HiGazOTcAciXJvfpGWJufZ+4jPC6Ur1l1kwNgL0G381ipr3kamPOY6gHhPLytgmIhz+nTWgjXS47kwdPbIIQDEe3qYRXko3N7+44kX/CpiTQP0dA3Ojw7HbJ8G0DQ1d83FxbxpgCxaByABABMZvAWAS5bMOQ6Alc7WSq+8fIQbjWP2u67Mo3g8RDqvZLAzP38Z91rjiXV3s25+Cmg8H7cAuj2VnyKDdkMRa1rqDEWw7G8mJqaIFwCMnLAuq7ZyOpdqOS5WOvJYXx/73gEAkXZe7E5Q53yAKt3JCgAA4MD+UFL95/rw31/Fy9lAuMztXpuWnQrnIgEAF3MHwIrVhZbN4yWBHvzVax5OA2d+fq9zxsyLR0/1sPbgO2fN7LSyCFDk2HFeESAF22uBZxOP545cd/m6u6HUgwCS39aneAmtRPIIvEWqw21tVhYFcky7oCjMaRA9djypZECRcJCVeEhBnfO7Gwx6WwHeFN/TT9Wycpgk6+p3l3GneBUc2bEdUAIAJmIGABetWZZ4ClCLDQ9Fj7S397KmH+Zee0M9AGe09Rhr50L+smJu6s8JRVtbmdMJdN7M/7vdlcUGCnYC9KVM90UwkMkakh5pb7OsrDYATC8rY21ZGwoEkgpARtvaeKNKRAkNoZMCqzjQGzsDq4jIsmmU8UyfkbeqYHY+K/kQKfVXdvWHQwIALuIFAMtXLLFsWxzX85sPsVflz77kklkAEHKcZ5kAACAASURBVAk1s1aH55eUDnKvNZHR4+2svAWUwFvEVFC2vOo9cKo9ULgi030RPCaonnN8vL//AhAx59PHl7dsGWtRXLQlyJ4eItM8GY9GWNt3NUoweDc11jSAruuujpN93G16yXB84INrWNdRwHuBj2Z89E0CAIbT+zeplNOmaNlc1kp2C5mPPLhjBaeBq2BWh2N6/kUAMNwSZn358wsLrfswEw3EBgZYc2Rqyu8A+KjDXV71XdPESwDYGchE5ik95yg4K+uJlBmPWbawddqihayh+Xj/wCIyiTVqYESG2QsXRqe5Ent46tp2AKzsoK++3GBlcbJx3fLBS7k7JuaXVCy/9XRhucyRAIChtVV3A2CVm5w1K9+y1Lgcp3qHD3Z28B6i86+7sQmARqbZYQwNsebznfPnWbbV0YhGg+ClLR4tvsA5ZbMAejzfXuAur3gewDrId3bSCoe9IwBY0wCx7i5eprkJaHl5JVCKNQpgRCNhzvEjHSe4U54d7fXehEYqw2HvCBS2c07+1KY9rB1QySotX1yhmL9bRXjSUAXD7vLK5tLyyvtLPJUfSneabrmZcDh4w//503KHHU6VkQBg89P72UPyBWvWzAX4UbzSNMPhymHlGpjIaFdnP6sBwXd6r/DUU+KpvNpQjlpAvTfTfREWUDjMOXy4pdWyvewKqsA1ew6rWuZIVwfrgT4SbueOBLJ+H0S8dQDt7b1F8bgeZvUoCZqmFq5aXZjMtkMHoEoJ6nal1FO5M/T20op1/1W02stKpZwsCQAYuAsAyyoWtcHC1LgM+uO/feNCTgPX3LntKjd3NQDokWHWMFvO/AWtSGUl+lmGQmHeTUSbmsP/7vKqO5RS2wFkVQUxkQLCIc7hw80BS2sC5Je4WcG90TfICkAi4SBr5JCYARGUwd4OeORwW1L5DBJh6HS84Wj7jh/ctXl3KNCVer4Xwhwi+o4rpofcFVWfsaCLE8qanMSTgonlnMf5qjVLLU2Nm6juroEDvb1DrEViC2+4sRlAEQA4cvNY0xz5JSUdACwbaos2B3g3EXNqbQFcvdo7IxrTf0nAP2S6L8JihMOce8hIS1spTpfDteRlbUZZWaS/LvHieo4ZeZwXGCNy4ngJpz8a8QKAsO/ORrenqgUKCY84Pvvk/vxLL7Ps9mQMD40079rZ1P37jXsXHT7YVkZErAXLCZoFwn3u8nUfiuc4/inRaRIuCQA4mCMAa9YUxuzqykSe3LiPXclrxqoL/7hewFlQUAZN0xMtBVyw5mIr/5+x6PFjrIWWCjRlAoDi8qqV0ZixiYBVme6LsB45nYeUkfhslREfnQ5DD8HhtOQJll9aytobn7+0OOFgnAy9hXSd9901FWtEBACUwgsEfC7R47e9enRVFW4bAZBUTRbDMLuCgZPBZ56u07Y8e3DV0NBIBZj1YJJHH3TF9O3FK9e+r6Vhg2Wpoc+QKQAeVgDg9ixivUlbZHTT47vXcBrkLlwU0nJcf9wxoIC5C667YXcibZ35+b3Tigov43ZyPGY8FibDYP3eHNCmRABQUlH5MQ3YQyB5+E9R4UZvC5g1AUZP9Vl243fm51+cX7S0KZFjp5d6jmi5uQl/FuN9fdykZ8bo6BD7u2sw0wJHo/H8nt5B1nVMk3peebl+2//7xL3NN1zlXXD7x+991xOPvXnl0NCIlcmZEnWh0rUdZWVey3f/SACQoJIS72wArFX1CxcUpGUhx9udOHGqbmhwhLWHf8FNN75jq9G897xnVc6C+RPPnWmaXvK5f29WUJbVABg91ctLqwlEAoHGdOz1tc3q1d4cd3nVTxSpRwFY9rsUWYnAHPYebW+zspy4WvrpTystd9qEi4QdeXn9Sz/x8Xww1jBFWluYI4HKf84aAGNwma6tAFi/k52v+hJeFH2qd7ju1vd9T637z8du8jUeL+P2zw4KKCNH/FGrSwlLAJAglRNnDfkopWhanivti7ce+92b7FXDM8qXv2PPvwLmln3+jtyZK1fVjdXGOWtmZ8VXvlbnKii4Mpl+jmekpY27n/YQsDGpqmXZwOPxFkVi+jYAd1h0SssSxwh7kOItBBwKBCwNCjVXToXn6/9xLG/R4jG3zk5bsiTg+fp/dCmHkzWcP+Tz80pLK2IP/wNAIOAdAJDQCOUZTz+5N6EFeqMjcd9tt/5oZd+pSNpf3s6FSP1FyzHda+U5ZQ1AopgLABcuntWhVJq3ACpEnn2iljX8n7ekyKdcrrGDG6UWFX3sHxYZ0cjB4aamvpGuLpcjP1+fXu5xTFu4+FIAlj78AWAo4OPl71a03+o+pEtpRdVfGqT/FgCr7PK4CA8qhW0E/NqS8wlbaITDnCwXQ+GQZVtsz3Dk5Kwo+ffPG/FTp94cCgRG4r29LtfcufEZFRX5roKCywB2jQiKhEOsgAFEvB0Ab6foBZC6PtHDmxqOlxk6nXA41YTpldd96/Ho6Eg8qbUCafINj6fq/kCgxpK8JxIAJEop1vz/ylVFJwCkNQBoCXcdiIyMvpvTZv6NN57AORa0OPLyL551yaXghfdJoWhrawmrhakmYQDg1dzl8bVE8IJ/ox3LKAFfDgdqflFSUfkxxcqhhEvd5ZVTJImS6gBhPynz/8L+DQcy3ZtxaXQYjL+RMTQ0n0yzQ2ma1RXkHK45c94158rU43gyzBYjGi3htFFQSf+NNEPbYmq0ntMm4D/RvHzlknEDAEM3W17f0XRxsn1KkxxD4S4AH7XiZBIAJI4VAFy4ZmnaiwA9+uAb7Kh9hqcsLZmyEmKabUY0ykpBbGJyBQBFq71znTH9IUDdYs0ZKaw0fDTUtH5fkifIBRTvzS17lULhGgXt30vL1/0g6Hd8OytLROv6YThcBMb8uj441OoqmJUVJWTHEjvVcxxACaeNGXcm+5lFc7Ojzl2ud4KRFvv5Z+ucy1eOv2PvxIm+40Di2wsz6MNud2VxKLQ+5TTRsgYgUcwiQCtWXWBZBq9EENHgC88fvITTJr+09CgczqypBx8bYK92Hp2R62AVWMmk0uWVV7hi8VoFWPLwJ+C5eI7r8mDyD/+pSiPQN0sr9A2Z7shYgsHv9QPEunmPnDie1Ws7oi2t3IWK7eGw92TyV/SaUHiR02LLc4dWAhh3D6ZuGGm5Z89bMLNr4aJZHZqmkg1ONTjVJ63oi4wAJMSrQekeTotlxfPTul2k2XfyYGw0fh2nzfzrr7csz7gVouFW1opgBdTX13szkmuBq6S86nNk4m4AVhT/MADyhv2uDVn5hpsliPCN0hXrHgk2Vic/12wb7TBAJYkePez35c1cwartlVbDfh9zAaBKPBvReEy1BYoSfhAO9EcLhodGD0+fkXvRWD9ftNCeXVuz5+T33nLrZY3vv2WNWVwyv9DlOp3TwTSpa8e2hnpv1aarY6M6d93BJwCwpkDGIgFAAkpWYBkM5HHaFMyentbhuocfeJ31AVJKmfnF7jQls0jM4NF61gJAouxfALhkiTc/N1//OYB/suiUXUrh40Hf+pctOt9UpsHAPwP4aqY7cjYic59S6tZEjx9sbChbfOvfsKYN0oiGw2HedjkyUx610sjxoql0VpbE3W/4e29+79hZ0vPyc5YvK5nf2hruTmlUVNOUeenl7oYP3XZF99XvLp8/fXruSgDvWJulaWrBje9ZddPml79V/7fv/+/iSGSUs9tjZfHyKndLU00opb6m0vi8oZus4f+cXOeI06FNuNrUSqZJva+8fIS1eGVGRcURpWkZKVQ0jvhwOMjbapnl8/+lpVXlufn6bijLHv5vOMh5WdBXIw//BBGR5TtVrEAa7eUcrw8Pz4dp2pbTPhWkx4PGSJQ1AkCmSjkAaG72dkJhzG3K43lq096JdtyoH979SVaxpDPmzpvR/cnbr3/9kSfu2LX9TW/fT+69ffXN773wxunTc1fjHM/Z6fk5q3963+2s/wcAOAx8IJm+vp2MACRCGcs5gXepZ1E7ANaUQSqO1h87bBjmjZw286+/gVdxz2ZGLOYzY/HVnDamyt4AoLS86sME3A9YtXlC/SQ/x/GNc055mBjJynfETFHWFamyUi5y9sahs97oR7o626ctWpx1i9RGOzuOA2CNADiVkfoUAHBmGuDyRA8/sD+8ggi9SmHM4f4lRXOv/t6PPr7tW1//3Y00QUlyh0MzLruytOHvbrui+4qryxZNz89dDuDaJP4HAIDlKwuvnrdgZldP12DCW4JJU+8H8PNkrwlIAJAQpbAcjOUhF15Y1I00BgAP3/9aAauBpunTCotW2tSdpIycaO9iNtH16FBSiUTsdNNNXmdLu34XAV+DNcO1Q6ToX8O+mscSOVg5KARTIoA/UcFM92AsPp+3211eGeLswBgOBIxpi7Jp0O60gUYf8wNH4UDgTu73fWwaXgBhbaKHmyZpbeGupmXuBdeMd8x1N6646ZkXv1l353ef0t543XeRaZIGAAsWzuz84K2X+z5wy0WOouIFK5QCq+LqObhu/dDlTb/5v22J5wQhugmn7zFJL16UACARzB0Aqy5aNmpXV85mGGbnrp0+VvKfglUXHoRSCUfN6TDc0MSrm0BoSCaNqJ2KV669oOWY/hgUEk5QMhEFddQAfaTFtz7hcsehpg2H3eWVwSm0tS81hKcy3YXxKKg9BCT8dxpoaFg871rWOt+0GDp6lFkGN/Xh/zPmzuzY3TuwcACMkbYtzx0yP/OFmyc8Zs7c6Zd+/38+ASIaNA3qBZDrcGqLwdh2mAhDN08GAx3+55+rcz6/+SA3oCjweLyFgYC3PdnrSwCQEF4SIE/ForT9Xg/UhRu4w/9zrr4667YUDTQ2lHCOV4pet6krSSnxVN2kDPwOFiV/IuB3+TmOz9bXe7n5JIgU1irCo1b0Y5I7VFzkeDQUyHQ3xqFoL0glXPJ59Fh7GYgGoFQacnIlhoh6R3u6WNMSRNZ9d2tr74uXlq/bSqC/S7TNs5v3l3/mCzcnNP2ilJrpcKqZKXXyz+kD/dHGHdsbe599qu6CQ4dayoko6XuGroxCABIA2GX1au+MSEwv5LRZtLhgjl39OdtDv945j9tG7+8jFDGDdhuRaZ6M9/XxamoTdtrUHS5V4qn6plKoAVnyfYpBqa+HfdU/TfYEYd/6x9yedWugKOGh0SmH0OIAPrxtmzfx2rvpt4dzMBE59OGhgHPGTMuqb6ZK7+vzg+hdnDZKwy4r+2CCtigg4QCgq3Nw4Ug05puWl5OWXVC6rrc1HT3R+vxzh/Jeeu7AiqHhUQunDoyURpslADiHodFYhaY01hzXjPwcVsCQLN0wj+/b08xaOAcAp+oOzJm52srpq9Top3qD4L45m64d9vQmcSUl3tkqx/gNiD5k0SnbiOjvw/4aVqGTsYQC1ZWl5VW1JvBdBbA/I5NYBKCHHTCrLJtntkksEql15U0fBSM3RKS1ZWDWquz57kZCIe40XGTuzK66lPaunUXp9AKcvGUIdbWhk9dct9yeAEAh0tM54N+xwxd98vE9hQH/yaUA7CgMRzkqJ+m3f0ACgHNSmqMClPgai3kLZnZBKWuKu5zDnjf8PiLivTkDiISaV+B01bhM1LZ+h6FgiJtFrDUY9GZ0S1RJ+dpLAH0TiLf6eQIvupTzEz6/t9ui8yHor/k9gN8vq/CWaqa+TNOm9vedQAOjQ64jx497I5nuSyLa238cLamoqlX0zj3i4xk62jAzmwKA/qNHuCOQe2pr77OyvDFCofUt7vJ1jQAlnClp89N1Bddcx5rZnVA8brQfPNDS8uQTe6a/vt23Kh7T01FToNHnS+1+MaVvCFbQQCs4SyxXrFhyHFZVdzuHB371WlK5BsgwcvThwcPO6TOzYiHgwJEj3N9XRt/+3Z7KTwHqXsCSLWakFL4f9DVV2lXWuNXnDQLIytXw5zuN1E4CJRwADPr9FQBYyW9sFImEW7hv0bas3VGgLQQkHADs3OFbRURDSqmkSi0TofdYe2/Tqy8f0Z96Yp/n5Im+IgDpnVdV9HCqp5AA4BxMQgVncGn1RUWDtnXmbeJxPXTkUFvSIWzEHxiadcmlVnYpKQQairS1lfPaqIzM/5eUeKepHP2nIPyLRafsMZX5qRbfhuctOp+YdGgHgG8merQ5OjLTjMUbtRxXxvMC60ODDaTHWS8RSlk7/3+GaeIFpeHLiR6vx3VX58m+A4sumJNooigjMjwa2L8v1LP5mbp5u15rKjcMc9ythGnQH9PMX6R6EgkAzkExokoAWHVhoS1vcWd7bVtjK4CkK/mdOnRwfjYEAHr/wFGY+lWcNk5K/whAaal3GTn0jSCw+joeBew3NHykpWmDldOhYpLRR/XXHblO1ht9pDXUMcNTkfEAYMjvY+9QibmcKa9vGYs+OrzdlTc9CiSesn3bq43Rj318/Ge4aVJXa0t3wx+erMXzm+vWDPRHrZszSJGC+vyxxjtTruUiAcDEFADW2+my4gVpyTz20P07UlpUEg2HlxOoX0HxkghZbKixYYTZpCcQqD5qS2fGUVq+9oOk9IdAsGR3BwE/d1D/V4NN96QtX4TITq2td51ye6rqoTBmgZqx9B04MHOGJ/NlPPoPHODtiSccaa/39trRl/b2H0fd5VU7ALwv0TZPbtxTclYAMNLbM9iwa2dgaPPT+wuPHGotJaK0TOdyKKW+G/RV/9aKc0kAMAGPx1toQGfNEc2dN93SRBFjGYnGmvxNJ1KKRsk0nXr/gM9VUJDRXOn9+/dzd0y8jhQyX3GVllf+I0E9BILDgtMNg9S/hQPVKc/diSlEox0glXAAMNTYtBIA623XagT0R9t4U5BK4RW7+gMAivACqcQDgLbWnmXdXQP7Wlq6hzc/WTd9+/aG1aPRWOaHRcc3SMA3Qr7qlIf+z5AAYAKmZrJSADudzrjL5WSvyud6ZevREwAvO+FYhvz+yJwrrrCgR8kh0zwZ7TjJXUWftvn/4uVVbjLxS8CSh3+TZpofaW7ecMSCc4kpRBFeIeDziR5PejzPiAzXOfKnZ+xhpfedaiDTvJrZzNYiVjqMLQ7mV/VDH/hB5m6AietWUA9r5PhhKln/xpINK0mzl0msh2yJe0EbAJdNvfmjh+/fbsnWs4GDBzOaWDzW0cHO0UZEaZv/d5jqS7Bmq+QmBzmvkoe/GEssx/UqANbaoWGff8Cm7iRksKGRO32la+R8zZbOvKU1cOdRAFlZMZGJANSRUncR4S/mzupcEvRXf9Xqhz8gIwATU8SaaFt54ZJuMHJ7J2N4ePRIS7jHko3A0fbWciL0KAV2NkEr9B85xK1aMzCvoKs2bEdnxkCg96d4irgi/GcwUPM/SOO0hZhc2uu9ve7yqv0AEp6O66vdu3jWJZfY2KuJnardV8I5nhT2BPxe+4MWwhYofMb261ivi4CXlFJbEDe2hEIbOs78IGzjRSUAmABxqwBetMz24jQvPHco5ZWfZxCRFuvpasqdvyDhfcgWov5Dh1gBliK8YnUSkYkviMUpPbaV+tegv/pBy/ojpixSaqsiSjgAiLS3l5NJPUpTaQ/eSdebY91drFFIDcrW4f8zlKItBDUZAgAdhDeh6AWltC1Bn6MW8Jrp7oQEABNhVgGsqFhkxVzxRMxHHnjN0q0op/bVqsUf+ICVp0yIGY/59cFB7lLmF23pzHgI3UAKK/+J7i7xVPaHA+uftq5TYirSoF4m0LcSPZ6ItHhvtz9n/oK0BwCRlnAbwMuASWRutak7f8aMu7Yql64jO59trSBsUYq2mHHX1nDY25fpDskagHGUlHinAWBVubqgcI6tW+r6TkUOdZzot3Tevn9/7UUA0r4dLdIaPsFto6U9AKDtKZ5htlLqSXd51fdvusmbjTckkSXMmPY6Tq/sT9hAfX1GCh317dk7m9lkOD/HZcv+/7O99VBNy7USMALgRaXo6wYZq0P+muJQoOazQf/6J7Lh4Q9IADAubZpRDubvZ/qMabYWAXr2mf2Wz6GZsdEZxsDAIavPey69b7zJfLOmQCBQ02xPb8ahaT8FkOpNVgH4RssxfWvxyrVJpW4WU1847B2BAivg7N27ZwWYiwdTRjQw4Pcx1yCpV+rrvTF7OjSmx9N4rbOoRgXcTSb+Kh4dnhvy17w/6Fv/o7cWKGYdCQDGQTpvB0DB7PxTmqbm2tUfAPqjD++ypapb38GD3GQ8KSGTOiPNAd5NhPCCTd0ZV8hXfVApfMei092gGdr+Es+6Gy06n5hilKme4RxvDA3NN6LRtO4sGe3pPgLT4I1mKfzBpu6MKZ7jfAQKp9J0uQEF9SQB/wadSkL+6pVBf81Xws01L7S3/9j2NWGpkgBgPIo5/79iyTG7ugIAvb2DB3p7hmyZ7+vdszutbxLR9rYGImJ+9ng3R6sEfTV3KsLXkPpIAEBYrBS9XOKp+k+cHhkQ4o8Umc+AuVtk4PDhfpu6M6b+ujpuE5Nijs129GU8b2UbXGfT6U0o1ILUBoBuLC50zgv6qz8c9tf8IhRa32LTNW0jAcB4CKwFahddWGTrnM4TG2tte0vXBwcXmCPRtA1R9b7xxkxmk4H8XOc2O/qSiGCg5scA3QyAvW5hDE6lcJe7vOqpkhIvdy5VTGHNzevbABzgtOl5facH6dtiOtK7bx+3zO2ecNh70pbeTCDkq/kZCFbtwOmEwsMg9SnNdF4Q8tVcEQpUV4b861/bts2bkXUYVpEAYDzMEQCbiwDFnnx8d8KpQpMxUH/UlhzdZyOgd7Cpgfd/UXghzXOI7xDyr3+N4s7LAGyz6JR/o1zx2mLPumxOPSrSTCneSFe8v2+JGRttsKs/b6ef6q2j0RFWYiyV5uH/twsFmv5ZAXeDHyDpAF6DokrNVFeE/M4LQr6aT4UC1Q83N3s7behqxkgAMD5WAFBcunCaXR3pONFX198XsXWHQc/unSV2nv+M2IkTR2GarGyJyqSM3UTeLhz2niwudL5XKXwPlrx1qVJN0S53xbp/Tf1cYkpQJnuqa6ihocuOrpyt903+4nrNVBn87m40gv6ar5imdjOdqwwxoQWg+0xFH3aQc17IX3NjyLd+Q3NzdUb256eLbE0ag9u9dhEA1vDs/Pkz5tvUHWx87E32MBMp7FKEhBP8xLp6io1YrNGRk2NrmdGePXtymE1iesx4zpbOJOGtIb9vuT1Vu6DwAJifkzFMA9EvS8srr41FI5+3Y+FQSYl3MTkNt0MjK9IaZyXD0AyXos7cXIc/06NFqQg2ra91l1e1AUi42mf3zp3Fsy62PStgpK+2bg2nAQHNgUB1vV0dSlRL83dfBXBtcXnVSk2pmxWRhxRmgNQwFB0hGDvC/jsbM93PTJAAYCxOxXr7dzg0IyfXVXSOw3RDN7sJJiuTHRH0pzft5X67jygT/wWFLZxGfftqO+e9+xrbAgACDQ0cPsi6iQB4sbX1rnSt6E1YKFDzh2UV3sudpG8k4LJUz0dQt7vypl9WWlr1kWCwxm9FH0srqm4hE/8FpV+hANAUTkasaSYMAJGY3u8uX/eAMRr3ZuPnJgEEqMcA+o9EG4x2dZaYejygOV0euzoV6+k+aMRHrzn3kX+iCE/Z1Z9ktPhrGgCkZbpkspAAYCxKsVIAFy6dewzAsrF+ZprU8ejDrzc99Jsdawb6o+kqvvNocZHzlZZjeheAhOtZd+94dc28d18TAZBvR6dGj5+sI12/ntWI1GN29MUKrT5vsKTEe61yxu+BUlYM468hB/aVllf9v6C/5vepnMhdXllFhO9CnXe7DQoA+pIj13FLaan35mDQO+mKw2gmHjU1JBwAAMDA4SPHZl96qW0BQPf27ewiZ6RMKXud5WQNwFhM5gLAVUUdY/17NBJr/NtbfqD97O4Xbxjoj6ZxxTeNbtsGUwGsh4gZHZk92t3FWoXM0fnyFm5a3WiOYzSr0+iGw96RUGD9Z0jR7QAiFpxyFgGb3J51P0w2e2BpeeVtgKrGeb3VUHnIqf8e+Kjd6bktd3reGaxRoK5XXl4NwJY6GWTSiYEjh7mLVY+E/Rtsu5cIa0gAMBbmDoALL176jhs/EXo/fttP5vR0DSb8Bm4d9d/ucv2gSXSc27Jr69Y8O3pE8XhwOBjkZhB7rqnp+4N29MdqYd/6B6CZ14B54x6HgqKvtRzTX1263LuE25hI22BBHyY/wuUlFSs+muluJOlRzsH64OD8+Kne/XZ0ZKjpaBOZJiuQIoK8/U8CEgCMhRQrB0D58gve8ab13Oa6w52dA4us6xTbhUqp/+I2GmxsuASGbvmwad+BA23cNqRoUt1EQk0bDjnIeQUxR14mcJ3T1PeXLa96T6INysrWXsgtYz2VKeDDme5DMgwyWAEAAHS9+qodU7rUuXUrd2rBdBD91oa+CItJAHCWyy//rAuKSjltCgvnzDr73x6+/zXWObIGkRo42hCy+Kyxrm2vchf/dcyb2fmsxf2wXSDgHQj7az6iFH0d1gzJLjJNvOiuqFyLBIb0TaVNzs+dTRQRq2pdtngrd/xeTpuBI4cvNU2TPeo3EX14cH+su/tcC5zP9tpbSY1ElpMA4Cw9g/PKwFwcWVCQd3aRl3h7W6+thYHs1PnylhWwsELgaHf3PmN4iDn/rx6qrb3PljnNNKCgb/2PlKL3KMCKFNEOkFrvLq/6Q9Fq74T1JkgjW6ZwJitTIa11Liyl1H2cw8k0taGGo5bsIDmjc8sW/t4RGf6fNCQAOJupseb/8/NzhzSHtvCsf3YopSZt8oh4/8CiSHvbHqvO1731JfauAoP0+626fqYEfet3KtN5GRFeseiUf+2KxWvLytZdbtH5pjxFqM10H5KV73I8CoBVAbTrpZfKYUXdCgCkx5v7Dx/mftb6cxyxDFbjExwSAJyNWwRo+QVteOfQrLZ85ZKgdZ1KvxObNpXAgiFsczRaP9DQwMpjQAq7srV8Jldzs7czHGh63+niIZZkDywxNXq9pLzqc6mfa8ozIpbCVQAACuxJREFUTVKTNpCsr/cOKfDm0mN9p5aMnDzxphXX79m56ziIWDtJFPCbybJwV0gAMBbeDoCLlo6ZQ//f7vhLKwrHZEys79TSaMfJlEcBTj77bBKZ7dQ9qV43u2w0QoHqSgXzVgBW1FzIVcC97oqqBxet+Y8pm90vVQrqJy2Banb5umxiEP2S2+bYpk1FSHEUgEyzo3vn9iuZzUwY+Fkq1xXpJQHAWRTxsgCuuqhwzLfky68ovXrNxcsmdXrJ4xs3LkEKZYKN2Ghj/+HDVzCbtc+b2fFEstfMZkH/hmfJ4bwchH2WnJDwqfzotN3u5VWsz+x5gADcE/Q3spLpZKOWwIb9AN7gtIl1dxWPdHamNArQs3t3E+k6q74JAS9YlcVSpIdkAjyb4pUBLi1bmDvOj3J/9n//MueOz97fcKAuvNKCnqVdrLvLPdrdtSt3/oKEawq8Xcdzzw1y888qhf+dxIv/zinc6A17PHdcZ2LW/xDUv1lwygthYq/bU/kvocD6jUm0HwXIioWKmUdqGKA3oeGXId96y9awZBoRfU8pxUqre/zxxwtLv/hFHUnc48k027u3vnQ1tx1MTLGRu6nvPM4U9k5Fq71zXTG9h9Nm686qpml5ORO9gelNDcfe+M3/vTazvr69MDOJgZLnKph9ouyrX52poGZw2hmjsQbfXetXMOcQIzGHsexY452sv8Fk5fas+yQU3QvAkmF8BdxNpPZB0UOMZrtD/hpWjneRbl7NXa4fAcB6kSj9whd35S5YyA7eO7e+9HrPjh3XMps1hfw1K2HJOheRLjIC8DaOUWM5JyRSStG0/Jyl5/jIO5evLLz+zh/+Y4q9e4eR/r5I0//e89Lo5qdqr7L65GfE+/su6N+777XZV155A6MZHX9io8FdQARS954vD38ACAWqHy4rW3vA1LRNYK49GQsBX4YiK9YYiKziNRWq/puAX3NatT3ycInny18dhlIJB5hGNHKoZ+dOdtCgYFWJbJFOsgbgbRRzB8AFFxScANlTOCcB0wpm51/87XUfuuon9356u50XOvn8s9easXjC6xlGTxx/fcjXxEz7iwgM4/vMNpNec/OGIzla7Eoolczw/VgmzBMgJqe8HOcj3JwS8b6+JX0HDnDWm8RaH3hwOjtwB5qWFTo5o04iS0gA8HbMAGDl6qKTdnWF4/Iry27858+9Z6dd5yfTdLQ98iAB506qQmS2hR/4DTfrH0jhF6HQhjGLKk11TU3fHwz5qv+egK/ApoIuYnKrr/fGTKCa2+7EM09fa0ajhxI5tv/AwV0jJ4/zMyeS+s62bV5Lcg+I9JIA4G004gUAqy9aOmRXX7g+/c83lCqlbBuCi7S0rOx86aVaTDzMN9L20MP95sjIO1Ijn8MQYs7z7u3/bGF/zd0mqRsBtGe6LyL7lBQ6f6WgePkxTNMZ+sW980HUPdFh+sDAnuNP/54zzXdGXShQbdXolUgzCQD+HHME4OwMwJnjdGpLyjyLrc7h/2d6Xt9x7WBj43jTDXrHM88cHA4GuEP/UAobwmFvVoymZFpLoPoNBxmXAfRSpvsissvpt2z6T267WN+pJS2/+XUXiMZM0GPGRo8Gf/6z5SBiPw+UQhVk7n/SkgDgjz7qIPAKhxQum5dVSVgWLZ5lewau9kd/e9OpvXu34+2JRoi62x979HBv7d53cc9HQLNm9v/Iyj5OdoHAnV0hv++vcHrId9KmlBbWC/prNieTWjrS0rIy9MtfdJCuh9/+7/rQ4D7/j39YaESjBUl0Z1vQV/NcEu1ElpBdAG/xeJaXGMB4e/rHdORA2+CChbN22NUnruPHTi1Nx3VOPvvMjQOHDjbOv/66k9GTnY7una9dRrHYpUmdjOjrgcA9lhUemjo2GiE/vlNcsfYNjbSHAMzLdI9EdtCc6itk0D4AOZx2I8ePexo3bIjPu+bqXXlLi2KDTf78/rqkdxDFDDK+kGRbkSUkD8BbSiuqbiHCpCs/mxraCqibM3Z5hcdDvpqPZez6k0RpqXcZOfSNAOzY7il5ACYhd3lVJYCaDHZhfchfU5XB6wsLyBTAW4gwKeuGp4IUHoJST2fk4gonY5rx+Yxce5IJBr2tDuq/ASR51sVpxYXO71mWUprvoIP62TsSRPaRAOBPWHmvp4gRxI3PAehK83VJET5zPiX9SVUgcM9oKFDzRQX1CQBZs/tEZMa2bV7dAXU7Etiaa7FR5VCfkmm7qUECgDOIzrtV6BpwLBTa0KFp+AdYVEM8IaTuDPprNqftelNI0F/9W2i4AsCRTPdFZFYgUF0PUp9GOlfhK9wRbKw+nLbrCVtJAPAWE9r5dkPVYy7XUQBobqp5hYi+kZarKvV0KOBYl5ZrTVGhppqm/BznNQp4NNN9EZkVClQ/Dqj1abrcPSFfDbs8scheEgC8pSVQfQBAa6b7kT60vb3e+8e88eHA+v8BbK/mtTff5fgk4JWtbSmqr/cOBf01/wil7gAQS/Y8pGSb4WQX8ld/BwqP23yZTSF/01dtvoZIMwkA/oSI6MeZ7kS6EDn+++x/C/lrvqxA99p0yTeUEX9vfb1X5q8tFPJV/5SgbkCSwasy0WZxl0T6Ub7L+SkCfmfT+Tfn5zg/AWw0bDq/yBAJAN7GiYGfA2jIdD9sp9TT4cB3t4zxEwr613+elLoLls4r0tYcLfb+YPB7/dadU5wR9le/6VLOywEa6286IQW8aUefRHrV13tjYb/zkyBlaVItAv26uND5d/X13qRHmUT2kjwAZyld8e0KMh27QZiT6b7YpEEZ8WvO9TAuqVj3D4rolwBmpHAtQynUBH1N1fL2kA5ercSjr1MK30Fiwf0AxZ3F4bC3z+6eifRxV1R9AYQfILWdTSMAvhny19g9LSgySAKAMZSVrb3Q1LQ/AHBnui8W2+Eg47ZA4M6Etv2VlVUuJU27m0B/x74SYR809bWQrzprMiWeL9yeqvdB4REA8yc4zCSF28K+mqfS1S+RPss8317l1LSfEqm/4LZVil5VBn2puXnD+bYw+rwjAcA4Skq8szWX8W0C3QEgL9P9SVEXgOq5szrvra29j11uttiz7hqHoi8RcBsA1wSHGgB2kcKPwr6apyFFQjKmrKxyqaHUb5TCe8b4cScRfTYcWJ+ZJFAibdyeqveRwpcV8H4AjgkONQA8T6T9dJzpQTEFSQBwDh6Pd5YB4wOk0dUgLFJKTfQAzCI0qoBjpoFt06c5X7FiDm/58m/OjFPO9YB6F5nmEmhaAZE5qKCOgcjv0lzP+3zeCcuOivQq8VTdpIC/hqaWwTT7AbVbmfFNsh7j/FK44tvzcnTnzaThUgUqBNQ0EEWUwkkQ9ijTubO52duZ6X4KIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBAc/x9duncasekNIwAAAABJRU5ErkJggg==]]
_G.NCLIENT_HOME_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAAA3NCSVQICAjb4U/gAAAACXBIWXMAAA9lAAAPZQFXwiB7AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAvdQTFRF////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVynFdwAAAPx0Uk5TAAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8gISIjJCUmJygpKistLi8wMTIzNDU2Nzg5Ojs8PT4/QEFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaW1xdXl9gYWJjZGVmZ2hpamtsbW5vcHJzdHV2d3h6e3x9fn+AgYKDhIWGh4iJiouMjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6ytrq+wsbKztLW2t7i5uru8vb6/wMHCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+1KDfXAAAE+ZJREFUeNrtnXlgVNW9gG9WIAHCWkCQRaQgioiIbIobFas+rAVF0YJULbZUxRb1+dAiWkTBIkVqqcW9PAlgEVFRtChifCyyKhCoiCCEsAqE7OePV7WUCZD5zfK7Z+6d+31/J3OGez5mvtzlHMcBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcJHavfoP++24abNnTxv322H9e9XmiARp8vuNyyszVSjLG3dFHZeHzewyZMKCvDhY8sp9V7Zg+uKkzl3HT/5Ryj8ZWdfFgfvkGw2m1WUO46D1hAPhju43T7Zx61NnSqXRYWs/pjFWeuaWS4e3PLenGyOn5Rk9BjCTMZEzPbLjOz1Hf+x7FOff7GrEZMbApVsj/pC9VHvs04s0BTAzmM2oyZocxXdw5eQs3dH/ZnQ5nwmNki4bozvCG7uoDr9JWYARzGh0DDgc7SE+/FPNPwEqlQX4M1MaFf8TwwRU/rfe+N2V59/kMadRUDPGb+CXa2q9g5u0BdjNrEZOs/+L9TB/3ETpLQzVFmA/0xp5/m2L46Tb2QgQvPwL5VB/BAhe/lVJwXsRwMfUUjgB83wNBAhe/oWyuDEC+JNzt+kc7S/OQoDg5V+VuwSuQgD/MVrx9GvFPQjgt/yboXvEn81EgODlXyiLGiFA8PIvlM0dEcAvDCwyLnDgCgQIXv5VuV/0bgQIYP6F8kwGAnidU5YaF3mvAQIEL/9Cye+AAMHLv1D29UUAz5LyYKVxnfIRCODV/PtfY4Wn0xEgePkXyjv1EMB7dN1urLGhHQJ4jeuKjEX2XoIAwcu/UMqGI0AA8y+Up9IQIHj5F8pbOQgQvPwL5bO2CBC8/Atldx8ESHz+PVRpEkbprQgQwPwLZWIqAiQ0/5aZBPNGHQQIXv6FsrYNAgQv/0Ip7I0Awcu/UEqGIkAi8u9V4xnGpyKAbZovMx5ibm0ECF7+hbKqFQLY5Poi4zEKeiCAvfz7nfEexTchQADzL5RHUxAgePkXyuxsBHCf8742nuXTUxHAZ/n3ta5OO85HAF/l3/IWLZarvuCRGxDARbJm6h7H3Kx/vWau7muOSUEAv+Tfw9/NVcrDuq86MwsBfJF/xz6tbzii+sLLmiOAGwxSzr9ux166m65a27sigH7+jdE9hCuq7MHaYoXqixcNRAAf5F+V19dNwcrRCKCbf7p/rP07/6p8wiin4N9qIoAP8i8U5RT8pBkCqOWf7tRUc7rOOX+H6jBfnYMAPsg/F1Pw8LUI4MH8mxVmV9isWbopeD8CxI3yuXozNiXsp81Y3dFeqoEA8aF8iubIjdKAN+r2xpImCBAPN9jJPxdT8MtOCOCZ/Kvufo2qnPqp6qAH/wsBYs0/5Qu1s7IjGzdbNwUrRiGAJ/LvkZSIP3ke0R35udsRIPH5NziawQfrtscBBEh4/nWPbvjuO4yXSXoBtC/NRJZ/LqYgAiQ0/2ZnR/8esmcjQMLyT/ecfBT552YKIkDE+af7/Vs8ONY3MrgYAfyffzu7x/5Wuu9EgODlnx9SMHkFUL4ga+Zkx/d+sucggJ/z71Ep/047TfpEehQB7KF8JS7cmg3fc9Hu3RdJP3NTMQJY4kbb+Te81JhScesHD6ZgUgqgfTfOypbCgOlTvv/BKdIuYC1XIkAS5l+DhUd/dKG0IaznUjAJBbCefx03HfvhTR19loLJJ4D1/LuyyiXaA1f6KwWTTgDt/OshDTiq4oTbdgR67ESApMm/Gi+c+Esv1PBRCiaXAMr34JnXpPxrmneyX8trKr3P1xDADbTPt/9eyr9zt538F7edK31S/R4BvJ9/N0sDVr/QXNH10u/eXIwAyijfflkg5V/4q40PS58ePQoQQDX/lO+6WSXlX23hlM6c2lIKrkIAxfxTvu/uNWn6WonTF37h/28Veg0BvJp/46RN/C7YJb/IrguEF0kdhwA6KF9lK/6ZNOCtpZG8jrwd6M+KEUAj/3QPY0FPYby0SZG+1CRpZ/ieBQjgufyTvrvrL4j8xRbUj7slEMBu/v1dyr/2G6N5uY3tpRT8OwL4Kv/67Y/yCPfzdAr6XQDr+TeyPNrXLB/p5RT0uQC28y9zeiwvOz3TuynoawG0765ZLeVfk49ie+GPmkgpuBoBYsi/OZbzr/PWWF96a2evpqCPBThV+baKx6T8G3A49hc/PEBKwccQIKH5VzJE+r55MK495isflC4PDilBgChQvrVyVy9hvPjXmZ2ZJQzRaxcCeDb/NE43iI8XJyIF/SmAdv7NlfKvp8r3zU7pr8zacxEgErTvqh0v5d9Qpa/nkqFSCo5HAJkelvMvbYLeYBOky4O2U9CHAtjOv5w3NYd7M8dbKeg7AbRvqF7dWhiw3XrdAde3EwZsvRoB7OXf63WEAfvu1T7ke/sKQ9Z5HQE8k393lusf8/I7PZSC/hJAO/+kKM+Y5s5Rn5Zh6c+OJBNA+WmaXb2F8Rp/4NZh/6CxMHTvXQjgdv6tkfKv0xb3jvuWTlIKrkGA486SKT9GIebfNQfdPPAHr/FGCvpGAO38e1zKvwcq3T3ylQ9IKfg4AoTkn+5NUyW3COPVmuH+sZ9RS3gTt5QgQILyr/kyG//7ljVPfAr6QoBU2/l3vqVtXsTdB91PQT8IoJ1/8+rY/bwJg7gIRZ15CKD9HP0TQv7ZvTtPuhMx9YmgC9DTcv7VnWesMq9uQlPQ8wIoPzVTKD2z33adscy6tsJbuqAwuAJoPze3to0w4CV7jHX2XCK8qTZrgyqA9uMSYv79sswkgLJfJi4FPS1AK8v5lzHVJIipGYlKQS8LoJ1/w4TxGr5vEsb7DYU3N6wkcALYzr8zN5sEsvnMxKSgZwWwnn9Xf2MSyjdXJyQFvSqAdv69If21fV+FSTAV90lnKN4IjgDa+TdByL+aLxkP8FJN4VNxQlAEUM6/0p8L4zX7xHiCT5oJb/TnpYEQQDv/LhTGO2+78QjbzxPe6oWFyS+A9sWYddKWnsp7TMfFkRuEN3vaumQXwHb+eW0bL2mTMu0U/EOax/JP+cGoial2fYsfaami1Im6472V46X572U5/9qsMZ5jTRu7Kfj56d6Zf+WHo3dL+den0HiQwj5SCu62ezkyafPv9lLjSUpvt5uCZcO9kX/KC6TMF/IvfbLxLJOFbajrzrc7ni/zT8jbBu8aD/OusA11mnIKvlMv4fmnew+8uFvHGfnG0+SfIfwDbtX9/trww+TKP6mjfnzAeJwDP5YKVjcF912WyPxTXhJBzL/fVBjPU/Ebyyk4IjD5V+N54wuer2E3BacmKAW1l0V6Usi/ph8bn/CxsA112pO64y1skAz5d5swXpevjG/4qovwj7lNNwXzO9if/6GW8++6w8ZHHL7Obgruv9zn+feZ8JxNyhjjM8YIlwfbfqY6XPldVudfeyGUN4X8y55lfMesbCEF39Qd788ZFvNP+WKcdHG71UrjQ1YKi9mn/UF3vH80tDX/vS3nX+8C40sKettNwc0d/Zl/F0nX0UuMTymR7mu4SDcFxbOQKvmnvAqWlH/afzPbRTq3oZyCFff4L/+EO5vqvW18zdvC5boc5RT8a2Zy5V/7DcbnbGhvNwU/bOyn/JNuobl8n/E9+6RzNMo3OH1xlnvzr7zuzR4p/+4uN0lA+d1SCuqub3Lwap/k3+dC/mU+a5KEZ4Uv5raf66bgKF/kn3Rj+w8Wm6Rh8Q+EFHxLdzzpgrQX8m+SkH9nf2mSiC/PFlJwku54S5r4Pf+uPWSSikPX2k1BybhE59/FwsW/0ZUmyagcLVwevFg3BQ9do5l/yqtdSU81Zb1qkpBXhW2oT9dNwcr79fJPeb27t4X8O3WFSUpWCNtQ5yif9Xy5ps78az+J+ZSQf8qbjHmInT2EFHxKd7y8phrzr7zQWdkvpEcNik3SUixtePwL3TVPxXsTvZd/bq+znmikZU+VU/DwAJ/lX858k+TMz7GbgqN9lX/K/3pPIv4fUE5BcZOrcPmnvMqllH+X7TUBYO9ldlNw6SleyT9pPYMRZSYQiE/zDdc9ENu7xjb/yitd7xVWNMl4xgSGZ4RbuC/R/Sgsut4D+be+XfjxGi0yAWJRo/BHo9163fF+l5Lo/Fsg3Bt31hcmUEj37dRboDvezKzE5t9kIf/6HzQB42B/IQWVl0Ja3sLL+Xd/pQkc4sUa5RQU9ztNXP7VesUEkldqWU3BIzdGmn/K69tL+dd8qQkoS5vbTcFHIkpB7WWNpfzr9rUJLF93s5uCs7Pt598fhQVsBh8xAebI4PBHJ/2PuuOtbCnNv/LWBmV3CF8340zAGSdcHrxDNwWlWxKUV7Tee6ndW839yOvCvqiX6qZg8c0W82+DkH+nrWX+jVkrrI7YboOtzxzt/JMWsr14N7P/LbuFm2TqvaM7XnV7W2jvayPl3x1lzH1kpaSdgqtb28g/YW/t9KeZ+GM8LfxnUd4ffVfvhOdfg/eY9VDea2A1BUtuOT7/lNexl1Yx77iZOa+KtMLTD5VTsOrdqdrLF79TP/y/5qpvmPHj+eaq8MesvnIKzqvrXv5NEb7RRlUw3yciPdafPsWtPz976/45JuVfzReZ7JPzYk2rKVjY69/fLvtUX1bawqJZHjNdHXnCNtSXKU/Vd6WWo3vNUcq/rtuY5+rZ1tVqCq7/9jkN3f57V8i/QUXMcjiKBgkpqLtp2nzHaWvzhEbKWKZYYmyKzRNobZ3hmvn3q/D61p7D/MrMEbah/pVmCg53chWboq+wztRqZjcSTn6q/hh9FVMw19Fbin1je6v3miQxhcLu2e03qg1V4GyxlX+3lTKzkSJtoaCXglucJXbyT/uR12RHeJBaLQWXKDVA+Qi7J7KTH+lyygiddZRzncds5F+Hjcxo1EnVwUYKPua0VFiTScq/K/Yzn9Gz/wr3U7C4pePEv0rtQuHT6h4u/sWEtAFM/YVxDzHp21W5412VV9i7uMZ0pjJWpodf9Tt9apyvf+i7VcyHuZp/TT5iHmPnoyaupuCw718lno0g9v0o/Ds8ZyuzGA9bzwl/fH8UTwo+fvSGwLkxv0S+kH8DDjOH8SEt9dg+P+aXnvuf2wJrr4o1/8Lfy5ryUCUzGC+VD4W/PNgg1hRcFXLRqVVsVwT+FD7/snOZPpWTNeEf6k7/U0yvWlBla+MeMZwNKP91+A+nlp8ydzp8KjzU/esYUrD4uMeEB0d/nkLIv14FzJwWBb2EFIz+TNsJCxNEe69Ofgerq4wHnBOe5Dn+XHu0KTj2xGCL7gtbeJQpbSKTpsvENM1H7XJPEpZZy/XyT3sfPBD3WYwqBZefdNnI5tsjzr87hZuX1zNf+qwXbri/M+IU3F7N6mRdI7xle//l9u5Zg2NIF90vjzAFi6p9+GBgROdtpPy7q5y5cofyuzRSsHJg9a8wOv78y/wLE+Uef8mMPwXDbiIjL9oqLHXf+ENmyU0+bBzvpguvhH9yNy++/Ou0hTlyly2d4kvBPOEJ5KZb48m/nxxihtzm0E/iScGt4l6SZ4eZw01nhP/dB7j4Z4HKB8LPwhmbwtgTwabi/au9g+/98PlXawaTYwdhJ7gG71f3ixX9I1ku/N7Y8q/FcmbGFsL2H9Wm4L2RbRjwXCx/gzqvMi/2mOnEci7muQh3jMg8yZ9y+/tJv8XpX4tslGaj30lS8MPMSLeMafzPaPPvX/Dwh0X2i9NxYgr+s3HkmwadueO4/GvoIIC/BHAaHpeCO86MZtuwph+E/t0xNcNBAL8J4GRUuUD8QVMnKtKfOPo4f8WMThH9BgJ4TADHuXDF0Z8vfSLdiZb6Q+YWH9m0aGr7CH8eATwngJM65NlF282h3MH1nJjIiOaHEcB7Anw/i2mOFRDAowLYAgEQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAABEAABEAABEAABEAABEAABEAABEKAK+XnK5COArwQYpP3PG4QACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAACIAAARWgEAHsUehBAdYggD3WeVCAtxHAHgs9KMBfEcAeL3tQgPs9dYSuT24BxnhQgM58AtijmwcFcLYigC22p3hRgCkIYIupXpx/p3MlAtihsrMnBXBeRAA7vOjN+XdaFSOADYpbeVQAZywC2GCsV+ffSZ2HAO4zL9WzAjh1ViOA26yu43iYVtsQwF22tXI8zSlLEcBNlp7ieJxaMxDAPWbUcrzPiD0I4A57Rji+oP6EEgTQp2RCfccvtB61uAIBNKlYPKq14ysaDRw5/oX5byWKPtr/nj4J+6fMf2H8yIGNHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPA1/w+6IpPeMz1YdgAAAABJRU5ErkJggg==]]
_G.NCLIENT_INFO_B64 = [[iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAACAASURBVHic7d13mF5lnf/xdyaFFEoiPfSi0pRepAgiCKIUERAL6K6KKBbUFXXX3d8uu6vr/nRtiwvYVgQRBJUmKlWkhY4UpZeEEiCQkErq/nHPkEkyM3nKOed7yvt1XeeaTHnO+eDuzP197joMSWU3ElgbWKf3Gt97Tej37/HA2N5rHDAKWAMY0fuxv1V779nfAmDWcl+bASzs/TgfmA3M6f04A5jee73U79/P9V7P995TUkkNiw4gNdy6wAbAhsAmvR/7Pl+731VFz/dezwFPAVN6ryeByb3/fj4sndRwFgBSvoaTGvYte68t+v17c2B0XLRSmAc8DDzS+7H/v58EFsVFk+rNAkDKxghgY2BbYJt+H7cmdcurfQuAh4D7gPt7Pz4K3Au8EphLqgULAKl9I4HXATv3u3bEhr4ofYXB7f2uO0jzEyS1yAJAGtoI0rv5PYDdgd2ArUhd+yqPhcBfgVuAm4FJpB4DhxCkQVgASMuaAOzde+1Benc/LjSROjULuI1UENwAXE9aqSAJCwBpHdI7+72AA0hd+T2hiZSXxaRegutJBcHVpJUIUiNZAKhpxgH7khr7A4HtYuMo0BLgHuBK4ArgOpxHoAaxAFDdDQN2Ag4iNfh7kjbJkZb3Cqln4Arg98CdsXGkfFkAqI7GkLr0DwWOJG2qI7XrOVIhcAnwO2BmbBwpWxYAqot1gcN7r7eQigApK3OBq4CLgd/gDoaqAQsAVdlGwNtJ7/QPJi3Zk/K2GLgJ+CVwIU4kVEVZAKhqNgSOBY4GdsX/H1asJaQ9B84HzgOejo0jtc4/nqqC8cBhpEbfd/oqq/49A+cAL8TGkYZmAaCyGkXq2j+O1M3vzH1VySvAb4GfAZeRjlOWSsUCQGWzLanR/xvSJj1S1b1E6hU4g3RmgVQKFgAqgwksbfR3CM4i5el24H+Bs3FbYgWzAFCknYETgPfjfvtqlnmk/QXOJO1EKBXOAkBFG00a2z+ZtCuf1HS3kwqBc4DZwVnUIBYAKspmwEnAR4A1grNIZTQd+CFwGvB4bBRJ6t7OwFnAAtKaaS8vr6GvRaThgQOQpIoZCRxPmvEc/cfUy6vK122kOTLufaHMOQSgLI0jdfF/Dtg4OItUJ08A3yINEThPQJmwAFAW1gI+2XutGZxFqrMXSHMEvgdMC86iirMAUDfWB04hLeUbG5xFapLZwOnA/wemBmdRRVkAqBPrkLr5P43H7kqRXgF+CvwLHkSkNlkAqB02/FI59RUCpwJPBWdRRVgAqBVrAl/Ahl8qu/mkrYb/EXguNorKzgJAQxlHmtj3Zdy8R6qSWaTJgl8FXg7OopIaHh1ApbQK8CngQuBw0va9kqpjFLA38GFSr8CdpA2GpFfZA6DlHUpab7xFdBBJmXmSNCzwM9IGQ5IFgF61G/ANYJ/oIJJycwvweeD66CCK1xMdQOE2B84HbsbGX6q73YDrgHOBTWOjKJpzAJprLPAPwM+B7bE3SGqKYcB2wMeA1UjF//zQRAphAdBMhwKXAkfgISNSU40kTRQ8nrSt8N2xcVQ03/U1y+uB7wAHRQeRVDrXkPb6uDc6iIphD0AzjAG+Quruf31wFknltBnpXI9xpEmCC2PjKG/2ANTfIaQNQTYNziGpOh4mzRG4OjqI8uMqgPpaDzgLuAwbf0nt2RK4kvQ35DXBWZQTewDqZxipG+/ruH2vpO49BZwEXBQdRNmyAKiXTYEfAAcE55BUP5cCHwemRAdRNpwEWA997/p/A2wVnEVSPb0O+FtgHnArbilcefYAVN8WwE9wFz9JxbkG+AjwaHQQdc4egGo7HrgEeG10EEmNshmpN2AacHtwFnXIHoBqWgP4PvC+6CCSGu9C0hDki9FB1B4LgOp5C2lpzobRQSSp12RSj+S1wTnUBvcBqI6RwD+T1uba+Esqk41ImwZ9BxgVnEUtsgegGrYCzgF2ig4iSStxO/B+4IHoIBqakwDL73jSBhybRAeRpBZMBD4MzAImBWfREOwBKK+1gR+Rju6VpCr6DWm54LToIFqRBUA57USaWbtpcA5J6tYU4CjsDSgdhwDK53jgV6QeAEmqutWB44CpwB3BWdSPPQDlsQrwPeCj0UEkKSc/Ix0zPDc6iCwAymJD4AJg9+ggkpSzO4B3A48H52g89wGIty9wGzb+kpphJ9JhQp5aGsw5AHGGAZ8BziaNkUlSU4wl7RXwCnBjcJbGcgggxqqkE/yOig4iScEuJk1+nhEdpGksAIq3BekEv62jg0hSSdxP2vPE44UL5ByAYu1B6u6y8ZekpbYBbgH2jg7SJBYAxXk36bCMdaKDSFIJrUk67OzY6CBN4STAYnwG+CGekiVJQxlBerM0DI8Wzp0FQL6Gkzb3+SecbyFJrRgG7EfaH+VyYHFomhqzUcrPqsC5wDujg0hSRf0BOBp4OTpIHVkA5GMiaab/TtFBJKni/kx6IzU5OkjdWABk7w3ApcDG0UEkqSaeJhUBd0YHqRNXAWTrAOAGbPwlKUsTSZMC9w/OUSsWANl5B6nbf7XoIJJUQ6sDvwWOiA5SF64CyMYxwPmkI30lSfnoWyb4V9LugeqCBUD33k8643pkdBBJaoDhwJHAFJwT0BULgO6cSNrgx/8dJak4PcBhwHRgUnCWyrLh6twpwLdxJYUkRRgGHEzaKOi64CyVZAHQmS8CX48OIUniLcAY0jkCaoMFQHuGAd8E/jE6iCTpVXsDa5O2DlaLLABa1wOcDnwyOogkaQW7AeuRlgouCc5SCRYArRkGfB/4WHQQSdKgdiFtxHZxdJAqsABozX+SjvSVJJXbjsAE4HfRQcrOAmDl/hX4cnQISVLLdif13F4bnKPULACGdjLw1egQkqS27QfMI53PogFYAAzuJOC70SEkSR17K/A8cGt0kDKyABjY8cAZuMmPJFXZMOAQ4CngjuAspWMBsKIjSXv7+7+NJFXfMNJprQ8C9wZnKRXf4S7rIOAiPNVPkupmAekN3qXRQcrCAmCpA4BLgNHRQSRJuZhH6g24OjpIGVgAJNuSZoquER1EkpSrmcA+wN3RQaJZAMBE4GZgo+ggkqRCPAXsAUyJDhKpJzpAsNWAy7Dxl6Qm2YC0XfCq0UEiNbkAGA6cDewQHUSSVLgdgfOBEdFBojR5qdv3gOOiQ0iSwrwWWJ80AbxxmloAnAL8fXQISVK4nYFZwE3RQYrWxALgKOB0nAApSUoOpIEbBTWtEdyVdDrU2OAckqRymQfsT4N6AppUAGxGWu63TnQQSVIpvQDsCTwUHaQITSkAVgMmAVtHB5Ekldr9wO6keQG11oRlgMOAH2HjL0lauW1IB8LV/g1yEyYBfgn4dHQISVJlbEXqAbgxOkie6l7h7A/8gWYUOpKk7CwCDiG1IbVU5wJgI+B2YO3oIJKkSpoG7AI8HpwjF3WdA7AKcCE2/pKkzq0JnEdqU2qnrl3jpwOHRoeQJFXeBqQ3k5dGB8laHQuAE4D/Fx1CklQbu5CODr4zOkiW6jYHYDfgOmraXSNJCjMPeDNwa3SQrNSpAFibNOlvo+ggkqRaeoJ0eNC06CBZqNMkwB9i4y9Jys8mpLamFuoyB+DjwOeiQ0iSam8r4Gngjugg3arDEMDWwG14wp8kqRizSUMBD0QH6UbVhwBGAj/Fxl+SVJxxwM+BUdFBulH1IYD/AI6ODiFJapz1gRHAVdFBOlXlIYA3A1dT/SJGklRNi4EDSW1R5VS1ABgP3A1sHB1EktRoU4DtgRejg7SrqnMATsfGX5IUb0PgzOgQnahi9/nfAn8fHUKSpF7bkE4MvDs4R1uqNgSwBXAXsGp0EEmS+pkJ7AA8Gh2kVVUaAugBfoyNvySpfFYjtVGVeWNdpSGATwInRoeQJGkQmwKTqcipgVWpVDYF7sF3/5KkcpsBbAs8FR1kZaowBDCMNMPSxl+SVHZrAN+KDtGKKhQAHyVttCBJUhUcDRweHWJlyj4EsB7wF9LGP5IkVcUzpOWB06ODDKbskwB/TDpxSZKkKlmNNBxwWXSQwZS5B+Bg4PLoEJIkdWgxsB/wp+AcAyprATCWNOt/8+ggkiR14UHSWQHzooMsr6xDAP8GvDM6hCRJXVoTWAJcEx1keWXsAdiWtInCyOggkiRlYD5pm+C/RAfpr4zLAL+Jjb8kqT5GAd+LDrG8shUARwMHRYeQJCljbwXeFR2ivzINAYwB7idt+ytJUt08CWwNzIkOAuWaBPjPwGHRISRJyskawELg2uAcQHl6ADYH7gNGRweRJClHc0m9AE9EBynLHICvY+MvSaq/McDXokNAOXoA9gBupBxZJEnK2xJgb1LbFya6B2AY8A1s/CVJzVGKti+6ADgG2Cs4gyRJRXsTcGRkgMjqYxXSsj/3+5ckNdEjpCOD50c8fETEQ3t9HBt/qQjPALcCDwOPAs8CM1i6FnksaXnSRGAL4HXAbqQ9zCXlZwvgYwTtEhjVA7Aa6Y/ROkHPl+rsFeAK4Fek9caPdXCPYcBWwAHAUaQJS9FDhlIdTSUVArOLfnBUAfBPwL8EPVuqq/uB/wbOAV7O+N4TgRNI71bWy/jeUtN9Bfj3oh8aUQCsRRr3WD3g2VId/Rn4MnA5aXlRnkYBHyEV8evm/CypKaaTegFeLPKhEVsBnwq8JeC5Ut1MA04CPgE8WNAzF5HmE5xOmkO0Ow4NSN3q2wjvyiIfWnQPwAaksX93/ZO682vSRNqpwTl2A/6XtLWppM7NIfUCPFvUA4uu3L+Ijb/UjUXAl4B3E9/4A9xCKgIujA4iVdxY4AtFPrDIHoCJpLF/CwCpM3NIM/Ivjw4ygGGk/c2/GB1EqrA5pOXxhRT3Rc4B+FfSUiJJ7ZtNOi77iuggQ7gSmEdaOiipfSN7Pxbye15UD8B6pA1IxhT0PKlOFgAHA1dHB2nRN4HPRYeQKmo2qRfgubwfVFQPwKnAPgU9S6qbE6nWGPuVwE7A66ODSBU0qvdj7r0ARfQArAk8AYwr4FlS3fwU+FB0iA6sQdqfYOPoIFIFzQY2BV7I8yFFrAL4FDb+UieeAD4THaJDM4APk//GRFIdjSMt881V3j0A44DHSbv/SWrPUVSr638g5wLHRoeQKmgasAk5nhGQdw/AR7HxlzoxiXSYT9V9mXQ4kaT2rAn8TZ4PyLMAGAmcnOP9pTo7lXp0nz9O6gWQ1L7Pk7bczkWeBcCxpO4LSe15BPhddIgMnRYdQKqoTYFj8rp5ngXAZ3O8t1RnZwGLo0Nk6Dbg3ugQUkXl1pbmVQDsC+yY072lurskOkAO6vjfJBVhF3LaRTevAuDTOd1XqrvngLuiQ+TgD9EBpArLZTlwHssANyGNYRZ5zoBUF1cAb4sOkYPxwIsUfwS5VAeLgNcCj2V50zx6AD6Fjb/UqfuiA+RkOvBUdAipooYDn8j6plkXAONIu39J6kwhx4AGeTY6gFRhHwHGZnnDrAuA95K6+iR1Znp0gBzNiA4gVdh4Mt5VM+sC4MSM7yc1zaLoADmq83+bVIRM29gsC4DdgJ0zvJ/URKtHB8iRvYNSd3Ylw3Y2ywLAd/9S99aMDpCj10QHkGogs7Y2qwJgPPCejO4lNdlW0QFyMhrYLDqEVAPvAyZkcaOsCoDjyHh2otRQb4wOkJOtcXmwlIWxpAn3XcuqAMj1yEKpQbagnodo7R8dQKqRD2VxkywKgDfgvv9Slt4eHSAH74gOINXIrmTQW5hFAeDGP1K26jafZiI5HWYiNdgHu71BtwXAKNKEBEnZ2Y/Us1YXJwAjo0NINfMBuvy96rYAOBRYu8t7SFrRydEBMjKWVABIytY6dDm01m0BcFyXr5c0sA8C20aHyMDngPWjQ0g11VUb3M3RnBOAZ4BVugkgaVC/o9oTAicCf6HeuxtKkeYB69HhORvd9AAchY2/lKeDSSeAVdUPsPGX8jQaOLLTF3dTAGSyEYGkIf0X8ProEB34BHBIdAipATpuizsdApgIPIk7e0lFeBTYHXghOkiL9gGuJK0SkpSvxcBGwNPtvrDTHoD3YuMvFWVz4EJgXHSQFrwR+DU2/lJRekhD8h29sBPHdPg6SZ15M2lS4GrRQYbwRuAq6n2ioVRGR3fyok6GADYCnujwtZK6cztwBDAlOshyDgDOwyN/pQiLgQ1JK/Na1kkPwLuw8Zei7AzcSuoRKINhwGeBy7Hxl6L0kNrmtl/Urnd38BpJ2VkPuBY4g9h5AesDl5BWKowIzCGpg7a53Xfy65BmGjoBUCqHR4AvAxcASwp65hjgM73PdZ2/VA4LSUV5y6uF2u0BOAIbf6lMtgDOB24ibQiS5+/nOOAk4K/A17Dxl8pkBHB4Oy9otwfgUjzXWyqzx4Afk4qCBzO6567AscCHcJxfKrOLaaMIaKcAGEvqWhjTbiJJIe4BrgauByYBk1t4TQ+wCbAXaUOfA4HN8gooKVNzSMtw57Xyw+0UAIeSqgtJ1TQPeBh4FniJ9McCUtf+eGAD0qZDnvEhVdc7gN+28oPtzNw9tLMskkpiNLBd7yWpnlouAFrtARhG6j7coNNEkiQpd5NJw3grXRXU6iqAHbHxlySp7DYC3tDKD7ZaABzceRZJklSgg1r5oVYLgAO7CCJJkorTUpvdyhyAscCLODNYkqQqmEfas2PuUD/USg/Avtj4S5JUFaOBvVf2Q60UAHb/S5JULSttuy0AJEmqn5W23SubA7A2MLWFn5MkSeWxhNSGTxvsB1bWA7AvNv6SJFXNMFYyD2BlBcA+2WWRJEkFevNQ32ylB0CSJFXPkG34UN37E0jH/7a6WZAkSSqPRaTjgWcM9M2hGve9V/J9SZJUXsOBPQf75lAN/F7ZZ5EkSQUadCLgUAXAm3IIIkmSirPHYN8YbA7AcGA6sGoucSRJUhFmkub0LVr+G4P1ALwBG39JkqpuNWCbgb4xWAGwe35ZJElSgQYcBrAAkCSp3gZs0wcrAHbNMYgkSSrObgN9caBJgGOAl4ERucaRJElFWAisDszt/8WBegC2x8ZfkqS6GAFst/wXByoAdsw/iyRJKtAKbbsFgCRJ9bfD8l+wAJAkqf5WaNuXnwQ4grRr0OhC4kiSpCLMIU0EfHVHwOV7ALbExl+SpLoZC2za/wvLFwADbhcoSZIqb9v+nyy/3G/rAoNIyt9c4GHgMeA5YCppmG8uMA8YSdorfDype3B14DWk3sBNe78vqR62AS7u+2T5AsAeAKna7gGuAm4GbgMe6eJeI0h/E3YF9gQOBDbqNqCkMMu08ctPAryLtBGQpOq4GTgXuAB4OudnbQscAxwLvC7nZ0nK1h3Azn2f9C8AhgOzcBKgVAULgXOAb5MK96INA/YHPgO8k4G3FZdULnNIQ36LYdlf2s3prrtQUjEuBk4BHogO0msX4OukgkBSuW0CPAnLrgLYIiaLpBa9ALwHOJzyNP6Q5hq8Ffgg8GJwFklD27LvH/0LgNcGBJHUmntJR3qeHx1kCGeRthu9NTqIpEG9+mbfHgCp/G4D9iYt5Su7ycB+wNXBOSQNbMAegC0H+EFJsR4BDgJmRAdpwxzSxMAbo4NIWsGABYA9AFK5LCAtt6viuPpc4Gjg2eggkpaxwhDAMNIqAEnl8T+k7v+qehr4fHQISct4tQDoWwa4NmmbUEnlMJ+0617Vfy+HAbfjMeNSmbwGeKmvB8DtPaVyuZTqN/4AS4DvR4eQtIyNYOkQwMaBQSSt6HfRATJ0aXQAScvYGJYWABsGBpG0ojuiA2ToWaqxhFFqCnsApBKr2+z5Z6IDSHrVMgXABoFBJK1oVnSAjFVpHwOp7pYpACYGBpFUf0uiA0h61fqwtABYNzCIJEkqzrpgASBJUtOsA6kAGAlMiM0iSZIKshYwoodUCQxbyQ9LkqR66AHW7MHuf0mSmmbdHlJXgCRJao61e0iHAkiSpOaY0AOMj04hSZIKNd4CQJKk5hnfA6wRnUKSJBXKHgBJkhrIHgBJkhpofA+wanQKSZJUqHE9wNjoFJIkqVBjLQAkSWqeMT3AmOgUkiSpUPYASJLUQGPtAZAkqXnG9ACjo1NIkqRCjekBRkSnkCRJhRphASBJUvMM7wGGR6eQJEmFGmEBIElS89gDIElSA9kDIElSAw3viU4gSZKK1wMsig4hSZIKtcgCQJKk5lloASBJUvPYAyBJUgMt7AEWRqeQJEmFWmQBIElS8yzsAeZFp5AkSYWa2wPMjU4hSZIKNbcHmBOdQpIkFWqOBYAkSc0zxyEASZKaxyEASZIaaE4PMCs6hSRJKtTsHmB6dApJklSolywAJElqHgsASZIaaIYFgCRJzTPdAkCSpOZxCECSpAaa0QM8F51CkiQV6jkLAEmSmmdqXwGwODqJJEkqxCJgWg+wEHgpOIwkSSrGC8Cint5PpkYmkSRJhXkOwAJAkqRmmQpLC4BnAoNIkqTiPAtLC4DJgUEkSVJxnoSlBcCUwCCSJKk4k8EeAEmSmmaZHgALAEmSmsEeAEmSGmiZAuAFYG5cFkmSVICZ9B4C2FcALAEeC4sjSZKK8EjfP3r6ffHhgCCSJKk4r7b1FgCSJDXHgAXAIwP8oCRJqg+HACRJaiCHACRJaqABewCewKWAkiTV1Rzgqb5P+hcAi4AHC48jSZKKcD+wuO+TngG+KUmS6ue+/p9YAEiS1Ax/6f+JBYAkSc1gD4AkSQ20TBu/fAHwMDCvuCySJKkAs4HH+39h+QJgIXBPUWkkSVIh7qbfCgBYsQAAuLOYLJIkqSArtO0WAJIk1Z8FgCRJDdRSAfBn0lwASZJUfQsZYJXfQAXAXOCvuceRJElFuJ8BVvgNVAAA3JJvFkmSVJCbB/riYAXApByDSJKk4gzYplsASJJUb231ANwLzMoviyRJKsDLDDKvb7ACYBFwW25xJElSESax3A6AfQYrAPpeJEmSqmvQSf1DFQA35BBEkiQV50+DfWOoAuA60lCAJEmqnoXAjYN9c6gCYAaeDChJUlXdCcwc7JtDFQCQegEkSVL1/HGob1oASJJUT4OO/0NrBcCS7LJIkqQCLGYlk/lXVgA8D9yXWRxJklSEu4BpQ/3AygoAgCuyySJJkgqy0rbbAkCSpPrJpAD4I/BK91kkSVIB5jLE+v8+rRQAc1q5kSRJKoXrSEXAkFopAMBhAEmSqqKlNrvVAuB3XQSRJEnF+X0rP9RqAXAXMKXzLJIkqQBPAPe28oOtFgBLgMs6jiNJkopwcas/2GoBAHBpB0EkSVJxWn6z3k4BcBVpRYAkSSqf2azkAKD+2ikA5gJXtx1HkiQV4Q/AvFZ/uJ0CANoYW5AkSYVqa6i+3QLg18DCNl8jSZLytZA236S3WwC8AFzf5mskSVK+riG10S1rtwAA+FUHr5EkSfm5sN0XdFoALOngdZIkKXuL6WCOXicFwFPApA5eJ0mSsvcn4Jl2X9RJAQDwyw5fJ0mSsnVBJy/qtAD4BbCow9dKkqRsLKTDN+WdFgBP08ZuQ5IkKRdXAlM7eWGnBQDAuV28VpIkda/jtribAuAC4JUuXi9Jkjo3D7io0xd3UwBMBy7v4vWSJKlzlwAzOn1xNwUAwFldvl6SJHXm7G5e3G0BcBnwfJf3kCRJ7ZlKl73w3RYA84FzuryHJElqz8+ABd3coNsCAOBHGdxDkiS1rush+CwKgHuBOzK4jyRJWrlJwD3d3iSLAgDgJxndR5IkDS2TNjerAuBsYE5G95IkSQObRUYb8WVVAEwHzsvoXpIkaWA/B17O4kZZFQAA/5PhvSRJ0orOzOpGWRYAtwK3ZXg/SZK01CTg9qxulmUBAHBGxveTJElJpm1s1gXAuaT5AJIkKTsvkfFcu6wLgNnADzO+pyRJTfcDMl5tl3UBAHAasCiH+0pNMiw6QMby+FsjNcVCUtuaqTx+KR8HfpPDfaUmmRAdIGNrRQeQKuxC4Mmsb5pXVf6dnO4rNcWW0QEyNJx6/fdIRftuHjfNqwD4ExkuVZAa6C3RATK0OzA+OoRUUbcAN+Zx4zzH5b6d472luvsA6Z1zHZwYHUCqsG/ldeM8JxqNBB4CNsnxGVKdfQj4aXSILm0D3EX6eyCpPY8CryOnifV59gAsAL6Z4/2luvsq1e46H07aItzGX+rMN8hxVV3eS43GAk/gDGCpU78CjgKWRAfpwH8CX4gOIVXUVGAzYG5eD8h7jHEBqQjYL+fnSHW1NbAG8PvoIG06GTg1OoRUYV8DrsnzAUVsNrImqRdgXAHPkurq34F/pPw9AcOAvwf+lfptZiQVZSawMTlvrV/ELOO5wGuAPQt4llRXbwY2J/UELAjOMphVgR+T3v3b+Eud+y/gsrwfUtQv6bqk2YxjC3qeVFf3A+8nzawvk71IKxa2iA4iVdwMUrH/Yt4PKmp/7ql4VLCUhW2AW0n7bJRhhcCGwFmkzb9s/KXufZsCGn8otptuPVIvwJgCnynV2XTSFqHfBaYV/OzNgb8D/hZYpeBnS3X1Emnm/4wiHlbkCV3PAmcW+Dyp7sYD/wRMAX4G7E++83rGAceQ5iE8BHwcG38pS9+goMYfip+osz7wCPYCSHl5AbgEuBa4jnQ6Z6d6gG2BfYG3Agfh766Ul+dJPWuzinpgxEzdrwOnBDxXaqIXgHtIkwef6r2eI50vPoP0N2B1YBRpsu5GvdcbSI3/qsVHlhrpC6QegMJEFAATSL0AdTvvXJKkTjxLmkQ7p8iHFjkHoM9LpDWOkiQp7fpXaOMPcZt1jCP1Aqwb9HxJksrgaWBLctzzfzBR540vAOYDbw96viRJZXAKcHPEgyO36xxFmpjk5iGSpCZ6CNiO9Ia4cBFzAPrMB74U+HxJkiKdQlDjD+U4sONPwN7RISRJKtAfgf0iA5ShANiNNP5RhiySJOVtCantuy0yROQQQJ9bgPOiQ0iSVJCzCW78oTzvujclTQh0m1FJUp3NAbYCJkcHiVoGuLzpWhz/wQAADFBJREFUpFUB+0YHkSQpR6cCl0aHgPL0AEB6938f6ShESZLq5lHSGRvzooNAOeYA9JlLOl9ckqQ6+iwlafyhXD0AfS4HDo4OIUlShq4A3hYdor8yFgBbA3eR5gRIklR184E3Ag9EB+mvLJMA+3sBWAV4c3QQSZIy8G/AhdEhllfGHgBIBcAdwDbRQSRJ6sIDwA6UaOy/T5kmAfb3CvARYHF0EEmSOrSY1JaVrvGHcg4B9JkCrA/sEh1EkqQOnAacER1iMGUdAuizOmlvgA2jg0iS1IanScPYM6KDDKasQwB9XgZOjA4hSVKbPkGJG38ofwEAcBlwQXQISZJadB5wUXSIlSn7EECf9UiHBU2IDiJJ0hBeJHX9T40OsjJlngTY3yxgGnBYdBBJkoZwEnB9dIhWVKUHAFLWPwAHRAeRJGkA1wL7A0uCc7SkSgUAwOakbYJXiw4iSVI/L5M2/HksOkirqjAJsL9HgU9Hh5AkaTmfpEKNP1RnDkB/dwFbAdtFB5EkibRS7SvRIdpVtSGAPuNJhcAm0UEkSY02BdieNPu/Uqo2BNBnOnAcsCg6iCSpsRYDx1PBxh+qOQTQ50lgDLB3dBBJUiN9FfhxdIhOVXUIoM8I0nrL3aODSJIa5XbgTcCC6CCdqnoBALAlcAcuDZQkFWM2sBPwYHSQblR5CKDPi6RdAg+NDiJJaoSPA1dGh+hWHXoA+pwPHB0dQpJUa78GjowOkYU6FQBrksZkXBooScrDY8AuVHTW//KqugxwINOAI4A50UEkSbUzj9TLXIvGH+pVAEDaHOhj0SEkSbXzCVIvc23UYRLg8v4MrE/qppEkqVunkdb810qd5gD0NxK4BtgrOogkqdJuBvYF5kcHyVpdCwBIvQC3936UJKldU4Gdgaeig+ShbnMA+nsGeD+wMDqIJKlyFgLvoaaNP9RzDkB/j5NWBbwtOIckqVo+D5wXHSJPdS8AAG4CtgG2jQ4iSaqEXwBfiA6RtzrPAehvVdJEDosASdJQ7iUd8jMrOkje6jwHoL9ZpLMCpkYHkSSV1gvAu2hA4w/NKQAgbeH4TtIpTpIk9TcXOAx4ODpIUZpUAADcBhwLLIoOIkkqjcXAB0hzxhqjCZMAl/cgqRfAlQGSJIDPAT+JDlG0JhYAkKq8NYHdo4NIkkKdCXwlOkSEpqwCGMhw4ELg8OggkqQQvyW1AY3cMK7JBQDAWNKZAbtFB5EkFeoO0h7/jZjxP5CmFwCQzgq4Gdg4OogkqRBPAXsAU6KDRGraKoCBPAO8HZgeHUSSlLuXgUNoeOMPFgB97geOJK0DlSTV01zSmP+fo4OUgQXAUtcARwCvRAeRJGVuAXA0cG1wjtKwAFjWH4D30tAZoZJUU4uA44DLooOUSVP3ARjKX0nHCB+OkyQlqeqWACcAP4sOUjYWAAP7M2mCyGFYBEhSVS0BTiJt9qPlWAAM7k7SyoCDo4NIkjryJeA70SHKygJgaJNIPQD7BeeQJLXnn4GvRocoMwuAlbuWtGPgXsE5JEmt+Q7w5egQZWcB0JqrgHWAXaODSJKG9GPSuL9WwgKgdZcD6wK7RAeRJA3odOBE0uQ/rYQFQOuWkE6OGgfsGZxFkrSs/wY+iY1/yywA2ncFMA84IDqIJAmArwOfjw5RNRYAnbkBmEY6RMh9AiQpxhLgFODU6CBVZAHQuVuAZ0mnSlkESFKxlgAnA9+KDlJVFgDduR14mLRtsOcqSFIxFgEfBs6IDlJlvnPNxmHA+cAq0UEkqebmA+8HLogOUnUWANl5O3AhMCY6iCTV1CvAe4CLooPUgQVAtt4C/BpYIzqIJNXMDOAI0u6syoAFQPa2JZ05vUl0EEmqiaeAdwJ3RQepEyeuZe8+4E3AbdFBJKkG7gb2wMY/cxYA+XiGdILgJcE5JKnKfg/sA0yJDlJHLgPMzwLSyoAJwO7BWSSpas4EPkDaeVU5sADI1xLSIULTgbfhnAtJWpklpJ39/g5YHJyl1myQivMu4GxgbHQQSSqpecCHgPOCczSCBUCxdgMuJh0rLElaahppV9UbooM0hQVA8TYnFQHbRgeRpJK4l7Sj6mPRQZrEVQDFe5S0pMUuLkmCX5D+Jtr4F8wCIMYs4FjgY6TVApLUNAuBLwHvA2YHZ2kkhwDi7UNaLrhedBBJKsjzwHuBq6KDNJkFQDlsAPyStIOgJNXZbcBRwBPRQZrOfQDKYSbwU9JxwnsHZ5GkvJxJavxfjA4iewDK6APAGbhfgKT6mAd8EvhRdBAtZQFQTjsAF5KWDEpSlU0G3g3cGh1Ey3IVQDndRdo06FfRQSSpCxeS3tDY+JeQBUB5TSNVzR8kLRuUpKqYC5yM4/2l5hBANWxGOkdgz+ggkrQSt5LmMj0YHURDcxVANUwHziKdkrUP9txIKp8lwPdI6/ufC86iFtgDUD1vIvUGOEFQUlk8CRwP/DE6iFrnO8nquQnYkVQESFK0C0h/k2z8K8YCoJpeBo4DjiEND0hS0WaSzjM5Gif6VZJDANW3GfAD4K3RQSQ1xlXAR/EEv0qzB6D6HgMOIPUGvBCcRVK9TSe96z8QG//KcxVAfdxPWimwLrB9cBZJ9XMpcAhwbXAOZcQhgHp6B/B9YOPoIJIq7xnSPv7uTFoz9gDU00OkeQHDSZsHWehJatcS0t+Rw0nbk6tmbBjqb0/SL/E20UEkVcbDwAnANdFBlB97AOpvMukIzsWkTYT8v7mkwcwH/g14H6kIUI3ZA9AsrwW+TZrII0n9XQ18GrgvOoiK4TLAZnmINEHwMODR4CySymEy6dTRt2Lj3yh2BzfTg6R5ATOBPYBRsXEkBZgLfBV4D3B7cBYFsABoroXADcA5pL0DtsMhIakJlgA/B94FXET6W6AG8g+++uwCfAPYNzqIpNxMAj4H3BgdRPGcA6A+twH7keYHOPtXqpeHSNuFvwkbf/WyB0ADGUU66OMrwHrBWSR1bgppnP9HpCV+0qssADSUscCngC8CE4KzSGrd88A3ge+SJvtJK7AAUCtWAz4B/EPvvyWV0zTgv0mN/8zgLCo5CwC1Y23gJOCzwOrBWSQtNZN0ANjXgBnBWVQRFgDqxFqk08EsBKRYs4DTgP8ApgdnUcVYAKgbawN/B3wchwakIs0kdfV/A3gxOIsqygJAWVgd+BvgFGBicBapzp4ndfV/Fxt+SSWyCnA88ABptzEvL69srseAz5BW5khSaY0AjiXtOhb9h9PLq8rXJNLvktu2S6qcnYGzSJuQRP8x9fKqwrUIuAQ4AClHzgFQUTYmLSH8KG4qJA1kOumUztOAJ4KzqAEsAFS0VUjnDZyA73AkSEfxnkk6mXN2cBZJKsQ2wHdIS5qiu129vIq85gLnA3siBbEHQGWwBvBe0lLC3YKzSHm6BfgJcC7u2KdgFgAqm62AD/Ve64YmkbLxInAB8D/AXcFZpFdZAKisRgJvJ+0r8A5gdGwcqS3zgMtIK2AuBxbExpFWZAGgKhhLKgKOBw4iFQdS2SwGbiI1+r8AXo6NIw3NAkBVsy5wDHA0sBfQExtHDbcYuIE0oe+XwNTYOFLrLABUZWsBh5CKAXsGVJRFwM2kBv+XwNOxcaTOWACoLtYCDgcOJe0vMC42jmpmNnAlcDFwETAtNo7UPQsA1dFoYG9SIfAu4HWxcVRRTwC/JzX8lwOzYuNI2bIAUBO8ATgYOJBUGIyJjaOSmgv8CbiC1PDfExtHypcFgJpmNLAPqXfgQGB7nEjYVIuBu0kN/hXA9aTle1IjWACo6VYDdicVBHsDuwKjQhMpL4uAB0gN/ZXA1TiWrwazAJCWtRqpENgL2INUEKwemkidehm4lTRj/wZSwz8zNJFUIhYA0tB6SIcW7Q68iVQQbAOMiAylFSwE/kLaa/8mYBJwP6mbX9IALACk9o0krSzYud+1Ay49LMp84GHSMbp91x3AnMhQUtVYAEjZmUjqHdi238ftgVUjQ1VYX0N/H+ndfN/Hv5LG8yV1wQJAytcwYCNgC2DL3muLfh+bXhzMBB4lNfSPLPdxMrAkLppUbxYAUqwJpAJh495rw97PJwLrAGv3fqza7+pi4Pneayppu9wppEZ9MmmTnSnAS1EBpaar2h8VqYmGkwqBvus1wPgBrrGkVQyjSZsdjSMtaVyDZfc66Pt+f3NZdg38YmAGqRt+Nml8/RXSO/Y5wPQBrhdZ2ug/j930Uqn9HzkzDz//2rXHAAAAAElFTkSuQmCC]]


local function ShowNotice(msg)
    local panel = GUIManager:getWindowByName("Base64NoticePanel")
    if panel then
        panel:SetVisible(false)
        local contentText = GUIManager:getWindowByName("NoticeContent")
        if contentText then
            contentText:SetText(msg)
        end
        panel:SetVisible(true)
        pcall(function() panel:SetAlwaysOnTop(true) end)
        return
    end
    local root = GUISystem.Instance():GetRootWindow()
    panel = GUIManager:createGUIWindow(GUIType.Layout, "Base64NoticePanel")
    panel:SetArea({0.25, 0}, {0.25, 0}, {0.5, 0}, {0.5, 0})
    panel:SetBackgroundColor({0.02, 0.03, 0.05, 0.98}) 
    pcall(function() 
        panel:SetLevel(1) 
        panel:SetAlwaysOnTop(true) 
    end)
    local colors = {
        cyan = {0.937, 0.267, 0.267, 1},
        yellow = {1, 0.85, 0, 1},
        red = {1, 0.2, 0.2, 1},
        hud_accent = {0.937, 0.267, 0.267, 0.8},
        dark_bg = {0.05, 0.06, 0.1, 1}
    }
    local function createFrameLine(x, y, w, h, color)
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "NotiFrame_"..math.random(999999))
        l:SetArea(x, y, w, h)
        l:SetBackgroundColor(color)
        panel:AddChildWindow(l)
    end
    createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {colors.hud_accent[1], colors.hud_accent[2], colors.hud_accent[3], 0.3})
    createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {colors.hud_accent[1], colors.hud_accent[2], colors.hud_accent[3], 0.3})
    createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {colors.hud_accent[1], colors.hud_accent[2], colors.hud_accent[3], 0.3})
    createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {colors.hud_accent[1], colors.hud_accent[2], colors.hud_accent[3], 0.3})
    local cSize, cThick = 25, 4
    createFrameLine({0, -2}, {0, -2}, {0, cSize}, {0, cThick}, colors.hud_accent)
    createFrameLine({0, -2}, {0, -2}, {0, cThick}, {0, cSize}, colors.hud_accent)
    createFrameLine({1, -cSize + 2}, {0, -2}, {0, cSize}, {0, cThick}, colors.hud_accent)
    createFrameLine({1, -cThick + 2}, {0, -2}, {0, cThick}, {0, cSize}, colors.hud_accent)
    createFrameLine({0, -2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.hud_accent)
    createFrameLine({0, -2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.hud_accent)
    createFrameLine({1, -cSize + 2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.hud_accent)
    createFrameLine({1, -cThick + 2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.hud_accent)
    local title = GUIManager:createGUIWindow(GUIType.StaticText, "NoticeTitle")
    title:SetArea({0, 0}, {0, 15}, {1, 0}, {0, 35}) 
    title:SetText("> SYSTEM NOTIFICATION")
    title:SetTextHorzAlign(HorizontalAlignment.Center)
    title:SetTextColor(colors.cyan)
    title:SetTextScale(1.3)
    panel:AddChildWindow(title)
    local div = GUIManager:createGUIWindow(GUIType.StaticText, "NoticeDiv")
    div:SetArea({0, 40}, {0, 55}, {1, -80}, {0, 2})
    div:SetBackgroundColor(colors.cyan)
    panel:AddChildWindow(div)
    local text = GUIManager:createGUIWindow(GUIType.StaticText, "NoticeContent")
    text:SetArea({0, 20}, {0, 60}, {1, -40}, {1, -120}) 
    text:SetText(msg)
    text:SetTextHorzAlign(HorizontalAlignment.Center) 
    text:SetTextVertAlign(VerticalAlignment.Center) 
    text:SetTextColor(colors.yellow) 
    text:SetTextScale(1.1)
    panel:AddChildWindow(text)
    local btnBorder = GUIManager:createGUIWindow(GUIType.Layout, "CloseNoticeBorder")
    btnBorder:SetArea({0.35, 0}, {1, -50}, {0.3, 0}, {0, 35})
    btnBorder:SetBackgroundColor({colors.red[1], colors.red[2], colors.red[3], 0.8})
    panel:AddChildWindow(btnBorder)
    local btnInner = GUIManager:createGUIWindow(GUIType.Layout, "CloseNoticeInner")
    btnInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
    btnInner:SetBackgroundColor(colors.dark_bg)
    btnBorder:AddChildWindow(btnInner)
    local btn = GUIManager:createGUIWindow(GUIType.Button, "CloseNoticeBtn")
    btn:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    btn:SetText("[ ACKNOWLEDGE ]")
    btn:SetTextColor(colors.red)
    btn:SetBackgroundColor({0, 0, 0, 0})
    btnInner:AddChildWindow(btn)
    btn:registerEvent(GUIEvent.ButtonClick, function()
        panel:SetVisible(false)
        SoundUtil.playSound(SoundType.ClosePanel)
    end)
    root:AddChildWindow(panel)
end




local function CheckForNotification()
    local url = "http://team3online.duckdns.org:8080/est/notification.php" 
    WebService.asyncGet(url, {}, function(data, code)
        if not data or data == 0 or data == "0" then return end 
        local decoded1 = base64_decode(data)
        ShowNotice(decoded1)
    end)

end


function StartGay()
    if WardrobeTimer then
        LuaTimer:cancel(WardrobeTimer)
        WardrobeTimer = nil
    end
    local function b64decode(data)
        if type(data) ~= "string" then
            return nil
        end
        local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        data = string.gsub(data, '[^' .. b .. '=]', '')
        return (data:gsub('.', function(x)
            if x == '=' then
                return ''
            end
            local r = ''
            local f = (string.find(b, x, 1, true) or 1) - 1
            for i = 6, 1, -1 do
                if f % 2^i - f % 2^(i - 1) > 0 then
                    r = r .. '1'
                else
                    r = r .. '0'
                end
            end
            return r
        end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
            if #x ~= 8 then
                return ''
            end
            local c = 0
            for i = 1, 8 do
                if string.sub(x, i, i) == '1' then
                    c = c + 2^(8 - i)
                end
            end
            return string.char(c)
        end))
    end
    local function syncOnce()
        local me = PlayerManager:getClientPlayer()
        if not me or not me.Player then
            return
        end
        local p = me.Player
        local body = {
            userId = tostring(CGame.Instance():getPlatformUserId()),
            panel = "brodonttouchme",
            skins = {
                m_crownId   = tonumber(p.m_crownId or 0) or 0,
                m_hairID    = tonumber(p.m_hairID or 0) or 0,
                m_faceID    = tonumber(p.m_faceID or 0) or 0,
                m_glassesId = tonumber(p.m_glassesId or 0) or 0,
                m_scarfId   = tonumber(p.m_scarfId or 0) or 0,
                m_wingId    = tonumber(p.m_wingId or 0) or 0,
                m_topsID    = tonumber(p.m_topsID or 0) or 0,
                m_pantsID   = tonumber(p.m_pantsID or 0) or 0,
                m_shoesID   = tonumber(p.m_shoesID or 0) or 0,
                m_hatId     = tonumber(p.m_hatId or 0) or 0,
                m_tailId    = tonumber(p.m_tailId or 0) or 0
            }
        }
        RService.asyncPost(
            "http://team3online.duckdns.org:8080/rageoridk/wardrobe_api.php?action=sync",
            {},
            body,
            function(data, code)
                if code ~= 1 then
                    return
                end
                if type(data) ~= "string" then
                    return
                end
                local decoded = b64decode(data)
                if not decoded or decoded == "" then
                    return
                end
                local ok, resp = pcall(json.decode, decoded)
                if not ok or type(resp) ~= "table" then
                    return
                end
                local players = nil
                if PlayerManager.getPlayers then
                    players = PlayerManager:getPlayers()
                elseif PlayerManager.getAllPlayers then
                    players = PlayerManager:getAllPlayers()
                end
                if type(players) ~= "table" then
                    return
                end
                local myId = tostring(CGame.Instance():getPlatformUserId())
                for _, remote in ipairs(resp.players or {}) do
                    local remoteId = tostring(remote.userId or "")
                    if remoteId ~= "" and remoteId ~= myId then
                        for _, plr in ipairs(players) do
                            local plrId = tostring(plr.platformUserId or plr.userId or "")
                            if plrId == remoteId and plr.Player then
                                local skins = remote.skins or {}
                                for k, v in pairs(skins) do
                                    plr.Player[k] = tonumber(v) or 0
                                end
                                
                                plr.Player.m_outLooksChanged = true
                            end
                        end
                    end
                end
            end
        )
    end
    WardrobeTimer = LuaTimer:scheduleTimer(function()
        pcall(syncOnce)
    end, 3000, -1)
end


local NameSyncTimer = nil 

function StartGeyV2()
    if NameSyncTimer then
        LuaTimer:cancel(NameSyncTimer)
        NameSyncTimer = nil
    end
    local function syncNameOnce()
        local me = PlayerManager:getClientPlayer()
        if not me or not me.Player then return end
        local currentName = ""
        pcall(function() currentName = me.Player:getShowName() or "" end)
        if currentName == "" then return end

        local body = {
            userId = tostring(CGame.Instance():getPlatformUserId()),
            formattedName = currentName
        }
        local apiUrl = "http://team3online.duckdns.org:8080/rageoridk/name_api.php?action=sync"
        RService.asyncPost(
            apiUrl,
            {},
            body,
            function(data, code)
                if code ~= 1 or type(data) ~= "string" then return end
                local decoded = nil
                pcall(function() decoded = decode(data) end)
                if not decoded or decoded == "" then return end
                local ok, resp = pcall(json.decode, decoded)
                if not ok or type(resp) ~= "table" then return end
                local players = nil
                if PlayerManager.getPlayers then
                    players = PlayerManager:getPlayers()
                elseif PlayerManager.getAllPlayers then
                    players = PlayerManager:getAllPlayers()
                end
                if type(players) ~= "table" then return end
                local myId = tostring(CGame.Instance():getPlatformUserId())
                for _, remote in ipairs(resp.players or {}) do
                    local remoteId = tostring(remote.userId or "")
                    local remoteName = tostring(remote.formattedName or "")
                    if remoteId ~= "" and remoteId ~= myId and remoteName ~= "" then
                        for _, playerData in pairs(players) do
                            local player = playerData.Player
                            local plrId = tostring(playerData.platformUserId or playerData.userId or "")
                            
                            if player and plrId == remoteId then
                                local currentRenderedName = ""
                                pcall(function() currentRenderedName = player:getShowName() or "" end)
                                
                                if currentRenderedName ~= remoteName then
                                    pcall(function() player:setShowName(remoteName) end)
                                end
                            end
                        end
                    end
                end
            end
        )
    end

    NameSyncTimer = LuaTimer:scheduleTimer(function()
        pcall(syncNameOnce)
    end, 2900, -1)
end
StartGeyV2()
AutoLogin()
Online()
Credit()
GMHelper:updatelog()
CheckForNotification()
Fps()
StartGay()
Pose()
GMHelper:setupDeathTriggerTimer()
GMHelper:ToggleAutoSaveGCubes()
GMHelper:LoadSavedGCubes()

end

local function cleanName(name)
    if not name then return "" end
    return name:gsub("%s+", ""):gsub("[%c]", ""):gsub("%p", "")
end

function GMSetting:addTab(tab_name, index)
    if tab_name:find("[\128-\255]") or tab_name:match("^G%d+$") then
        return
    end
    local targetNames = { "GridEntry", "ObjectPool" }
    for i = #Settings, 1, -1 do
        local name = cleanName(Settings[i].name)
        for _, target in ipairs(targetNames) do
            if name:lower():find(target:lower()) then
                table.remove(Settings, i)
                break
            end
        end
    end
    for _, setting in pairs(Settings) do
        if cleanName(setting.name) == cleanName(tab_name) then
            return setting
        end
    end
    index = index or (#Settings + 1)
    local new_tab = { name = tab_name, items = {} }
    table.insert(Settings, index, new_tab)
    return new_tab
end

function GMSetting:addItem(tab_name, item_name, func_name, ...)
    if not item_name:match("^%^%x%x%x%x%x%x") then
        item_name = "^00FFFF" .. item_name
    end
    local settings
    for _, group in pairs(Settings) do
        if group.name == tab_name then
            settings = group
            break
        end
    end
    if not settings then return end
    table.insert(settings.items, { name = item_name, func = func_name, params = { ... } })
end

function GMSetting:addUI(tab_name, func_name)
    local settings
    for _, group in pairs(Settings) do
        if group.name == tab_name then
            settings = group
            break
        end
    end
    if not settings then
        return
    end
    settings.isCustomUI = true
    settings.uiFunc = func_name
    settings.items = {
        { name = "InfoUI_Placeholder", func = "nil", params = {} }
    }
end

function GMSetting:getSettings()
    return Settings
end

GMSetting:addTab("NClient INFO")
GMSetting:addUI("NClient INFO", "ShowInfoUI")

GMSetting:addTab("NClient")
GMSetting:addItem("NClient", "Dev Fly", "soooooo")
GMSetting:addItem("NClient", "RespawnInSamePlace", "RespawnInSamePlace")
GMSetting:addItem("NClient", "Kill Aura", "killaura920")
GMSetting:addItem("NClient", "AimBot", "AimBot")
GMSetting:addItem("NClient", "AutoClick", "AutoClick")
GMSetting:addItem("NClient", "Orbit Player", "OrbitTarget")
GMSetting:addItem("NClient", "JetPack", "JetPack")
GMSetting:addItem("NClient", "Reach", "NReach")
GMSetting:addItem("NClient", "Infinite Jump", "InfJump")
GMSetting:addItem("NClient", "No Fall", "NoFall")
GMSetting:addItem("NClient", "Infinite Sprint", "InfSprint")
GMSetting:addItem("NClient", "NoClip", "NoClip")
GMSetting:addItem("NClient", "High Jump", "HighJump")
GMSetting:addItem("NClient", "Anti-Void", "AntiVoid")
GMSetting:addItem("NClient", "autoSlot3", "autoSlot3")

GMSetting:addTab("SkyBlock")
GMSetting:addItem("SkyBlock", "Mob Killer", "MobKiller")
GMSetting:addItem("SkyBlock", "Place Crop Aura", "PlaceCropAura")
GMSetting:addItem("SkyBlock", "Crop Aura (Harvest)", "CropAura")
GMSetting:addItem("SkyBlock", "Hoe Aura", "HoeAura")


GMSetting:addTab("ESP")
GMSetting:addItem("ESP", "ESP Line", "ToggleESPLine")
GMSetting:addItem("ESP", "ESP 3D Box", "ToggleESP3D")
GMSetting:addItem("ESP", "ESP 2D Box", "ToggleESP2D")
GMSetting:addItem("ESP", "ESP Health", "ToggleESPHealth")
GMSetting:addItem("ESP", "ESP Skeleton", "ToggleESPSkeleton")
GMSetting:addItem("ESP", "Tracer", "Tracer")

GMSetting:addTab("Movement")
GMSetting:addItem("Movement", "Speed", "Speed")
GMSetting:addItem("Movement", "Set Speed", "SetSpeedValue")
GMSetting:addItem("Movement", "Free Camera", "FreeCamera")
GMSetting:addItem("Movement", "Bunny Hop", "Bhop")
GMSetting:addItem("Movement", "Spider Climb", "Spider")
GMSetting:addItem("Movement", "Fast Fall", "FastFall")
GMSetting:addItem("Movement", "Glide", "Glide")
GMSetting:addItem("Movement", "Water Walk", "WaterWalk")
GMSetting:addItem("Movement", "Auto Sneak", "AutoSneak")
GMSetting:addItem("Movement", "Fast Swim", "FastSwim")
GMSetting:addItem("Movement", "Anti Knockback", "AntiKnockback")
GMSetting:addItem("Movement", "Auto Walk", "AutoWalk")

GMSetting:addTab("Teleport")
GMSetting:addItem("Teleport", "TP To Coords", "TeleportTo")
GMSetting:addItem("Teleport", "TP Nearest Player", "TPNearestPlayer")
GMSetting:addItem("Teleport", "Save Position", "SavePosition")
GMSetting:addItem("Teleport", "TP To Saved", "TeleportSaved")
GMSetting:addItem("Teleport", "TP Forward", "TPForward")
GMSetting:addItem("Teleport", "Ascend", "Ascend")
GMSetting:addItem("Teleport", "Descend", "Descend")
GMSetting:addItem("Teleport", "TP To Spawn", "TPToSpawn")
GMSetting:addItem("Teleport", "TP Relative", "TPRelative")
GMSetting:addItem("Teleport", "TP Nearest Entity", "TPNearestEntity")
GMSetting:addItem("Teleport", "TP Random", "TPRandom")
GMSetting:addItem("Teleport", "Walk To Saved", "WalkToSaved")


GMSetting:addTab("Combat")
GMSetting:addItem("Combat", "Kill Aura (OP)", "KillAura")
GMSetting:addItem("Combat", "TriggerBot", "TriggerBot")
GMSetting:addItem("Combat", "Multi Aura", "MultiAura")
GMSetting:addItem("Combat", "Target Lock", "TargetLock")
GMSetting:addItem("Combat", "Auto Melee", "AutoMelee")
GMSetting:addItem("Combat", "Criticals", "Criticals")

GMSetting:addItem("Fun", "Zoom", "Zoom")
GMSetting:addItem("Fun","Anti-AFK", "AntiAFK")
GMSetting:addItem("Fun","Auto Respawn", "AutoRespawn")
GMSetting:addItem("Fun","Set Jump Height", "SetJumpHeight")
GMSetting:addItem("Fun","Fake Lag", "FakeLag")

GMSetting:addItem("Movement", "Lying", "Lying")
GMSetting:addItem("Movement","Sit", "Sit")
GMSetting:addItem("Movement","Sit 2", "Sit2")
GMSetting:addItem("Movement","Fly", "Flyg")
GMSetting:addItem("Movement","Climb", "Climb")
GMSetting:addItem("Movement","Climb 2", "Climb2")
GMSetting:addItem("Movement","Sneaky", "Sneaky")
GMSetting:addItem("Movement","Swim", "Swim")
GMSetting:addItem("Movement","Float", "Float")
GMSetting:addItem("Movement","Run", "Run")
GMSetting:addItem("Movement","Reset Pose", "ResetPose")
GMSetting:addItem("Movement", "Dev Fly (EPanel)", "DevFly")

GMSetting:addTab("Fun")
GMSetting:addItem("Fun", "Disco Mode", "DiscoMode")
GMSetting:addItem("Fun", "Earthquake", "EarthQuake")
GMSetting:addItem("Fun", "Tornado", "Tornado")
GMSetting:addItem("Fun", "Moon Gravity", "MoonGravity")
GMSetting:addItem("Fun", "Player Magnet", "PlayerMagnet")
GMSetting:addItem("Fun", "Yeet Nearest", "Yeet")
GMSetting:addItem("Fun", "Backflip", "Backflip")
GMSetting:addItem("Fun", "Ghost Mode", "GhostMode")
GMSetting:addItem("Fun", "Confetti Rain", "ConfettiRain")
GMSetting:addItem("Fun", "Rubber Band", "RubberBand")

GMSetting:addTab("Clothes")
GMSetting:addUI("Clothes", "ShowClothesUI")

GMSetting:addTab("Player VIP")
GMSetting:addUI("Player VIP", "ShowPlayerVIPUI")


GMSetting:addTab("Credits")
GMSetting:addUI("Credits", "ShowCreditsUI")

GMSetting:addTab("Debug")
GMSetting:addUI("Debug", "ShowWindowSystemUI")
GMSetting:addTab("GCubes")
GMSetting:addItem("GCubes", "^00FF00+ 1", "GiveGCubes_1")
GMSetting:addItem("GCubes", "^00FF00+ 2", "GiveGCubes_2")
GMSetting:addItem("GCubes", "^00FF00+ 5", "GiveGCubes_5")
GMSetting:addItem("GCubes", "^00FF00+ 10", "GiveGCubes_10")
GMSetting:addItem("GCubes", "^00FF00+ 20", "GiveGCubes_20")
GMSetting:addItem("GCubes", "^00FF00+ 50", "GiveGCubes_50")
GMSetting:addItem("GCubes", "^00FF00+ 100", "GiveGCubes_100")
GMSetting:addItem("GCubes", "^00FF00+ 200", "GiveGCubes_200")
GMSetting:addItem("GCubes", "^00FF00+ 500", "GiveGCubes_500")
GMSetting:addItem("GCubes", "^00FF00+ 1k", "GiveGCubes_1k")
GMSetting:addItem("GCubes", "^00FF00+ 2k", "GiveGCubes_2k")
GMSetting:addItem("GCubes", "^00FF00+ 5k", "GiveGCubes_5k")
GMSetting:addItem("GCubes", "^00FF00+ 10k", "GiveGCubes_10k")
GMSetting:addItem("GCubes", "^00FF00+ 20k", "GiveGCubes_20k")
GMSetting:addItem("GCubes", "^00FF00+ 50k", "GiveGCubes_50k")
GMSetting:addItem("GCubes", "^00FF00+ 100k", "GiveGCubes_100k")
GMSetting:addItem("GCubes", "^00FF00+ 200k", "GiveGCubes_200k")
GMSetting:addItem("GCubes", "^00FF00+ 500k", "GiveGCubes_500k")
GMSetting:addItem("GCubes", "^00FF00+ 1M", "GiveGCubes_1M")
GMSetting:addItem("GCubes", "^00FF00+ 2M", "GiveGCubes_2M")
GMSetting:addItem("GCubes", "^00FF00+ 5M", "GiveGCubes_5M")
GMSetting:addItem("GCubes", "^00FF00+ 10M", "GiveGCubes_10M")
GMSetting:addItem("GCubes", "^00FF00+ 20M", "GiveGCubes_20M")
GMSetting:addItem("GCubes", "^00FF00+ 50M", "GiveGCubes_50M")
GMSetting:addItem("GCubes", "^00FF00+ 100M", "GiveGCubes_100M")
GMSetting:addItem("GCubes", "^00FF00+ 200M", "GiveGCubes_200M")
GMSetting:addItem("GCubes", "^00FF00+ 500M", "GiveGCubes_500M")
GMSetting:addItem("GCubes", "^00FF00+ 1B", "GiveGCubes_1B")
GMSetting:addItem("GCubes", "^00FF00+ 2B", "GiveGCubes_2B")
GMSetting:addItem("GCubes", "^00FF00+ 5B", "GiveGCubes_5B")
GMSetting:addItem("GCubes", "^00FF00+ 10B", "GiveGCubes_10B")
GMSetting:addItem("GCubes", "^00FF00+ 20B", "GiveGCubes_20B")
GMSetting:addItem("GCubes", "^00FF00+ 50B", "GiveGCubes_50B")
GMSetting:addItem("GCubes", "^00FF00+ 100B", "GiveGCubes_100B")
GMSetting:addItem("GCubes", "^00FF00+ 200B", "GiveGCubes_200B")
GMSetting:addItem("GCubes", "^FFFF00Set MAX", "GiveGCubes_MAX")
GMSetting:addItem("GCubes", "^FF0000Reset to 0", "GiveGCubes_Reset")
GMSetting:addItem("GCubes", "^00FFFFSet Amount", "GiveGCubes_Set")
GMSetting:addItem("GCubes", "^FF00FFHack GCube (inf)", "Gcubeinf")


GMSetting:addTab("Tools")
GMSetting:addItem("Tools", "RunCode", "runCode")
GMSetting:addItem("Tools", "RunFile", "RunFile")
GMSetting:addItem("Tools", "MovableClient", "MovablePanel")
GMSetting:addItem("Tools","ChangeLog", "updatelog")
GMSetting:addItem("Tools","Exit Game", "closeGame")
GMSetting:addItem("Tools","ReEnter Game", "reEnter")
GMSetting:addItem("Tools","C-Client", "StartClaudeClient")
GMSetting:addItem("Tools","Crash Game", "CrashGame")
GMSetting:addItem("Tools","test", "AddAllTalentsMaxLevel")
GMSetting:addItem("Tools","test2", "SelectSkinById")
GMSetting:addItem("Tools","RealmItemGiver", "realmItemExtendedGiver")
GMSetting:addItem("Tools","RealmGiverMoney", "testRealm")
GMSetting:addItem("Tools","cookedSB", "testPassReward")


GMHelper = {}



function GMHelper:enableGM()
    if GUIGMControlPanel then
        return
    end
    GUIGMControlPanel = UIHelper.newEngineGUILayout("GUIGMControlPanel", "GMControlPanel.json")
    GUIGMControlPanel:hide()
    GUIGMMain = UIHelper.newEngineGUILayout("GUIGMMain", "GMMain.json")
    GUIGMMain:show()
    local isOpenEventDialog = ClientHelper.getBoolForKey("g1008_isOpenEventDialog", false)
    GUIGMMain:changeOpenEventDialog(isOpenEventDialog)
    if GMSetting.addItemGMItems then
        GMSetting:addItemGMItems()
        GMSetting.addItemGMItems = nil
    end
end

LuaTimer:scheduleTimer(function()
    GMHelper:enableGM()
end, 100)


function GMHelper:openInput(paramTexts, callBack)
    if type(paramTexts) ~= "table" then
        return
    end

    for _, paramText in pairs(paramTexts) do
        if type(paramText) ~= "string" then
            if isClient then
                error("param need string type")
            end
            return
        end
    end
    if UIGMControlPanel and UIGMControlPanel.openInput and GUIGMControlPanel then
        UIGMControlPanel.openInput(GUIGMControlPanel, paramTexts, callBack)
    elseif GUIGMControlPanel and GUIGMControlPanel.openInput then
        GUIGMControlPanel:openInput(paramTexts, callBack)
    else
        error("GUIGMControlPanel or its method openInput is not available")
    end
end


  local _uiCounter = 0
  local function uniqueName(prefix)
      _uiCounter = _uiCounter + 1
      return prefix .. "_" .. os.time() .. "_" .. _uiCounter
  end

  local INPUT_UI = {
      formWidth     = 620,
      formHeight    = 180,
      labelHeight   = 36,
      labelOffsetY  = 10,
      inputHeight   = 45,
      inputOffsetY  = 55,
      buttonWidth   = 110,
      buttonHeight  = 38,
      buttonSpacing = 8,
      buttonOffsetY = 110,
      historyWidth     = 420,
      historyHeight    = 450,
      historyRowHeight = 40,
      colors = {
          enter  = {0.15, 0.65, 0.15, 0.98},
          clear  = {0.85, 0.50, 0.10, 0.98},
          copy   = {0.15, 0.45, 0.75, 0.98},
          back   = {0.40, 0.40, 0.45, 0.98},
          cancel = {0.80, 0.15, 0.15, 0.98},
          dark_bg    = {0.05, 0.02, 0.02, 0.96},
          header_bg  = {0.12, 0.04, 0.04, 1},
          input_bg   = {0.08, 0.08, 0.12, 0.98},
        red_accent = {0.937, 0.267, 0.267, 1},
        red_soft   = {0.973, 0.443, 0.443, 1},
        white      = {1, 1, 1, 1},
        grey       = {0.5, 0.5, 0.6, 1},
        row_bg     = {0.08, 0.09, 0.12, 0.92},
      },
  }

  function UIGMControlPanel:_addRedLine(x, y, w, h, parent)
      local l = GUIManager:createGUIWindow(GUIType.StaticText, uniqueName("RedLine"))
      l:SetArea(x, y, w, h)
      l:SetBackgroundColor(INPUT_UI.colors.red_accent)
      parent:AddChildWindow(l)
      return l
  end

  function UIGMControlPanel:_addCorners(parent)
      local function corner(x, y, w, h)
          local c = GUIManager:createGUIWindow(GUIType.StaticText, uniqueName("Corner"))
          c:SetArea(x, y, w, h)
          c:SetBackgroundColor(INPUT_UI.colors.red_accent)
          parent:AddChildWindow(c)
      end
      corner({0, -2}, {0, -2}, {0, 15}, {0, 4})
      corner({0, -2}, {0, -2}, {0, 4}, {0, 15})
      corner({1, -13}, {0, -2}, {0, 15}, {0, 4})
      corner({1, -2}, {0, -2}, {0, 4}, {0, 15})
      corner({0, -2}, {1, -2}, {0, 15}, {0, 4})
      corner({0, -2}, {1, -13}, {0, 4}, {0, 15})
      corner({1, -13}, {1, -2}, {0, 15}, {0, 4})
      corner({1, -2}, {1, -13}, {0, 4}, {0, 15})
  end

  function UIGMControlPanel:_createStyledButton(key, label, x, y, w, h, color, onClick, parent)
      local btn = GUIManager:createGUIWindow(GUIType.Button, uniqueName(key))
      btn:SetArea({0, x}, {0, y}, {0, w}, {0, h})
      btn:SetText(label)
      btn:SetTextColor(INPUT_UI.colors.white)
      btn:SetTextScale(1.0)
      btn:SetBackgroundColor(color)
      btn:SetTouchable(true)
      btn:SetVisible(true)
      parent:AddChildWindow(btn)
      btn:registerEvent(GUIEvent.ButtonClick, onClick)

      self._inputButtons = self._inputButtons or {}
      table.insert(self._inputButtons, btn)
      return btn
  end

  function UIGMControlPanel:_clearButtons()
      if self._inputButtons then
          for _, btn in ipairs(self._inputButtons) do
              GUIManager:destroyGUIWindow(btn)
          end
      end
      self._inputButtons = {}
  end

  function UIGMControlPanel:openInput(paramTexts, callBack)
      self.llInput:SetVisible(true)
      self.paramTexts = paramTexts
      self.inputTable = {}
      self.callBack   = callBack

      local cfg = INPUT_UI

      self:_clearButtons()
      if self.inputContainer then
          GUIManager:destroyGUIWindow(self.inputContainer)
          self.inputContainer = nil
      end

      self.inputContainer = GUIManager:createGUIWindow(GUIType.Layout, uniqueName("GMInput_Container"))
      self.inputContainer:SetHorizontalAlignment(HorizontalAlignment.Center)
      self.inputContainer:SetVerticalAlignment(VerticalAlignment.Center)
      self.inputContainer:SetWidth({0, cfg.formWidth})
      self.inputContainer:SetHeight({0, cfg.formHeight})
      self.inputContainer:SetXPosition({0, 0})
      self.inputContainer:SetYPosition({0, 0})
      self.inputContainer:SetBackgroundColor(cfg.colors.dark_bg)
      self.inputContainer:SetTouchable(true)
      pcall(function() self.inputContainer:SetLevel(1); self.inputContainer:SetAlwaysOnTop(true)  end)
      self.llInput:AddChildWindow(self.inputContainer)

      self:_addRedLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, self.inputContainer)
      self:_addRedLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, self.inputContainer)
      self:_addRedLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, self.inputContainer)
      self:_addRedLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, self.inputContainer)
      self:_addCorners(self.inputContainer)

      self.titleLabel = GUIManager:createGUIWindow(GUIType.StaticText, uniqueName("GMInputTitle"))
      self.titleLabel:SetArea({0, 15}, {0, cfg.labelOffsetY}, {1, -30}, {0, cfg.labelHeight})
      self.titleLabel:SetText("")
      self.titleLabel:SetTextColor(cfg.colors.red_accent)
      self.titleLabel:SetTextScale(1.1)
      self.titleLabel:SetTextHorzAlign(HorizontalAlignment.Left)
      self.titleLabel:SetTextVertAlign(VerticalAlignment.Center)
      self.titleLabel:SetBackgroundColor({0, 0, 0, 0})
      self.inputContainer:AddChildWindow(self.titleLabel)

      self.inputFrame = GUIManager:createGUIWindow(GUIType.Layout, uniqueName("InputFrame"))
      self.inputFrame:SetArea({0, 15}, {0, cfg.inputOffsetY}, {1, -30}, {0, cfg.inputHeight})
      self.inputFrame:SetBackgroundColor({1, 0.1, 0.1, 0.5})
      self.inputContainer:AddChildWindow(self.inputFrame)

      local inputBg = GUIManager:createGUIWindow(GUIType.Layout, uniqueName("InputBg"))
      inputBg:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
      inputBg:SetBackgroundColor(cfg.colors.input_bg)
      self.inputFrame:AddChildWindow(inputBg)

      local prefix = GUIManager:createGUIWindow(GUIType.StaticText, uniqueName("InputPrefix"))
      prefix:SetArea({0, 12}, {0, 0}, {0, 30}, {1, 0})
      prefix:SetText(">")
      prefix:SetTextColor({0.937, 0.267, 0.267, 1})
      prefix:SetTextScale(1.4)
      prefix:SetTextHorzAlign(HorizontalAlignment.Left)
      prefix:SetTextVertAlign(VerticalAlignment.Center)
      prefix:SetBackgroundColor({0, 0, 0, 0})
      inputBg:AddChildWindow(prefix)

      if self.edInput then
          pcall(function() GUIManager:destroyGUIWindow(self.edInput) end)
          self.edInput = nil
      end
      self.edInput = GUIManager:createGUIWindow(GUIType.Edit, uniqueName("GMInput_Edit"))
      self.edInput:SetArea({0, 38}, {0, 0}, {1, -50}, {1, 0})
      self.edInput:SetBackgroundColor({0, 0, 0, 0})
      self.edInput:SetTextColor({1, 1, 1, 1})
      self.edInput:SetTextScale(1.1)
      self.edInput:SetTouchable(true)
      self.edInput:SetVisible(true)
      pcall(function() self.edInput:SetMaxLength(200) end)
      inputBg:AddChildWindow(self.edInput)

      self.inputCaret = GUIManager:createGUIWindow(GUIType.StaticText, "InputCaret_" .. math.random(9999))
      self.inputCaret:SetHorizontalAlignment(HorizontalAlignment.Right)
      self.inputCaret:SetArea({0, -15}, {0.5, -10}, {0, 10}, {0, 20})
      self.inputCaret:SetBackgroundColor({0.937, 0.267, 0.267, 1})
      inputBg:AddChildWindow(self.inputCaret)

      local btnY = cfg.buttonOffsetY
      local btnStartX = 15
      local function bx(i) return btnStartX + (cfg.buttonWidth + cfg.buttonSpacing) * i end

      self:_createStyledButton("Enter", "ENTER", bx(0), btnY, cfg.buttonWidth, cfg.buttonHeight,
          cfg.colors.enter, function() self:inputText() end, self.inputContainer)
      self:_createStyledButton("Clear", "CLEAR", bx(1), btnY, cfg.buttonWidth, cfg.buttonHeight,
          cfg.colors.clear, function() self.edInput:SetText("") end, self.inputContainer)
      self:_createStyledButton("Copy", "COPY", bx(2), btnY, cfg.buttonWidth, cfg.buttonHeight,
          cfg.colors.copy, function()
              local text = self.edInput:GetText()
              if text ~= "" then pcall(function() ClientHelper.onSetClipboard(text) end) end
          end, self.inputContainer)
      self:_createStyledButton("Back", "BACK", bx(3), btnY, cfg.buttonWidth, cfg.buttonHeight,
          cfg.colors.back, function() self:backInput() end, self.inputContainer)
      self:_createStyledButton("Cancel", "CANCEL", bx(4), btnY, cfg.buttonWidth, cfg.buttonHeight,
          cfg.colors.cancel, function() self:closeInput() end, self.inputContainer)

      if not self.historyRoot then
          self:_createHistoryUI()
      end
      self:_refreshHistoryList()
      self.historyRoot:SetVisible(true)
      
      if self.historyCollapsed == nil then
          self.historyCollapsed = true 
      end

      local expandedX  = -15
      local slideDist  = cfg.historyWidth - 46
      local collapsedX = expandedX + slideDist

      if self.historyCollapsed then
          if self.historyToggle then self.historyToggle:SetText(">") end
          self.historyRoot:SetXPosition({0, collapsedX}) 
      else
          if self.historyToggle then self.historyToggle:SetText("<") end
          self.historyRoot:SetXPosition({0, expandedX})
      end
      if self.inputAnimTimer then
          LuaTimer:cancel(self.inputAnimTimer)
          self.inputAnimTimer = nil
      end
      local pulse = 0
      self.inputAnimTimer = LuaTimer:scheduleTimer(function()
          local ok = pcall(function()
              if not self.inputFrame or not self.llInput:IsVisible() then error("stop") end
              pulse = pulse + 0.12
              local t = 0.5 + (math.sin(pulse) * 0.5)
              if self.inputFrame then
                  self.inputFrame:SetBackgroundColor({1, 0.1 + t * 0.25, 0.1 + t * 0.25, 0.4 + t * 0.5})
              end
              if self.inputCaret then
                  local blink = (math.sin(pulse * 1.8) > 0) and 1 or 0
                  self.inputCaret:SetBackgroundColor({1, 0.15, 0.15, blink})
              end
          end)
          if not ok then
              if self.inputAnimTimer then
                  LuaTimer:cancel(self.inputAnimTimer)
                  self.inputAnimTimer = nil
              end
          end
      end, 30, -1)

      LuaTimer:schedule(function()
          self:showInputBox()
      end, 50)
  end

  function UIGMControlPanel:_createHistoryUI()
      local cfg = INPUT_UI
      local root = GUISystem.Instance():GetRootWindow()

      self.commandHistory = self.commandHistory or {}

      self.historyRoot = GUIManager:createGUIWindow(GUIType.Layout, "GMHistory_Root_" .. math.random(9999))
      self.historyRoot:SetHorizontalAlignment(HorizontalAlignment.Right)
      self.historyRoot:SetVerticalAlignment(VerticalAlignment.Top)
      self.historyRoot:SetWidth({0, cfg.historyWidth})
      self.historyRoot:SetHeight({0, cfg.historyHeight})
      self.historyRoot:SetXPosition({0, -15})
      self.historyRoot:SetYPosition({0, 110})
      self.historyRoot:SetBackgroundColor(cfg.colors.dark_bg)
      self.historyRoot:SetTouchable(true)
      pcall(function() self.historyRoot:SetLevel(1) ;self.historyRoot:SetAlwaysOnTop(true) end)
      root:AddChildWindow(self.historyRoot)

      self:_addRedLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, self.historyRoot)
      self:_addRedLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, self.historyRoot)
      self:_addRedLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, self.historyRoot)
      self:_addRedLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, self.historyRoot)
      self:_addCorners(self.historyRoot)

      local header = GUIManager:createGUIWindow(GUIType.Layout, "History_Header")
      header:SetArea({0, 2}, {0, 2}, {1, -4}, {0, 45})
      header:SetBackgroundColor(cfg.colors.header_bg)
      self.historyRoot:AddChildWindow(header)
      self:_addRedLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, header)
      if self.historyCollapsed == nil then self.historyCollapsed = true end
      
      self.historyToggle = GUIManager:createGUIWindow(GUIType.Button, "HistToggle_" .. math.random(9999))
      self.historyToggle:SetArea({0, 6}, {0, 6}, {0, 34}, {0, 34})
      self.historyToggle:SetText(self.historyCollapsed and ">" or "<")
      self.historyToggle:SetTextScale(1.5)
      self.historyToggle:SetTextColor(cfg.colors.red_accent)
      self.historyToggle:SetBackgroundColor({0.18, 0.04, 0.04, 1})
      self.historyToggle:SetTouchable(true)
      pcall(function() self.historyToggle:SetLevel(3) end)
      header:AddChildWindow(self.historyToggle)
      self.historyToggle:registerEvent(GUIEvent.ButtonClick, function()
          self:_toggleHistoryPanel()
      end)

      local title = GUIManager:createGUIWindow(GUIType.StaticText, "History_Title")
      title:SetArea({0, 48}, {0, 0}, {1, -56}, {1, 0})
      title:SetText("> COMMAND HISTORY")
      title:SetTextColor(cfg.colors.red_accent)
      title:SetTextScale(1.1)
      title:SetTextHorzAlign(HorizontalAlignment.Left)
      title:SetTextVertAlign(VerticalAlignment.Center)
      header:AddChildWindow(title)

      local scrollBg = GUIManager:createGUIWindow(GUIType.Layout, "History_ScrollBg")
      scrollBg:SetArea({0, 8}, {0, 52}, {1, -16}, {1, -12})
      scrollBg:SetBackgroundColor({0.05, 0.02, 0.02, 0.85})
      self.historyRoot:AddChildWindow(scrollBg)

      self:_addRedLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, scrollBg)
      self:_addRedLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, scrollBg)
      self:_addRedLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, scrollBg)
      self:_addRedLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, scrollBg)

      self.historyList = GUIManager:createGUIWindow(GUIType.List, "History_List")
      self.historyList:SetArea({0, 5}, {0, 5}, {1, -10}, {1, -10})
      self.historyList:SetBackgroundColor({0, 0, 0, 0})
      scrollBg:AddChildWindow(self.historyList)
  end


  function UIGMControlPanel:_toggleHistoryPanel()
      if not self.historyRoot then return end
      local cfg = INPUT_UI
      self.historyCollapsed = not self.historyCollapsed

      local expandedX  = -15            
      local slideDist  = cfg.historyWidth - 46
      local collapsedX = expandedX + slideDist

      local fromX = self.historyCollapsed and expandedX or collapsedX
      local toX   = self.historyCollapsed and collapsedX or expandedX

      if self.historyToggle then
          self.historyToggle:SetText(self.historyCollapsed and ">" or "<")
      end

      local steps    = 10
      local stepTime = 180 / steps
      local delta    = (toX - fromX) / steps
      local cur      = 0
      local function anim()
          cur = cur + 1
          self.historyRoot:SetXPosition({0, fromX + delta * cur})
          if cur < steps then
              LuaTimer:schedule(anim, stepTime)
          end
      end
      anim()
  end

  function UIGMControlPanel:_refreshHistoryList()
      if not self.historyList then return end
      self.historyList:ClearAllItem()

      local cfg = INPUT_UI

      if #self.commandHistory == 0 then
          local empty = GUIManager:createGUIWindow(GUIType.StaticText, "EmptyText_" .. math.random(9999))
          empty:SetWidth({1, 0})
          empty:SetHeight({0, 80})
          empty:SetText("[ No History Yet ]")
          empty:SetTextColor({0.45, 0.4, 0.4, 1})
          empty:SetTextScale(1.0)
          empty:SetTextHorzAlign(HorizontalAlignment.Center)
          empty:SetTextVertAlign(VerticalAlignment.Center)
          empty:SetBackgroundColor({0, 0, 0, 0})
          self.historyList:AddItem(empty)
          return
      end

      for i = #self.commandHistory, 1, -1 do
          self:_createHistoryRow(self.commandHistory[i], i)
      end
  end

  function UIGMControlPanel:_createHistoryRow(cmdData, index)
      local cfg = INPUT_UI

      local row = GUIManager:createGUIWindow(GUIType.Layout, "HistoryRow_" .. index .. "_" .. math.random(9999))
      row:SetWidth({1, 0})
      row:SetHeight({0, cfg.historyRowHeight})
      row:SetBackgroundColor(cfg.colors.row_bg)
      row:SetTouchable(true)

      local divider = GUIManager:createGUIWindow(GUIType.StaticText, "Divider_" .. math.random(9999))
      divider:SetArea({0, 0}, {1, -1}, {1, 0}, {0, 1})
      divider:SetBackgroundColor({0.15, 0.05, 0.05, 0.6})
      row:AddChildWindow(divider)

      local displayText = table.concat(cmdData.params, ", ")
      if #displayText > 32 then
          displayText = string.sub(displayText, 1, 29) .. "..."
      end

      local text = GUIManager:createGUIWindow(GUIType.StaticText, "HistoryText_" .. math.random(9999))
      text:SetArea({0, 10}, {0, 0}, {1, -125}, {1, 0})
      text:SetText(displayText)
      text:SetTextColor(cfg.colors.white)
      text:SetTextScale(0.92)
      text:SetTextHorzAlign(HorizontalAlignment.Left)
      text:SetTextVertAlign(VerticalAlignment.Center)
      text:SetBackgroundColor({0, 0, 0, 0})
      row:AddChildWindow(text)

      local btnContainer = GUIManager:createGUIWindow(GUIType.Layout, "BtnContainer_" .. math.random(9999))
      btnContainer:SetArea({1, 0}, {0, 0}, {0, 120}, {1, 0})
      btnContainer:SetBackgroundColor({0, 0, 0, 0})
      row:AddChildWindow(btnContainer)

      local useBtn = GUIManager:createGUIWindow(GUIType.Button, "UseBtn_" .. math.random(9999))
      useBtn:SetArea({0, 6}, {0, 5}, {0, 55}, {1, -10})
      useBtn:SetText("USE")
      useBtn:SetTextColor({0.2, 1, 0.2, 1})
      useBtn:SetBackgroundColor({0.1, 0.4, 0.1, 0.96})
      useBtn:SetTextScale(0.88)
      useBtn:SetTouchable(true)
      btnContainer:AddChildWindow(useBtn)
      useBtn:registerEvent(GUIEvent.ButtonClick, function()
          self:_applyHistory(cmdData)
      end)

      local delBtn = GUIManager:createGUIWindow(GUIType.Button, "DelBtn_" .. math.random(9999))
      delBtn:SetArea({0, 65}, {0, 5}, {0, 55}, {1, -10})
      delBtn:SetText("DEL")
      delBtn:SetTextColor({0.7, 0.74, 1, 1})
      delBtn:SetBackgroundColor({0.2, 0.21, 0.35, 0.96})
      delBtn:SetTextScale(0.88)
      delBtn:SetTouchable(true)
      btnContainer:AddChildWindow(delBtn)
      delBtn:registerEvent(GUIEvent.ButtonClick, function()
          self:_deleteHistory(index)
      end)

      local isExpanded = false
      row:registerEvent(GUIEvent.Click, function()
          isExpanded = not isExpanded
          self:_animateSlide(btnContainer, isExpanded)
      end)

      self.historyList:AddItem(row)
  end

  function UIGMControlPanel:_animateSlide(container, expand)
      local startX = expand and 0 or -120
      local endX   = expand and -120 or 0
      local steps  = 8
      local stepTime = 160 / steps
      local stepDelta = (endX - startX) / steps

      local currentStep = 0
      local function animate()
          currentStep = currentStep + 1
          container:SetXPosition({1, startX + (stepDelta * currentStep)})
          if currentStep < steps then
              LuaTimer:schedule(animate, stepTime)
          end
      end
      animate()
  end

  function UIGMControlPanel:_applyHistory(cmdData)
      if self.edInput and cmdData.params and #cmdData.params > 0 then
          self.edInput:SetText("")
          self.edInput:SetText(table.concat(cmdData.params, ", "))
      end
  end

  function UIGMControlPanel:_deleteHistory(index)
      table.remove(self.commandHistory, index)
      self:_refreshHistoryList()
  end

  function UIGMControlPanel:_saveToHistory(params)
      self.commandHistory = self.commandHistory or {}

      local paramsCopy = {}
      for i, v in ipairs(params) do
          paramsCopy[i] = v
      end

      local last = self.commandHistory[#self.commandHistory]
      if last and table.concat(last.params, "\1") == table.concat(paramsCopy, "\1") then
          return
      end

      table.insert(self.commandHistory, {
          params = paramsCopy,
          timestamp = os.time()
      })

      if #self.commandHistory > 50 then
          table.remove(self.commandHistory, 1)
      end
  end

  function UIGMControlPanel:showInputBox()
      local idx   = #self.inputTable + 1
      local total = #self.paramTexts
      self.tipText = tostring(self.paramTexts[idx])

      local done = (#self.inputTable > 0) and ("  |  Entered: " .. table.concat(self.inputTable, ", ")) or ""
      if self.titleLabel then
          self.titleLabel:SetText(string.format("[%d/%d] %s%s", idx, total, self.tipText, done))
      end

      self.edInput:SetText("")
      self.edInput:OpenKeyboard()
      LuaTimer:schedule(function()
          self.edInput:TouchUp({VectorUtil.newVector2(0, 0)})
      end, 50)
  end

  function UIGMControlPanel:inputText()
      local text = self.edInput:GetText()
      if text == "" then return end
      table.insert(self.inputTable, text)

      if #self.inputTable < #self.paramTexts then
          self:showInputBox()
      else
          self.edInput:SetText("")
          self:_saveToHistory(self.inputTable)
          if self.callBack then
              self.callBack(unpack(self.inputTable))
          end
          self:closeInput()
      end
  end

  function UIGMControlPanel:backInput()
      if #self.inputTable > 0 then
          table.remove(self.inputTable)
      end
      self:showInputBox()
  end

  function UIGMControlPanel:closeInput()
      self.llInput:SetVisible(false)
      self.paramTexts = {}
      self.inputTable = {}
      self.callBack   = nil
      if self.edInput then self.edInput:SetText("") end

      if self.inputAnimTimer then
          LuaTimer:cancel(self.inputAnimTimer)
          self.inputAnimTimer = nil
      end

      self:_clearButtons()
      if self.inputContainer then
          GUIManager:destroyGUIWindow(self.inputContainer)
          self.inputContainer = nil
      end
      self.inputFrame  = nil
      self.inputCaret  = nil
      self.titleLabel  = nil
      self.edInput     = nil

      if self.historyRoot then
          self.historyRoot:SetVisible(false)
      end
  end


function GMHelper:callCommand(name, ...)
    local func = self[name]
    local args = { ... }
    local text_element = args[#args] 

    if type(func) == "function" then
        func(self, unpack(args))
    end

    local toggleVar = _G["tog" .. name]
    GMSetting:changeColorByFunction(name, toggleVar, text_element)
    
    local data = { name = name, params = { ... } }
    if #data.params > 0 then
        table.remove(data.params)
    end
end

function GMSetting:changeColorByFunction(func_name, toggle, text)
    for _, group in pairs(Settings) do
        for _, item in pairs(group.items) do
            if item.func == func_name then
                item.toggle = toggle
                local color = toggle and _G.NTheme.accentBg or _G.NTheme.cardOff
                if text then
                    text:SetBackgroundColor(color)
                end
                if toggle then
                    SoundUtil.playSound(70)
                else
                    SoundUtil.playSound(0)
                end
                return
            end
        end
    end
end

local function ForceTurnOffESP_UI(func_name)
    _G["tog" .. func_name] = false
    if reButtonColorUI then pcall(reButtonColorUI, func_name) end
    if GMSetting and GMSetting.changeColorByFunction then 
        pcall(function() GMSetting:changeColorByFunction(func_name, false) end) 
    end
    if _G.GMItemUIs and _G.GMItemUIs[func_name] then
        local targetItem = _G.GMItemUIs[func_name]
        local offColor = _G.NTheme.cardOff
        if targetItem.root and targetItem.root.SetBackgroundColor then
            targetItem.root:SetBackgroundColor(offColor)
        elseif targetItem.tvName and targetItem.tvName.SetBackgroundColor then
            targetItem.tvName:SetBackgroundColor(offColor)
        elseif targetItem.tvItemName and targetItem.tvItemName.SetBackgroundColor then
            targetItem.tvItemName:SetBackgroundColor(offColor)
        end
    end
end

function GMHelper:updatelog()
    local existingWin = GUIManager:getWindowByName("NClient_UpdateLog_Root")
    if existingWin then
        local isVisible = existingWin:IsVisible()
        existingWin:SetVisible(not isVisible)
        if not isVisible then pcall(function() existingWin:SetAlwaysOnTop(true) end) end
        if not isVisible and self._ulTimerStart then self._ulTimerStart() end
        return
    end
    local root = GUISystem.Instance():GetRootWindow()
    local updateLog = [[
  ^FF0000[ N-CLIENT V1.0 CHANGELOG ]^FFFFFF
  ^00FF00[+] Bypass for ENGINE 10113
  ^00FF00[+] Add Fly Dev Bypass
  ^00FF00[+] Add RunCode / RunFile
  ^00FF00[+] Add MovableClient
  ^00FF00[+] Add ChangeLog
  ^00FF00[+] Add RespawnInSamePlace
  ^00FF00[+] Add Kill Aura / AimBot
  ^00FF00[+] Add ESP (Line / 3D / 2D / Health / Tracer)
  ^00FF00[+] Add Auto Click
  ^00FF00[+] Add Speed Hack + Free Camera
  ^00FF00[+] Add Clothes / VIP Nameplate Editor
  ^00FF00[+] Add TP Bypass (no rubber-band)
  ^00FF00[+] Add Window Inspector (Debug)
  ^00FF00[+] Add Orbit Player (orbit around target)
  ^00FF00[+] Add JetPack (fly toward look direction)
  ^00FF00[+] Add NoClip (xuyen tuong)
  ^00FF00[+] Add High Jump + Infinite Jump
  ^00FF00[+] Add Anti-Void (chong roi vuc)
  ^00FF00[+] Add No Fall + Infinite Sprint
  ^00FF00[+] Add Reach
  ^00FF00[+] Add Show/Hide Window Toggle (Debug)

  ^AAAAAA====================================
  ^FF0000[i]^FFFFFF Join Our Discord Server For More Info
  ^FF0000[*]^FFFFFF NClient By Ice
  ^FF0000[*]^FFFFFF Helper: What
  ^FF0000[*]^FFFFFF GUI Design By Ice
    ]]
    local _, lineCount = string.gsub(updateLog, "\n", "")
    local textHeight = (lineCount * 28) + 60
    local colors = {
        dark_bg   = {0.05, 0.01, 0.01, 0.98}, 
        header_bg = {0.086, 0.098, 0.145, 1},
        red_accent= {0.937, 0.267, 0.267, 1},
        white     = {1, 1, 1, 1},
    }
    local borderLines = {}
    local mainBg = GUIManager:createGUIWindow(GUIType.Layout, "NClient_UpdateLog_Root")
    mainBg:SetArea({0.5, -350}, {0.5, -225}, {0, 700}, {0, 450})
    mainBg:SetBackgroundColor(colors.dark_bg)
    mainBg:SetTouchable(true)
    pcall(function() mainBg:SetLevel(1); mainBg:SetAlwaysOnTop(true) end)
    root:AddChildWindow(mainBg)
    local function addRedLine(x, y, w, h, parent, track)
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "Red_Line_" .. math.random(9999))
        l:SetArea(x, y, w, h)
        l:SetBackgroundColor(colors.red_accent)
        parent:AddChildWindow(l)
        if track then table.insert(borderLines, l) end
        return l
    end
    addRedLine({0, 0}, {0, 0}, {1, 0}, {0, 2}, mainBg, true)
    addRedLine({0, 0}, {1, -2}, {1, 0}, {0, 2}, mainBg, true)
    addRedLine({0, 0}, {0, 0}, {0, 2}, {1, 0}, mainBg, true)
    addRedLine({1, -2}, {0, 0}, {0, 2}, {1, 0}, mainBg, true)
    local header = GUIManager:createGUIWindow(GUIType.Layout, "Header_Bg")
    header:SetArea({0, 2}, {0, 2}, {1, -4}, {0, 45})
    header:SetBackgroundColor(colors.header_bg)
    mainBg:AddChildWindow(header)
    addRedLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, header, true)
    local headerText = GUIManager:createGUIWindow(GUIType.StaticText, "Header_Title")
    headerText:SetArea({0, 15}, {0, 0}, {1, -60}, {1, 0})
    headerText:SetText("> N-CLIENT :: UPDATE LOG")
    headerText:SetTextColor(colors.red_accent)
    headerText:SetTextScale(1.4)
    headerText:SetTextHorzAlign(HorizontalAlignment.Left)
    headerText:SetTextVertAlign(VerticalAlignment.Center)
    header:AddChildWindow(headerText)
    local closeBtn = GUIManager:createGUIWindow(GUIType.StaticText, "Btn_Close")
    closeBtn:SetArea({1, -45}, {0, 5}, {0, 40}, {0, 35})
    closeBtn:SetText("[ X ]")
    closeBtn:SetTextColor({0.937, 0.267, 0.267, 1})
    closeBtn:SetTextHorzAlign(HorizontalAlignment.Center)
    closeBtn:SetTextVertAlign(VerticalAlignment.Center)
    closeBtn:SetTextScale(1.2)
    closeBtn:SetTouchable(true)
    header:AddChildWindow(closeBtn)
    closeBtn:registerEvent(GUIEvent.Click, function() mainBg:SetVisible(false) end)
    local scrollBg = GUIManager:createGUIWindow(GUIType.Layout, "Scroll_Container")
    scrollBg:SetArea({0, 10}, {0, 55}, {1, -20}, {1, -95})
    scrollBg:SetBackgroundColor({0.02, 0, 0, 0.5})
    mainBg:AddChildWindow(scrollBg)

    local scroll = GUIManager:createGUIWindow(GUIType.List, "Scroll_List")
    scroll:SetArea({0, 5}, {0, 5}, {1, -10}, {1, -10})
    scroll:SetBackgroundColor({0, 0, 0, 0})
    scrollBg:AddChildWindow(scroll)
    local textUI = GUIManager:createGUIWindow(GUIType.MultilineEdit, "Text_Content")
    textUI:SetWidth({1, 0})
    textUI:SetHeight({0, textHeight})
    textUI:SetText(updateLog)
    textUI:SetTextScale(1.1)
    textUI:SetBackgroundColor({0, 0, 0, 0})
    textUI:SetTouchable(false)
    scroll:AddItem(textUI)
    local footerBg = GUIManager:createGUIWindow(GUIType.Layout, "Footer_Bg")
    footerBg:SetArea({0, 10}, {1, -35}, {1, -20}, {0, 25})
    footerBg:SetBackgroundColor({0.1, 0, 0, 0.7})
    mainBg:AddChildWindow(footerBg)
    
    local footerText = GUIManager:createGUIWindow(GUIType.StaticText, "Footer_Title")
    footerText:SetArea({0, 10}, {0, 0}, {1, 0}, {1, 0})
    footerText:SetText("STATUS: UNDETECTED  |  V1.0.0  |  ENGINE: 10113")
    footerText:SetTextColor({0.8, 0.8, 0.8, 1})
    footerText:SetTextScale(0.9)
    footerText:SetTextHorzAlign(HorizontalAlignment.Left)
    footerText:SetTextVertAlign(VerticalAlignment.Center)
    footerBg:AddChildWindow(footerText)
    local scanline = GUIManager:createGUIWindow(GUIType.StaticText, "UL_Scan")
    scanline:SetArea({0, 2}, {0, 0}, {1, -4}, {0, 1})
    scanline:SetBackgroundColor({1, 0, 0, 0.3})
    mainBg:AddChildWindow(scanline)
    local pulse, scanPos = 0, 0
    local function startTimer()
        if self.updateLogTimer then LuaTimer:cancel(self.updateLogTimer); self.updateLogTimer = nil end
        self.updateLogTimer = LuaTimer:scheduleTimer(function()
            local ok = pcall(function()
                if not mainBg or not mainBg:IsVisible() then error("stop") end
                pulse = pulse + 0.05
                for i, line in ipairs(borderLines) do
                    local t = 0.5 + 0.5 * math.sin(pulse + i * 0.5)
                    line:SetBackgroundColor({1, 0, 0, 0.3 + t * 0.7})
                end
                scanPos = (scanPos + 0.01) % 1
                scanline:SetYPosition({scanPos, 0})
            end)
            if not ok and self.updateLogTimer then
                LuaTimer:cancel(self.updateLogTimer)
                self.updateLogTimer = nil
            end
        end, 20, -1)
    end
    self._ulTimerStart = startTimer
    local steps, cur = 8, 0
    local function zoomIn()
        cur = cur + 1
        local p = cur / steps
        mainBg:SetArea({0.5, - (700 * p) / 2}, {0.5, - (450 * p) / 2}, {0, 700 * p}, {0, 450 * p})
        if cur < steps then
            LuaTimer:schedule(zoomIn, 15)
        else
            startTimer()
        end
    end
    zoomIn()
end
local isTest1 = false 

function test1()
    isTest1 = not isTest1
    if isTest1 then
        UIHelper.showToast("coca test")
    else
        UIHelper.showToast("coda")
    end
end

  local GM_BTN_SIZE_ON  = 70  
  local GM_BTN_SIZE_OFF = 55  

  function GMHelper:MovablePanel()
      local openBtn = GUIManager:getWindowByName("GMMain-Open")
      if not openBtn then return end

      self.movable = not self.movable

      if self.movable then
          UIHelper.showToast("Movable: Enabled")
          openBtn:SetWidth({0, GM_BTN_SIZE_ON})
          openBtn:SetHeight({0, GM_BTN_SIZE_ON})
          if not self.moveEventRegistered then
              local half = GM_BTN_SIZE_ON / 2
              openBtn:registerEvent(GUIEvent.TouchMove, function(args)
                  if not self.movable then return end
                  local pos = args.position
                  if not pos then return end

                  local targetX = pos.x - half
                  local targetY = pos.y - half
                  local sw = GUISystem.Instance():GetScreenWidth()
                  local sh = GUISystem.Instance():GetScreenHeight()
                  if sw and sh then
                      if targetX < 0 then targetX = 0 end
                      if targetY < 0 then targetY = 0 end
                      if targetX > sw - GM_BTN_SIZE_ON then targetX = sw - GM_BTN_SIZE_ON end
                      if targetY > sh - GM_BTN_SIZE_ON then targetY = sh - GM_BTN_SIZE_ON end
                  end

                  openBtn:SetHorizontalAlignment(HorizontalAlignment.Left)
                  openBtn:SetVerticalAlignment(VerticalAlignment.Top)
                  openBtn:SetXPosition({0, targetX})
                  openBtn:SetYPosition({0, targetY})
              end)
              self.moveEventRegistered = true
          end
      else
          UIHelper.showToast("Movable: Disabled")
          openBtn:SetWidth({0, GM_BTN_SIZE_OFF})
          openBtn:SetHeight({0, GM_BTN_SIZE_OFF})
          openBtn:SetHorizontalAlignment(HorizontalAlignment.Left)
          openBtn:SetVerticalAlignment(VerticalAlignment.Top)
          openBtn:SetXPosition({0.5, -GM_BTN_SIZE_OFF / 2})
          openBtn:SetYPosition({0, 54})
      end
  end

function GMHelper:runCode()
    GMHelper:openInput({"Enter Lua Code"}, function(input)
        if not input or input == "" then return end
        local loader = loadk or loadn
        local func, err = loader(input)
        if not func and (#input % 2 == 1) then
            input = input .. " "
            func, err = loader(input)
        end
        if not func then
            print("Syntax Error: " .. tostring(err))
            UIHelper.showToast("Syntax Error: " .. tostring(err))
            return
        end
        local ok, runErr = pcall(func)
        if not ok then
            print("Runtime Error: " .. tostring(runErr))
            UIHelper.showToast("Runtime Error: " .. tostring(runErr))
            return
        end
    end)
end

local function createButtonHandler(button, moveVector)
    local isTouching = false
    local timer
    local pos = PlayerManager:getClientPlayer():getPosition()

    local function movePlayer()
        if isTouching then
            pos = PlayerManager:getClientPlayer():getPosition()
            PlayerManager:getClientPlayer().Player:moveEntity(moveVector)
        end
    end

    local function startTouch()
        if not isTouching then
            isTouching = true
            timer = LuaTimer:scheduleTimer(movePlayer, 0.05, -1)
        end
    end

    local function stopTouch()
        isTouching = false
        if timer then
            LuaTimer:cancel(timer)
            timer = nil
        end
    end

    button:registerEvent(GUIEvent.TouchDown, startTouch)
    button:registerEvent(GUIEvent.TouchMove, movePlayer)
    button:registerEvent(GUIEvent.TouchUp, stopTouch)
    button:registerEvent(GUIEvent.LongTouchStart, startTouch)
    button:registerEvent(GUIEvent.LongTouchEnd, stopTouch)
    button:registerEvent(GUIEvent.DragStart, startTouch)
    button:registerEvent(GUIEvent.Dragging, movePlayer)
    button:registerEvent(GUIEvent.DragEnd, stopTouch)
    button:registerEvent(GUIEvent.Release, stopTouch)
end
function GMHelper:soooooo()
    togsoooooo = not togsoooooo
    
    local function getPlayer()
        local cp = PlayerManager:getClientPlayer()
        return cp and cp.Player
    end

    local p = getPlayer()
    if not p then return end
    
    if not self.flyButton then
        local btn = GUIManager:createGUIWindow(GUIType.Button, "GUIRoot-BwFly")
        btn:SetHorizontalAlignment(HorizontalAlignment.Right)
        btn:SetVerticalAlignment(VerticalAlignment.Bottom)
        btn:SetLevel(50)
        btn:SetTouchable(true)
        btn:SetBackgroundColor({0, 0, 0, 0})
        btn:SetVisible(false)
        btn:SetProperty("Area", "{{-0.015,0},{-0.330000,0},{-0.015,70},{-0.330000,70}}")
        btn:SetNormalImage("set:fly_control.json image:luodi")
        btn:SetPushedImage("set:fly_control.json image:luodi")
        btn:SetArea(btn:GetXPosition(), btn:GetYPosition(), { 0, 70 }, { 0, 70 })
        GUISystem.Instance():GetRootWindow():AddChildWindow(btn)
        self.flyButton = btn
        
        createButtonHandler(GUIManager:getWindowByName("Main-Down"), VectorUtil.newVector3(0, -0.0020, 0))
        createButtonHandler(GUIManager:getWindowByName("Main-Up"), VectorUtil.newVector3(0, 0.0020, 0))
        
        btn:registerEvent(GUIEvent.ButtonClick, function()
            local currentPlayer = getPlayer()
            if not currentPlayer then return end

            if self.fly then LuaTimer:cancel(self.fly) end
            
            self.fly = LuaTimer:scheduleTimer(function()
                local innerPlayer = getPlayer()
                if not innerPlayer then 
                    LuaTimer:cancel(self.fly)
                    return 
                end
                if innerPlayer:getIsFlying() then
                    btn:SetVisible(false)
                else
                    btn:SetVisible(true)
                    LuaTimer:cancel(self.fly)
                end
            end, 50, -1)
            
            currentPlayer:setAllowFlying(true)
            currentPlayer:setFlying(true)
            currentPlayer:moveEntity(VectorUtil.newVector3(0.0, 1.35, 0.0))
        end)
    end
    
    local isEnabled = togsoooooo
    self.flyButton:SetVisible(isEnabled)
    
    if isEnabled then
        local freshP = getPlayer()
        if freshP then
            local caps = freshP:getCapabilities()
            caps:setFlySpeed(0.11)
            caps.allowFlying = true
            caps.isFlying = false
            
            freshP.m_isPulled = true
            freshP.m_remainingFlyTicksByPulled = 999999
            freshP.onGround = false
            freshP.onGroundPrev = false
            freshP.m_flyingByPulled = false
            
            if type(ground) == "function" then ground() end
            if type(bypass) == "function" then bypass() end
        end
    end
end

local RespawnInSamePlaceCallback = nil

function GMHelper:RespawnInSamePlace(btn)
    self.RespawnInSamePlaceEnabled = not self.RespawnInSamePlaceEnabled
    _G["togRespawnInSamePlace"] = self.RespawnInSamePlaceEnabled
    reButtonColorUI("RespawnInSamePlace")
    ClientHelper.putBoolPrefs("SyncClientPositionToServer", true)
    if self.RespawnInSamePlaceEnabled then
        AddButton("RespawnInPlace", "RespawnInSamePlace")
        UIHelper.showToast("Enabled")
        RespawnInSamePlaceCallback = function(deadPlayer)
            if deadPlayer == CGame.Instance():getPlatformUserId() then
                local meWrapper = PlayerManager:getClientPlayer()
                if not meWrapper or not meWrapper.Player then return end
                local player = meWrapper.Player

                local savedPos   = player:getPosition()
                local savedPitch = player:getPitch()
                local savedYaw   = player:getYaw()

                if CGame.Instance():getGameType() == "g1014" then
                    respawn()
                    LuaTimer:scheduleTimer(function()
                        respawn()
                    end, 1000, 6)
                else
                    PacketSender:getSender():sendRebirth()
                    Teleport(VectorUtil.newVector3(
                        math.floor(savedPos.x),
                        math.floor(savedPos.y),
                        math.floor(savedPos.z)
                    ))
                end

                player.rotationPitch = savedPitch
                player.rotationYaw = savedYaw
                RootGuiLayout.Instance():showMainControl()
            end
        end
        CEvents.LuaPlayerDeathEvent:registerCallBack(RespawnInSamePlaceCallback)
    else
        UIHelper.showToast("Disabled")
        if RespawnInSamePlaceCallback then
            CEvents.LuaPlayerDeathEvent:unregisterCallBack(RespawnInSamePlaceCallback)
            RespawnInSamePlaceCallback = nil
        end
    end
end



function GMHelper:closeGame()
UIHelper.showToast("Bye") 
CGame.Instance():exitGame("normal")
end

function GMHelper:reEnter()
    gameType = CGame.Instance():getGameType() or "g1001"
    targetId = targetId or Game:getPlatformUserId()
    mapId = mapId or ""
    UIHelper.showToast("Resetting...") 
    CGame.Instance():resetGame(gameType, targetId, mapId)
end


local KillAuraEnabled = false
local KillAuraTimerId = nil

function GMHelper:killaura920(btn)
    KillAuraEnabled = not KillAuraEnabled
    _G["togkillaura920"] = KillAuraEnabled
    reButtonColorUI("killaura920")

    if KillAuraEnabled then
        AddButton("KillAura", "killaura920")
        UIHelper.showToast("KillAura Enabled")

        if KillAuraTimerId then
            LuaTimer:cancel(KillAuraTimerId)
            KillAuraTimerId = nil
        end

        KillAuraTimerId = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if not me or not me.Player then return end
            local myPos = me.Player:getPosition()
            if not myPos then return end

            local players = PlayerManager:getPlayers()
            if not players then return end

            for _, target in pairs(players) do
                if target and target ~= me and target.entityId and target:getPosition() then
                    local targetPos = target:getPosition()
                    local distance = MathUtil:distanceSquare3d(targetPos, myPos)
                    if distance < 64 then
                        local roundedPos = VectorUtil.newVector3(
                            math.floor(targetPos.x),
                            math.floor(targetPos.y),
                            math.floor(targetPos.z)
                        )
                        Zentex(target.entityId, roundedPos)
                    end
                end
            end
        end, 600, -1)

    else
        UIHelper.showToast("KillAura Disabled")
        if KillAuraTimerId then
            LuaTimer:cancel(KillAuraTimerId)
            KillAuraTimerId = nil
        end
    end
end
function GMHelper:ShowCreditsUI(parent)
      if self.creditsTimer then
          LuaTimer:cancel(self.creditsTimer)
          self.creditsTimer = nil
      end
      if parent.CleanupChildren then
          parent:CleanupChildren()
      end

      parent:SetBackgroundColor({0.05, 0.01, 0.01, 0.98})

      local colors = {
          primary_red = {0.937, 0.267, 0.267, 1},
          red_soft    = {0.973, 0.443, 0.443, 1},
          dark_red    = {0.2, 0.21, 0.55, 1},
          orange_red  = {0.937, 0.267, 0.267, 1},
          white       = {1, 1, 1, 1},
          grey        = {0.6, 0.62, 0.72, 1},
          dark_bg     = {0.07, 0.078, 0.11, 1},
          darker_bg   = {0.05, 0.015, 0.015, 1},
          hud_accent  = {1, 0.1, 0.1, 0.8},
      }

      local borderLines = {}   
      local pulseTexts  = {}   
      local cardAccents = {}  

      local mainFrame = GUIManager:createGUIWindow(GUIType.Layout, "MainFrame_HUD")
      mainFrame:SetArea({0, 15}, {0, 15}, {1, -30}, {1, -30})
      parent:AddChildWindow(mainFrame)

      local function createFrameLine(x, y, w, h, color, track)
          local l = GUIManager:createGUIWindow(GUIType.StaticText, "FrameLine_" .. math.random(999999))
          l:SetArea(x, y, w, h)
          l:SetBackgroundColor(color)
          mainFrame:AddChildWindow(l)
          if track then table.insert(borderLines, l) end
          return l
      end

      createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3}, true)
      createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3}, true)
      createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3}, true)
      createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3}, true)

      local cSize, cThick = 28, 3
      createFrameLine({0, -2}, {0, -2}, {0, cSize}, {0, cThick}, colors.primary_red, true)
      createFrameLine({0, -2}, {0, -2}, {0, cThick}, {0, cSize}, colors.primary_red, true)
      createFrameLine({1, -cSize + 2}, {0, -2}, {0, cSize}, {0, cThick}, colors.primary_red, true)
      createFrameLine({1, -cThick + 2}, {0, -2}, {0, cThick}, {0, cSize}, colors.primary_red, true)
      createFrameLine({0, -2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.primary_red, true)
      createFrameLine({0, -2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.primary_red, true)
      createFrameLine({1, -cSize + 2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.primary_red, true)
      createFrameLine({1, -cThick + 2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.primary_red, true)

      local scrollPane = GUIManager:createGUIWindow(GUIType.ScrollablePane, "Credits_Scroll")
      scrollPane:SetArea({0, 5}, {0, 5}, {1, -10}, {1, -10})
      scrollPane:InitializeContainer()
      scrollPane:SetProperty("AutoScrollBar", "true")
      mainFrame:AddChildWindow(scrollPane)

      local pWidth = 0
      pcall(function() pWidth = parent:GetPixelSize().x end)
      if not pWidth or pWidth < 100 then
          pcall(function() pWidth = GUISystem.Instance():GetRootWindow():GetPixelSize().x * 0.75 end)
      end
      if not pWidth or pWidth < 100 then pWidth = 1000 end
      local contentW = pWidth - 50

      local contentLayout = GUIManager:createGUIWindow(GUIType.Layout, "Credits_Content")
      contentLayout:SetWidth({0, contentW})
      contentLayout:SetHeight({0, 680})
      scrollPane:AddItem(contentLayout)

      local function addContentText(text, y, size, color, align)
          local t = GUIManager:createGUIWindow(GUIType.StaticText, "CTxt_" .. math.random(999999))
          t:SetArea({0, 20}, {0, y}, {0, contentW - 40}, {0, size * 25})
          t:SetText(text)
          t:SetTextColor(color or colors.white)
          t:SetTextScale(size or 1)
          t:SetTextHorzAlign(align or HorizontalAlignment.Left)
          t:SetTextVertAlign(VerticalAlignment.Center)
          contentLayout:AddChildWindow(t)
          return t
      end

      local function createContentCard(y, height, accentColor, name, role, desc)
          local uid = name .. "_" .. math.random(100000, 999999)

          local cardBorder = GUIManager:createGUIWindow(GUIType.Layout, "CardBorder_" .. uid)
          cardBorder:SetArea({0, 20}, {0, y}, {1, -40}, {0, height})
          cardBorder:SetBackgroundColor({accentColor[1], accentColor[2], accentColor[3], 0.25})
          contentLayout:AddChildWindow(cardBorder)

          local cardInner = GUIManager:createGUIWindow(GUIType.Layout, "CardInner_" .. uid)
          cardInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          cardInner:SetBackgroundColor(colors.dark_bg)
          cardBorder:AddChildWindow(cardInner)

          local headStrip = GUIManager:createGUIWindow(GUIType.StaticText, "Head_" .. uid)
          headStrip:SetArea({0, 0}, {0, 0}, {1, 0}, {0, 40})
          headStrip:SetBackgroundColor({accentColor[1], accentColor[2], accentColor[3], 0.12})
          cardInner:AddChildWindow(headStrip)
          local leftLine = GUIManager:createGUIWindow(GUIType.StaticText, "Line_" .. uid)
          leftLine:SetArea({0, 0}, {0, 0}, {0, 6}, {1, 0})
          leftLine:SetBackgroundColor(accentColor)
          cardInner:AddChildWindow(leftLine)
          table.insert(cardAccents, leftLine)

          local rightDot = GUIManager:createGUIWindow(GUIType.StaticText, "Dot_" .. uid)
          rightDot:SetHorizontalAlignment(HorizontalAlignment.Right)
          rightDot:SetArea({0, -12}, {0, 14}, {0, 12}, {0, 12})
          rightDot:SetBackgroundColor(accentColor)
          cardInner:AddChildWindow(rightDot)
          table.insert(cardAccents, rightDot)

          local txtName = GUIManager:createGUIWindow(GUIType.StaticText, "Name_" .. uid)
          txtName:SetArea({0, 22}, {0, 15}, {1, -50}, {0, 30})
          txtName:SetText(name)
          txtName:SetTextScale(1.45)
          txtName:SetTextColor(colors.white)
          cardInner:AddChildWindow(txtName)

          local txtRole = GUIManager:createGUIWindow(GUIType.StaticText, "Role_" .. uid)
          txtRole:SetArea({0, 22}, {0, 50}, {1, -50}, {0, 18})
          txtRole:SetText("[ " .. role .. " ]")
          txtRole:SetTextScale(0.85)
          txtRole:SetTextColor(accentColor)
          cardInner:AddChildWindow(txtRole)

          local txtDesc = GUIManager:createGUIWindow(GUIType.StaticText, "Desc_" .. uid)
          txtDesc:SetArea({0, 22}, {0, 74}, {1, -50}, {0, 20})
          txtDesc:SetText("> " .. desc)
          txtDesc:SetTextScale(0.8)
          txtDesc:SetTextColor(colors.grey)
          cardInner:AddChildWindow(txtDesc)
      end

      local sysLog = addContentText("[ TEAM 3 ONLINE // SECURE CHANNEL ]", 18, 0.7, colors.hud_accent, HorizontalAlignment.Center)
      table.insert(pulseTexts, sysLog)

      local mainTitle = addContentText("N C L I E N T   V 1 . 0 . 0", 42, 2.0, colors.primary_red, HorizontalAlignment.Center)
      table.insert(pulseTexts, mainTitle)

      local divider = GUIManager:createGUIWindow(GUIType.StaticText, "Divider")
      divider:SetArea({0, 50}, {0, 100}, {0, contentW - 100}, {0, 2})
      divider:SetBackgroundColor(colors.primary_red)
      contentLayout:AddChildWindow(divider)
      table.insert(borderLines, divider)

      addContentText("> SYS_DEV : CORE", 122, 0.9, colors.primary_red, HorizontalAlignment.Left)
      createContentCard(155, 115, colors.primary_red, "Ice", "LEAD DEVELOPER & GUI DESIGNER", "I am Ice")

      addContentText("> SYS_SUPPORT : HELPERS", 295, 0.9, colors.white, HorizontalAlignment.Left)
      createContentCard(328, 105, colors.orange_red, "What?", "PAID API HELPER", "Co-Developer")
      createContentCard(445, 105, colors.dark_red, "no one", "no one", "no one")

      local footerDivider = GUIManager:createGUIWindow(GUIType.StaticText, "FooterDivider")
      footerDivider:SetArea({0, 100}, {0, 590}, {0, contentW - 200}, {0, 1})
      footerDivider:SetBackgroundColor(colors.grey)
      contentLayout:AddChildWindow(footerDivider)
      addContentText("NClient V1.0.0  (c) 2026  //  Connection Secured.", 605, 0.8, colors.dark_red, HorizontalAlignment.Center)

      local pulse = 0
      self.creditsTimer = LuaTimer:scheduleTimer(function()
          local status, err = pcall(function()
              if not parent or not parent:IsVisible() then error("Stop") end

              pulse = pulse + 0.08
              local t = 0.5 + (math.sin(pulse) * 0.5)  

              local breath = {1, 0.1 + t * 0.2, 0.1 + t * 0.2, 0.35 + t * 0.55}
              for _, line in ipairs(borderLines) do
                  if line then line:SetBackgroundColor(breath) end
              end

              for _, txt in ipairs(pulseTexts) do
                  if txt then txt:SetTextColor({1, 0.05 + t * 0.25, 0.05 + t * 0.25, 0.6 + t * 0.4}) end
              end

              local t2 = 0.5 + (math.sin(pulse * 1.3 + 1) * 0.5)
              local glow = {1, 0.05 + t2 * 0.3, 0.05 + t2 * 0.1, 0.6 + t2 * 0.4}
              for _, ac in ipairs(cardAccents) do
                  if ac then ac:SetBackgroundColor(glow) end
              end
          end)

          if not status then
              if self.creditsTimer then
                  LuaTimer:cancel(self.creditsTimer)
                  self.creditsTimer = nil
              end
          end
      end, 50, -1)
  end
local ESP_Line_Active = false
local ESP_Line_Ticker = nil
local NClient_Line_Cache = {}

local function DrawUILine(ui, p1, p2, color, thickness, sw, sh)
    if not p1 or not p2 then return end
    local x1, y1 = p1.x * sw, p1.y * sh
    local x2, y2 = p2.x * sw, p2.y * sh
    local dx, dy = x2 - x1, y2 - y1
    local dist = math.sqrt(dx * dx + dy * dy)
    if dist <= 0.01 then
        ui:SetVisible(false)
        return
    end
    ui:SetVisible(true)
    ui:SetBackgroundColor(color)
    pcall(function()
        ui:SetHorizontalAlignment(HorizontalAlignment.Left)
        ui:SetVerticalAlignment(VerticalAlignment.Top)
    end)
    ui:SetWidth({0, dist})
    ui:SetHeight({0, thickness})
    ui:SetXPosition({0, x1 + dx / 2 - dist / 2})
    ui:SetYPosition({0, y1 + dy / 2})
    ui:SetRotate(math.deg(math.atan2(dy, dx)))
end

local function GetBtnCenter(btn, sw, sh)
    local cx, cy = sw * 0.5, 81.5
    pcall(function()
        local xp, yp = btn:GetXPosition(), btn:GetYPosition()
        local w, h = btn:GetWidth(), btn:GetHeight()
        
        local xo = type(xp) == "table" and xp[2] or 0
        local yo = type(yp) == "table" and yp[2] or 0
        local xs = type(xp) == "table" and xp[1] or 0
        local ys = type(yp) == "table" and yp[1] or 0
        
        local wo = type(w) == "table" and w[2] or 50
        local ho = type(h) == "table" and h[2] or 50
        local ws = type(w) == "table" and w[1] or 0
        local hs = type(h) == "table" and h[1] or 0

        local realX = (xs * sw) + xo
        local realY = (ys * sh) + yo
        local realW = (ws * sw) + wo
        local realH = (hs * sh) + ho
        local hAlign = btn:GetHorizontalAlignment()
        if hAlign == HorizontalAlignment.Center or tostring(hAlign) == "1" then
            realX = (sw / 2) + realX - (realW / 2)
        elseif hAlign == HorizontalAlignment.Right or tostring(hAlign) == "2" then
            realX = sw - realX - realW
        end
        
        local vAlign = btn:GetVerticalAlignment()
        if vAlign == VerticalAlignment.Center or tostring(vAlign) == "1" then
            realY = (sh / 2) + realY - (realH / 2)
        elseif vAlign == VerticalAlignment.Bottom or tostring(vAlign) == "2" then
            realY = sh - realY - realH
        end

        cx = realX + (realW / 2)
        cy = realY + (realH / 2)
    end)
    return cx, cy
end

function GMHelper:ToggleESPLine()
    if ESP_Line_Active then
        ESP_Line_Active = false
        _G["togToggleESPLine"] = false
        
        if ESP_Line_Ticker then 
            LuaTimer:cancel(ESP_Line_Ticker); ESP_Line_Ticker = nil 
        end
        for _, line in pairs(NClient_Line_Cache) do 
            if line then GUIManager:destroyGUIWindow(line) end 
        end
        NClient_Line_Cache = {}
        
        local btn = GUIManager:getWindowByName("NClient-OpenPanel")
        local isNClientBtn = true
        if not btn then 
            btn = GUIManager:getWindowByName("GMMain-Open")
            isNClientBtn = false
        end
        if btn and isNClientBtn then btn:SetText("N") end
        
        UIHelper.showToast("ESP Line Disabled")
        return
    end

    ESP_Line_Active = true
    _G["togToggleESPLine"] = true
    UIHelper.showToast("ESP Line Enabled")

    local function ESP_LineLoop()
        local me = PlayerManager:getClientPlayer()
        local players = PlayerManager:getPlayers()
        if not me or not players then return end
        
        local cam = SceneManager.Instance():getMainCamera()
        if not cam then return end
        local _espPixel = GUISystem.Instance():GetRootWindow():GetPixelSize()
        local sw, sh = _espPixel.x, _espPixel.y
        local camPos, camDir = cam:getPosition(), cam:getDirection()
        
        for id, obj in pairs(NClient_Line_Cache) do
            local exists = false
            for _, p in pairs(players) do 
                if p.userId == id then exists = true; break end 
            end
            if not exists then 
                GUIManager:destroyGUIWindow(obj)
                NClient_Line_Cache[id] = nil 
            end
        end

        local count = 0
        local btn = GUIManager:getWindowByName("NClient-OpenPanel")
        local isNClientBtn = true
        if not btn then 
            btn = GUIManager:getWindowByName("GMMain-Open")
            isNClientBtn = false
        end
        
        local startX, startY = sw * 0.5, 81.5
        if btn then
            startX, startY = GetBtnCenter(btn, sw, sh)
        end
        
        for _, target in pairs(players) do
            if target and target.userId ~= me.userId then
                local entity = target.Player
                local lineObj = NClient_Line_Cache[target.userId]
                if not lineObj then
                    lineObj = GUIManager:createGUIWindow(GUIType.StaticText, "NL_" .. target.userId)
                    pcall(function() lineObj:SetLevel(99); lineObj:SetAlwaysOnTop(true) end)
                    GUISystem.Instance():GetRootWindow():AddChildWindow(lineObj)
                    NClient_Line_Cache[target.userId] = lineObj
                end

                if lineObj then
                    if not entity or not target:isEntityAlive() then
                        lineObj:SetVisible(false)
                    else
                        local isAlly = false
                        pcall(function() isAlly = (me:getTeamId() == target:getTeamId()) end)
                        local lineColor = isAlly and {0, 1, 0, 1} or {1, 0, 0, 1}

                        local pos = entity:getPosition(0)
                        local dist3D = math.sqrt((pos.x - camPos.x)^2 + (pos.y - camPos.y)^2 + (pos.z - camPos.z)^2)
                        local dot = (pos.x - camPos.x) * camDir.x + (pos.y - camPos.y) * camDir.y + (pos.z - camPos.z) * camDir.z
                        if dot > 0 and dist3D < 500 then
                            local yaw = 0
                            pcall(function() yaw = math.rad(entity:getYaw() or entity:getRotationYaw() or 0) end)
                            
                            local cosY, sinY = math.cos(yaw) * 0.4, math.sin(yaw) * 0.4
                            local height = entity:getHeight() or 1.9
                            local center2D = Blockman.Instance():getScreenPos({x = pos.x, y = pos.y + height, z = pos.z})
                            local c1 = Blockman.Instance():getScreenPos({x = pos.x + cosY - sinY, y = pos.y + height, z = pos.z + sinY + cosY})
                            local c2 = Blockman.Instance():getScreenPos({x = pos.x - cosY - sinY, y = pos.y + height, z = pos.z - sinY + cosY})
                            local c3 = Blockman.Instance():getScreenPos({x = pos.x - cosY + sinY, y = pos.y + height, z = pos.z - sinY - cosY})
                            local c4 = Blockman.Instance():getScreenPos({x = pos.x + cosY + sinY, y = pos.y + height, z = pos.z + sinY - cosY})
                            
                            if center2D.z > 0 and c1.z > 0 and c2.z > 0 and c3.z > 0 and c4.z > 0 then
                                local topY = math.min(c1.y, c2.y, c3.y, c4.y)
                                local p2d = {x = center2D.x, y = topY, z = center2D.z}
                                count = count + 1
                                local p1Norm = {x = startX / sw, y = startY / sh}
                                DrawUILine(lineObj, p1Norm, p2d, lineColor, 2, sw, sh)
                            else
                                lineObj:SetVisible(false)
                            end
                        else
                            lineObj:SetVisible(false)
                        end
                    end
                end
            end
        end
        if btn and isNClientBtn then btn:SetText(count > 0 and tostring(count) or "N") end
    end
    ESP_Line_Ticker = LuaTimer:scheduleTimer(ESP_LineLoop, 16, -1)
end

local ESP_Box_Active = false
local ESP_Box_Ticker = nil
local NPanel_3D_Cache = {}

local ESP_2D_Active = false
local ESP_2D_Ticker = nil
local NPanel_2D_Cache = {}

local function GetESPComponents(userId)
    if NPanel_3D_Cache[userId] then return NPanel_3D_Cache[userId] end
    local root = GUISystem.Instance():GetRootWindow()
    local box = {}
    for i = 1, 12 do
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_3D_" .. userId .. "_" .. i)
        pcall(function() l:SetLevel(99); l:SetAlwaysOnTop(true) end)
        root:AddChildWindow(l)
        box[i] = l
    end
    NPanel_3D_Cache[userId] = box
    return box
end

local function GetESP2DComponents(userId)
    if NPanel_2D_Cache[userId] then return NPanel_2D_Cache[userId] end
    local root = GUISystem.Instance():GetRootWindow()
    local box = {}
    for i = 1, 4 do
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_2D_" .. userId .. "_" .. i)
        pcall(function() l:SetLevel(99); l:SetAlwaysOnTop(true) end)
        root:AddChildWindow(l)
        box[i] = l
    end
    NPanel_2D_Cache[userId] = box
    return box
end

local function ForceTurnOff3D()
    ESP_Box_Active = false
    _G["togToggleESP3D"] = false
    if ESP_Box_Ticker then 
        LuaTimer:cancel(ESP_Box_Ticker)
        ESP_Box_Ticker = nil 
    end
    for _, box in pairs(NPanel_3D_Cache) do
        for i = 1, 12 do box[i]:SetVisible(false) end
    end
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESP3D", false) end end)
    pcall(function() if reButtonColorUI then reButtonColorUI("ToggleESP3D") end end)
    pcall(function() if ForceTurnOffESP_UI then ForceTurnOffESP_UI("ToggleESP3D") end end)
end

local function ForceTurnOff2D()
    ESP_2D_Active = false
    _G["togToggleESP2D"] = false
    if ESP_2D_Ticker then 
        LuaTimer:cancel(ESP_2D_Ticker)
        ESP_2D_Ticker = nil 
    end
    for _, box in pairs(NPanel_2D_Cache) do
        for i = 1, 4 do box[i]:SetVisible(false) end
    end
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESP2D", false) end end)
    pcall(function() if reButtonColorUI then reButtonColorUI("ToggleESP2D") end end)
    pcall(function() if ForceTurnOffESP_UI then ForceTurnOffESP_UI("ToggleESP2D") end end)
end

function GMHelper:ToggleESP3D()
    if ESP_Box_Active or _G["togToggleESP3D"] then
        ForceTurnOff3D()
        UIHelper.showToast("ESP 3D Box Disabled")
        return
    end
    ForceTurnOff2D()
    ESP_Box_Active = true
    _G["togToggleESP3D"] = true
    UIHelper.showToast("ESP 3D Box Enabled")
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESP3D", true) end end)
    
    ESP_Box_Ticker = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        local players = PlayerManager:getPlayers()
        local cam = SceneManager.Instance():getMainCamera()
        if not (me and players and cam) then return end
        local _espPixel = GUISystem.Instance():GetRootWindow():GetPixelSize()
        local sw, sh = _espPixel.x, _espPixel.y
        local camPos, camDir = cam:getPosition(), cam:getDirection()
        
        for cachedUserId, box in pairs(NPanel_3D_Cache) do
            local stillInGame = false
            for _, p in pairs(players) do
                if p.userId == cachedUserId then stillInGame = true; break end
            end
            if not stillInGame then
                for i = 1, 12 do 
                    if box[i] then GUIManager:destroyGUIWindow(box[i]) end 
                end
                NPanel_3D_Cache[cachedUserId] = nil
            end
        end
        
        for _, target in pairs(players) do
            if target and target.userId ~= me.userId then
                local box = GetESPComponents(target.userId)
                local entity = target.Player
                local isVisible = false
                
                if entity and target:isEntityAlive() then
                    local pos = entity:getPosition(0)
                    local dot = (pos.x - camPos.x) * camDir.x + (pos.y - camPos.y) * camDir.y + (pos.z - camPos.z) * camDir.z
                    
                    if dot > 0 then
                        local isAlly = false
                        pcall(function() isAlly = (me:getTeamId() == target:getTeamId()) end)
                        local rgbColor = isAlly and {0, 1, 0, 1} or {1, 0, 0, 1}

                        local yaw = math.rad(entity:getYaw() or 0)
                        local cosY, sinY = math.cos(yaw), math.sin(yaw)
                        local corners = {{-0.45, -0.45}, {0.45, -0.45}, {0.45, 0.45}, {-0.45, 0.45}}
                        local pts2D = {}
                        local onScreen = true
                        local entityHeight = entity:getHeight() or 1.9
                        
                        for i = 1, 4 do
                            local rx = corners[i][1] * cosY - corners[i][2] * sinY
                            local rz = corners[i][1] * sinY + corners[i][2] * cosY
                            local pB = Blockman.Instance():getScreenPos({x = pos.x + rx, y = pos.y - 0.1, z = pos.z + rz})
                            local pT = Blockman.Instance():getScreenPos({x = pos.x + rx, y = pos.y + entityHeight, z = pos.z + rz})
                            
                            if not (pB and pB.z > 0 and pT and pT.z > 0) then 
                                onScreen = false; break 
                            end
                            pts2D[i], pts2D[i+4] = {x = pB.x * sw, y = pB.y * sh}, {x = pT.x * sw, y = pT.y * sh}
                        end
                        
                        if onScreen then
                            isVisible = true
                            DrawUILine(box[1], {x=pts2D[1].x/sw, y=pts2D[1].y/sh}, {x=pts2D[2].x/sw, y=pts2D[2].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[2], {x=pts2D[2].x/sw, y=pts2D[2].y/sh}, {x=pts2D[3].x/sw, y=pts2D[3].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[3], {x=pts2D[3].x/sw, y=pts2D[3].y/sh}, {x=pts2D[4].x/sw, y=pts2D[4].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[4], {x=pts2D[4].x/sw, y=pts2D[4].y/sh}, {x=pts2D[1].x/sw, y=pts2D[1].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[5], {x=pts2D[5].x/sw, y=pts2D[5].y/sh}, {x=pts2D[6].x/sw, y=pts2D[6].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[6], {x=pts2D[6].x/sw, y=pts2D[6].y/sh}, {x=pts2D[7].x/sw, y=pts2D[7].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[7], {x=pts2D[7].x/sw, y=pts2D[7].y/sh}, {x=pts2D[8].x/sw, y=pts2D[8].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[8], {x=pts2D[8].x/sw, y=pts2D[8].y/sh}, {x=pts2D[5].x/sw, y=pts2D[5].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[9], {x=pts2D[1].x/sw, y=pts2D[1].y/sh}, {x=pts2D[5].x/sw, y=pts2D[5].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[10], {x=pts2D[2].x/sw, y=pts2D[2].y/sh}, {x=pts2D[6].x/sw, y=pts2D[6].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[11], {x=pts2D[3].x/sw, y=pts2D[3].y/sh}, {x=pts2D[7].x/sw, y=pts2D[7].y/sh}, rgbColor, 2, sw, sh)
                            DrawUILine(box[12], {x=pts2D[4].x/sw, y=pts2D[4].y/sh}, {x=pts2D[8].x/sw, y=pts2D[8].y/sh}, rgbColor, 2, sw, sh)
                        end
                    end
                end
                
                if not isVisible then
                    for i = 1, 12 do box[i]:SetVisible(false) end
                end
            end
        end
    end, 16, -1)
end

function GMHelper:ToggleESP2D()
    if ESP_2D_Active or _G["togToggleESP2D"] then
        ForceTurnOff2D()
        UIHelper.showToast("ESP 2D Box Disabled")
        return
    end
    ForceTurnOff3D()
    ESP_2D_Active = true
    _G["togToggleESP2D"] = true
    UIHelper.showToast("ESP 2D Box Enabled")
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESP2D", true) end end)
    ESP_2D_Ticker = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        local players = PlayerManager:getPlayers()
        local cam = SceneManager.Instance():getMainCamera()
        if not (me and players and cam) then return end
        local _espPixel = GUISystem.Instance():GetRootWindow():GetPixelSize()
        local sw, sh = _espPixel.x, _espPixel.y
        local camPos, camDir = cam:getPosition(), cam:getDirection()
        for cachedUserId, box in pairs(NPanel_2D_Cache) do
            local stillInGame = false
            for _, p in pairs(players) do
                if p.userId == cachedUserId then stillInGame = true; break end
            end
            if not stillInGame then
                for i = 1, 4 do 
                    if box[i] then GUIManager:destroyGUIWindow(box[i]) end 
                end
                NPanel_2D_Cache[cachedUserId] = nil
            end
        end
        for _, target in pairs(players) do
            if target and target.userId ~= me.userId then
                local box = GetESP2DComponents(target.userId)
                local entity = target.Player
                local isVisible = false
                if entity and target:isEntityAlive() then
                    local pos = entity:getPosition(0)
                    local dot = (pos.x - camPos.x) * camDir.x + (pos.y - camPos.y) * camDir.y + (pos.z - camPos.z) * camDir.z
                    local dist3D = math.sqrt((pos.x - camPos.x)^2 + (pos.y - camPos.y)^2 + (pos.z - camPos.z)^2)
                    if dot > 0 and dist3D < 500 then
                        local entityHeight = entity:getHeight() or 1.9
                        local pTop = Blockman.Instance():getScreenPos({x = pos.x, y = pos.y + entityHeight, z = pos.z})
                        local pBot = Blockman.Instance():getScreenPos({x = pos.x, y = pos.y - 0.1, z = pos.z})
                        if pTop and pTop.z > 0 and pBot and pBot.z > 0 then
                            isVisible = true
                            local isAlly = false
                            pcall(function() isAlly = (me:getTeamId() == target:getTeamId()) end)
                            local teamColor = isAlly and {0, 1, 0, 1} or {1, 0, 0, 1}
                            local h = pBot.y - pTop.y
                            local w = h * (sh / sw) * 0.45 
                            local left = pTop.x - (w / 2)
                            local right = pTop.x + (w / 2)
                            local top = pTop.y
                            local bot = pBot.y
                            local topLeft = {x = left, y = top}
                            local topRight = {x = right, y = top}
                            local botLeft = {x = left, y = bot}
                            local botRight = {x = right, y = bot}
                            DrawUILine(box[1], topLeft, topRight, teamColor, 2, sw, sh)
                            DrawUILine(box[2], botLeft, botRight, teamColor, 2, sw, sh)
                            DrawUILine(box[3], topLeft, botLeft, teamColor, 2, sw, sh)
                            DrawUILine(box[4], topRight, botRight, teamColor, 2, sw, sh)
                        end
                    end
                end
                
                if not isVisible then
                    for i = 1, 4 do box[i]:SetVisible(false) end
                end
            end
        end
    end, 16, -1)
end
local ESP_Health_Active = false
local ESP_Health_Ticker = nil
local NPanel_HP_Cache = {}

local function GetESPHealthComponents(userId)
    if NPanel_HP_Cache[userId] then return NPanel_HP_Cache[userId] end
    local root = GUISystem.Instance():GetRootWindow()
    local box = {}
    box.info = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_HP_I_" .. userId)
    box.info:SetTextScale(0.85)
    box.info:SetTextHorzAlign(HorizontalAlignment.Center)
    pcall(function() box.info:SetLevel(99); box.info:SetAlwaysOnTop(true) end)
    root:AddChildWindow(box.info)
    
    box.hpBg = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_HP_BG_" .. userId)
    box.hpBg:SetBackgroundColor({0, 0, 0, 1})
    pcall(function() box.hpBg:SetLevel(98); box.hpBg:SetAlwaysOnTop(true) end)
    root:AddChildWindow(box.hpBg)
    
    box.hpFg = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_HP_FG_" .. userId)
    box.hpFg:SetBackgroundColor({0, 1, 0, 1})
    box.hpBg:AddChildWindow(box.hpFg)
    
    NPanel_HP_Cache[userId] = box
    return box
end

function GMHelper:ToggleESPHealth()
    if ESP_Health_Active then
        ESP_Health_Active = false
        _G["togToggleESPHealth"] = false
        
        if ESP_Health_Ticker then 
            LuaTimer:cancel(ESP_Health_Ticker); ESP_Health_Ticker = nil 
        end
        for _, box in pairs(NPanel_HP_Cache) do
            if box.info then box.info:SetVisible(false) end
            if box.hpBg then box.hpBg:SetVisible(false) end
            if box.hpFg then box.hpFg:SetVisible(false) end
        end
        UIHelper.showToast("ESP Health Disabled")
        return
    end

    ESP_Health_Active = true
    _G["togToggleESPHealth"] = true
    UIHelper.showToast("ESP Health Enabled")
    
    ESP_Health_Ticker = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        local players = PlayerManager:getPlayers()
        local cam = SceneManager.Instance():getMainCamera()
        if not (me and players and cam) then return end
        local _espPixel = GUISystem.Instance():GetRootWindow():GetPixelSize()
        local sw, sh = _espPixel.x, _espPixel.y
        local camPos, camDir = cam:getPosition(), cam:getDirection()
        
        for cachedUserId, box in pairs(NPanel_HP_Cache) do
            local stillInGame = false
            for _, p in pairs(players) do
                if p.userId == cachedUserId then stillInGame = true; break end
            end
            if not stillInGame then
                if box.info then GUIManager:destroyGUIWindow(box.info) end
                if box.hpBg then GUIManager:destroyGUIWindow(box.hpBg) end
                if box.hpFg then GUIManager:destroyGUIWindow(box.hpFg) end
                NPanel_HP_Cache[cachedUserId] = nil
            end
        end
        
        for _, target in pairs(players) do
            if target and target.userId ~= me.userId then
                local box = GetESPHealthComponents(target.userId)
                local entity = target.Player
                local isVisible = false
                
                if entity and target:isEntityAlive() then
                    local pos = entity:getPosition(0)
                    local dist3D = math.sqrt((pos.x - camPos.x)^2 + (pos.y - camPos.y)^2 + (pos.z - camPos.z)^2)
                    local dot = (pos.x - camPos.x) * camDir.x + (pos.y - camPos.y) * camDir.y + (pos.z - camPos.z) * camDir.z
                    
                    if dot > 0 and dist3D < 500 then
                        local entityHeight = entity:getHeight() or 1.9
                        local pTop = Blockman.Instance():getScreenPos({x = pos.x, y = pos.y + entityHeight, z = pos.z})
                        local pBot = Blockman.Instance():getScreenPos({x = pos.x, y = pos.y - 0.1, z = pos.z})
                        
                        if pTop and pTop.z > 0 and pBot and pBot.z > 0 then
                            isVisible = true
                            local curHP = target:getHealth() or 0
                            local maxHP = target:getMaxHealth() or 1
                            if maxHP <= 0 then maxHP = 1 end
                            local pct = math.max(0, math.min(1, curHP / maxHP))
                            
                            local isAlly = false
                            pcall(function() isAlly = (me:getTeamId() == target:getTeamId()) end)
                            local teamColor = isAlly and {0, 1, 0, 1} or {1, 0, 0, 1}

                            local hpColor = {0, 1, 0, 1}
                            if pct <= 0.2 then
                                hpColor = {1, 0, 0, 1}
                            elseif pct <= 0.5 then
                                hpColor = {1, 1, 0, 1}
                            end

                            box.info:SetVisible(true)
                            box.info:SetText(string.format("[%d HP] %dm", math.floor(curHP), math.floor(dist3D)))
                            box.info:SetTextColor(teamColor)
                            
                            local tx, ty = pTop.x * sw, pTop.y * sh
                            local bx, by = pBot.x * sw, pBot.y * sh
                            box.info:SetArea({0, tx - 100}, {0, ty - 25}, {0, 200}, {0, 20})
                            local bH = math.max(1, by - ty)
                            local bW, bdr = 4, 1
                            local dynamicOffset = (bH * 0.225) + 6
                            local bX = tx - dynamicOffset
                            
                            local fgH = bH * pct
                            box.hpBg:SetVisible(true)
                            box.hpBg:SetArea({0, bX - bdr}, {0, ty - bdr}, {0, bW + (bdr * 2)}, {0, bH + (bdr * 2)})
                            box.hpFg:SetVisible(true)
                            box.hpFg:SetArea({0, bdr}, {0, bdr + (bH - fgH)}, {0, bW}, {0, fgH})
                            box.hpFg:SetBackgroundColor(hpColor)
                        end
                    end
                end
                
                if not isVisible then
                    box.info:SetVisible(false)
                    box.hpBg:SetVisible(false)
                    box.hpFg:SetVisible(false)
                end
            end
        end
    end, 16, -1)
end


--==================== ESP SKELETON (xuong that theo bone socket) ====================--
-- Lay vi tri bone thuc te tu model: EntityRenderManager -> ActorObject -> SceneNode
-- Socket nguoi choi: s_head, s_xiongkou(nguc), s_pelvis(hong), s_hand_l/r, s_foot_l/r
local ESP_Skel_Active = false
local ESP_Skel_Ticker = nil
local NPanel_Skel_Cache = {}
local NSkel_State = {}   -- [userId] = {phase, lx, ly, lz, amp} : nhip buoc theo di chuyen

-- so duong xuong: dau, than(cot song), 2 tay, 2 chan = 6
local SKEL_LINE_COUNT = 6

local function GetESPSkelComponents(userId)
    if NPanel_Skel_Cache[userId] then return NPanel_Skel_Cache[userId] end
    local root = GUISystem.Instance():GetRootWindow()
    local box = {}
    for i = 1, SKEL_LINE_COUNT do
        local l = GUIManager:createGUIWindow(GUIType.StaticText, "NPanel_Skel_" .. userId .. "_" .. i)
        pcall(function() l:SetLevel(99); l:SetAlwaysOnTop(true) end)
        root:AddChildWindow(l)
        box[i] = l
    end
    NPanel_Skel_Cache[userId] = box
    return box
end

local function ForceTurnOffSkel()
    ESP_Skel_Active = false
    _G["togToggleESPSkeleton"] = false
    if ESP_Skel_Ticker then
        LuaTimer:cancel(ESP_Skel_Ticker)
        ESP_Skel_Ticker = nil
    end
    for _, box in pairs(NPanel_Skel_Cache) do
        for i = 1, SKEL_LINE_COUNT do if box[i] then box[i]:SetVisible(false) end end
    end
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESPSkeleton", false) end end)
    pcall(function() if reButtonColorUI then reButtonColorUI("ToggleESPSkeleton") end end)
    pcall(function() if ForceTurnOffESP_UI then ForceTurnOffESP_UI("ToggleESPSkeleton") end end)
end

function GMHelper:ToggleESPSkeleton()
    if ESP_Skel_Active or _G["togToggleESPSkeleton"] then
        ForceTurnOffSkel()
        UIHelper.showToast("ESP Skeleton Disabled")
        return
    end
    ESP_Skel_Active = true
    _G["togToggleESPSkeleton"] = true
    UIHelper.showToast("ESP Skeleton Enabled")
    pcall(function() if GMSetting and GMSetting.changeColorByFunction then GMSetting:changeColorByFunction("ToggleESPSkeleton", true) end end)

    ESP_Skel_Ticker = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        local players = PlayerManager:getPlayers()
        local cam = SceneManager.Instance():getMainCamera()
        if not (me and players and cam) then return end
        local _espPixel = GUISystem.Instance():GetRootWindow():GetPixelSize()
        local sw, sh = _espPixel.x, _espPixel.y
        local camPos, camDir = cam:getPosition(), cam:getDirection()
        local myPos = nil
        pcall(function() myPos = me.Player:getPosition(0) end)
        if not myPos then return end

        -- don cache nguoi da roi tran
        for cachedUserId, box in pairs(NPanel_Skel_Cache) do
            local stillInGame = false
            for _, p in pairs(players) do
                if p.userId == cachedUserId then stillInGame = true; break end
            end
            if not stillInGame then
                for i = 1, SKEL_LINE_COUNT do if box[i] then GUIManager:destroyGUIWindow(box[i]) end end
                NPanel_Skel_Cache[cachedUserId] = nil
                NSkel_State[cachedUserId] = nil
            end
        end

        for _, target in pairs(players) do
            if target and target.userId ~= me.userId then
                local box = GetESPSkelComponents(target.userId)
                local entity = target.Player
                local drawn = false

                if entity and target:isEntityAlive() then
                    local pos = entity:getPosition(0)
                    local dot = (pos.x - camPos.x) * camDir.x + (pos.y - camPos.y) * camDir.y + (pos.z - camPos.z) * camDir.z
                    if dot > 0 then
                        local isAlly = false
                        pcall(function() isAlly = (me:getTeamId() == target:getTeamId()) end)
                        local col = isAlly and {0, 1, 0, 1} or {1, 0, 0, 1}

                        local actor = nil
                        pcall(function() actor = EntityRenderManager.Instance():getEntityActor(entity) end)

                        -- Lay vi tri MAN HINH cua 1 bone socket that.
                        -- Socket co the o he "render" (goc noi = vi tri minh) hoac world tuyet doi
                        -- => tu chon he nao gan vi tri logic cua target (pos) hon roi moi chieu.
                        local function bone(name)
                            if not actor then return nil end
                            local out = nil
                            pcall(function()
                                local node = actor:getSocketSceneNode(name)
                                if not node then return end
                                local p = node:getWorldPosition()
                                if not p then return end
                                local raw   = {x = p.x,           y = p.y,           z = p.z}
                                local shift = {x = p.x + myPos.x, y = p.y + myPos.y, z = p.z + myPos.z}
                                local function d2(a)
                                    local dx, dy, dz = a.x - pos.x, a.y - pos.y, a.z - pos.z
                                    return dx * dx + dy * dy + dz * dz
                                end
                                local w = (d2(shift) < d2(raw)) and shift or raw
                                local s = Blockman.Instance():getScreenPos(w)
                                if s and s.z and s.z > 0 then out = {x = s.x, y = s.y} end
                            end)
                            return out
                        end

                        -- 2 diem THAN: nguc (tren) + hong (duoi)
                        local chest  = bone("s_xiongkou")
                        local pelvis = bone("s_pelvis")
                        local head   = bone("s_head")
                        local handL  = bone("s_hand_l")
                        local handR  = bone("s_hand_r")
                        local footL  = bone("s_foot_l")
                        local footR  = bone("s_foot_r")

                        local function line(idx, a, b)
                            if a and b then
                                DrawUILine(box[idx], a, b, col, 2, sw, sh)
                                drawn = true
                            else
                                box[idx]:SetVisible(false)
                            end
                        end

                        line(1, chest,  head)    -- dau: duong thang tu nguc len dau
                        line(2, pelvis, chest)   -- than (cot song): hong -> nguc
                        line(3, chest,  handL)   -- tay trai  (tu diem tren than)
                        line(4, chest,  handR)   -- tay phai
                        line(5, pelvis, footL)   -- chan trai (tu diem duoi than)
                        line(6, pelvis, footR)   -- chan phai
                    end
                end

                if not drawn then
                    for i = 1, SKEL_LINE_COUNT do box[i]:SetVisible(false) end
                end
            end
        end
    end, 16, -1)
end

local togAimBot = false

function GMHelper:AimBot(btn)
    togAimBot = not togAimBot
    _G["togAimBot"] = togAimBot
    reButtonColorUI("AimBot")

    LuaTimer:cancel(self.ja)

    if not togAimBot then
        UIHelper.showToast("AimBot Disabled")
        return
    end
    AddButton("AimBot", "AimBot")
    UIHelper.showToast("AimBot Enabled")
    Blockman.Instance().m_gameSettings:setCollimatorMode(false)

    self.ja = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        if me then
            local myPos = me.Player:getPosition()
            local players = PlayerManager:getPlayers()
            local myTeamId = me.Player:getTeamId()
            local closestDistance = math.huge
            local closestPlayer = nil

            for _, player in pairs(players) do
                if player ~= me and player.Player and player.Player:getTeamId() ~= myTeamId then
                    local playerPos = player:getPosition()
                    local distance = MathUtil:distanceSquare2d(playerPos, myPos)
                    if distance < closestDistance then
                        closestDistance = distance
                        closestPlayer = player
                    end
                end
            end

            if closestPlayer ~= nil and closestDistance < 60 then
                local health = math.min(closestPlayer:getHealth(), 50.0)
                local locationString = string.format("Closest player's health: %.1f", health)
                UIHelper.showToast(locationString)

                local camera = SceneManager.Instance():getMainCamera()
                local pos = camera:getPosition()
                local dir = VectorUtil.sub3(closestPlayer:getPosition(), pos)
                local yaw = math.atan2(dir.x, dir.z) / math.pi * -180
                local calculate = math.sqrt(dir.x * dir.x + dir.z * dir.z)
                local pitch = -math.atan2(dir.y + 1.5, calculate) / math.pi * 180
                me.Player.rotationYaw = yaw or 0
                me.Player.rotationPitch = pitch or 0
            end
        end
    end, 5, -1)
end




function GMHelper:AutoClick(btn)
    self.AutoClickEnabled = not self.AutoClickEnabled
    _G["togAutoClick"] = self.AutoClickEnabled
    reButtonColorUI("AutoClick")

    if autoClickTimer then
        LuaTimer:cancel(autoClickTimer)
        autoClickTimer = nil
        local throwpotControls = GUIManager:getWindowByName("Main-throwpot-Controls")
        if throwpotControls then
            throwpotControls:SetVisible(false)
        end
        UIHelper.showToast("^FF0000Disabled")
    end

    if self.AutoClickEnabled then
        AddButton("AutoClick", "AutoClick")
        UIHelper.showToast("^00FF00Enabled")
        autoClickTimer = LuaTimer:scheduleTimer(function()
            if not self.AutoClickEnabled then return end
            local throwpotControls = GUIManager:getWindowByName("Main-throwpot-Controls")
            if throwpotControls then
                throwpotControls:SetVisible(true)
                throwpotControls:SetAlpha(0)
                throwpotControls:SetXPosition({0, 0})
                throwpotControls:SetYPosition({0, -170})
            end
            CGame.Instance():handleTouchClick(1, 1)
        end, 100, -1)
    end
end

--- ===================== SkyBlock bots =====================
function distanceM(va, vb)
    local dx = va.x - vb.x
    local dy = va.y - vb.y
    local dz = va.z - vb.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Dung ham Teleport xin co san o duoi (~dong 4867, co chong rubberband).
local MonsterMgr = T(Global, "CMonsterMgr")
local function getClosestMonster(perDist)
    local player = PlayerManager:getClientPlayer()
    if not player.Player then return end
    local myPos = player:getPosition()
    local monsterList = MonsterMgr:getAllMonsterEntity()
    local dist = perDist or 7
    local entityTarget

    for _, entity in pairs(monsterList) do
        local mob = entity.entity
        if mob then
            local pos = mob:getPosition()
            local distance = distanceM(myPos, pos)
            if distance <= dist then
                entityTarget = entity
                dist = distance
            end
        end
    end

    return entityTarget
end

local MobKillerTimer = nil
local function MobKillerTick()
    if not togMobKiller then return end
    local player = PlayerManager:getClientPlayer()
    if not player or not player.Player then return end

    local ae = getClosestMonster(1000)
    if ae and ae.entity then
        local trg = ae.entity
        local serverId = EntityCache:getServerId(trg.entityId)
        if not serverId then return end

        local pos = trg:getPosition()
        local mobPos = VectorUtil.newVector3(pos.x, pos.y + 1.2, pos.z)
        Teleport(mobPos)
        player:sendPacket({
            pid = "tryAttackMonster",
            entityId = serverId,
        })
    end
end

function GMHelper:MobKiller()
    togMobKiller = not togMobKiller
    if MobKillerTimer then
        LuaTimer:cancel(MobKillerTimer)
        MobKillerTimer = nil
    end
    if togMobKiller then
        MobKillerTimer = LuaTimer:scheduleTimer(MobKillerTick, 350, -1)
        UIHelper.showToast("^00FF00Mob Killer Enabled")
    else
        UIHelper.showToast("^FF0000Mob Killer Disabled")
    end
end

local HomePlantFactory = T(Global, "HomePlantFactory")

function GMHelper:PlaceCropAura()
    _G["togPlaceCropAura"] = not _G["togPlaceCropAura"]
    if _G["togPlaceCropAura"] then
        UIHelper.showToast("^00FF00Place Crop Aura ON")
        _G["PlaceCropAuraTimer"] = LuaTimer:scheduleTimer(function()
            local player = PlayerManager:getClientPlayer()
            if not player then return end
            local pos = player:getPosition()
            local cx, cy, cz = math.floor(pos.x), math.floor(pos.y), math.floor(pos.z)
            local r = 16
            for x = -r, r do
                for z = -r, r do
                    for y = -2, 1 do
                        local bPos = VectorUtil.newVector3(cx + x, cy + y, cz + z)
                        if EngineWorld:getBlockId(bPos) == BlockID.TILLED_FIELD then
                            local cropPos = VectorUtil.getPosY(bPos, 1)
                            if EngineWorld:getBlockId(cropPos) then
                                player:sendPacket({
                                    pid = "tryCreateCrop",
                                    blockPos = cropPos
                                })
                            end
                        end
                    end
                end
            end
        end, 1000, -1)
    else
        UIHelper.showToast("^FF0000Place Crop Aura OFF")
        if _G["PlaceCropAuraTimer"] then
            LuaTimer:cancel(_G["PlaceCropAuraTimer"])
            _G["PlaceCropAuraTimer"] = nil
        end
    end
end

function GMHelper:CropAura()
    _G["togCropAura"] = not _G["togCropAura"]
    if _G["togCropAura"] then
        UIHelper.showToast("^00FF00Crop Aura ON")
        _G["CropAuraTimer"] = LuaTimer:scheduleTimer(function()
            local player = PlayerManager:getClientPlayer()
            if not player then return end
            local pos = player:getPosition()
            local cx, cy, cz = math.floor(pos.x), math.floor(pos.y), math.floor(pos.z)
            local r = 16
            for x = -r, r do
                for z = -r, r do
                    for y = -2, 1 do
                        local bPos = VectorUtil.newVector3(cx + x, cy + y, cz + z)
                        if EngineWorld:getBlockId(bPos) == BlockID.TILLED_FIELD then
                            local cropPos = VectorUtil.getPosY(bPos, 1)
                            if EngineWorld:getBlockId(cropPos) then
                                player:sendPacket({
                                    pid = "tryBreakCrop",
                                    blockPos = cropPos
                                })
                            end
                        end
                    end
                end
            end
        end, 1000, -1)
    else
        UIHelper.showToast("^FF0000Crop Aura OFF")
        if _G["CropAuraTimer"] then
            LuaTimer:cancel(_G["CropAuraTimer"])
            _G["CropAuraTimer"] = nil
        end
    end
end

function GMHelper:HoeAura()
    _G["togHoeAura"] = not _G["togHoeAura"]
    if _G["togHoeAura"] then
        UIHelper.showToast("^00FF00Hoe Aura ON")
        _G["HoeAuraTimer"] = LuaTimer:scheduleTimer(function()
            local player = PlayerManager:getClientPlayer()
            if not player then return end
            local pos = player:getPosition()
            local cx, cy, cz = math.floor(pos.x), math.floor(pos.y), math.floor(pos.z)
            local r = 16
            for x = -r, r do
                for z = -r, r do
                    for y = -2, 1 do
                        local bPos = VectorUtil.newVector3(cx + x, cy + y, cz + z)
                        if EngineWorld:getBlockId(bPos) == BlockID.GRASS then
                            local abovePos = VectorUtil.getPosY(bPos, 1)
                            if EngineWorld:getBlockId(abovePos) == 0 then
                                player:sendPacket({
                                    pid = "tryUseItemHoe",
                                    blockPos = bPos,
                                })
                            end
                        end
                    end
                end
            end
        end, 1000, -1)
    else
        UIHelper.showToast("^FF0000Hoe Aura OFF")
        if _G["HoeAuraTimer"] then
            LuaTimer:cancel(_G["HoeAuraTimer"])
            _G["HoeAuraTimer"] = nil
        end
    end
end
--- =================== het SkyBlock bots ===================



function GMHelper:ShowInfoUI(parent)
      if self.infoTimer then
          LuaTimer:cancel(self.infoTimer)
          self.infoTimer = nil
      end
      if parent.CleanupChildren then
          parent:CleanupChildren()
      end
      parent:SetBackgroundColor({0.05, 0.02, 0.02, 0.96})

      local colors = {
          red        = {0.937, 0.267, 0.267, 1},
          red_soft   = {0.973, 0.443, 0.443, 1},
          red_deep   = {0.2, 0.21, 0.55, 1},
          orange     = {1, 0.5, 0.1, 1},
          white      = {1, 1, 1, 1},
          grey       = {0.6, 0.62, 0.72, 1},
          dark_bg    = {0.08, 0.088, 0.13, 0.88},
          darker_bg  = {0.05, 0.055, 0.08, 0.92},
          accent     = {1, 0, 0, 0.85},  
          neon_green = {0.2, 1, 0.2, 1},  
          neon_red   = {1, 0.2, 0.2, 1},    
          yellow     = {1, 0.85, 0, 1},      
          btn_bg     = {0.15, 0.04, 0.04, 1},
      }

      local borderLines = {}  
      local pulseTexts  = {}  

      local mainFrame = GUIManager:createGUIWindow(GUIType.Layout, "MainFrame_InfoHUD")
      mainFrame:SetArea({0, 15}, {0, 15}, {1, -30}, {1, -30})
      parent:AddChildWindow(mainFrame)

      local function createFrameLine(x, y, w, h, color)
          local l = GUIManager:createGUIWindow(GUIType.StaticText, "InfoFrame_" .. math.random(999999))
          l:SetArea(x, y, w, h)
          l:SetBackgroundColor(color)
          mainFrame:AddChildWindow(l)
          table.insert(borderLines, l)
          return l
      end

      createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {colors.accent[1], colors.accent[2], colors.accent[3], 0.25})
      createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {colors.accent[1], colors.accent[2], colors.accent[3], 0.25})
      createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {colors.accent[1], colors.accent[2], colors.accent[3], 0.25})
      createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {colors.accent[1], colors.accent[2], colors.accent[3], 0.25})

      local cSize, cThick = 25, 3
      createFrameLine({0, -1}, {0, -1}, {0, cSize}, {0, cThick}, colors.accent)
      createFrameLine({0, -1}, {0, -1}, {0, cThick}, {0, cSize}, colors.accent)
      createFrameLine({1, -cSize + 1}, {0, -1}, {0, cSize}, {0, cThick}, colors.accent)
      createFrameLine({1, -cThick + 1}, {0, -1}, {0, cThick}, {0, cSize}, colors.accent)
      createFrameLine({0, -1}, {1, -cThick + 1}, {0, cSize}, {0, cThick}, colors.accent)
      createFrameLine({0, -1}, {1, -cSize + 1}, {0, cThick}, {0, cSize}, colors.accent)
      createFrameLine({1, -cSize + 1}, {1, -cThick + 1}, {0, cSize}, {0, cThick}, colors.accent)
      createFrameLine({1, -cThick + 1}, {1, -cSize + 1}, {0, cThick}, {0, cSize}, colors.accent)

      local contentLayout = GUIManager:createGUIWindow(GUIType.Layout, "Info_Content")
      contentLayout:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
      mainFrame:AddChildWindow(contentLayout)

      local function addTxt(win, id, content, ax, ay, aw, ah, color, scale, align)
          local t = GUIManager:createGUIWindow(GUIType.StaticText, id)
          t:SetArea(ax, ay, aw, ah)
          t:SetText(content)
          t:SetTextColor(color or colors.white)
          t:SetBackgroundColor({0, 0, 0, 0})
          t:SetTextScale(scale or 1)
          t:SetTextHorzAlign(align or HorizontalAlignment.Left)
          t:SetTextVertAlign(VerticalAlignment.Center)
          win:AddChildWindow(t)
          return t
      end

      local function createModernBox(id, titleText, ax, ay, aw, ah, accentColor)
          local boxBorder = GUIManager:createGUIWindow(GUIType.Layout, "BoxBorder_" .. id)
          boxBorder:SetArea(ax, ay, aw, ah)
          boxBorder:SetBackgroundColor({accentColor[1], accentColor[2], accentColor[3], 0.45})
          contentLayout:AddChildWindow(boxBorder)
          local boxInner = GUIManager:createGUIWindow(GUIType.Layout, "BoxInner_" .. id)
          boxInner:SetArea({0, 1}, {0, 1}, {1, -2}, {1, -2})
          boxInner:SetBackgroundColor(colors.dark_bg)
          boxBorder:AddChildWindow(boxInner)
          local headerBg = GUIManager:createGUIWindow(GUIType.StaticText, "HeaderBg_" .. id)
          headerBg:SetArea({0, 0}, {0, 0}, {1, 0}, {0, 30})
          headerBg:SetBackgroundColor({accentColor[1], accentColor[2], accentColor[3], 0.18})
          boxInner:AddChildWindow(headerBg)
          addTxt(headerBg, "Title_" .. id, "  " .. titleText, {0, 0}, {0, 0}, {1, 0}, {1, 0}, accentColor, 1.05)
          local decoLine = GUIManager:createGUIWindow(GUIType.StaticText, "Deco_" .. id)
          decoLine:SetArea({0, 0}, {0, 30}, {1, 0}, {0, 2})
          decoLine:SetBackgroundColor(accentColor)
          boxInner:AddChildWindow(decoLine)
          return boxInner
      end

      local sysLog = addTxt(contentLayout, "SysLog", "[ SYSTEM.ONLINE // AWAITING COMMANDS ]", {0, 0}, {0, 5}, {1, 0},{0, 20}, colors.accent, 0.75, HorizontalAlignment.Center)
      local mainTitle = addTxt(contentLayout, "MainTitle", "N C L I E N T   I N F O", {0, 0}, {0, 25}, {1, 0}, {0, 45},colors.red, 2.2, HorizontalAlignment.Center)
      table.insert(pulseTexts, mainTitle)

      local divLine = GUIManager:createGUIWindow(GUIType.StaticText, "DivLine")
      divLine:SetArea({0, 60}, {0, 85}, {1, -120}, {0, 2})
      divLine:SetBackgroundColor(colors.red)
      contentLayout:AddChildWindow(divLine)
      table.insert(borderLines, divLine)

      local logoInfo = GUIManager:createGUIWindow(GUIType.StaticImage, "Logo_Info")
      logoInfo:SetArea({1, -114}, {0, 5}, {0, 100}, {0, 85})
      logoInfo:SetImage("/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/hangvnchatluongcao.png")
      contentLayout:AddChildWindow(logoInfo)

      local me = PlayerManager:getClientPlayer()
      local myID = tostring(CGame.Instance():getPlatformUserId())
      local myName = me and me:getName() or "Unknown"
      local mySex = 1
      if me then
          if me.Player and me.Player.getSex then mySex = me.Player:getSex()
          elseif me.getSex then mySex = me:getSex() end
      end

      local leftBox = createModernBox("LeftZone", "[ USER PROFILE & SYSTEM ]", {0.04, 0}, {0, 105}, {0.55, 0}, {1,-125}, colors.red)

      local actorBg = GUIManager:createGUIWindow(GUIType.Layout, "ActorBg")
      actorBg:SetArea({0, 10}, {0, 50}, {0.30, 0}, {1, -65})
      actorBg:SetBackgroundColor(colors.darker_bg)
      leftBox:AddChildWindow(actorBg)

      local aw = GUIManager:createGUIWindow(GUIType.ActorWindow, "Actor_Preview")
      aw:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
      actorBg:AddChildWindow(aw)
      local actorFile = (mySex == 2) and "girl.actor" or "boy.actor"
      aw:SetActor1(actorFile, "idle", 105)
      aw:SetActorByUserId(myID, 0)

      addTxt(leftBox, "P_ID", "ID:", {0.35, 0}, {0.18, 0}, {0.2, 0}, {0, 25}, colors.grey, 0.9)
      addTxt(leftBox, "P_ID_Val", myID, {0.45, 0}, {0.18, 0}, {0.5, 0}, {0, 25}, colors.white, 0.95)
      addTxt(leftBox, "P_Name", "NAME:", {0.35, 0}, {0.28, 0}, {0.2, 0}, {0, 25}, colors.grey, 0.9)
      addTxt(leftBox, "P_Name_Val", myName, {0.45, 0}, {0.28, 0}, {0.5, 0}, {0, 25}, colors.orange, 0.95)
      addTxt(leftBox, "P_Sex", "GENDER:", {0.35, 0}, {0.38, 0}, {0.2, 0}, {0, 25}, colors.grey, 0.9)
      addTxt(leftBox, "P_Sex_Val", (mySex == 1 and "Boy" or "Girl"), {0.45, 0}, {0.38, 0}, {0.5, 0}, {0, 25},colors.white, 0.95)

      addTxt(leftBox, "T_Dev", "// DEV SPECS", {0.35, 0}, {0.50, 0}, {0.55, 0}, {0, 30}, colors.red_soft, 1.1)
      addTxt(leftBox, "D_Ver", "> Version:  1.0.0 BETA", {0.35, 0}, {0.60, 0}, {0.55, 0}, {0, 25}, colors.white, 0.9)
      addTxt(leftBox, "D_Dev", "> System:   Ice", {0.35, 0}, {0.70, 0}, {0.55, 0}, {0, 25}, colors.white, 0.9)
      addTxt(leftBox, "D_Help", "> Support:  What?", {0.35, 0}, {0.80, 0}, {0.55, 0}, {0, 25}, colors.white, 0.9)

      local function createDiscordBtn(id, text, ax, ay, url)
          local btnBorder = GUIManager:createGUIWindow(GUIType.Layout, "BtnB_" .. id)
          btnBorder:SetArea(ax, ay, {0.25, 0}, {0, 35})
          btnBorder:SetBackgroundColor(colors.red)
          leftBox:AddChildWindow(btnBorder)
          local btn = GUIManager:createGUIWindow(GUIType.Button, id)
          btn:SetArea({0, 1}, {0, 1}, {1, -2}, {1, -2})
          btn:SetText(text)
          btn:SetTextScale(0.85)
          btn:SetTextColor(colors.red_soft)
          btn:SetBackgroundColor(colors.btn_bg)
          btn:registerEvent(GUIEvent.ButtonClick, function() openURL(url) end)
          btnBorder:AddChildWindow(btn)
      end
      createDiscordBtn("Btn_D1", "NCLient", {0.38, 0}, {0.91, 0}, "https://discord.gg/PfJtxVaFSZ")
      createDiscordBtn("Btn_D2", "Hyper", {0.68, 0}, {0.91, 0}, "https://discord.gg/pF5ntJWfZu")

      local rightBox = createModernBox("RightZone", "[ TELEMETRY & NETWORK ]", {0.61, 0}, {0, 105}, {0.35, 0}, {1,-125}, colors.red_deep)

      addTxt(rightBox, "T_Net", "// CONNECTED NODES", {0, 15}, {0.10, 0}, {1, -30}, {0, 30}, colors.red_soft, 1.05)
      local players = PlayerManager:getPlayers()
      local count = 0
      local yOffset = 0.22
      for _, p in pairs(players) do
          if count < 4 then
              addTxt(rightBox, "P_Node_" .. count, ">> " .. p:getName(), {0, 15}, {yOffset, 0}, {1, -30}, {0, 25},colors.grey, 0.9)
              yOffset = yOffset + 0.08
              count = count + 1
          end
      end

      addTxt(rightBox, "T_Stat", "// LIVE STATS", {0, 15}, {0.6, 0}, {1, -30}, {0, 30}, colors.red, 1.05)
      local fpsTxt  = addTxt(rightBox, "St_FPS", "[ FPS ]   Loading...", {0, 15}, {0.72, 0}, {1, -30}, {0, 25},colors.white, 0.95)
      local pingTxt = addTxt(rightBox, "St_Ping", "[ PING ]  Loading...", {0, 15}, {0.82, 0}, {1, -30}, {0, 25},colors.white, 0.95)
      local itemTxt = addTxt(rightBox, "St_Item", "[ ITEM ]  Loading...", {0, 15}, {0.92, 0}, {1, -30}, {0, 25},colors.white, 0.95)

      local pulse = 0
      local rot = 0
      self.infoTimer = LuaTimer:scheduleTimer(function()
          local status, err = pcall(function()
              if not parent or not parent:IsVisible() then
                  error("StopTimer")
              end

              local fps = Root.Instance():getFPS() or 0
              local ping = ClientNetwork.Instance():getRaknetPing() or 0
              local heldItemId = -1
              local playerWrapper = PlayerManager:getClientPlayer()
              if playerWrapper and playerWrapper.Player then
                  heldItemId = playerWrapper.Player:getHeldItemId() or -1
              end

              local fpsColor  = fps >= 50 and colors.neon_green or (fps >= 30 and colors.yellow or colors.neon_red)
              local pingColor = ping <= 80 and colors.neon_green or (ping <= 180 and colors.yellow or colors.neon_red)

              if fpsTxt then
                  fpsTxt:SetText(string.format("[ FPS ]   %d", fps))
                  fpsTxt:SetTextColor(fpsColor)
              end
              if pingTxt then
                  pingTxt:SetText(string.format("[ PING ]  %d ms", ping))
                  pingTxt:SetTextColor(pingColor)
              end
              if itemTxt then itemTxt:SetText(string.format("[ ITEM ]  %d", heldItemId)) end

              pulse = pulse + 0.08
              local t = 0.5 + (math.sin(pulse) * 0.5)      
              local breath = {1, 0.1 + t * 0.25, 0.1 + t * 0.25, 0.4 + t * 0.6}

              for _, line in ipairs(borderLines) do
                  if line then line:SetBackgroundColor(breath) end
              end
              for _, txt in ipairs(pulseTexts) do
                  if txt then txt:SetTextColor({1, 0.15 + t * 0.3, 0.15 + t * 0.3, 1}) end
              end

              if aw and aw.SetRotateY then
                  rot = (rot + 1.5) % 360
                  aw:SetRotateY(rot)
              end

              if sysLog then
                  local alpha = 0.4 + (math.sin(pulse) * 0.4)
                  sysLog:SetTextColor({colors.accent[1], colors.accent[2], colors.accent[3], alpha})
              end
          end)

          if not status then
              if self.infoTimer then
                  LuaTimer:cancel(self.infoTimer)
                  self.infoTimer = nil
              end
          end
      end, 20, -1)
  end



local selectedColorCode = "&$[ff0000ff-ff7f00ff-ffff00ff-00ff00ff-00ffffff-0000ffff-7f00ffff]$"
local currentVipName = customVipName or "Ice"
local vipBorderTimer = nil 

local vipNameplates = {
    "vip_nameplate_1.json", "vip_nameplate_2.json", "vip_nameplate_3.json", "vip_nameplate_4.json",
    "vip_nameplate_5.json", "vip_nameplate_6.json", "vip_nameplate_7.json", "vip_nameplate_8.json",
    "vip_nameplate_9.json", "vip_nameplate_10.json", "vip_nameplate_10_plus.json"
}

local function Logic_ApplyVip(index)
    local client = PlayerManager:getClientPlayer()
    if not client or not client.Player then
        UIHelper.showToast("No player found!")
        return
    end
    
    local player = client.Player
    local colorPrefix = selectedColorCode or ""
    local fixedNickname

    if string.find(colorPrefix, "&%$.*") then
        fixedNickname = colorPrefix .. currentVipName .. "$&"
    else
        fixedNickname = colorPrefix .. currentVipName
    end
    
    local formattedNickname = string.format("%s[S=%s]", fixedNickname, vipNameplates[index])
    player:setShowName(formattedNickname)
    UIHelper.showToast("VIP " .. index .. " Activated")
end

local function Logic_SetCustomName()
    GMHelper:openInput({"Enter New VIP Name"}, function(inputName)
        if inputName and inputName ~= "" then
            currentVipName = inputName
            customVipName = inputName 
            UIHelper.showToast("Name Set: " .. currentVipName)
        end
    end)
end

    function GMHelper:ShowPlayerVIPUI(parent)
      if self.vipBorderTimer then
          LuaTimer:cancel(self.vipBorderTimer)
          self.vipBorderTimer = nil
      end
      if parent.CleanupChildren then parent:CleanupChildren() end
      local function safeCreate(t, id)
          local old = GUIManager:getWindowByName(id)
          if old then GUIManager:destroyGUIWindow(old) end
          return GUIManager:createGUIWindow(t, id)
      end
      parent:SetBackgroundColor({0.05, 0.01, 0.01, 0.98})

      local colors = {
          red = {0.937, 0.267, 0.267, 1}, red_soft = {0.973, 0.443, 0.443, 1}, orange = {1, 0.4, 0.1, 1},
          white = {1, 1, 1, 1}, grey = {0.6, 0.62, 0.72, 1}, dark_bg = {0.06, 0.067, 0.1, 1},
          accent = {0.937, 0.267, 0.267, 0.85},
      }

      local borderLines = {}
      local pulseTexts  = {}

      local mainFrame = safeCreate(GUIType.Layout, "MainFrame_VIP")
      mainFrame:SetArea({0, 15}, {0, 15}, {1, -30}, {1, -30})
      parent:AddChildWindow(mainFrame)

      local function createFrameLine(x, y, w, h, color, track)
          local l = safeCreate(GUIType.StaticText, "FrameLine_" .. math.random(999999))
          l:SetArea(x, y, w, h)
          l:SetBackgroundColor(color)
          mainFrame:AddChildWindow(l)
          if track ~= false then table.insert(borderLines, l) end
          return l
      end

      createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
      createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
      createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
      createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
      local cSize, cThick = 28, 4
      createFrameLine({0, -2}, {0, -2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({0, -2}, {0, -2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({1, -cSize + 2}, {0, -2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({1, -cThick + 2}, {0, -2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({0, -2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({0, -2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({1, -cSize + 2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({1, -cThick + 2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.red)

      local scanline = createFrameLine({0, 2}, {0, 0}, {1, -4}, {0, 2}, {1, 0.2, 0.2, 0.18}, false)

      local title = safeCreate(GUIType.StaticText, "VIP_P_Title")
      title:SetArea({0, 0}, {0, 20}, {1, 0}, {0, 40})
      title:SetText("N C L I E N T   V I P   M O D U L E")
      title:SetTextColor(colors.red)
      title:SetTextScale(1.8)
      title:SetTextHorzAlign(HorizontalAlignment.Center)
      mainFrame:AddChildWindow(title)
      table.insert(pulseTexts, title)

      local divLine = createFrameLine({0, 50}, {0, 70}, {1, -100}, {0, 2}, colors.red)

      local credit = safeCreate(GUIType.StaticText, "VIP_P_Credit")
      credit:SetArea({1, -210}, {0, 8}, {0, 200}, {0, 20})
      credit:SetText("SYS_ADMIN: Ice")
      credit:SetTextColor(colors.grey)
      credit:SetTextScale(0.8)
      credit:SetTextHorzAlign(HorizontalAlignment.Right)
      mainFrame:AddChildWindow(credit)

      local nameTitle = safeCreate(GUIType.StaticText, "Name_Title")
      nameTitle:SetArea({0, 30}, {0, 85}, {0, 300}, {0, 25})
      nameTitle:SetText("> IDENTITY ALIAS [ CUSTOM NAME ]")
      nameTitle:SetTextColor(colors.red_soft)
      nameTitle:SetTextScale(0.9)
      mainFrame:AddChildWindow(nameTitle)
      table.insert(pulseTexts, nameTitle)

      local inputBorder = safeCreate(GUIType.Layout, "IB_Border_RGB")
      inputBorder:SetArea({0, 30}, {0, 115}, {1, -60}, {0, 45})
      inputBorder:SetBackgroundColor(colors.red)
      mainFrame:AddChildWindow(inputBorder)
      table.insert(borderLines, inputBorder)

      local inputInner = safeCreate(GUIType.Layout, "IB_Inner")
      inputInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
      inputInner:SetBackgroundColor(colors.dark_bg)
      inputBorder:AddChildWindow(inputInner)

      local lastKnownName = tostring(currentVipName or "CLICK TO SET IDENTITY")
      local inputBtn = safeCreate(GUIType.Button, "Btn_InputName")
      inputBtn:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
      inputBtn:SetBackgroundColor({0, 0, 0, 0})
      inputBtn:SetText(lastKnownName)
      inputBtn:SetTextColor(colors.white)
      inputInner:AddChildWindow(inputBtn)
      inputBtn:registerEvent(GUIEvent.ButtonClick, function() Logic_SetCustomName() end)

      local vipTitle = safeCreate(GUIType.StaticText, "VIP_Title")
      vipTitle:SetArea({0, 30}, {0, 180}, {0.4, 0}, {0, 25})
      vipTitle:SetText("> VIP OVERRIDE")
      vipTitle:SetTextColor(colors.white)
      mainFrame:AddChildWindow(vipTitle)

      local colorTitle = safeCreate(GUIType.StaticText, "Color_Title")
      colorTitle:SetArea({0.52, 0}, {0, 180}, {0.4, 0}, {0, 25})
      colorTitle:SetText("> CHROMA INJECTION")
      colorTitle:SetTextColor(colors.white)
      mainFrame:AddChildWindow(colorTitle)

      local scrollVip = safeCreate(GUIType.List, "Scroll_Vip")
      scrollVip:SetArea({0, 30}, {0, 215}, {0.45, -15}, {1, -235})
      scrollVip:SetBackgroundColor({0, 0, 0, 0})
      mainFrame:AddChildWindow(scrollVip)

      for i = 1, 11 do
          local container = safeCreate(GUIType.Layout, "VIP_Container_" .. i)
          container:SetHeight({0, 55}); container:SetWidth({1, 0})
          local btnBorder = safeCreate(GUIType.Layout, "VIPBtn_Border_" .. i)
          btnBorder:SetArea({0, 0}, {0, 5}, {1, 0}, {1, -10})
          btnBorder:SetBackgroundColor(colors.red)
          container:AddChildWindow(btnBorder)
          table.insert(borderLines, btnBorder)
          local btnInner = safeCreate(GUIType.Layout, "VIPBtn_Inner_" .. i)
          btnInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          btnInner:SetBackgroundColor(colors.dark_bg)
          btnBorder:AddChildWindow(btnInner)
          local leftLine = safeCreate(GUIType.StaticText, "VIP_Line_" .. i)
          leftLine:SetArea({0, 0}, {0, 0}, {0, 4}, {1, 0})
          leftLine:SetBackgroundColor(colors.red)
          btnInner:AddChildWindow(leftLine)
          table.insert(borderLines, leftLine)
          local rightDot = safeCreate(GUIType.StaticText, "VIP_Dot_" .. i)
          rightDot:SetArea({1, -15}, {0.5, -5}, {0, 10}, {0, 10})
          rightDot:SetBackgroundColor(colors.red)
          btnInner:AddChildWindow(rightDot)
          table.insert(borderLines, rightDot)
          local btn = safeCreate(GUIType.Button, "Btn_Vip_" .. i)
          btn:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
          btn:SetText("   [ ACCESS VIP " .. i .. " ]")
          btn:SetBackgroundColor({0, 0, 0, 0})
          btn:SetTextColor(colors.white)
          btn:registerEvent(GUIEvent.ButtonClick, function()
              Logic_ApplyVip(i)
              UIHelper.showToast("VIP Tier " .. i .. " Injected")
          end)
          btnInner:AddChildWindow(btn)
          scrollVip:AddItem(container)
      end

      local scrollColor = safeCreate(GUIType.List, "Scroll_Color")
      scrollColor:SetArea({0.52, 0}, {0, 215}, {0.48, -30}, {1, -235})
      scrollColor:SetBackgroundColor({0, 0, 0, 0})
      mainFrame:AddChildWindow(scrollColor)

      local colorDataList = {
          {name="Rainbow", code="&$[ff0000ff-ff7f00ff-ffff00ff-00ff00ff-00ffffff-0000ffff-7f00ffff]$", color={1,1,1,1}, isRGB=true},
          {name="Red", code="&$[ff0000ff]$", color={1,0.2,0.2,1}},
          {name="Green", code="&$[00ff00ff]$", color={0.2,1,0.2,1}},
          {name="Blue", code="&$[0000ffff]$", color={0.2,0.4,1,1}},
          {name="Yellow", code="&$[ffff00ff]$", color={1,0.9,0,1}},
          {name="Cyan", code="&$[00ffffff]$", color={0,0.85,1,1}},
          {name="Pink", code="&$[ff00ffff]$", color={1,0.3,0.8,1}},
          {name="Black", code="&$[000000ff]$", color={0.3,0.3,0.3,1}},
          {name="White", code="&$[ffffffff]$", color={0.9,0.9,0.9,1}},
      }
      for _, c in ipairs(colorDataList) do
          local container = safeCreate(GUIType.Layout, "Color_Container_" .. c.name)
          container:SetHeight({0, 55}); container:SetWidth({1, 0})
          local btnBorder = safeCreate(GUIType.Layout, "ColBtn_Border_" .. c.name)
          btnBorder:SetArea({0, 0}, {0, 5}, {1, 0}, {1, -10})
          btnBorder:SetBackgroundColor({c.color[1], c.color[2], c.color[3], 0.3})
          container:AddChildWindow(btnBorder)
          if c.isRGB then table.insert(borderLines, btnBorder) end
          local btnInner = safeCreate(GUIType.Layout, "ColBtn_Inner_" .. c.name)
          btnInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          btnInner:SetBackgroundColor(colors.dark_bg)
          btnBorder:AddChildWindow(btnInner)
          local leftLine = safeCreate(GUIType.StaticText, "ColLine_" .. c.name)
          leftLine:SetArea({0, 0}, {0, 0}, {0, 4}, {1, 0})
          leftLine:SetBackgroundColor(c.color)
          btnInner:AddChildWindow(leftLine)
          if c.isRGB then table.insert(borderLines, leftLine) end
          local rightDot = safeCreate(GUIType.StaticText, "ColDot_" .. c.name)
          rightDot:SetArea({1, -15}, {0.5, -5}, {0, 10}, {0, 10})
          rightDot:SetBackgroundColor(c.color)
          btnInner:AddChildWindow(rightDot)
          if c.isRGB then table.insert(borderLines, rightDot) end
          local btn = safeCreate(GUIType.Button, "Btn_Color_" .. c.name)
          btn:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
          btn:SetText("   " .. c.name)
          btn:SetBackgroundColor({0, 0, 0, 0})
          btn:SetTextColor(c.color)
          if c.isRGB then table.insert(pulseTexts, btn) end
          btn:registerEvent(GUIEvent.ButtonClick, function()
              selectedColorCode = c.code
              UIHelper.showToast("Chroma Active: " .. c.name)
          end)
          btnInner:AddChildWindow(btn)
          scrollColor:AddItem(container)
      end

      local pulse, scanPos = 0, 0
      self.vipBorderTimer = LuaTimer:scheduleTimer(function()
          local status = pcall(function()
              if not parent or not parent:IsVisible() then error("StopTimer") end

              local currentNameStr = tostring(currentVipName or "CLICK TO SET IDENTITY")
              if lastKnownName ~= currentNameStr then
                  lastKnownName = currentNameStr
                  if inputBtn then inputBtn:SetText(lastKnownName) end
              end

              pulse = pulse + 0.1
              for i, line in ipairs(borderLines) do
                  if line then
                      local t = 0.5 + 0.5 * math.sin(pulse + i * 0.35)
                      local nm = line:GetName() or ""
                      if string.find(nm, "Border") or string.find(nm, "FrameLine") then
                          line:SetBackgroundColor({1, 0.05 + t * 0.25, 0.05 + t * 0.1, 0.2 + t * 0.3})
                      else
                          line:SetBackgroundColor({1, 0.05 + t * 0.3, 0.05 + t * 0.1, 0.4 + t * 0.6})
                      end
                  end
              end

              for _, txt in ipairs(pulseTexts) do
                  if txt then
                      local flick = (math.random() > 0.93) and 1 or (0.55 + 0.45 * math.sin(pulse * 2))
                      txt:SetTextColor({1, 0.1 + flick * 0.15, 0.1, flick})
                  end
              end
              if title then
                  title:SetXPosition({0, (math.random() > 0.88) and math.random(-5, 5) or 0})
              end

              scanPos = (scanPos + 0.012) % 1
              if scanline then scanline:SetYPosition({scanPos, 0}) end
          end)
          if not status then
              if self.vipBorderTimer then LuaTimer:cancel(self.vipBorderTimer); self.vipBorderTimer = nil end
          end
      end, 16, -1)
  end



 function GMHelper:ShowClothesUI(parent)
      if self.clothesTimer then
          LuaTimer:cancel(self.clothesTimer)
          self.clothesTimer = nil
      end
      if parent.CleanupChildren then parent:CleanupChildren() end
      parent:SetBackgroundColor({0.05, 0.01, 0.01, 0.98})

      local colors = {
          red = {0.937, 0.267, 0.267, 1}, red_soft = {0.973, 0.443, 0.443, 1}, orange = {1, 0.4, 0.1, 1},
          white = {1, 1, 1, 1}, grey = {0.6, 0.62, 0.72, 1}, dark_bg = {0.06, 0.067, 0.1, 1},
          accent = {0.937, 0.267, 0.267, 0.85}, neon_green = {0.1, 1, 0.1, 1}, neon_red = {0.973, 0.443, 0.443, 1},
      }

      local borderLines = {} 
      local pulseTexts  = {}  

      local mainFrame = GUIManager:createGUIWindow(GUIType.Layout, "MainFrame_Clothes")
      mainFrame:SetArea({0, 15}, {0, 15}, {1, -30}, {1, -30})
      parent:AddChildWindow(mainFrame)

      local function createFrameLine(x, y, w, h, color, track)
          local l = GUIManager:createGUIWindow(GUIType.StaticText, "FrameLine_" .. math.random(999999))
          l:SetArea(x, y, w, h)
          l:SetBackgroundColor(color)
          mainFrame:AddChildWindow(l)
          if track ~= false then table.insert(borderLines, l) end
          return l
      end

      createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
      createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
      createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
      createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
      local cSize, cThick = 28, 4
      createFrameLine({0, -2}, {0, -2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({0, -2}, {0, -2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({1, -cSize + 2}, {0, -2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({1, -cThick + 2}, {0, -2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({0, -2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({0, -2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.red)
      createFrameLine({1, -cSize + 2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, colors.red)
      createFrameLine({1, -cThick + 2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, colors.red)

      local scanline = createFrameLine({0, 2}, {0, 0}, {1, -4}, {0, 2}, {1, 0.2, 0.2, 0.18}, false)

      local title = GUIManager:createGUIWindow(GUIType.StaticText, "Title_Clothes")
      title:SetArea({0, 0}, {0, 20}, {1, 0}, {0, 40})
      title:SetText("N C L I E N T   W A R D R O B E")
      title:SetTextColor(colors.red)
      title:SetTextScale(1.8)
      title:SetTextHorzAlign(HorizontalAlignment.Center)
      mainFrame:AddChildWindow(title)
      table.insert(pulseTexts, title)

      local divLine = createFrameLine({0, 50}, {0, 70}, {1, -100}, {0, 2}, colors.red)

      local myID = tostring(CGame.Instance():getPlatformUserId())
      local me = PlayerManager:getClientPlayer()
      local mySex = 1
      if me then
          if me.Player and me.Player.getSex then mySex = me.Player:getSex()
          elseif me.getSex then mySex = me:getSex() end
      end

      local previewBorder = GUIManager:createGUIWindow(GUIType.Layout, "PreviewBorder")
      previewBorder:SetArea({0.6, 0}, {0, 85}, {0.35, 0}, {1, -110})
      previewBorder:SetBackgroundColor({1, 0.1, 0.1, 0.3})
      mainFrame:AddChildWindow(previewBorder)
      table.insert(borderLines, previewBorder)

      local previewInner = GUIManager:createGUIWindow(GUIType.Layout, "PreviewInner")
      previewInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
      previewInner:SetBackgroundColor(colors.dark_bg)
      previewBorder:AddChildWindow(previewInner)

      local previewTitle = GUIManager:createGUIWindow(GUIType.StaticText, "PreviewTitle")
      previewTitle:SetArea({0, 0}, {0, 15}, {1, 0}, {0, 20})
      previewTitle:SetText("[ LIVE HOLOGRAM ]")
      previewTitle:SetTextColor(colors.red_soft)
      previewTitle:SetTextHorzAlign(HorizontalAlignment.Center)
      previewInner:AddChildWindow(previewTitle)
      table.insert(pulseTexts, previewTitle)

      local actorBg = GUIManager:createGUIWindow(GUIType.StaticText, "ActorBg")
      actorBg:SetArea({0, 15}, {0, 50}, {1, -30}, {1, -65})
      actorBg:SetBackgroundColor({0, 0, 0, 0.5})
      previewInner:AddChildWindow(actorBg)

      local actorView = GUIManager:createGUIWindow(GUIType.ActorWindow, "Clothes_Actor_View")
      actorView:SetWidth({0, 160})
      actorView:SetHeight({0, 300})
      actorView:SetHorizontalAlignment(HorizontalAlignment.Center)
      actorView:SetVerticalAlignment(VerticalAlignment.Center)
      actorBg:AddChildWindow(actorView)
      local baseActor = (mySex == 2) and "girl.actor" or "boy.actor"
      if actorView.SetActor1 then actorView:SetActor1(baseActor, "idle", 150) end
      if actorView.SetActorScale then actorView:SetActorScale(0.85) end
      if actorView.SetActorByUserId then actorView:SetActorByUserId(myID, 0) end

      local scrollPane = GUIManager:createGUIWindow(GUIType.ScrollablePane, "Clothes_Scroll")
      scrollPane:SetArea({0.05, 0}, {0, 85}, {0.5, 0}, {1, -110})
      scrollPane:InitializeContainer()
      scrollPane:SetProperty("AutoScrollBar", "true")
      mainFrame:AddChildWindow(scrollPane)

      local pWidth = 0
      pcall(function() pWidth = parent:GetPixelSize().x end)
      if not pWidth or pWidth < 100 then pWidth = 1000 end
      local contentW = (pWidth - 30) * 0.5

      local contentLayout = GUIManager:createGUIWindow(GUIType.Layout, "Clothes_Content")
      contentLayout:SetWidth({0, contentW})

      local clothesList = {
          { name = "Crown", prop = "m_crownId" }, { name = "Hair", prop = "m_hairID" },
          { name = "Face", prop = "m_faceID" }, { name = "Glasses", prop = "m_glassesId" },
          { name = "Scarf", prop = "m_scarfId" }, { name = "Wings", prop = "m_wingId" },
          { name = "Tops", prop = "m_topsID" }, { name = "Pants", prop = "m_pantsID" },
          { name = "Shoes", prop = "m_shoesID" }, { name = "Hat", prop = "m_hatId" },
          { name = "Tail", prop = "m_tailId" }
      }
      contentLayout:SetHeight({0, #clothesList * 65 + 20})
      scrollPane:AddItem(contentLayout)

      local function createRow(index, data)
          local yPos = (index - 1) * 65
          local container = GUIManager:createGUIWindow(GUIType.Layout, "ClothRow_" .. index)
          container:SetArea({0, 5}, {0, yPos}, {1, -10}, {0, 55})
          container:SetBackgroundColor({0.1, 0.03, 0.03, 0.5})
          contentLayout:AddChildWindow(container)

          local accLine = GUIManager:createGUIWindow(GUIType.StaticText, "AccLine_" .. index)
          accLine:SetArea({0, 0}, {0, 0}, {0, 4}, {1, 0})
          accLine:SetBackgroundColor(colors.red)
          container:AddChildWindow(accLine)
          table.insert(borderLines, accLine)

          local label = GUIManager:createGUIWindow(GUIType.StaticText, "Lbl_" .. index)
          label:SetArea({0, 15}, {0, 0}, {0.35, 0}, {1, 0})
          label:SetText("[ " .. data.name .. " ]")
          label:SetTextColor(colors.orange)
          label:SetTextScale(0.9)
          label:SetTextHorzAlign(HorizontalAlignment.Left)
          label:SetTextVertAlign(VerticalAlignment.Center)
          container:AddChildWindow(label)

          local editBorder = GUIManager:createGUIWindow(GUIType.Layout, "EdBorder_" .. index)
          editBorder:SetArea({0.4, 0}, {0, 10}, {0.25, 0}, {1, -20})
          editBorder:SetBackgroundColor(colors.red)
          container:AddChildWindow(editBorder)
          table.insert(borderLines, editBorder)

          local edit = GUIManager:createGUIWindow(GUIType.Edit, "Edit_" .. index)
          edit:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          edit:SetBackgroundColor({0, 0, 0, 0.9})
          edit:SetTextColor(colors.white)
          edit:SetTextVertAlign(VerticalAlignment.Center)
          edit:SetTextHorzAlign(HorizontalAlignment.Center)
          local playerInit = PlayerManager:getClientPlayer().Player
          local currentVal = playerInit and playerInit[data.prop] or 0
          edit:SetText(tostring(currentVal))
          editBorder:AddChildWindow(edit)

          local function applyToPlayer(val)
              local num = tonumber(val) or 0
              if num < 0 then num = 0 end
              local p = PlayerManager:getClientPlayer().Player
              if p then p[data.prop] = num; p.m_outLooksChanged = true end
          end
          edit:registerEvent(GUIEvent.WindowLostFocus, function() applyToPlayer(edit:GetText()) end)

          local btnMinusBorder = GUIManager:createGUIWindow(GUIType.Layout, "MinusBorder_" .. index)
          btnMinusBorder:SetArea({0.68, 0}, {0, 10}, {0.12, 0}, {1, -20})
          btnMinusBorder:SetBackgroundColor(colors.neon_red)
          container:AddChildWindow(btnMinusBorder)
          local btnMinus = GUIManager:createGUIWindow(GUIType.Button, "BtnMinus_" .. index)
          btnMinus:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          btnMinus:SetText("-")
          btnMinus:SetTextColor(colors.white)
          btnMinus:SetBackgroundColor({0.15, 0.05, 0.05, 1})
          btnMinusBorder:AddChildWindow(btnMinus)
          btnMinus:registerEvent(GUIEvent.ButtonClick, function()
              local cur = tonumber(edit:GetText()) or 0
              local newVal = cur - 1; if newVal < 0 then newVal = 0 end
              edit:SetText(tostring(newVal)); applyToPlayer(newVal)
          end)

          local btnPlusBorder = GUIManager:createGUIWindow(GUIType.Layout, "PlusBorder_" .. index)
          btnPlusBorder:SetArea({0.83, 0}, {0, 10}, {0.12, 0}, {1, -20})
          btnPlusBorder:SetBackgroundColor(colors.neon_green)
          container:AddChildWindow(btnPlusBorder)
          local btnPlus = GUIManager:createGUIWindow(GUIType.Button, "BtnPlus_" .. index)
          btnPlus:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
          btnPlus:SetText("+")
          btnPlus:SetTextColor(colors.white)
          btnPlus:SetBackgroundColor({0.05, 0.15, 0.05, 1})
          btnPlusBorder:AddChildWindow(btnPlus)
          btnPlus:registerEvent(GUIEvent.ButtonClick, function()
              local cur = tonumber(edit:GetText()) or 0
              local newVal = cur + 1
              edit:SetText(tostring(newVal)); applyToPlayer(newVal)
          end)
      end
      for i, item in ipairs(clothesList) do createRow(i, item) end

      local pulse, rot, scanPos = 0, 0, 0
      self.clothesTimer = LuaTimer:scheduleTimer(function()
          local status = pcall(function()
              if not parent or not parent:IsVisible() then error("StopTimer") end
              pulse = pulse + 0.1
              for i, line in ipairs(borderLines) do
                  if line then
                      local t = 0.5 + 0.5 * math.sin(pulse + i * 0.35)
                      line:SetBackgroundColor({1, 0.05 + t * 0.3, 0.05 + t * 0.1, 0.35 + t * 0.55})
                  end
              end
              for _, txt in ipairs(pulseTexts) do
                  if txt then
                      local flick = (math.random() > 0.93) and 1 or (0.55 + 0.45 * math.sin(pulse * 2))
                      txt:SetTextColor({1, 0.1 + flick * 0.15, 0.1, flick})
                  end
              end
              if title then
                  if math.random() > 0.88 then
                      title:SetXPosition({0, math.random(-5, 5)})  
                  else
                      title:SetXPosition({0, 0})
                  end
              end
              scanPos = (scanPos + 0.012) % 1
              if scanline then scanline:SetYPosition({scanPos, 0}) end
              if actorView and actorView.SetRotateY then
                  rot = (rot + 2) % 360
                  actorView:SetRotateY(rot)
              end
          end)
          if not status then
              if self.clothesTimer then LuaTimer:cancel(self.clothesTimer); self.clothesTimer = nil end
          end
      end, 16, -1)
  end



function GMHelper:RunFile()
    local filePath = "/storage/emulated/0/Android/data/com.sandboxol.blockymods.channel.official/RunCode.lua"
    local file = io.open(filePath, "r")
    if file then
        local content = file:read("*all")
        file:close()
        local loader = loadk or loadn
        if #content % 2 ~= 0 then
            content = content .. " " 
        end
        local success, err = pcall(function()
            local func = loader(content)
            if func then
                func()
                UIHelper.showToast("Code Executed Successfully")
            end
        end)
        if not success then
            UIHelper.showToast("Error: " .. tostring(err))
        end
    else
        UIHelper.showToast("File Not Found: " .. filePath)
    end
end


local SpeedHackValue = 500
local SpeedHackTimer = nil

function GMHelper:SetSpeedValue()
    GMHelper:openInput({ "Enter speed value (default 500)" }, function(v)
        local n = tonumber(v)
        if n and n > 0 then
            SpeedHackValue = n
            UIHelper.showToast("Speed value set to " .. SpeedHackValue)
            if _G["togSpeed"] then
                local me = PlayerManager:getClientPlayer()
                if me and me.Player then me.Player:setSpeedAdditionLevel(SpeedHackValue) end
            end
        else
            UIHelper.showToast("Invalid value!")
        end
    end)
end

function GMHelper:Speed(btn)
    self.speedEnabled = not self.speedEnabled
    _G["togSpeed"] = self.speedEnabled
    reButtonColorUI("Speed")

    local meWrapper = PlayerManager:getClientPlayer()
    if not meWrapper or not meWrapper.Player then
        self.speedEnabled = false
        _G["togSpeed"] = false
        return
    end
    local player = meWrapper.Player

    if self.speedEnabled then
        AddButton("Speed", "Speed")
        UIHelper.showToast("Speed Enabled (" .. SpeedHackValue .. ")")
        if SpeedHackTimer then LuaTimer:cancel(SpeedHackTimer); SpeedHackTimer = nil end
        SpeedHackTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if me and me.Player then
                me.Player:setSpeedAdditionLevel(SpeedHackValue)
            else
                if SpeedHackTimer then LuaTimer:cancel(SpeedHackTimer); SpeedHackTimer = nil end
                _G["togSpeed"] = false
                reButtonColorUI("Speed")
            end
        end, 1000, -1)
    else
        UIHelper.showToast("Speed Disabled")
        if SpeedHackTimer then LuaTimer:cancel(SpeedHackTimer); SpeedHackTimer = nil end
        pcall(function() player:setSpeedAdditionLevel(100) end)
    end
end

function GMHelper:FreeCamera(text)
    self.freeCamEnabled = not self.freeCamEnabled
    _G["togFreeCamera"] = self.freeCamEnabled

    local op = GUIManager:getWindowByName("Main-HideAndSeek-Operate")
    if op then
        op:SetVisible(self.freeCamEnabled)
    else
        UIHelper.showToast("FreeCam only works in Hide & Seek map")
    end

    if text and text.SetBackgroundColor then
        text:SetBackgroundColor(self.freeCamEnabled and Color.BLUE or Color.BLACK)
    end
end

function GMHelper:Tracer(btn)
    self.tracerEnabled = not self.tracerEnabled
    _G["togTracer"] = self.tracerEnabled
    reButtonColorUI("Tracer")
    UIHelper.showToast(self.tracerEnabled and "Tracer Enabled" or "Tracer Disabled")

    local me = PlayerManager:getClientPlayer()
    if not me or not me.Player then
        self.tracerEnabled = false
        _G["togTracer"] = false
        return
    end

    if self.tracerEnabled then
        if self.tracer then LuaTimer:cancel(self.tracer) end
        self.tracer = LuaTimer:scheduleTimer(function()
            local m = PlayerManager:getClientPlayer()
            if not m or not m.Player then
                if self.tracer then LuaTimer:cancel(self.tracer); self.tracer = nil end
                return
            end
            pcall(function() m.Player:deleteAllGuideArrow() end)
            for _, c_player in pairs(PlayerManager:getPlayers()) do
                if c_player ~= m and c_player.getPosition and c_player:getPosition() then
                    pcall(function() m.Player:addGuideArrow(c_player:getPosition()) end)
                end
            end
        end, 500, -1)
    else
        if self.tracer then LuaTimer:cancel(self.tracer); self.tracer = nil end
        pcall(function() me.Player:deleteAllGuideArrow() end)
    end
end

local SavedTPPos = nil

local function forceServerPos(player, x, y, z)
    local sp = player.serverPos
    if sp then
        pcall(function() sp.x = x * 32 end)
        pcall(function() sp.y = y * 32 end)
        pcall(function() sp.z = z * 32 end)
    end
    pcall(function() player.oldPos = VectorUtil.newVector3(x, y, z) end)
    pcall(function() player.prevPos = VectorUtil.newVector3(x, y, z) end)
end

Teleport = function(targetPos, opts)
    opts = opts or {}
    local me = PlayerManager:getClientPlayer()
    if not me or not me.Player then return end
    local player = me.Player

    pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)

    local startPos = player:getPosition()
    local dest = VectorUtil.newVector3(targetPos.x, targetPos.y + 1.3, targetPos.z)

    local savedYaw = player.rotationYaw
    local savedPitch = player.rotationPitch

    local function spoof(p)
        if not p then return end
        pcall(function() p.m_isPulled = true end)
        pcall(function() p.m_remainingFlyTicksByPulled = 999999 end)
        pcall(function() p.onGround = false end)
        pcall(function() p.onGroundPrev = false end)
        if type(ground) == "function" then pcall(ground) end
        if type(bypass) == "function" then pcall(bypass) end
    end

    player:setAllowFlying(true)
    player:setFlying(true)
    player.noClip = true
    spoof(player)

    if not startPos then
        player:setPosition(dest)
        forceServerPos(player, dest.x, dest.y, dest.z)
        if opts.ground ~= false and type(ground) == "function" then pcall(ground) end
        return
    end

    local STEP     = opts.step or 4.0    
    local INTERVAL = opts.interval or 40    
    local dx, dy, dz = dest.x - startPos.x, dest.y - startPos.y, dest.z - startPos.z
    local dist  = math.sqrt(dx * dx + dy * dy + dz * dz)
    local steps = math.max(1, math.ceil(dist / STEP))

    local i = 0
    local glideTimer
    glideTimer = LuaTimer:scheduleTimer(function()
        local p = PlayerManager:getClientPlayer()
        if not p or not p.Player then
            if glideTimer then LuaTimer:cancel(glideTimer) end
            return
        end
        i = i + 1
        local t = i / steps
        if t > 1 then t = 1 end
        local cx = startPos.x + dx * t
        local cy = startPos.y + dy * t
        local cz = startPos.z + dz * t

        spoof(p.Player)
        p.Player.noClip = true
        p.Player:setPosition(VectorUtil.newVector3(cx, cy, cz))
        forceServerPos(p.Player, cx, cy, cz)
        p.Player.rotationYaw = savedYaw
        p.Player.rotationPitch = savedPitch

        if i >= steps then
            LuaTimer:cancel(glideTimer)
            local holds = 0
            local holdTimer
            holdTimer = LuaTimer:scheduleTimer(function()
                local q = PlayerManager:getClientPlayer()
                if not q or not q.Player then
                    if holdTimer then LuaTimer:cancel(holdTimer) end
                    return
                end
                spoof(q.Player)
                local np = q.Player:getPosition()
                if np and MathUtil:distanceSquare3d(np, dest) > 4 then
                    q.Player.noClip = true
                    q.Player:setPosition(dest)
                end
                forceServerPos(q.Player, dest.x, dest.y, dest.z)
                holds = holds + 1
                if holds >= 20 then
                    LuaTimer:cancel(holdTimer)
                    local fp = q.Player
                    fp.noClip = false
                    fp:setAllowFlying(true)
                    fp:setFlying(false)
                    if opts.ground ~= false and type(ground) == "function" then
                        pcall(ground)
                    end
                end
            end, 50, -1)
        end
    end, INTERVAL, -1)
end

function GMHelper:TeleportTo()
    GMHelper:openInput({ "X", "Y", "Z" }, function(x, y, z)
        local nx, ny, nz = tonumber(x), tonumber(y), tonumber(z)
        if not (nx and ny and nz) then
            UIHelper.showToast("Invalid coords!")
            return
        end
        Teleport(VectorUtil.newVector3(nx, ny, nz))
        UIHelper.showToast(string.format("TP -> %d, %d, %d", nx, ny, nz))
    end)
end

function GMHelper:TPNearestPlayer()
    local me = PlayerManager:getClientPlayer()
    if not me or not me.Player then UIHelper.showToast("No player") return end
    local myPos = me.Player:getPosition()
    if not myPos then return end

    local players = PlayerManager:getPlayers()
    if not players then return end

    local nearest, nearestDist = nil, math.huge
    for _, target in pairs(players) do
        if target and target ~= me and target.getPosition and target:getPosition() then
            local d = MathUtil:distanceSquare3d(target:getPosition(), myPos)
            if d > 1 and d < nearestDist then
                nearestDist = d
                nearest = target
            end
        end
    end

    if not nearest then
        UIHelper.showToast("No player found")
        return
    end
    local tp = nearest:getPosition()
    Teleport(VectorUtil.newVector3(tp.x, tp.y + 1, tp.z))
    local nm = (nearest.getName and nearest:getName()) or "player"
    UIHelper.showToast("TP -> " .. tostring(nm))
end

function GMHelper:SavePosition()
    local me = PlayerManager:getClientPlayer()
    if not me or not me.Player then UIHelper.showToast("No player") return end
    local p = me.Player:getPosition()
    if not p then return end
    SavedTPPos = VectorUtil.newVector3(p.x, p.y, p.z)
    UIHelper.showToast(string.format("Saved: %d, %d, %d",
        math.floor(p.x), math.floor(p.y), math.floor(p.z)))
end

function GMHelper:TeleportSaved()
    if not SavedTPPos then
        UIHelper.showToast("No saved position!")
        return
    end
    Teleport(SavedTPPos)
    UIHelper.showToast("TP to saved position")
end

function GMHelper:CrashGame()
    window.Main = GUIManager:createGUIWindow("Layout", "Main")
    UIHelper.showToast("GULULULU")
end


local _ws_uid = 0
local function ws_uid(prefix)
    _ws_uid = _ws_uid + 1
    return prefix .. "_" .. os.time() .. "_" .. _ws_uid
end

local function ws_safe(fn, default)
    local ok, res = pcall(fn)
    if ok then return res end
    return default
end

local function ws_trim(s)
    s = tostring(s or "")
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    return s
end

local function ws_lower(s)
    return string.lower(ws_trim(s))
end

local function ws_contains(hay, needle)
    hay = ws_lower(hay)
    needle = ws_lower(needle)
    if needle == "" then return true end
    return hay:find(needle, 1, true) ~= nil
end

local function ws_win_name(win)
    if not win then return "<?>" end
    local name = ws_safe(function() return win:GetName() end, "")
    name = ws_trim(name)
    if name ~= "" then return name end

    local text = ws_safe(function() return win:GetText() end, "")
    text = ws_trim(text)
    if text ~= "" then return text end

    return "<?>"
end

local function ws_win_text(win)
    if not win then return "" end
    return ws_trim(ws_safe(function() return win:GetText() end, ""))
end

local function ws_win_visible(win)
    if not win then return false end
    return ws_safe(function() return win:IsVisible() end, false)
end

local function ws_win_touchable(win)
    if not win then return false end
    return ws_safe(function() return win:IsTouchable() end, false)
end

local function ws_win_child_count(win)
    if not win then return 0 end
    return ws_safe(function() return win:GetChildCount() end, 0) or 0
end

local function ws_win_child(win, idx)
    if not win then return nil end
    return ws_safe(function() return win:GetChildByIndex(idx) end, nil)
end

local function ws_indent(depth)
    return string.rep("  ", depth or 0)
end

local function ws_make_line(node, depth)
    local name = ws_win_name(node.win)
    local text = ws_win_text(node.win)
    local vis = tostring(ws_win_visible(node.win))
    local touch = tostring(ws_win_touchable(node.win))

    if text ~= "" and text ~= name then
        return string.format("%s- %s | text=%s | vis=%s | touch=%s", ws_indent(depth), name, text, vis, touch)
    end
    return string.format("%s- %s | vis=%s | touch=%s", ws_indent(depth), name, vis, touch)
end

local function ws_build_tree(win, path, depth, openMap)
    local node = {
        win = win,
        path = path or "root",
        depth = depth or 0,
        open = false,
        children = {}
    }

    if path and openMap and openMap[path] ~= nil then
        node.open = openMap[path]
    else
        node.open = (depth or 0) < 1
    end

    local c = ws_win_child_count(win)
    for i = 0, c - 1 do
        local child = ws_win_child(win, i)
        if child then
            local childName = ws_win_name(child)
            local childPath = (path or "root") .. "/" .. tostring(i) .. ":" .. childName
            table.insert(node.children, ws_build_tree(child, childPath, (depth or 0) + 1, openMap))
        end
    end

    return node
end

local function ws_has_match(node, query)
    if not node then return false end
    local q = ws_lower(query)
    if q == "" then return true end

    local name = ws_win_name(node.win)
    local text = ws_win_text(node.win)

    if ws_contains(name, q) or ws_contains(text, q) then
        return true
    end

    for _, child in ipairs(node.children) do
        if ws_has_match(child, q) then
            return true
        end
    end

    return false
end

local function ws_collect_visible(node, query, out, depth)
    if not node then return end
    local q = ws_lower(query)

    if node.path ~= "root" then
        local match = (q == "") or ws_contains(ws_win_name(node.win), q) or ws_contains(ws_win_text(node.win), q)
        local subtree = match
        if not subtree then
            for _, child in ipairs(node.children) do
                if ws_has_match(child, q) then
                    subtree = true
                    break
                end
            end
        end

        if not subtree then return end

        table.insert(out, {
            node = node,
            depth = depth or 0,
            match = match
        })
    end

    if q ~= "" then
        for _, child in ipairs(node.children) do
            if ws_has_match(child, q) then
                ws_collect_visible(child, query, out, (depth or 0) + 1)
            end
        end
    else
        if node.open then
            for _, child in ipairs(node.children) do
                ws_collect_visible(child, query, out, (depth or 0) + 1)
            end
        end
    end
end

local function ws_dump_full(node, lines, depth)
    if not node then return end
    if node.path ~= "root" then
        table.insert(lines, ws_make_line(node, depth))
    end
    for _, child in ipairs(node.children) do
        ws_dump_full(child, lines, (depth or 0) + 1)
    end
end

local function ws_export_text(lines, filename)
    local text = table.concat(lines, "\n")
    pcall(function()
        ClientHelper.onSetClipboard(text)
    end)
    pcall(function()
        local f = io.open(filename, "w")
        if f then
            f:write(text)
            f:close()
        end
    end)
    return text
end

local function ws_toast(msg)
    pcall(function() UIHelper.showToast(msg) end)
end

local ws_colors = {
    red = {1, 0, 0, 1},
    red_soft = {1, 0.35, 0.35, 1},
    dark_bg = {0.05, 0.01, 0.01, 0.98},
    panel_bg = {0.08, 0.02, 0.02, 1},
    row_bg = {0.12, 0.03, 0.03, 0.8},
    white = {1, 1, 1, 1},
    grey = {0.6, 0.5, 0.5, 1},
    green = {0.2, 1, 0.2, 1},
    btn_bg = {0.15, 0.04, 0.04, 1}
}
function GMHelper:_ws_refresh()
    if not self._ws or not self._ws.list then return end
    local root = ws_safe(function() return GUISystem.Instance():GetRootWindow() end, nil)
    if not root then return end

    self._ws.openMap = self._ws.openMap or {}
    local tree = ws_build_tree(root, "root", 0, self._ws.openMap)
    self._ws.tree = tree

    local rows = {}
    ws_collect_visible(tree, self._ws.searchText or "", rows, 0)

    self._ws.list:ClearAllItem()

    local rowHeight = 48

    if #rows == 0 then
        local empty = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("WS_Empty"))
        empty:SetWidth({1, 0})
        empty:SetHeight({0, 60})
        empty:SetText("[ SYSTEM: NO WINDOWS FOUND ]")
        empty:SetTextColor(ws_colors.grey)
        empty:SetTextScale(1.0)
        empty:SetTextHorzAlign(HorizontalAlignment.Center)
        empty:SetTextVertAlign(VerticalAlignment.Center)
        empty:SetBackgroundColor({0, 0, 0, 0})
        self._ws.list:AddItem(empty)
        return
    end

    for i, entry in ipairs(rows) do
        local node = entry.node
        local depth = entry.depth or 0
        local indent = math.min(depth * 20, 160)

        local row = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_Row"))
        row:SetWidth({1, 0})
        row:SetHeight({0, rowHeight})
        row:SetBackgroundColor(ws_colors.red)
        row:SetTouchable(true)

        local inner = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_RowInner"))
        inner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
        inner:SetBackgroundColor(ws_colors.row_bg)
        row:AddChildWindow(inner)

        local treeIcon = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("WS_TreeIcon"))
        treeIcon:SetArea({0, 10 + indent}, {0, 0}, {0, 20}, {1, 0})
        treeIcon:SetText((#node.children > 0) and (node.open and "[-]" or "[+]") or ">")
        treeIcon:SetTextColor((#node.children > 0) and ws_colors.red_soft or ws_colors.grey)
        treeIcon:SetTextVertAlign(VerticalAlignment.Center)
        inner:AddChildWindow(treeIcon)

        local label = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("WS_Label"))
        label:SetArea({0, 35 + indent}, {0, 0}, {1, -300}, {1, 0})
        label:SetText(ws_win_name(node.win))
        label:SetTextColor(ws_colors.white)
        label:SetTextScale(0.82)
        label:SetTextHorzAlign(HorizontalAlignment.Left)
        label:SetTextVertAlign(VerticalAlignment.Center)
        label:SetBackgroundColor({0, 0, 0, 0})
        inner:AddChildWindow(label)

        local function createRowBtn(id, text, ax, ay, aw, ah, color)
            local btn = GUIManager:createGUIWindow(GUIType.Button, ws_uid(id))
            btn:SetArea(ax, ay, aw, ah)
            btn:SetText(text)
            btn:SetTextColor(color)
            btn:SetBackgroundColor(ws_colors.btn_bg)
            btn:SetTextScale(0.7)
            btn:SetTouchable(true)
            inner:AddChildWindow(btn)
            return btn
        end

        local toggleBtn = createRowBtn("WS_Toggle", node.open and "COLLAPSE" or "EXPAND", {1, -110}, {0, 8}, {0, 100}, {0, 28}, ws_colors.red_soft)
        local copyBtn = createRowBtn("WS_Copy", "COPY", {1, -195}, {0, 8}, {0, 80}, {0, 28}, ws_colors.white)

        local isVis = ws_win_visible(node.win)
        local visBtn = createRowBtn("WS_Vis", isVis and "HIDE" or "SHOW", {1, -290}, {0, 8}, {0, 90}, {0, 28}, isVis and ws_colors.red_soft or ws_colors.green)
        visBtn:registerEvent(GUIEvent.ButtonClick, function()
            pcall(function() node.win:SetVisible(not isVis) end)
            ws_toast(isVis and "Window Hidden" or "Window Shown")
            self:_ws_refresh()
        end)

        local lineText = ws_make_line(node, depth)
        copyBtn:registerEvent(GUIEvent.ButtonClick, function()
            pcall(function() ClientHelper.onSetClipboard(lineText) end)
            ws_toast("Node Copied.")
        end)

        toggleBtn:registerEvent(GUIEvent.ButtonClick, function()
            self._ws.openMap[node.path] = not node.open
            self:_ws_refresh()
        end)

        self._ws.list:AddItem(row)
    end
end
function GMHelper:ShowWindowSystemUI(parent)
    if not parent then return end
    if self.wsAnimTimer then LuaTimer:cancel(self.wsAnimTimer); self.wsAnimTimer = nil end

    if parent.CleanupChildren then
        pcall(function() parent:CleanupChildren() end)
    end

    self._ws = self._ws or {}
    self._ws.searchText = self._ws.searchText or ""
    self._ws.openMap = self._ws.openMap or {}
    self._ws.borderLines = {}
    self._ws.pulseTexts = {}

    parent:SetBackgroundColor(ws_colors.dark_bg)

    local mainFrame = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_MainFrame"))
    mainFrame:SetArea({0, 15}, {0, 15}, {1, -30}, {1, -30})
    parent:AddChildWindow(mainFrame)

    local function createFrameLine(x, y, w, h, color, track)
        local l = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("FrameLine"))
        l:SetArea(x, y, w, h)
        l:SetBackgroundColor(color)
        mainFrame:AddChildWindow(l)
        if track ~= false then table.insert(self._ws.borderLines, l) end
        return l
    end

    createFrameLine({0, 0}, {0, 0}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
    createFrameLine({0, 0}, {1, -1}, {1, 0}, {0, 1}, {1, 0.1, 0.1, 0.3})
    createFrameLine({0, 0}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
    createFrameLine({1, -1}, {0, 0}, {0, 1}, {1, 0}, {1, 0.1, 0.1, 0.3})
    local cSize, cThick = 28, 4
    createFrameLine({0, -2}, {0, -2}, {0, cSize}, {0, cThick}, ws_colors.red)
    createFrameLine({0, -2}, {0, -2}, {0, cThick}, {0, cSize}, ws_colors.red)
    createFrameLine({1, -cSize + 2}, {0, -2}, {0, cSize}, {0, cThick}, ws_colors.red)
    createFrameLine({1, -cThick + 2}, {0, -2}, {0, cThick}, {0, cSize}, ws_colors.red)
    createFrameLine({0, -2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, ws_colors.red)
    createFrameLine({0, -2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, ws_colors.red)
    createFrameLine({1, -cSize + 2}, {1, -cThick + 2}, {0, cSize}, {0, cThick}, ws_colors.red)
    createFrameLine({1, -cThick + 2}, {1, -cSize + 2}, {0, cThick}, {0, cSize}, ws_colors.red)

    self._ws.scanline = createFrameLine({0, 2}, {0, 0}, {1, -4}, {0, 2}, {1, 0.2, 0.2, 0.18}, false)

    local title = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("WS_Title"))
    title:SetArea({0, 0}, {0, 15}, {1, 0}, {0, 40})
    title:SetText("NCLIENT WINDOW INSPECTOR")
    title:SetTextScale(1.1)
    title:SetTextColor(ws_colors.red)
    title:SetTextHorzAlign(HorizontalAlignment.Center)
    title:SetTextVertAlign(VerticalAlignment.Center)
    mainFrame:AddChildWindow(title)
    table.insert(self._ws.pulseTexts, title)

    local divLine = createFrameLine({0, 50}, {0, 60}, {1, -100}, {0, 2}, ws_colors.red)

    local toolLayout = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_Tools"))
    toolLayout:SetArea({0, 30}, {0, 75}, {1, -60}, {0, 40})
    mainFrame:AddChildWindow(toolLayout)

    local findLabel = GUIManager:createGUIWindow(GUIType.StaticText, ws_uid("WS_FindLabel"))
    findLabel:SetArea({0, 0}, {0, 0}, {0, 80}, {1, 0})
    findLabel:SetText("> QUERY:")
    findLabel:SetTextScale(0.9)
    findLabel:SetTextColor(ws_colors.red_soft)
    findLabel:SetTextVertAlign(VerticalAlignment.Center)
    toolLayout:AddChildWindow(findLabel)

    local searchBorder = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_SearchBorder"))
    searchBorder:SetArea({0, 80}, {0, 2}, {0, 250}, {1, -4})
    searchBorder:SetBackgroundColor(ws_colors.red)
    toolLayout:AddChildWindow(searchBorder)
    table.insert(self._ws.borderLines, searchBorder)

    local searchInner = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_SearchInner"))
    searchInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
    searchInner:SetBackgroundColor(ws_colors.dark_bg)
    searchBorder:AddChildWindow(searchInner)

    self._ws.searchEdit = GUIManager:createGUIWindow(GUIType.Edit, ws_uid("WS_Search"))
    self._ws.searchEdit:SetArea({0, 10}, {0, 0}, {1, -20}, {1, 0})
    self._ws.searchEdit:SetBackgroundColor({0, 0, 0, 0})
    self._ws.searchEdit:SetTextColor(ws_colors.white)
    self._ws.searchEdit:SetText(self._ws.searchText or "")
    self._ws.searchEdit:SetMaxLength(120)
    searchInner:AddChildWindow(self._ws.searchEdit)

    local function createToolBtn(id, text, ax, aw)
        local btnBorder = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("Border_" .. id))
        btnBorder:SetArea(ax, {0, 2}, aw, {1, -4})
        btnBorder:SetBackgroundColor(ws_colors.red)
        toolLayout:AddChildWindow(btnBorder)
        table.insert(self._ws.borderLines, btnBorder)

        local btnInner = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("Inner_" .. id))
        btnInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
        btnInner:SetBackgroundColor(ws_colors.btn_bg)
        btnBorder:AddChildWindow(btnInner)

        local btn = GUIManager:createGUIWindow(GUIType.Button, ws_uid("Btn_" .. id))
        btn:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
        btn:SetText(text)
        btn:SetTextScale(0.75)
        btn:SetTextColor(ws_colors.red_soft)
        btn:SetBackgroundColor({0, 0, 0, 0})
        btnInner:AddChildWindow(btn)
        return btn
    end
    local refreshBtn = createToolBtn("Refresh", "REFRESH", {1, -110}, {0, 110})
    local copyAllBtn = createToolBtn("CopyAll", "COPY ALL", {1, -228}, {0, 110})
    local exportBtn = createToolBtn("Export", "EXPORT", {1, -346}, {0, 110})

    local listBorder = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_ListBorder"))
    listBorder:SetArea({0, 30}, {0, 130}, {1, -60}, {1, -150})
    listBorder:SetBackgroundColor({1, 0.1, 0.1, 0.3})
    mainFrame:AddChildWindow(listBorder)
    table.insert(self._ws.borderLines, listBorder)

    local listInner = GUIManager:createGUIWindow(GUIType.Layout, ws_uid("WS_ListInner"))
    listInner:SetArea({0, 2}, {0, 2}, {1, -4}, {1, -4})
    listInner:SetBackgroundColor(ws_colors.panel_bg)
    listBorder:AddChildWindow(listInner)

    self._ws.list = GUIManager:createGUIWindow(GUIType.List, ws_uid("WS_List"))
    self._ws.list:SetArea({0, 5}, {0, 5}, {1, -10}, {1, -10})
    self._ws.list:SetBackgroundColor({0, 0, 0, 0})
    pcall(function() self._ws.list:SetInterval(2) end)
    listInner:AddChildWindow(self._ws.list)

    local function bindSearch()
        self._ws.searchText = self._ws.searchEdit:GetText() or ""
        self:_ws_refresh()
    end

    self._ws.searchEdit:registerEvent(GUIEvent.EditTextInput, function(args)
        if args and args.trigger == 0 then bindSearch() end
    end)

    refreshBtn:registerEvent(GUIEvent.ButtonClick, function()
        self:_ws_refresh()
        ws_toast("System Tree Refreshed.")
    end)

    copyAllBtn:registerEvent(GUIEvent.ButtonClick, function()
        local rootWin = ws_safe(function() return GUISystem.Instance():GetRootWindow() end, nil)
        if not rootWin then return end
        local tree = ws_build_tree(rootWin, "root", 0, self._ws.openMap or {})
        local lines = {}
        ws_dump_full(tree, lines, 0)
        ws_export_text(lines, "nclient_window_dump_all.txt")
        ws_toast("All Nodes Copied to Clipboard.")
    end)

    exportBtn:registerEvent(GUIEvent.ButtonClick, function()
        local rootWin = ws_safe(function() return GUISystem.Instance():GetRootWindow() end, nil)
        if not rootWin then return end
        local tree = ws_build_tree(rootWin, "root", 0, self._ws.openMap or {})
        local lines = {}
        ws_dump_full(tree, lines, 0)
        ws_export_text(lines, "nclient_window_dump.txt")
        ws_toast("Exported to Local Storage.")
    end)

    self:_ws_refresh()
    local pulse, scanPos = 0, 0
    self.wsAnimTimer = LuaTimer:scheduleTimer(function()
        local status = pcall(function()
            if not parent or not parent:IsVisible() then error("StopTimer") end
            pulse = pulse + 0.1
            
            for i, line in ipairs(self._ws.borderLines) do
                if line then
                    local t = 0.5 + 0.5 * math.sin(pulse + i * 0.35)
                    local nm = line:GetName() or ""
                    if string.find(nm, "Border") then
                        line:SetBackgroundColor({1, 0.05 + t * 0.25, 0.05 + t * 0.1, 0.2 + t * 0.3})
                    else
                        line:SetBackgroundColor({1, 0.05 + t * 0.3, 0.05 + t * 0.1, 0.4 + t * 0.6})
                    end
                end
            end

            for _, txt in ipairs(self._ws.pulseTexts) do
                if txt then
                    local flick = (math.random() > 0.93) and 1 or (0.55 + 0.45 * math.sin(pulse * 2))
                    txt:SetTextColor({1, 0.1 + flick * 0.15, 0.1, flick})
                end
            end

            if title then
                title:SetXPosition({0, (math.random() > 0.88) and math.random(-3, 3) or 0})
            end

            scanPos = (scanPos + 0.012) % 1
            if self._ws.scanline then self._ws.scanline:SetYPosition({scanPos, 0}) end
        end)
        if not status then
            if self.wsAnimTimer then LuaTimer:cancel(self.wsAnimTimer); self.wsAnimTimer = nil end
        end
    end, 16, -1)
end

function GMHelper:NReach(btn)
    self.nReachOn = not self.nReachOn
    _G["togNReach"] = self.nReachOn
    reButtonColorUI("NReach")
    if self.nReachOn then
        AddButton("Reach", "NReach")
        pcall(function() ClientHelper.putFloatPrefs("BlockReachDistance", 999) end)
        UIHelper.showToast("^00FF00Reach Enabled")
    else
        pcall(function() ClientHelper.putFloatPrefs("BlockReachDistance", 6.5) end)
        UIHelper.showToast("^FF0000Reach Disabled")
    end
end

function GMHelper:InfJump(btn)
    self.infJumpOn = not self.infJumpOn
    _G["togInfJump"] = self.infJumpOn
    reButtonColorUI("InfJump")
    pcall(function() ClientHelper.putBoolPrefs("EnableDoubleJumps", self.infJumpOn) end)
    UIHelper.showToast(self.infJumpOn and "^00FF00Infinite Jump ON" or "^FF0000Infinite Jump OFF")
end

function GMHelper:NoFall(btn)
    self.noFallOn = not self.noFallOn
    _G["togNoFall"] = self.noFallOn
    reButtonColorUI("NoFall")
    if self.noFallTimer then LuaTimer:cancel(self.noFallTimer); self.noFallTimer = nil end
    if self.noFallOn then
        AddButton("NoFall", "NoFall")
        UIHelper.showToast("^00FF00No Fall ON")
        self.noFallTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if me and me.Player then
                pcall(function() me.Player.fallDistance = 0 end)
            end
        end, 100, -1)
    else
        UIHelper.showToast("^FF0000No Fall OFF")
    end
end

function GMHelper:InfSprint(btn)
    self.infSprintOn = not self.infSprintOn
    _G["togInfSprint"] = self.infSprintOn
    reButtonColorUI("InfSprint")
    if self.infSprintTimer then LuaTimer:cancel(self.infSprintTimer); self.infSprintTimer = nil end
    if self.infSprintOn then
        AddButton("Sprint", "InfSprint")
        UIHelper.showToast("^00FF00Infinite Sprint ON")
        self.infSprintTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if me and me.Player then pcall(function() me.Player:setSprinting(true) end) end
        end, 16, -1)
    else
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then pcall(function() me.Player:setSprinting(false) end) end
        UIHelper.showToast("^FF0000Infinite Sprint OFF")
    end
end

function GMHelper:JetPack(btn)
    self.jetPackOn = not self.jetPackOn
    _G["togJetPack"] = self.jetPackOn
    reButtonColorUI("JetPack")
    if self.jetPackTimer then LuaTimer:cancel(self.jetPackTimer); self.jetPackTimer = nil end
    if self.jetPackOn then
        AddButton("JetPack", "JetPack")
        UIHelper.showToast("^00FF00JetPack ON ")
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then
            pcall(function()
                me.Player.m_isPulled = true
                me.Player.m_remainingFlyTicksByPulled = 999999
                me.Player.m_flyingByPulled = true
                me.Player.onGround = false
            end)
            if type(bypass) == "function" then pcall(bypass) end
        end
        self.jetPackTimer = LuaTimer:scheduleTimer(function()
            local p = PlayerManager:getClientPlayer()
            if not p or not p.Player then return end
            local yaw   = math.rad(p.Player:getYaw() or 0)
            local pitch = math.rad(p.Player:getPitch() or 0)
            local speed = 1.0
            local x = -speed * math.cos(pitch) * math.sin(yaw)
            local y = -speed * math.sin(pitch)
            local z =  speed * math.cos(pitch) * math.cos(yaw)
            pcall(function() p.Player:setVelocity(VectorUtil.newVector3(x, y, z)) end)
        end, 5, -1)
    else
        UIHelper.showToast("^FF0000JetPack OFF")
    end
end

function GMHelper:OrbitTarget(btn)
    self.orbitOn = not self.orbitOn
    _G["togOrbitTarget"] = self.orbitOn
    reButtonColorUI("OrbitTarget")
    if self.orbitTimer then LuaTimer:cancel(self.orbitTimer); self.orbitTimer = nil end

    if not self.orbitOn then
        UIHelper.showToast("^FF0000Orbit OFF")
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then pcall(function() me.Player:setFlying(false) end) end
        return
    end

    AddButton("Orbit", "OrbitTarget")
    UIHelper.showToast("^00FF00Orbit ON")
    pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)

    local angle  = 0
    local radius = 3.0   
    local height = 1.2   
    local speed  = 0.18   

    self.orbitTimer = LuaTimer:scheduleTimer(function()
        local me = PlayerManager:getClientPlayer()
        if not me or not me.Player then return end
        local myPos = me.Player:getPosition()
        if not myPos then return end

        local players = PlayerManager:getPlayers()
        if not players then return end

        local target, bestDist = nil, math.huge
        for _, pl in pairs(players) do
            if pl and pl ~= me and pl.getPosition and pl:getPosition() then
                local d = MathUtil:distanceSquare3d(pl:getPosition(), myPos)
                if d > 0.5 and d < bestDist then bestDist = d; target = pl end
            end
        end
        if not target then return end

        local tp = target:getPosition()
        angle = (angle + speed) % (math.pi * 2)
        local nx = tp.x + math.cos(angle) * radius
        local nz = tp.z + math.sin(angle) * radius
        local ny = tp.y + height

        me.Player:setAllowFlying(true)
        me.Player:setFlying(true)
        me.Player:setPosition(VectorUtil.newVector3(nx, ny, nz))

        local dx, dz = tp.x - nx, tp.z - nz
        me.Player.rotationYaw   = math.atan2(dx, dz) / math.pi * -180
        me.Player.rotationPitch = 0
    end, 16, -1)
end

function GMHelper:NoClip(btn)
    self.noClipOn = not self.noClipOn
    _G["togNoClip"] = self.noClipOn
    reButtonColorUI("NoClip")
    if self.noClipTimer then LuaTimer:cancel(self.noClipTimer); self.noClipTimer = nil end
    if self.noClipOn then
        AddButton("NoClip", "NoClip")
        UIHelper.showToast("^00FF00NoClip ON - Walk through walls")
        pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then
            pcall(function()
                me.Player:setAllowFlying(true)
                me.Player:setFlying(true)
            end)
        end
        self.noClipTimer = LuaTimer:scheduleTimer(function()
            local p = PlayerManager:getClientPlayer()
            if p and p.Player then pcall(function() p.Player.noClip = true end) end
        end, 100, -1)
    else
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then pcall(function() me.Player.noClip = false end) end
        UIHelper.showToast("^FF0000NoClip OFF")
    end
end

function GMHelper:HighJump(btn)
    self.highJumpOn = not self.highJumpOn
    _G["togHighJump"] = self.highJumpOn
    reButtonColorUI("HighJump")
    if self.highJumpTimer then LuaTimer:cancel(self.highJumpTimer); self.highJumpTimer = nil end
    if self.highJumpOn then
        AddButton("HighJump", "HighJump")
        UIHelper.showToast("^00FF00High Jump ON")
        self.highJumpTimer = LuaTimer:scheduleTimer(function()
            local p = PlayerManager:getClientPlayer()
            if p and p.Player then pcall(function() p.Player:setFloatProperty("JumpHeight", 1.2) end) end
        end, 300, -1)
    else
        local me = PlayerManager:getClientPlayer()
        if me and me.Player then pcall(function() me.Player:setFloatProperty("JumpHeight", 0.42) end) end
        UIHelper.showToast("^FF0000High Jump OFF")
    end
end

function GMHelper:AntiVoid(btn)
    self.antiVoidOn = not self.antiVoidOn
    _G["togAntiVoid"] = self.antiVoidOn
    reButtonColorUI("AntiVoid")
    if self.antiVoidTimer then LuaTimer:cancel(self.antiVoidTimer); self.antiVoidTimer = nil end
    if self.antiVoidOn then
        AddButton("AntiVoid", "AntiVoid")
        UIHelper.showToast("^00FF00Anti-Void ON")
        self.antiVoidTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if not me or not me.Player then return end
            local pos = me.Player:getPosition()
            if pos and pos.y < 5 then
                pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)
                me.Player:setAllowFlying(true)
                me.Player:setFlying(true)
                me.Player:setPosition(VectorUtil.newVector3(pos.x, 120, pos.z))
                UIHelper.showToast("^FFFF00Anti-Void: pulled to safety")
            end
        end, 200, -1)
    else
        UIHelper.showToast("^FF0000Anti-Void OFF")
    end
end

function GMHelper:SelectSkinById()
    self:openInput({ "" }, function(inputValue)
        local skinId = tonumber(inputValue)
        if not skinId then return end

        WebService.GetPlayerDecoration(skinId, function(decorationData)
            if not decorationData then return end

            for _, data in ipairs(decorationData) do
                if data.slave and data.master then
                    ChangeSkin(tonumber(data.slave), tostring(data.master))
                    print("slave: " .. data.slave)
                    print("master: " .. data.master)
                end
            end
        end)
    end)
end

function nGetPlayer()
    local me = PlayerManager:getClientPlayer()
    if me and me.Player then return me, me.Player end
    return nil, nil
end

function nForwardVec(player, speed)
    local yaw   = math.rad(player:getYaw() or 0)
    local pitch = math.rad(player:getPitch() or 0)
    local x = -speed * math.cos(pitch) * math.sin(yaw)
    local y = -speed * math.sin(pitch)
    local z =  speed * math.cos(pitch) * math.cos(yaw)
    return x, y, z
end

function nToggle(self, field, name)
    self[field] = not self[field]
    _G["tog" .. name] = self[field]
    if reButtonColorUI then reButtonColorUI(name) end
    return self[field]
end

function nNearestPlayer(maxDistSq)
    local me = PlayerManager:getClientPlayer()
    if not me or not me.Player then return nil, nil end
    local myPos = me.Player:getPosition()
    if not myPos then return nil, nil end
    local players = PlayerManager:getPlayers()
    if not players then return nil, nil end
    local best, bestDist = nil, (maxDistSq or math.huge)
    for _, pl in pairs(players) do
        if pl and pl ~= me and pl.getPosition and pl:getPosition() then
            local d = MathUtil:distanceSquare3d(pl:getPosition(), myPos)
            if d > 0.1 and d < bestDist then bestDist = d; best = pl end
        end
    end
    return best, me
end


function GMHelper:Bhop(btn)
    local on = nToggle(self, "bhopOn", "Bhop")
    if self.bhopTimer then LuaTimer:cancel(self.bhopTimer); self.bhopTimer = nil end
    if on then
        AddButton("Bhop", "Bhop")
        UIHelper.showToast("^00FF00Bunny Hop ON")
        self.bhopTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if p and p.onGround then
                pcall(function() p:setVelocity(VectorUtil.newVector3(0, 0.42, 0)) end)
            end
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Bunny Hop OFF")
    end
end

function GMHelper:Spider(btn)
    local on = nToggle(self, "spiderOn", "Spider")
    if self.spiderTimer then LuaTimer:cancel(self.spiderTimer); self.spiderTimer = nil end
    if on then
        AddButton("Spider", "Spider")
        UIHelper.showToast("^00FF00Spider Climb ON")
        self.spiderTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            if p.horizontalCollision or p.isCollidedHorizontally then
                pcall(function() p:setVelocity(VectorUtil.newVector3(0, 0.2, 0)) end)
            end
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Spider Climb OFF")
    end
end

function GMHelper:FastFall(btn)
    local on = nToggle(self, "fastFallOn", "FastFall")
    if self.fastFallTimer then LuaTimer:cancel(self.fastFallTimer); self.fastFallTimer = nil end
    if on then
        AddButton("FastFall", "FastFall")
        UIHelper.showToast("^00FF00Fast Fall ON")
        self.fastFallTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p or p.onGround then return end
            pcall(function() p:setVelocity(VectorUtil.newVector3(0, -2.0, 0)) end)
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Fast Fall OFF")
    end
end

function GMHelper:Glide(btn)
    local on = nToggle(self, "glideOn", "Glide")
    if self.glideTimer then LuaTimer:cancel(self.glideTimer); self.glideTimer = nil end
    if on then
        AddButton("Glide", "Glide")
        UIHelper.showToast("^00FF00Glide ON")
        self.glideTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p or p.onGround then return end
            local x, _, z = nForwardVec(p, 0.35)
            pcall(function() p:setVelocity(VectorUtil.newVector3(x, -0.08, z)) end)
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Glide OFF")
    end
end

function GMHelper:WaterWalk(btn)
    local on = nToggle(self, "waterWalkOn", "WaterWalk")
    if self.waterWalkTimer then LuaTimer:cancel(self.waterWalkTimer); self.waterWalkTimer = nil end
    if on then
        AddButton("Jesus", "WaterWalk")
        UIHelper.showToast("^00FF00Water Walk ON")
        self.waterWalkTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            if p.isInWater or p.inWater then
                pcall(function() p:setVelocity(VectorUtil.newVector3(0, 0.1, 0)) end)
            end
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Water Walk OFF")
    end
end

function GMHelper:AutoSneak(btn)
    local on = nToggle(self, "autoSneakOn", "AutoSneak")
    if self.autoSneakTimer then LuaTimer:cancel(self.autoSneakTimer); self.autoSneakTimer = nil end
    if on then
        AddButton("Sneak", "AutoSneak")
        UIHelper.showToast("^00FF00Auto Sneak ON")
        self.autoSneakTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if p then pcall(function() p:setSneaking(true) end) end
        end, 100, -1)
    else
        local _, p = nGetPlayer()
        if p then pcall(function() p:setSneaking(false) end) end
        UIHelper.showToast("^FF0000Auto Sneak OFF")
    end
end

function GMHelper:FastSwim(btn)
    local on = nToggle(self, "fastSwimOn", "FastSwim")
    if self.fastSwimTimer then LuaTimer:cancel(self.fastSwimTimer); self.fastSwimTimer = nil end
    if on then
        AddButton("FastSwim", "FastSwim")
        UIHelper.showToast("^00FF00Fast Swim ON")
        self.fastSwimTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            if p.isInWater or p.inWater then
                local x, y, z = nForwardVec(p, 1.2)
                pcall(function() p:setVelocity(VectorUtil.newVector3(x, y, z)) end)
            end
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Fast Swim OFF")
    end
end

function GMHelper:AntiKnockback(btn)
    local on = nToggle(self, "antiKbOn", "AntiKnockback")
    if self.antiKbTimer then LuaTimer:cancel(self.antiKbTimer); self.antiKbTimer = nil end
    if on then
        AddButton("AntiKB", "AntiKnockback")
        UIHelper.showToast("^00FF00Anti Knockback ON")
        self.antiKbTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            pcall(function() p.m_knockbackX = 0; p.m_knockbackZ = 0 end)
        end, 20, -1)
    else
        UIHelper.showToast("^FF0000Anti Knockback OFF")
    end
end

function GMHelper:AutoWalk(btn)
    local on = nToggle(self, "autoWalkOn", "AutoWalk")
    if self.autoWalkTimer then LuaTimer:cancel(self.autoWalkTimer); self.autoWalkTimer = nil end
    if on then
        AddButton("AutoWalk", "AutoWalk")
        UIHelper.showToast("^00FF00Auto Walk ON")
        self.autoWalkTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            local x, _, z = nForwardVec(p, 0.5)
            pcall(function() p:setVelocity(VectorUtil.newVector3(x, 0, z)) end)
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Auto Walk OFF")
    end
end


function GMHelper:TriggerBot(btn)
    local on = nToggle(self, "triggerOn", "TriggerBot")
    if self.triggerTimer then LuaTimer:cancel(self.triggerTimer); self.triggerTimer = nil end
    if on then
        AddButton("Trigger", "TriggerBot")
        UIHelper.showToast("^00FF00TriggerBot ON")
        self.triggerTimer = LuaTimer:scheduleTimer(function()
            local target = nNearestPlayer(9) 
            if target and target.entityId and target:getPosition() then
                local tp = target:getPosition()
                Zentex(target.entityId, VectorUtil.newVector3(math.floor(tp.x), math.floor(tp.y), math.floor(tp.z)))
            end
        end, 150, -1)
    else
        UIHelper.showToast("^FF0000TriggerBot OFF")
    end
end

function GMHelper:MultiAura(btn)
    local on = nToggle(self, "multiAuraOn", "MultiAura")
    if self.multiAuraTimer then LuaTimer:cancel(self.multiAuraTimer); self.multiAuraTimer = nil end
    if on then
        AddButton("MultiAura", "MultiAura")
        UIHelper.showToast("^00FF00Multi Aura ON")
        self.multiAuraTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if not me or not me.Player then return end
            local myPos = me.Player:getPosition()
            local players = PlayerManager:getPlayers()
            if not myPos or not players then return end
            for _, target in pairs(players) do
                if target and target ~= me and target.entityId and target:getPosition() then
                    local tp = target:getPosition()
                    if MathUtil:distanceSquare3d(tp, myPos) < 100 then
                        Zentex(target.entityId, VectorUtil.newVector3(math.floor(tp.x), math.floor(tp.y), math.floor(tp.z)))
                    end
                end
            end
        end, 400, -1)
    else
        UIHelper.showToast("^FF0000Multi Aura OFF")
    end
end

function GMHelper:TargetLock(btn)
    local on = nToggle(self, "targetLockOn", "TargetLock")
    if self.targetLockTimer then LuaTimer:cancel(self.targetLockTimer); self.targetLockTimer = nil end
    if on then
        AddButton("Lock", "TargetLock")
        UIHelper.showToast("^00FF00Target Lock ON")
        self.targetLockTimer = LuaTimer:scheduleTimer(function()
            local target, me = nNearestPlayer(2500)
            if not target or not me then return end
            local camera = SceneManager.Instance():getMainCamera()
            local pos = camera:getPosition()
            local dir = VectorUtil.sub3(target:getPosition(), pos)
            local yaw  = math.atan2(dir.x, dir.z) / math.pi * -180
            local flat = math.sqrt(dir.x * dir.x + dir.z * dir.z)
            local pitch = -math.atan2(dir.y + 1.5, flat) / math.pi * 180
            me.Player.rotationYaw = yaw or 0
            me.Player.rotationPitch = pitch or 0
        end, 20, -1)
    else
        UIHelper.showToast("^FF0000Target Lock OFF")
    end
end

function GMHelper:AutoMelee(btn)
    local on = nToggle(self, "autoMeleeOn", "AutoMelee")
    if self.autoMeleeTimer then LuaTimer:cancel(self.autoMeleeTimer); self.autoMeleeTimer = nil end
    if on then
        AddButton("AutoMelee", "AutoMelee")
        UIHelper.showToast("^00FF00Auto Melee ON")
        self.autoMeleeTimer = LuaTimer:scheduleTimer(function()
            local target = nNearestPlayer(36) 
            if target and target.entityId and target:getPosition() then
                local tp = target:getPosition()
                Zentex(target.entityId, VectorUtil.newVector3(math.floor(tp.x), math.floor(tp.y), math.floor(tp.z)))
            end
        end, 200, -1)
    else
        UIHelper.showToast("^FF0000Auto Melee OFF")
    end
end

function GMHelper:Criticals(btn)
    local on = nToggle(self, "critOn", "Criticals")
    if self.critTimer then LuaTimer:cancel(self.critTimer); self.critTimer = nil end
    if on then
        AddButton("Crits", "Criticals")
        UIHelper.showToast("^00FF00Criticals ON")
        self.critTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if p and p.onGround then
                pcall(function() p:setVelocity(VectorUtil.newVector3(0, 0.1, 0)) end)
            end
        end, 250, -1)
    else
        UIHelper.showToast("^FF0000Criticals OFF")
    end
end

function GMHelper:Zoom(btn)
    local on = nToggle(self, "zoomOn", "Zoom")
    local cam = SceneManager.Instance():getMainCamera()
    if on then
        AddButton("Zoom", "Zoom")
        pcall(function() cam:setFov(30) end)
        UIHelper.showToast("^00FF00Zoom ON")
    else
        pcall(function() cam:setFov(70) end)
        UIHelper.showToast("^FF0000Zoom OFF")
    end
end


function GMHelper:AntiAFK(btn)
    local on = nToggle(self, "antiAfkOn", "AntiAFK")
    if self.antiAfkTimer then LuaTimer:cancel(self.antiAfkTimer); self.antiAfkTimer = nil end
    if on then
        AddButton("AntiAFK", "AntiAFK")
        UIHelper.showToast("^00FF00Anti-AFK ON")
        self.antiAfkTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            local yaw = (p:getYaw() or 0) + 20
            pcall(function() p.rotationYaw = yaw end)
        end, 2000, -1)
    else
        UIHelper.showToast("^FF0000Anti-AFK OFF")
    end
end

function GMHelper:AutoRespawn(btn)
    local on = nToggle(self, "autoRespawnOn", "AutoRespawn")
    if self.autoRespawnTimer then LuaTimer:cancel(self.autoRespawnTimer); self.autoRespawnTimer = nil end
    if on then
        AddButton("AutoResp", "AutoRespawn")
        UIHelper.showToast("^00FF00Auto Respawn ON")
        self.autoRespawnTimer = LuaTimer:scheduleTimer(function()
            local me, p = nGetPlayer()
            if not p then return end
            local hp = (p.getHealth and p:getHealth()) or 1
            if hp and hp <= 0 then
                pcall(function() me:respawn() end)
            end
        end, 500, -1)
    else
        UIHelper.showToast("^FF0000Auto Respawn OFF")
    end
end

function GMHelper:SetJumpHeight()
    self:openInput({ "Jump Height (default 0.42)" }, function(v)
        local h = tonumber(v)
        if not h then UIHelper.showToast("^FF0000Invalid value") return end
        local _, p = nGetPlayer()
        if p then pcall(function() p:setFloatProperty("JumpHeight", h) end) end
        UIHelper.showToast("^00FF00Jump Height set to " .. h)
    end)
end

function GMHelper:FakeLag(btn)
    local on = nToggle(self, "fakeLagOn", "FakeLag")
    if on then
        AddButton("FakeLag", "FakeLag")
        pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", false) end)
        UIHelper.showToast("^00FF00Fake Lag ON (blink)")
    else
        pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)
        UIHelper.showToast("^FF0000Fake Lag OFF")
    end
end

function GMHelper:TPForward()
    local _, p = nGetPlayer()
    if not p then UIHelper.showToast("^FF0000No player") return end
    local pos = p:getPosition()
    if not pos then return end
    local x, _, z = nForwardVec(p, 5)
    Teleport(VectorUtil.newVector3(pos.x + x, pos.y, pos.z + z))
    UIHelper.showToast("^00FF00TP Forward 5 blocks")
end

function GMHelper:Ascend()
    local _, p = nGetPlayer()
    if not p then UIHelper.showToast("^FF0000No player") return end
    local pos = p:getPosition()
    if not pos then return end
    Teleport(VectorUtil.newVector3(pos.x, pos.y + 10, pos.z))
    UIHelper.showToast("^00FF00Ascend +10")
end

function GMHelper:Descend()
    local _, p = nGetPlayer()
    if not p then UIHelper.showToast("^FF0000No player") return end
    local pos = p:getPosition()
    if not pos then return end
    Teleport(VectorUtil.newVector3(pos.x, pos.y - 10, pos.z))
    UIHelper.showToast("^00FF00Descend -10")
end

function GMHelper:TPToSpawn()
    local _, p = nGetPlayer()
    local pos = p and p:getPosition()
    Teleport(VectorUtil.newVector3((pos and pos.x) or 0, 100, (pos and pos.z) or 0))
    UIHelper.showToast("^00FF00TP to spawn area (y=100)")
end

function GMHelper:TPRelative()
    self:openInput({ "dX", "dY", "dZ" }, function(dx, dy, dz)
        local nx, ny, nz = tonumber(dx), tonumber(dy), tonumber(dz)
        local _, p = nGetPlayer()
        if not p or not (nx and ny and nz) then UIHelper.showToast("^FF0000Invalid") return end
        local pos = p:getPosition()
        if not pos then return end
        Teleport(VectorUtil.newVector3(pos.x + nx, pos.y + ny, pos.z + nz))
        UIHelper.showToast(string.format("^00FF00TP +(%d,%d,%d)", nx, ny, nz))
    end)
end

function GMHelper:TPNearestEntity()
    local target = nNearestPlayer(math.huge)
    if not target or not target.getPosition then UIHelper.showToast("^FF0000No entity") return end
    local tp = target:getPosition()
    Teleport(VectorUtil.newVector3(tp.x, tp.y + 1, tp.z))
    UIHelper.showToast("^00FF00TP to nearest entity")
end

function GMHelper:TPRandom()
    local _, p = nGetPlayer()
    if not p then UIHelper.showToast("^FF0000No player") return end
    local pos = p:getPosition()
    if not pos then return end
    local ox = math.random(-30, 30)
    local oz = math.random(-30, 30)
    Teleport(VectorUtil.newVector3(pos.x + ox, pos.y + 5, pos.z + oz))
    UIHelper.showToast(string.format("^00FF00TP random (%d, %d)", ox, oz))
end

function GMHelper:WalkToSaved(btn)
    if not SavedTPPos then UIHelper.showToast("^FF0000No saved position!") return end
    local on = nToggle(self, "walkToSavedOn", "WalkToSaved")
    if self.walkSavedTimer then LuaTimer:cancel(self.walkSavedTimer); self.walkSavedTimer = nil end
    if not on then UIHelper.showToast("^FF0000Walk To Saved OFF") return end
    AddButton("WalkSaved", "WalkToSaved")
    UIHelper.showToast("^00FF00Walking to saved position...")
    self.walkSavedTimer = LuaTimer:scheduleTimer(function()
        local _, p = nGetPlayer()
        if not p then return end
        local pos = p:getPosition()
        if not pos then return end
        local dx, dy, dz = SavedTPPos.x - pos.x, SavedTPPos.y - pos.y, SavedTPPos.z - pos.z
        local dist = math.sqrt(dx*dx + dy*dy + dz*dz)
        if dist < 1.0 then
            UIHelper.showToast("^00FF00Arrived at saved position")
            self.walkToSavedOn = false
            _G["togWalkToSaved"] = false
            if reButtonColorUI then reButtonColorUI("WalkToSaved") end
            LuaTimer:cancel(self.walkSavedTimer); self.walkSavedTimer = nil
            return
        end
        local s = 0.4 / dist
        pcall(function() p:setVelocity(VectorUtil.newVector3(dx*s, dy*s, dz*s)) end)
    end, 50, -1)
end

function GMHelper:DiscoMode(btn)
    local on = nToggle(self, "discoOn", "DiscoMode")
    if self.discoTimer then LuaTimer:cancel(self.discoTimer); self.discoTimer = nil end
    if on then
        AddButton("Disco", "DiscoMode")
        local colors = { "^FF0000", "^00FF00", "^0000FF", "^FFFF00", "^FF00FF", "^00FFFF" }
        local i = 0
        self.discoTimer = LuaTimer:scheduleTimer(function()
            i = (i % #colors) + 1
            UIHelper.showToast(colors[i] .. "*** DISCO PARTY ***")
        end, 250, -1)
    else
        UIHelper.showToast("^FF0000Disco Mode OFF")
    end
end

function GMHelper:EarthQuake(btn)
    local on = nToggle(self, "quakeOn", "EarthQuake")
    if self.quakeTimer then LuaTimer:cancel(self.quakeTimer); self.quakeTimer = nil end
    if on then
        AddButton("Quake", "EarthQuake")
        UIHelper.showToast("^FFFF00EARTHQUAKE!")
        self.quakeTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            local jx = (math.random() - 0.5) * 0.6
            local jz = (math.random() - 0.5) * 0.6
            pcall(function() p:setVelocity(VectorUtil.newVector3(jx, 0.05, jz)) end)
        end, 60, -1)
    else
        UIHelper.showToast("^FF0000Earthquake OFF")
    end
end

function GMHelper:Tornado(btn)
    local on = nToggle(self, "tornadoOn", "Tornado")
    if self.tornadoTimer then LuaTimer:cancel(self.tornadoTimer); self.tornadoTimer = nil end
    if on then
        AddButton("Tornado", "Tornado")
        UIHelper.showToast("^00FFFFTORNADO!")
        local angle = 0
        self.tornadoTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p then return end
            angle = angle + 0.5
            local vx = math.cos(angle) * 0.8
            local vz = math.sin(angle) * 0.8
            pcall(function()
                p.rotationYaw = math.deg(angle) % 360
                p:setVelocity(VectorUtil.newVector3(vx, 0.3, vz))
            end)
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Tornado OFF")
    end
end

function GMHelper:MoonGravity(btn)
    local on = nToggle(self, "moonOn", "MoonGravity")
    if self.moonTimer then LuaTimer:cancel(self.moonTimer); self.moonTimer = nil end
    if on then
        AddButton("Moon", "MoonGravity")
        UIHelper.showToast("^00FF00Moon Gravity ON")
        self.moonTimer = LuaTimer:scheduleTimer(function()
            local _, p = nGetPlayer()
            if not p or p.onGround then return end
            pcall(function() p:setVelocity(VectorUtil.newVector3(0, -0.03, 0)) end)
        end, 50, -1)
    else
        UIHelper.showToast("^FF0000Moon Gravity OFF")
    end
end

function GMHelper:PlayerMagnet(btn)
    local on = nToggle(self, "magnetOn", "PlayerMagnet")
    if self.magnetTimer then LuaTimer:cancel(self.magnetTimer); self.magnetTimer = nil end
    if on then
        AddButton("Magnet", "PlayerMagnet")
        UIHelper.showToast("^00FF00Player Magnet ON")
        self.magnetTimer = LuaTimer:scheduleTimer(function()
            local me = PlayerManager:getClientPlayer()
            if not me or not me.Player then return end
            local myPos = me.Player:getPosition()
            local players = PlayerManager:getPlayers()
            if not myPos or not players then return end
            for _, t in pairs(players) do
                if t and t ~= me and t.getPosition and t:getPosition() then
                    local tp = t:getPosition()
                    if MathUtil:distanceSquare3d(tp, myPos) < 400 then
                        pcall(function() t:setPosition(VectorUtil.newVector3(myPos.x, myPos.y, myPos.z)) end)
                    end
                end
            end
        end, 100, -1)
    else
        UIHelper.showToast("^FF0000Player Magnet OFF")
    end
end

function GMHelper:Yeet()
    local target = nNearestPlayer(2500)
    if not target then UIHelper.showToast("^FF0000No target to yeet") return end
    pcall(function() target:setVelocity(VectorUtil.newVector3(0, 5, 0)) end)
    local nm = (target.getName and target:getName()) or "player"
    UIHelper.showToast("^FFFF00YEETED " .. tostring(nm) .. " to the moon!")
end

function GMHelper:Backflip()
    local _, p = nGetPlayer()
    if not p then UIHelper.showToast("^FF0000No player") return end
    pcall(function() p:setVelocity(VectorUtil.newVector3(0, 0.9, 0)) end)
    local startPitch = p:getPitch() or 0
    local steps = 0
    LuaTimer:scheduleTimer(function()
        steps = steps + 1
        pcall(function() p.rotationPitch = (startPitch + steps * 36) % 360 end)
    end, 20, 10)
    UIHelper.showToast("^00FFFFBackflip!")
end

function GMHelper:GhostMode(btn)
    local on = nToggle(self, "ghostOn", "GhostMode")
    if self.ghostTimer then LuaTimer:cancel(self.ghostTimer); self.ghostTimer = nil end
    if on then
        AddButton("Ghost", "GhostMode")
        UIHelper.showToast("^00FF00Ghost Mode ON (fly + noclip)")
        pcall(function() ClientHelper.putBoolPrefs("SyncClientPositionToServer", true) end)
        local _, p = nGetPlayer()
        if p then pcall(function() p:setAllowFlying(true); p:setFlying(true) end) end
        self.ghostTimer = LuaTimer:scheduleTimer(function()
            local _, pp = nGetPlayer()
            if pp then pcall(function() pp.noClip = true end) end
        end, 100, -1)
    else
        local _, p = nGetPlayer()
        if p then pcall(function() p.noClip = false; p:setFlying(false) end) end
        UIHelper.showToast("^FF0000Ghost Mode OFF")
    end
end

function GMHelper:ConfettiRain()
    local parts = { "^FF0000@", "^00FF00*", "^0000FF+", "^FFFF00o", "^FF00FF#", "^00FFFF~" }
    LuaTimer:scheduleTimer(function()
        local line = ""
        for _ = 1, 6 do
            line = line .. parts[math.random(#parts)] .. "  "
        end
        UIHelper.showToast(line)
    end, 200, 15)
    UIHelper.showToast("^FF00FFConfetti Rain!")
end

function GMHelper:RubberBand(btn)
    local on = nToggle(self, "rubberOn", "RubberBand")
    if self.rubberTimer then LuaTimer:cancel(self.rubberTimer); self.rubberTimer = nil end
    if on then
        AddButton("Rubber", "RubberBand")
        UIHelper.showToast("^00FF00Rubber Band ON")
        local _, p = nGetPlayer()
        local a = p and p:getPosition()
        self.rubberAnchor = a and VectorUtil.newVector3(a.x, a.y, a.z) or nil
        self.rubberTimer = LuaTimer:scheduleTimer(function()
            if not self.rubberAnchor then return end
            local _, pp = nGetPlayer()
            if not pp then return end
            pcall(function() pp:setVelocity(VectorUtil.newVector3((math.random()-0.5)*4, 0.5, (math.random()-0.5)*4)) end)
            LuaTimer:scheduleTimer(function() Teleport(self.rubberAnchor) end, 300, 1)
        end, 800, -1)
    else
        UIHelper.showToast("^FF0000Rubber Band OFF")
    end
end


function GMHelper:Lying()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 15)
    UIHelper.showToast("^00FF00Pose: Lying")
end

function GMHelper:Sit()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 12)
    UIHelper.showToast("^00FF00Pose: Sit")
end

function GMHelper:Sit2()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 13)
    UIHelper.showToast("^00FF00Pose: Sit 2")
end

function GMHelper:Flyg()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 2)
    UIHelper.showToast("^00FF00Pose: Fly")
end

function GMHelper:Climb()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 9)
    UIHelper.showToast("^00FF00Pose: Climb")
end

function GMHelper:Climb2()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 10)
    UIHelper.showToast("^00FF00Pose: Climb 2")
end

function GMHelper:Sneaky()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 1008)
    UIHelper.showToast("^00FF00Pose: Sneaky")
end

function GMHelper:Swim()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 7)
    UIHelper.showToast("^00FF00Pose: Swim")
end

function GMHelper:Float()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 8)
    UIHelper.showToast("^00FF00Pose: Float")
end

function GMHelper:Run()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", true)
    HostApi.setClientAction(player, 0, 2, 1)
    UIHelper.showToast("^00FF00Pose: Run")
end

function GMHelper:ResetPose()
    local clientPlayer = PlayerManager:getClientPlayer()
    if not clientPlayer or not clientPlayer.Player then return end
    local player = clientPlayer.Player
    player:setBoolProperty("DisableUpdateAnimState", false)
    HostApi.setClientAction(player, 0, 2, 0)
    UIHelper.showToast("^FF0000Pose: Reset")
end

function GMHelper:KillAura()
    togKillAura = not togKillAura
    _G["togKillAura"] = togKillAura
    reButtonColorUI("KillAura")

    if togKillAura then
        AddButton("Kill Aura", "KillAura")
        UIHelper.showToast("KillAura: ^00FF00Enabled")

        if not killAuraTimer then
            killAuraTimer = LuaTimer:scheduleTimer(function()
                local me = PlayerManager:getClientPlayer()
                if not (me and me.Player) then
                    return
                end

                local myPos = me.Player:getPosition()
                local allPlayers = PlayerManager:getPlayers()
                if not allPlayers then
                    return
                end

                local targets = {}

                for _, p in ipairs(allPlayers) do
                    if p ~= me and p.Player and p:isEntityAlive() then
                        local pPos = p.Player:getPosition()
                        local dx, dy, dz = pPos.x - myPos.x, pPos.y - myPos.y, pPos.z - myPos.z
                        local dist = math.sqrt(dx * dx + dy * dy + dz * dz)

                        if dist <= 6.00 then
                            table.insert(targets, {
                                id = p.Player.entityId,
                                pos = pPos,
                                distance = dist,
                            })
                        end
                    end
                end

                table.sort(targets, function(a, b)
                    return a.distance < b.distance
                end)

                for _, target in ipairs(targets) do
                    local roundedPos = VectorUtil.newVector3(
                        math.floor(target.pos.x),
                        math.floor(target.pos.y),
                        math.floor(target.pos.z)
                    )
                    Zentex(target.id, roundedPos)
                end
            end, 600, -1)
        end
    else
        UIHelper.showToast("KillAura: ^FF0000Disabled")

        if killAuraTimer then
            LuaTimer:cancel(killAuraTimer)
            killAuraTimer = nil
        end
    end
end

local function print_table(node, name, indent)
    indent = indent or ""
    name = name or "Data"
    if type(node) ~= "table" then
        print(indent .. name .. " = " .. tostring(node))
        return
    end

    print(indent .. name .. " = {")
    for k, v in pairs(node) do
        local key = type(k) == "string" and '["' .. k .. '"]' or "[" .. tostring(k) .. "]"
        if type(v) == "table" then
            print_table(v, key, indent .. "  ")
        else
            local value = type(v) == "string" and '"' .. v .. '"' or tostring(v)
            print(indent .. "  " .. key .. " = " .. value)
        end
    end
    print(indent .. "}")
end

function GMHelper:SelectSkinById()
    self:openInput({ "Nhập ID Skin" }, function(inputValue)
        local skinId = tonumber(inputValue)
        if not skinId then 
            UIHelper.showToast("^FF0000Lỗi: ID Skin không hợp lệ!")
            return 
        end
        WebService.GetPlayerDecoration(skinId, function(decorationData)
            if not decorationData or #decorationData == 0 then 
                UIHelper.showToast("^FF0000Lỗi: Không tìm thấy dữ liệu!")
                return 
            end
            local skinMap = {
                ["custom_crown"]   = "m_crownId",
                ["custom_hair"]    = "m_hairID", 
                ["custom_face"]    = "m_faceID",
                ["custom_glasses"] = "m_glassesId",
                ["custom_scarf"]   = "m_scarfId",
                ["custom_wing"]    = "m_wingId",
                ["clothes_tops"]   = "m_topsID",
                ["clothes_pants"]  = "m_pantsID",
                ["custom_shoes"]   = "m_shoesID",
                ["custom_hat"]     = "m_hatId",
                ["custom_tail"]    = "m_tailId"
            }
            local me = PlayerManager:getClientPlayer()
            if not me or not me.Player then return end
            local p = me.Player
            local hasChangedSkin = false
            for _, data in ipairs(decorationData) do
                if data.slave and data.master then
                    local masterStr = tostring(data.master)
                    local slaveId = tonumber(data.slave) or 0
                    local propName = skinMap[masterStr]
                    if propName then
                        p[propName] = slaveId
                        hasChangedSkin = true
                    end
                    if type(ChangeSkin) == "function" then
                        pcall(function() ChangeSkin(slaveId, masterStr) end)
                    end
                end
            end
            
            if hasChangedSkin then
                p.m_outLooksChanged = true 
                UIHelper.showToast("^00FF00[+] Đã apply Skin ID: " .. skinId)
            else
                UIHelper.showToast("^FF0000[-] Dữ liệu Skin bị thiếu hoặc không khớp!")
            end
        end)
    end)
end


function GMHelper:realmItemExtendedGiver()
    GMHelper:openInput({ "", "" }, function(itemIdStr, metaStr)
        local itemId = tonumber(itemIdStr) or 0
        local meta   = tonumber(metaStr) or 0

        local data = string.format(
            "hotbarIndex=0&isAdd=1&isEditMode=1&itemId=%d&meta=%d",
            itemId,
            meta
        )

        PacketSender:sendClientCommonData(
            "BlockCityStorageOperation", 
            "",                         
            data                        
        )
    end)
end

local TestRealmTimer = nil

function GMHelper:testRealm()
    self.testRealmOn = not self.testRealmOn
    _G["togTestRealm"] = self.testRealmOn
    if TestRealmTimer then
        LuaTimer:cancel(TestRealmTimer)
        TestRealmTimer = nil
    end
    if not self.testRealmOn then
        UIHelper.showToast("^FF0000testRealm OFF")
        return
    end
    UIHelper.showToast("^00FF00testRealm ON")
    local itemId = 10000
    local meta   = 0
    local data = string.format(
        "hotbarIndex=0&isAdd=1&isEditMode=1&itemId=%d&meta=%d",
        itemId,
        meta
    )
    TestRealmTimer = LuaTimer:scheduleTimer(function()
    for i = 1, 5 do
        PacketSender:sendClientCommonData(
            "BlockCityStorageOperation",
            "",
            data
        )
    end
end, 0.05, -1)
end


function Tptogirls()
local players = PlayerManager:getPlayers()
local found = false
for _, player in pairs(players) do
    if player.Player:getSex() ~= 1 then
        local position = player.Player:getPosition()
        position.y = position.y + 2
        PlayerManager:getClientPlayer().Player:setPosition(position)
        found = true
    end
end
if not found then
    UIHelper.showToast("No girls dickhead")
end
end


function GMHelper:DevFly(btn)
    self.devFlyEnabled = not self.devFlyEnabled
    _G["togDevFly"] = self.devFlyEnabled
    if reButtonColorUI then pcall(reButtonColorUI, "DevFly") end

    local meWrapper = PlayerManager:getClientPlayer()
    local player = meWrapper and meWrapper.Player
    if not player then
        self.devFlyEnabled = false
        _G["togDevFly"] = false
        UIHelper.showToast("^FF0000No player")
        return
    end
    if not self.devFlyButton then
        local b = GUIManager:createGUIWindow(GUIType.Button, "GUIRoot-DevFly")
        b:SetHorizontalAlignment(HorizontalAlignment.Right)
        b:SetVerticalAlignment(VerticalAlignment.Bottom)
        b:SetLevel(50)
        b:SetTouchable(true)
        b:SetBackgroundColor({0, 0, 0, 0})
        b:SetVisible(false)
        b:SetNormalImage("set:fly_control.json image:luodi")
        b:SetPushedImage("set:fly_control.json image:luodi")
        b:SetArea(b:GetXPosition(), b:GetYPosition(), { 0, 70 }, { 0, 70 })
        GUISystem.Instance():GetRootWindow():AddChildWindow(b)
        self.devFlyButton = b

        b:registerEvent(GUIEvent.ButtonClick, function()
            local mw = PlayerManager:getClientPlayer()
            local p = mw and mw.Player
            if not p then return end

            if self.devFlyWatch then LuaTimer:cancel(self.devFlyWatch) end
            self.devFlyWatch = LuaTimer:scheduleTimer(function()
                local w = PlayerManager:getClientPlayer()
                local pp = w and w.Player
                if not pp then
                    if self.devFlyWatch then LuaTimer:cancel(self.devFlyWatch); self.devFlyWatch = nil end
                    return
                end
                if pp:getIsFlying() then
                    self.devFlyButton:SetVisible(false)
                else
                    self.devFlyButton:SetVisible(true)
                    pp:setSpeedAdditionLevel(0)
                    if self.devFlyWatch then LuaTimer:cancel(self.devFlyWatch); self.devFlyWatch = nil end
                end
            end, 50, -1)

            p:setAllowFlying(true)
            p:setSpeedAdditionLevel(SpeedHackValue or 500)
            p:setFlying(true)
            p:moveEntity(VectorUtil.newVector3(0, 1.35, 0))
        end)
    end

    self.devFlyButton:SetVisible(false)

    if self.devFlyEnabled then
        self.devFlyButton:SetVisible(true)
        player:setAllowFlying(true)
        player:setSpeedAdditionLevel(SpeedHackValue or 500)
        player:setFlying(true)
        player:moveEntity(VectorUtil.newVector3(0, 1.35, 0))
        UIHelper.showToast("^00FF00DevFly ON")
    else
        if self.devFlyWatch then LuaTimer:cancel(self.devFlyWatch); self.devFlyWatch = nil end
        UIHelper.showToast("^FF0000DevFly OFF")
    end
end

local gm_gcube_save_path = "/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/Download/SandboxOL/BlockMan/config/MyGC.txt"
local g_giveCubesTimer  = nil
local g_animationTarget  = 0
local g_updateInterval   = 16
local gm_autoSaveTimer   = nil

local function applyAllCurrencies(value)
    value = math.floor(value)
    local cp = Game and Game:getPlayer()
    if cp and cp:getWallet() then
        local wallet = cp:getWallet()
        pcall(function() wallet.m_diamondBlues = value end)
        pcall(function() wallet.m_Currency     = value end)
        pcall(function() wallet.m_diamondGolds = value end)
        pcall(function() wallet:setGolds(value) end)
    end
    pcall(function()
        if PlayerWallet and CurrencyId then
            PlayerWallet:setMoneyCount(CurrencyId.Currency, value)
        end
    end)
end
local function g_getGolds()
    local cp = Game and Game:getPlayer()
    if cp and cp:getWallet() then return cp:getWallet().m_diamondGolds or 0 end
    return 0
end
local function g_startCubesAnimation()
    if g_giveCubesTimer then return end
    g_giveCubesTimer = LuaTimer:scheduleTimer(function()
        local cp = Game and Game:getPlayer()
        if not (cp and cp:getWallet()) then
            LuaTimer:cancel(g_giveCubesTimer); g_giveCubesTimer = nil
            return
        end
        local current = cp:getWallet().m_diamondGolds or 0
        if current >= g_animationTarget or math.abs(current - g_animationTarget) < 1 then
            applyAllCurrencies(g_animationTarget)
            LuaTimer:cancel(g_giveCubesTimer); g_giveCubesTimer = nil
            return
        end
        local remaining = g_animationTarget - current
        local increment = math.max(1, remaining * 0.1)
        local newCubes  = current + increment
        if newCubes > g_animationTarget then newCubes = g_animationTarget end
        applyAllCurrencies(newCubes)
    end, g_updateInterval, -1)
end

local function addCubesToTarget(amount)
    local cp = Game and Game:getPlayer()
    if not (cp and cp:getWallet()) then
        UIHelper.showToast("^FF0000Failed to give G-Cubes")
        return
    end
    local current = cp:getWallet().m_diamondGolds or 0
    g_animationTarget = math.max(current, g_animationTarget) + amount
    UIHelper.showToast(string.format("^00FF00+%s G-Cubes!", tostring(amount)))
    g_startCubesAnimation()
end

function GMHelper:GiveGCubes_1()   addCubesToTarget(1)   end
function GMHelper:GiveGCubes_2()   addCubesToTarget(2)   end
function GMHelper:GiveGCubes_5()   addCubesToTarget(5)   end
function GMHelper:GiveGCubes_10()  addCubesToTarget(10)  end
function GMHelper:GiveGCubes_20()  addCubesToTarget(20)  end
function GMHelper:GiveGCubes_50()  addCubesToTarget(50)  end
function GMHelper:GiveGCubes_100() addCubesToTarget(100) end
function GMHelper:GiveGCubes_200() addCubesToTarget(200) end
function GMHelper:GiveGCubes_500() addCubesToTarget(500) end
function GMHelper:GiveGCubes_1k()   addCubesToTarget(1000)    end
function GMHelper:GiveGCubes_2k()   addCubesToTarget(2000)    end
function GMHelper:GiveGCubes_5k()   addCubesToTarget(5000)    end
function GMHelper:GiveGCubes_10k()  addCubesToTarget(10000)   end
function GMHelper:GiveGCubes_20k()  addCubesToTarget(20000)   end
function GMHelper:GiveGCubes_50k()  addCubesToTarget(50000)   end
function GMHelper:GiveGCubes_100k() addCubesToTarget(100000)  end
function GMHelper:GiveGCubes_200k() addCubesToTarget(200000)  end
function GMHelper:GiveGCubes_500k() addCubesToTarget(500000)  end
function GMHelper:GiveGCubes_1M()   addCubesToTarget(1000000)    end
function GMHelper:GiveGCubes_2M()   addCubesToTarget(2000000)    end
function GMHelper:GiveGCubes_5M()   addCubesToTarget(5000000)    end
function GMHelper:GiveGCubes_10M()  addCubesToTarget(10000000)   end
function GMHelper:GiveGCubes_20M()  addCubesToTarget(20000000)   end
function GMHelper:GiveGCubes_50M()  addCubesToTarget(50000000)   end
function GMHelper:GiveGCubes_100M() addCubesToTarget(100000000)  end
function GMHelper:GiveGCubes_200M() addCubesToTarget(200000000)  end
function GMHelper:GiveGCubes_500M() addCubesToTarget(500000000)  end
function GMHelper:GiveGCubes_1B()   addCubesToTarget(1000000000)    end
function GMHelper:GiveGCubes_2B()   addCubesToTarget(2000000000)    end
function GMHelper:GiveGCubes_5B()   addCubesToTarget(5000000000)    end
function GMHelper:GiveGCubes_10B()  addCubesToTarget(10000000000)   end
function GMHelper:GiveGCubes_20B()  addCubesToTarget(20000000000)   end
function GMHelper:GiveGCubes_50B()  addCubesToTarget(50000000000)   end
function GMHelper:GiveGCubes_100B() addCubesToTarget(100000000000)  end
function GMHelper:GiveGCubes_200B() addCubesToTarget(200000000000)  end

function GMHelper:GiveGCubes_MAX()
    g_animationTarget = 999999999999
    applyAllCurrencies(g_animationTarget)
    UIHelper.showToast("^FFFF00G-Cubes set to MAX!")
    g_startCubesAnimation()
end

function GMHelper:GiveGCubes_Reset()
    if g_giveCubesTimer then LuaTimer:cancel(g_giveCubesTimer); g_giveCubesTimer = nil end
    g_animationTarget = 0
    applyAllCurrencies(0)
    UIHelper.showToast("^FF0000G-Cubes Reset to 0")
end

function GMHelper:GiveGCubes_Set()
    GMHelper:openInput({ "Enter the amount of G-Cubes you want" }, function(amountStr)
        local amount = tonumber(amountStr)
        if not amount or amount < 0 then
            UIHelper.showToast("^FF0000Invalid number!")
            return
        end
        if amount == 0 then
            GMHelper:GiveGCubes_Reset()
            return
        end
        g_animationTarget = math.floor(amount)
        applyAllCurrencies(g_animationTarget)
        UIHelper.showToast(string.format("^00FF00Set G-Cubes to %d!", g_animationTarget))
        g_startCubesAnimation()
    end)
end

function GMHelper:Gcubeinf(btn)
    self.gcubeInfEnabled = not self.gcubeInfEnabled
    _G["togGcubeinf"] = self.gcubeInfEnabled
    if reButtonColorUI then pcall(reButtonColorUI, "Gcubeinf") end
    if self.gcubeInfEnabled then
        g_animationTarget = 999999999
        if self.gcubeInfTimer then LuaTimer:cancel(self.gcubeInfTimer) end
        self.gcubeInfTimer = LuaTimer:scheduleTimer(function()
            applyAllCurrencies(999999999)
        end, 1000, -1)
        UIHelper.showToast("^00FF00Hack GCube ON")
    else
        if self.gcubeInfTimer then LuaTimer:cancel(self.gcubeInfTimer); self.gcubeInfTimer = nil end
        UIHelper.showToast("^FF0000Hack GCube OFF")
    end
end
local function WriteValueToFile(path, value)
    local open_func = original_io_open or io.open
    local file = open_func(path, "w")
    if not file then return false end
    file:write(tostring(value))
    file:close()
    return true
end

function GMHelper:LoadSavedGCubes()
    local open_func = original_io_open or io.open
    local file = open_func(gm_gcube_save_path, "r")
    if not file then return end -- <-- ДОБАВЛЕНА ПРОВЕРКА
    local content = file:read("*a")
    file:close()
    local saved = tonumber(content)
    if saved and saved > 0 then
        g_animationTarget = saved
        applyAllCurrencies(saved)
    end
end

function GMHelper:ToggleAutoSaveGCubes()
    gm_autoSaveTimer = LuaTimer:scheduleTimer(function()
        WriteValueToFile(gm_gcube_save_path, g_getGolds())
    end, 1500, -1)
end

function GMHelper:setupDeathTriggerTimer()
    if CEvents and CEvents.LuaPlayerDeathEvent then
        CEvents.LuaPlayerDeathEvent:registerCallBack(function(deadPlayerId)
            if deadPlayerId == CGame.Instance():getPlatformUserId() then
                LuaTimer:scheduleTimer(function()
                    if g_animationTarget and g_animationTarget > 0 then
                        applyAllCurrencies(g_animationTarget)
                    end
                end, 10, 700)
            end
        end)
    end
end

local player = PlayerManager:getClientPlayer()
--- Generated by EmmyLua(https://github.com/EmmyLua)
--- Created by 10184.
--- DateTime: 2022/9/19 20:16
---
---@type PassSeasonConfig
local PassSeasonConfig = T(Global, "PassSeasonConfig")
---@type PassConfig
local PassConfig = T(Global, "PassConfig")

GMSetting:addTab("Battle Pass")
GMSetting:addItem("Battle Pass", "Open UI", "openPassUI")
GMSetting:addItem("Battle Pass", "View Data", "printPassData")
GMSetting:addItem("Battle Pass", "Reset Pass", "resetPass")
GMSetting:addItem("Battle Pass", "Start Newest Season", "startNewestPassSeason")
GMSetting:addItem("Battle Pass", "Upgrade VIP", "upgradePassVip")
GMSetting:addItem("Battle Pass", "Set First Buy True", "setFirstBuy", true)
GMSetting:addItem("Battle Pass", "Set First Buy False", "setFirstBuy", false)
GMSetting:addItem("Battle Pass", "Enable All Tasks", "startAllPassTask")
GMSetting:addItem("Battle Pass", "", "")
GMSetting:addItem("Battle Pass", "EXP +100", "addPassExp", 100)
GMSetting:addItem("Battle Pass", "EXP +500", "addPassExp", 500)
GMSetting:addItem("Battle Pass", "EXP +1000", "addPassExp", 1000)
GMSetting:addItem("Battle Pass", "EXP +2000", "addPassExp", 2000)
GMSetting:addItem("Battle Pass", "EXP +5000", "addPassExp", 5000)
GMSetting:addItem("Battle Pass", "Score +100", "addPassScore", 100)
GMSetting:addItem("Battle Pass", "Score +500", "addPassScore", 500)
GMSetting:addItem("Battle Pass", "Score +1000", "addPassScore", 1000)
GMSetting:addItem("Battle Pass", "Score +2000", "addPassScore", 2000)
GMSetting:addItem("Battle Pass", "Score +5000", "addPassScore", 5000)



function CPassPkSender:tryGetPassReward(level, isPay)
    self:sendPacket({
        pid = "tryGetPassReward",
        level = level,
        isPay = isPay,
    })
end

function CPassPkSender:tryGetAllPassReward()
    self:sendPacket({
        pid = "tryGetAllPassReward",
    })
end

function CPassPkSender:tryUpgradePassVip(vip)
    self:sendPacket({
        pid = "tryUpgradePassVip",
        vip = vip,
    })
end

function CPassPkSender:tryBuyPassShopItem(id, count)
    self:sendPacket({
        pid = "tryBuyPassShopItem",
        id = id,
        count = count,
    })
end

function CPassPkSender:trySwitchPassEffect(switch)
    self:sendPacket({
        pid = "trySwitchPassEffect",
        switch = switch,
    })
end

function CPassPkSender:tryBuyLevel()
    self:sendPacket({
        pid = "tryBuyLevel",
    })
end


function GMHelper:testPassReward()
CPassPkSender:tryGetPassReward(50, true)
end


function GMHelper:openPassUI()
    UIHelper.showGameGUILayout("GUIPass")
end

function GMHelper:printPassData()
    ---@type DataInfoMgr
    local DataInfoMgr = T(Global, "DataInfoMgr")
    DataInfoMgr:getPassInfo(Game:getPlatformUserId()):print()
end

function GMHelper:startNewestPassSeason()
    --[[if not isTest and not isStaging then
        UIHelper.showToast("This command is not allowed in the production environment")
        return
    end]]
    local cfgs = PassSeasonConfig:getAllCfgs()
    table.sort(cfgs, function(a, b)
        return a.season < b.season
    end)
    local newest = cfgs[#cfgs]
    for _, cfg in pairs(cfgs) do
        if newest ~= cfg then
            cfg.endDate = os.time()
        else
            newest.startDate = os.time()
        end
    end
end

function GMHelper:startAllPassTask()
    --[[if not isTest and not isStaging then
        UIHelper.showToast("This command is not allowed in the production environment")
        return
    end]]
    local tasks = PassConfig.config.tasks
    for _, task in pairs(tasks) do
        if task.key and task.startTime then
            task.startTime = 0
        end
        for _, child in pairs(task.child or {}) do
            if child.key and child.startTime then
                child.startTime = 0
            end
        end
    end
end

---@param player SBasePlayer
function GMHelper:addPassExp(addExp)
    local player = PlayerManager:getClientPlayer()
    if not player or not player.pass then return end

    player.pass:addPassExp(addExp)
    UIHelper.showToast("Đã cộng " .. addExp .. " EXP")
end

---@param player SBasePlayer
function GMHelper:addPassScore(addScore)
    local player = PlayerManager:getClientPlayer()
    if not player or not player.pass then return end

    player.pass:addPassScore(addScore, "GM")
end

function GMHelper:printPassData()
    local player = PlayerManager:getClientPlayer()
    if not player then return end

    ---@type DataInfoMgr
    local DataInfoMgr = T(Global, "DataInfoMgr")
    DataInfoMgr:getPassInfo(player.userId):print()
    UIHelper.showToast("Đã in data ra Console log")
end

function GMHelper:resetPass()
    local player = PlayerManager:getClientPlayer()
    if not player or not player.pass then return end

    -- Xóa cờ ghi nhận và gọi hàm reset
    player.pass.info:setValue(Define.PassInfoKey.PassRecord, {})
    player.pass:resetPlayerPass()
    
    UIHelper.showToast("Đã reset Battle Pass (Lưu ý: Chỉ có tác dụng ở Client)")
end

function GMHelper:startNewestPassSeason()
    --[[if not isTest and not isStaging then
        return
    end]]
    local cfgs = PassSeasonConfig:getAllCfgs()
    table.sort(cfgs, function(a, b)
        return a.season < b.season
    end)
    local newest = cfgs[#cfgs]
    for _, cfg in pairs(cfgs) do
        if newest ~= cfg then
            cfg.endDate = os.time()
        else
            newest.startDate = os.time()
        end
    end
end

---@param player SBasePlayer
function GMHelper:upgradePassVip()
    local player = PlayerManager:getClientPlayer()
    if not player or not player.pass then return end

    player.pass.info:setValue(Define.PassInfoKey.VIP, 2)
    UIHelper.showToast("Đã nâng VIP Pass")
end
function GMHelper:startAllPassTask()
    --[[if not isTest and not isStaging then
        UIHelper.showToast("正式环境不允许使用该指令")
        return
    end]]
    local tasks = PassConfig.config.tasks
    for _, task in pairs(tasks) do
        if task.key and task.startTime then
            task.startTime = 0
        end
        for _, child in pairs(task.child or {}) do
            if child.key and child.startTime then
                child.startTime = 0
            end
        end
    end
end

---@param player SBasePlayer
function GMHelper:setFirstBuy(isFirst)
    -- Tự lấy object người chơi ở Client
    local player = PlayerManager:getClientPlayer()
    if not player or not player.pass then return end

    local record = player.pass.info:getValue(Define.PassInfoKey.PassRecord)
    record.isFirst = isFirst
    player.pass.info:setValue(Define.PassInfoKey.PassRecord, record)
    
    UIHelper.showToast("Set First Buy: " .. tostring(isFirst))
end

-- =====================================================================
-- Free-Reward Ads (Sky Block g1048)
-- The server grants the reward by ad id -> tag -> callback, NOT by item id.
-- Only the two FreeReward ads give a flat reward with no extra params:
--   ad 104806 -> tag FreeReward:70003 -> reward 70003
--   ad 104807 -> tag FreeReward:70001 -> reward 70001
-- We send the exact packet the server expects: DataBuilder params + ad_uuid.
-- =====================================================================

GMSetting:addTab("Ad Rewards")
GMSetting:addItem("Ad Rewards", "Watch Ad -> Reward 70003", "watchAdReward", 104806)
GMSetting:addItem("Ad Rewards", "Skip Ad  -> Reward 70003 (Lazy)", "skipAdReward", 104806)
GMSetting:addItem("Ad Rewards", "", "")
GMSetting:addItem("Ad Rewards", "Watch Ad -> Reward 70001", "watchAdReward", 104807)
GMSetting:addItem("Ad Rewards", "Skip Ad  -> Reward 70001 (Lazy)", "skipAdReward", 104807)

-- Build the params blob exactly like AdvertInfo:tryWatchAdvert does.
function GMHelper:buildAdParams(adId)
    local AdUuid = require "engine_base.util.uuid"
    if not self._adSeeded then
        AdUuid.randomseed(os.time())
        self._adSeeded = true
    end
    local cfg = T(Global, "AdvertConfig"):getCfgById(adId)
    return DataBuilder.new():fromTable({
        ad_type = cfg and cfg.type or "video",
        ad_game = "g1048",
        ad_uuid = AdUuid(),
    }):getData()
end

-- Watch the ad the normal way (real ad on device, instant on test), then claim.
function GMHelper:watchAdReward(adId)
    adId = tonumber(adId)
    if not adId then return end
    ClientHelper.onWatchAd(adId, GMHelper:buildAdParams(adId))
    UIHelper.showToast("^FFFF00Watching ad " .. adId .. " ...")
end

-- Lazy mode: skip the ad, fire the success packet straight to the server.
function GMHelper:skipAdReward(adId)
    adId = tonumber(adId)
    if not adId then return end
    CPassPkSender:onWatchAdSuccess(adId, GMHelper:buildAdParams(adId))
    UIHelper.showToast("^00FF00Ad skipped! Claimed reward from ad " .. adId)
end

function GMHelper:skipAdReward(adId)
    adId = tonumber(adId)
    if not adId then return end
    CPassPkSender:onWatchAdSuccess(adId, GMHelper:buildAdParams(adId))
end

for i = 1, 100000 do
     GMHelper:skipAdReward(adId)
end













































local isSpamming = false
local currentSpamTimer = nil
function GMHelper:ToggleSpamChat()
    isSpamming = not isSpamming
    if isSpamming then
        GMHelper:openInput({ "Nhập nội dung spam:" }, function(content)
            if not content or content == "" then
                isSpamming = false
                return
            end
            local ChatService = T(Global, "ChatService")
            if not ChatService then 
                isSpamming = false
                return 
            end
            if currentSpamTimer then
                LuaTimer:cancel(currentSpamTimer)
                currentSpamTimer = nil
            end
            UIHelper.showToast("Đang SPAM! Ấn lại nút ở Menu để TẮT.")
            currentSpamTimer = LuaTimer:scheduleTimer(function()
                ChatService:sendMsgToLangGroup(Define.ChatMsgType.TextMsg, { content = content })
            end, 150, 999999)
        end)
    else
        if currentSpamTimer then
            LuaTimer:cancel(currentSpamTimer)
            currentSpamTimer = nil
        end
        UIHelper.showToast("Đã TẮT Spam Chat!")
    end
end

-- ============================================================
-- MINE GOD — đào nhanh + buff may mắn (cúp đểu nhất = kim cương)
-- Patch runtime PickaxeConfig + OutputConfig, giữ hàm gốc.
-- ============================================================
GMSetting:addItem("NClient", "", "")
GMSetting:addItem("NClient", "Mine God (Dao Nhanh + May Man)", "MineGod")

MineGodEnabled = false
local _MineGod_origGetCfg   = nil
local _MineGod_origDigTimes = nil
local _MineGod_origOreCheck = nil

function GMHelper:MineGod(btn)
    MineGodEnabled = not MineGodEnabled
    _G["togMineGod"] = MineGodEnabled
    reButtonColorUI("MineGod")

    local PickaxeConfig = T(Global, "PickaxeConfig")
    local OutputConfig  = T(Global, "OutputConfig")

    if MineGodEnabled then
        AddButton("MineGod", "MineGod")

        if PickaxeConfig and not _MineGod_origGetCfg then
            _MineGod_origGetCfg = PickaxeConfig.getPickaxeCfgById
            PickaxeConfig.getPickaxeCfgById = function(self, itemId)
                local cfg = _MineGod_origGetCfg(self, itemId)
                if MineGodEnabled and cfg then
                    cfg.digSpeed   = 1
                    cfg.efficiency = 1
                end
                return cfg
            end

            _MineGod_origDigTimes = PickaxeConfig.getUnitDamageDigTimes
            PickaxeConfig.getUnitDamageDigTimes = function(self, itemId)
                if MineGodEnabled then return 1 end
                return _MineGod_origDigTimes(self, itemId)
            end
        end

        if OutputConfig and not _MineGod_origOreCheck then
            _MineGod_origOreCheck = OutputConfig.checkOreRemoval
            OutputConfig.checkOreRemoval = function(self, itemId)
                if MineGodEnabled then return true end
                return _MineGod_origOreCheck(self, itemId)
            end
        end

        UIHelper.showToast("Mine God: BAT - dao 1 nhat/khoi, khoi nao cung ra loot")
    else
        UIHelper.showToast("Mine God: TAT")
    end
end
