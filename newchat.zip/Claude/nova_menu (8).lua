-- nova_menu.lua v0.8 : standalone animated menu, UI only.
-- Floating draggable button + FPS/Ping/Held-item HUD -> animated panel -> Info tab.
-- Same engine APIs as 1.lua (GUIManager / GUISystem / LuaTimer / registerEvent).
-- Nothing is sent over the network. Not tested in-game.

if _G.NovaMenu then return _G.NovaMenu end
local NovaMenu = { tabs = {} }
_G.NovaMenu = NovaMenu

----------------------------------------------------------------------
-- config
----------------------------------------------------------------------
local W, H     = 840, 480          -- panel size
local SIDE     = 180               -- sidebar width
local HEAD     = 52                -- header height
local ROW_W    = W - SIDE - 30     -- default row width
local FRAME_MS = 16                -- tween tick
local HUD_W    = 220               -- width of the fps/ping text block

local C = {
    clear   = {0, 0, 0, 0},
    bg      = {0.043, 0.051, 0.082, 0.98},
    panel   = {0.067, 0.078, 0.125, 1},
    card    = {0.094, 0.109, 0.165, 1},
    line    = {0.17, 0.19, 0.28, 1},
    off     = {0.20, 0.22, 0.31, 1},
    tabOn   = {0.115, 0.13, 0.20, 1},
    accent  = {0.49, 0.36, 1.00, 1},
    accent2 = {0.25, 0.85, 0.95, 1},
    text    = {0.93, 0.94, 0.98, 1},
    muted   = {0.55, 0.58, 0.70, 1},
    danger  = {0.95, 0.32, 0.38, 1},
    good    = {0.30, 0.90, 0.50, 1},
    warn    = {1.00, 0.80, 0.25, 1},
}

----------------------------------------------------------------------
-- utils
----------------------------------------------------------------------
local uid = 0
local function nid(p) uid = uid + 1; return "NV_" .. p .. "_" .. uid end

local function lerp(a, b, t) return a + (b - a) * t end
local function lerpC(a, b, t)
    return { lerp(a[1], b[1], t), lerp(a[2], b[2], t), lerp(a[3], b[3], t), lerp(a[4], b[4], t) }
end
local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end

local ease = {
    outCubic = function(t) t = 1 - t; return 1 - t * t * t end,
    inCubic  = function(t) return t * t * t end,
}

-- own clock (seconds), so we do not depend on os.clock existing
local clock = 0
local function now() return clock end

local function setAlpha(w, a) pcall(function() w:SetAlpha(a) end) end
local function on(w, ev, fn) pcall(function() w:registerEvent(ev, fn) end) end
local function sound(id) pcall(function() SoundUtil.playSound(id) end) end
local function toast(t) pcall(function() UIHelper.showToast(t) end) end

-- keyed tweens: starting a tween on a key cancels the previous one
local running = {}
local function stop(key)
    if running[key] then LuaTimer:cancel(running[key]); running[key] = nil end
end
local function tween(key, ms, fn, step, done)
    stop(key)
    local frames, f = math.max(1, math.floor(ms / FRAME_MS)), 0
    running[key] = LuaTimer:scheduleTimer(function()
        f = f + 1
        local ok = pcall(step, fn(f / frames))
        if f >= frames or not ok then
            stop(key)
            if done then pcall(done) end
        end
    end, FRAME_MS, -1)
end

----------------------------------------------------------------------
-- widget factory
----------------------------------------------------------------------
local function win(gtype, prefix, parent)
    local w = GUIManager:createGUIWindow(gtype, nid(prefix))
    if parent then parent:AddChildWindow(w) end
    return w
end

local function box(parent, x, y, w, h, col, touch)          -- absolute pixels
    local l = win(GUIType.Layout, "L", parent)
    l:SetArea({0, x}, {0, y}, {0, w}, {0, h})
    l:SetBackgroundColor(col)
    l:SetTouchable(touch == true)
    return l
end

local function text(parent, str, x, y, w, h, col, scale, align)  -- absolute pixels
    local t = win(GUIType.StaticText, "T", parent)
    t:SetArea({0, x}, {0, y}, {0, w}, {0, h})
    t:SetText(str)
    t:SetTextColor(col)
    t:SetTextScale(scale or 1)
    t:SetBackgroundColor(C.clear)
    t:SetTouchable(false)
    t:SetTextHorzAlign(align or HorizontalAlignment.Left)
    t:SetTextVertAlign(VerticalAlignment.Center)
    return t
end

local function button(parent, str, x, y, w, h, bg, fg, scale, onClick)
    local b = win(GUIType.Button, "B", parent)
    b:SetArea({0, x}, {0, y}, {0, w}, {0, h})
    b:SetText(str)
    b:SetTextColor(fg)
    b:SetTextScale(scale or 1)
    b:SetBackgroundColor(bg)
    b:SetTouchable(true)
    if onClick then on(b, GUIEvent.ButtonClick, onClick) end
    return b
end

local function pressFx(b, normal, pressed)
    on(b, GUIEvent.TouchDown, function() b:SetBackgroundColor(pressed) end)
    on(b, GUIEvent.TouchUp,   function() b:SetBackgroundColor(normal) end)
end

----------------------------------------------------------------------
-- state
----------------------------------------------------------------------
local S = {
    pdx = 0, pdy = 0,        -- panel offset from screen center
    fdx = -150, fy = 6,      -- button: x offset from screen center, y from top
    fabSize = 64,
    prog = 0,                -- 0 closed .. 1 open
    cur = nil,               -- current tab index
    closeOutside = true,
    pulse = true,
    hud = true,
    hideBagFull = true,
    learned = "",          -- extra tip texts to hide, separated by |
}
local frame, dim, sidebar, content, indicator, root
local fab, fabInner, fabLabel
local hud = {}               -- hud.fps, hud.ping, hud.item
local INFO = {}              -- live labels of the Info tab

----------------------------------------------------------------------
-- saved settings (positions, toggles) -> small text file
----------------------------------------------------------------------
local SAVE_PATHS = {
    "/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/nova_settings.txt",
    "nova_settings.txt",
}
local NUM_KEYS  = { "pdx", "pdy", "fdx", "fy", "fabSize" }
local BOOL_KEYS = { "hud", "pulse", "closeOutside", "hideBagFull" }
local KNOWN = {}
for _, k in ipairs(NUM_KEYS) do KNOWN[k] = "num" end
for _, k in ipairs(BOOL_KEYS) do KNOWN[k] = "bool" end
KNOWN.learned = "str"

local function markDirty() S._dirty = true end

local function saveSettings()
    local lines = {}
    for _, k in ipairs(NUM_KEYS)  do lines[#lines + 1] = k .. "=" .. tostring(S[k]) end
    for _, k in ipairs(BOOL_KEYS) do lines[#lines + 1] = k .. "=" .. tostring(S[k]) end
    if S.learned ~= "" then lines[#lines + 1] = "learned=" .. S.learned:gsub("[\r\n]", " ") end
    local data = table.concat(lines, "\n")
    for _, path in ipairs(SAVE_PATHS) do
        local ok = pcall(function()
            local f = io.open(path, "w")
            if not f then error("open failed") end
            f:write(data); f:close()
        end)
        if ok then return true end
    end
    return false
end

local function loadSettings()
    for _, path in ipairs(SAVE_PATHS) do
        local data
        pcall(function()
            local f = io.open(path, "r")
            if f then data = f:read("*a"); f:close() end
        end)
        if data and #data > 0 then
            for k, v in data:gmatch("([%w_]+)=([^\n\r]+)") do
                if KNOWN[k] == "num" and tonumber(v) then
                    S[k] = clamp(tonumber(v), -4000, 4000)
                elseif KNOWN[k] == "bool" then
                    S[k] = (v == "true")
                elseif KNOWN[k] == "str" then
                    S[k] = v:sub(1, 600)
                end
            end
            S.fabSize = clamp(S.fabSize, 48, 88)
            return true
        end
    end
    return false
end

----------------------------------------------------------------------
-- menu-style notifications (3 slots, round robin)
----------------------------------------------------------------------
local TOAST = { slots = {}, n = 3, i = 0 }

local function buildToasts(guiRoot)
    for k = 1, TOAST.n do
        local card = box(guiRoot, 0, 0, 340, 42, C.accent)
        card:SetArea({0.5, -170}, {0, 150 + (k - 1) * 48}, {0, 340}, {0, 42})
        local inner = box(card, 1, 1, 338, 40, C.panel)
        local bar = box(inner, 0, 0, 4, 40, C.accent)
        local lbl = text(inner, "", 14, 0, 318, 40, C.text, 0.9)
        pcall(function() card:SetLevel(15) end)
        card:SetVisible(false)
        TOAST.slots[k] = { card = card, bar = bar, lbl = lbl, gen = 0 }
    end
end

local function notify(msg, kind)               -- kind: "ok" | "bad" | nil
    if #TOAST.slots == 0 then toast(msg); return end
    TOAST.i = TOAST.i % TOAST.n + 1
    local k = TOAST.i
    local sl = TOAST.slots[k]
    sl.gen = sl.gen + 1
    local gen = sl.gen
    local col = (kind == "bad") and C.danger or ((kind == "ok") and C.good or C.accent)
    sl.card:SetBackgroundColor(col)
    sl.bar:SetBackgroundColor(col)
    sl.lbl:SetText(msg)
    sl.card:SetVisible(true)
    local y = 150 + (k - 1) * 48
    tween("toast" .. k, 220, ease.outCubic, function(p)
        sl.card:SetArea({0.5, -170}, {0, y - 14 * (1 - p)}, {0, 340}, {0, 42})
        setAlpha(sl.card, p)
    end)
    LuaTimer:schedule(function()
        if sl.gen ~= gen then return end
        tween("toast" .. k, 220, ease.inCubic, function(p)
            sl.card:SetArea({0.5, -170}, {0, y - 14 * p}, {0, 340}, {0, 42})
            setAlpha(sl.card, 1 - p)
        end, function() if sl.gen == gen then sl.card:SetVisible(false) end end)
    end, 2400)
end
NovaMenu.notify = notify

local function homeFab()     -- top of the screen, a bit left of center
    S.fdx, S.fy = -150, 6
end

----------------------------------------------------------------------
-- game info helpers
----------------------------------------------------------------------
local function readStats()
    local fps, ping, held = 0, 0, -1
    pcall(function() fps = Root.Instance():getFPS() or 0 end)
    pcall(function() ping = ClientNetwork.Instance():getRaknetPing() or 0 end)
    pcall(function()
        local p = PlayerManager:getClientPlayer()
        if p and p.Player then held = p.Player:getHeldItemId() or -1 end
    end)
    return fps, ping, held
end

local function fpsColor(v)  return v >= 50 and C.good or (v >= 30 and C.warn or C.danger) end
local function pingColor(v) return v <= 80 and C.good or (v <= 180 and C.warn or C.danger) end

local function gameVersion()
    local v = "?.??.?"
    pcall(function()
        local info = HostApi.getClientInfo()
        if info then
            info = json.decode(info)
            if info and info.app_version then v = info.app_version end
        end
    end)
    return v
end

local function profile()
    local name, id, sex = "Unknown", "?", 1
    pcall(function() id = tostring(CGame.Instance():getPlatformUserId()) end)
    pcall(function()
        local p = PlayerManager:getClientPlayer()
        if p then
            name = p:getName() or name
            if p.Player and p.Player.getSex then sex = p.Player:getSex()
            elseif p.getSex then sex = p:getSex() end
        end
    end)
    return name, id, sex
end

----------------------------------------------------------------------
-- page builder (rows inside a scroll pane)
----------------------------------------------------------------------
-- parent/area optional: default is a full-size page inside `content`
local function newPage(parent, rowW, area)
    local RW = rowW or ROW_W
    local pane = win(GUIType.ScrollablePane, "P", parent or content)
    if area then
        pane:SetArea({0, area[1]}, {0, area[2]}, {0, area[3]}, {0, area[4]})
    else
        pane:SetArea({0, 6}, {0, 6}, {1, -12}, {1, -12})
    end
    pane:InitializeContainer()
    pane:SetProperty("AutoScrollBar", "true")

    local holder = win(GUIType.Layout, "PH")
    holder:SetWidth({0, RW + 6})
    holder:SetHeight({0, 600})

    local ui = { y = 4, pane = pane, holder = holder }

    function ui:section(str)
        text(holder, str:upper(), 4, self.y, RW, 20, C.accent2, 0.8)
        self.y = self.y + 24
    end

    function ui:row(h)
        local card  = box(holder, 0, self.y, RW, h, C.line)
        local inner = box(card, 1, 1, RW - 2, h - 2, C.card)
        self.y = self.y + h + 8
        return inner
    end

    function ui:info(str)                      -- StaticText does not wrap: wrap by hand
        local maxChars = math.floor((RW - 32) / 8.8)
        local lines, cur = {}, ""
        for word in str:gmatch("%S+") do
            if #cur + #word + 1 > maxChars and #cur > 0 then
                lines[#lines + 1] = cur; cur = word
            else
                cur = (#cur > 0) and (cur .. " " .. word) or word
            end
        end
        if #cur > 0 then lines[#lines + 1] = cur end
        local h = 20 + #lines * 20
        local r = self:row(h)
        for k, ln in ipairs(lines) do
            text(r, ln, 16, 10 + (k - 1) * 20, RW - 32, 20, C.muted, 0.88)
        end
    end

    function ui:kv(key, value, col)            -- "key ........ value" row, value updatable
        local r = self:row(38)
        text(r, key, 16, 0, RW * 0.4, 36, C.muted, 0.9)
        local v = text(r, value, RW * 0.4, 0, RW * 0.6 - 18, 36, col or C.text, 0.95, HorizontalAlignment.Right)
        return {
            set = function(str, c)
                v:SetText(str)
                if c then v:SetTextColor(c) end
            end,
        }
    end

    function ui:toggle(title, desc, default, cb)
        local r   = self:row(58)
        local key = nid("tg")
        local state = default and true or false
        text(r, title, 16, 8, RW - 100, 20, C.text, 1)
        text(r, desc,  16, 31, RW - 100, 18, C.muted, 0.78)
        local track = box(r, RW - 66, 18, 44, 20, state and C.accent or C.off)
        local knob  = box(track, state and 26 or 2, 2, 16, 16, C.text)

        local function render(v, animate)
            local x0, x1 = v and 2 or 26, v and 26 or 2
            local c0, c1 = v and C.off or C.accent, v and C.accent or C.off
            if not animate then
                knob:SetArea({0, x1}, {0, 2}, {0, 16}, {0, 16}); track:SetBackgroundColor(c1); return
            end
            tween(key, 180, ease.outCubic, function(p)
                knob:SetArea({0, lerp(x0, x1, p)}, {0, 2}, {0, 16}, {0, 16})
                track:SetBackgroundColor(lerpC(c0, c1, p))
            end)
        end

        button(r, "", 0, 0, RW - 2, 56, C.clear, C.text, 1, function()
            state = not state
            render(state, true)
            sound(state and 70 or 0)
            if cb then pcall(cb, state) end
        end)
        return {
            get = function() return state end,
            set = function(v) state = v and true or false; render(state, true) end,
        }
    end

    function ui:stepper(title, desc, min, max, step, default, cb)
        local r, val = self:row(58), default
        text(r, title, 16, 8, RW - 180, 20, C.text, 1)
        text(r, desc,  16, 31, RW - 180, 18, C.muted, 0.78)
        local lbl = text(r, tostring(val), RW - 96, 13, 44, 30, C.text, 1, HorizontalAlignment.Center)
        local function bump(d)
            val = clamp(val + d, min, max)
            lbl:SetText(tostring(val))
            sound(0)
            if cb then pcall(cb, val) end
        end
        local m = button(r, "-", RW - 136, 12, 34, 32, C.off, C.text, 1.1, function() bump(-step) end)
        local p = button(r, "+", RW - 50,  12, 34, 32, C.accent, C.text, 1.1, function() bump(step) end)
        pressFx(m, C.off, C.line); pressFx(p, C.accent, C.accent2)
        return { get = function() return val end }
    end

    function ui:action(title, cb)
        local r = self:row(46)
        local b = button(r, title, 6, 6, RW - 14, 32, C.accent, C.text, 0.95, function()
            sound(4)
            if cb then pcall(cb) end
        end)
        pressFx(b, C.accent, C.accent2)
    end

    function ui:finish()
        holder:SetHeight({0, self.y + 8})
        pane:AddItem(holder)
    end
    return ui
end

----------------------------------------------------------------------
-- tabs
----------------------------------------------------------------------
local function tabY(i) return 16 + (i - 1) * 54 end
local indY = 16

local function selectTab(i, instant)
    if i == S.cur or not NovaMenu.tabs[i] then return end
    local old = S.cur
    S.cur = i

    local fromY, toY = indY, tabY(i)
    tween("ind", instant and FRAME_MS or 240, ease.outCubic, function(p)
        indY = lerp(fromY, toY, p)
        indicator:SetArea({0, 0}, {0, indY}, {0, 3}, {0, 46})
    end)

    for k, t in ipairs(NovaMenu.tabs) do
        t.btn:SetTextColor(k == i and C.text or C.muted)
        t.btn:SetBackgroundColor(k == i and C.tabOn or C.clear)
    end

    if old and NovaMenu.tabs[old] then
        local op = NovaMenu.tabs[old].ui.pane
        stop("pin" .. old)
        tween("pout" .. old, 120, ease.inCubic, function(p) setAlpha(op, 1 - p) end,
            function() op:SetVisible(false) end)
    end
    local np = NovaMenu.tabs[i].ui.pane
    stop("pout" .. i)
    np:SetVisible(true)
    tween("pin" .. i, instant and FRAME_MS or 260, ease.outCubic, function(p)
        setAlpha(np, p)
        np:SetArea({0, 6 + (1 - p) * 18}, {0, 6}, {1, -12}, {1, -12})
    end)
    local t = NovaMenu.tabs[i]
    if t.onShow then pcall(t.onShow) end
end

-- builder(ui) for a normal scrolling page.
-- custom=true: builder(host) gets a plain full-size Layout and must return nothing special.
function NovaMenu.addTab(name, builder, custom)
    local i = #NovaMenu.tabs + 1
    local btn = button(sidebar, "   " .. name, 0, tabY(i), SIDE, 46, C.clear, C.muted, 0.95, function()
        sound(0)
        selectTab(i)
    end)
    pcall(function() btn:SetTextHorzAlign(HorizontalAlignment.Left) end)

    local ui, onShow
    if custom then
        local host = box(content, 6, 6, W - 2 - SIDE - 12, H - 2 - HEAD - 1 - 12, C.clear)
        host:SetArea({0, 6}, {0, 6}, {1, -12}, {1, -12})
        host:SetVisible(false)
        local okb, ret = pcall(builder, host)
        ui = { pane = host }
        if okb and type(ret) == "table" then onShow = ret.onShow end
    else
        ui = newPage()
        ui.pane:SetVisible(false)
        local okb, ret = pcall(builder, ui)
        if okb and type(ret) == "table" then onShow = ret.onShow end
        ui:finish()
    end
    NovaMenu.tabs[i] = { name = name, btn = btn, ui = ui, onShow = onShow }
    if not S.cur then selectTab(i, true) end
    return ui
end

----------------------------------------------------------------------
-- floating button + hud (positions)
----------------------------------------------------------------------
-- all positions are anchored to the screen center ({0.5, offset}) so they stay
-- centered whatever unit scale the engine uses
local function placeFab()
    local s = S.fabSize
    S.fy = math.max(0, S.fy)
    fab:SetArea({0.5, S.fdx - s / 2}, {0, S.fy}, {0, s}, {0, s})
    fabInner:SetArea({0, 3}, {0, 3}, {0, s - 6}, {0, s - 6})
    fabLabel:SetArea({0, 0}, {0, 0}, {0, s - 6}, {0, s - 6})
    pcall(function() fabLabel:SetTextScale(s / 40) end)

    local hy = S.fy + s + 4
    hud.fps:SetArea({0.5, S.fdx - HUD_W / 2}, {0, hy}, {0, HUD_W / 2}, {0, 24})
    hud.ping:SetArea({0.5, S.fdx}, {0, hy}, {0, HUD_W / 2}, {0, 24})
    hud.item:SetArea({0.5, S.fdx - HUD_W / 2}, {0, hy + 24}, {0, HUD_W}, {0, 24})
end

local function setHudVisible(v)
    for _, k in ipairs({ "fps", "ping", "item" }) do hud[k]:SetVisible(v) end
end

local function updateStats()
    local fps, ping, held = readStats()
    if S.hud then
        hud.fps:SetText(string.format("FPS %d", fps));   hud.fps:SetTextColor(fpsColor(fps))
        hud.ping:SetText(string.format("Ping %d", ping)); hud.ping:SetTextColor(pingColor(ping))
        hud.item:SetText(held >= 0 and ("Held item: " .. held) or "Held item: -")
    end
    if S.prog > 0.5 and INFO.fps then
        INFO.fps.set(tostring(fps), fpsColor(fps))
        INFO.ping.set(ping .. " ms", pingColor(ping))
        INFO.held.set(held >= 0 and tostring(held) or "-")
    end
end

----------------------------------------------------------------------
-- open / close (single progress value, safe to spam)
----------------------------------------------------------------------
local function placePanel(off)
    frame:SetArea({0.5, -W / 2 + S.pdx}, {0.5, -H / 2 + S.pdy + (off or 0)}, {0, W}, {0, H})
end

local function applyProg(p)
    S.prog = p
    setAlpha(frame, p)
    placePanel((1 - p) * 24)
    dim:SetBackgroundColor({0, 0, 0, 0.55 * p})
    if fab then fab:SetBackgroundColor(lerpC(C.accent, C.accent2, p)) end   -- border follows state
end

local function refreshProfile()
    if not INFO.name then return end
    local name, id, sex = profile()
    INFO.name:SetText(name)
    INFO.id:SetText("ID " .. id)
    INFO.sex.set(sex == 2 and "Girl" or "Boy")
    pcall(function()
        INFO.aw:SetActor1(sex == 2 and "girl.actor" or "boy.actor", "idle", 105)
        INFO.aw:SetActorByUserId(id, 0)
    end)
end

local function animateTo(target)
    local from = S.prog
    if target == 1 then
        root:SetVisible(true); sound(4); pcall(refreshProfile)
        local ct = NovaMenu.tabs[S.cur or 0]
        if ct and ct.onShow and ct ~= NovaMenu.tabs[1] then pcall(ct.onShow) end
    else
        sound(0)
    end
    local ms = math.max(60, 260 * math.abs(target - from))
    tween("panel", ms, target == 1 and ease.outCubic or ease.inCubic,
        function(p) applyProg(lerp(from, target, p)) end,
        function() if target == 0 then root:SetVisible(false) end end)
end

function NovaMenu.open()   animateTo(1) end
function NovaMenu.close()  animateTo(0) end
function NovaMenu.toggle() animateTo(S.prog < 0.5 and 1 or 0) end
function NovaMenu.isOpen() return S.prog > 0.5 end

----------------------------------------------------------------------
-- floating button build
----------------------------------------------------------------------
local function buildFab(guiRoot)
    -- the button is its own frame: accent border (fab) + dark body (fabInner)
    fab = box(guiRoot, 0, 0, S.fabSize, S.fabSize, C.accent, true)
    fabInner = box(fab, 3, 3, S.fabSize - 6, S.fabSize - 6, C.panel)
    fabLabel = text(fabInner, "N", 0, 0, S.fabSize - 6, S.fabSize - 6, C.text, 1.6, HorizontalAlignment.Center)
    pcall(function() fab:SetLevel(10) end)

    -- hud text under the button
    local function hudText(str)
        local t = text(guiRoot, str, 0, 0, HUD_W, 24, C.text, 0.95, HorizontalAlignment.Center)
        pcall(function() t:SetTextBoader(Color.BLACK) end)
        pcall(function() t:SetLevel(10) end)
        return t
    end
    hud.fps, hud.ping, hud.item = hudText("FPS -"), hudText("Ping -"), hudText("Held item: -")

    -- drag with the finger (same session logic as the panel header), tap = toggle
    local sess = { t = -1, lx = 0, ly = 0, sx = 0, sy = 0, moved = false, lastMove = -10 }
    on(fab, GUIEvent.TouchDown, function() sess.t = -1; sess.moved = false end)
    on(fab, GUIEvent.TouchMove, function(args)
        local pos = args and args.position
        if not pos then return end
        local t = now()
        if t - sess.t > 0.3 then                       -- new touch session
            sess.lx, sess.ly = pos.x, pos.y
            sess.sx, sess.sy = pos.x, pos.y
            sess.moved = false
        end
        sess.t = t
        if not sess.moved and math.abs(pos.x - sess.sx) + math.abs(pos.y - sess.sy) > 8 then
            sess.moved = true
        end
        if sess.moved then
            sess.lastMove = t
            S.fdx = S.fdx + (pos.x - sess.lx)          -- move by finger delta
            S.fy  = S.fy  + (pos.y - sess.ly)
            placeFab(); markDirty()
        end
        sess.lx, sess.ly = pos.x, pos.y
    end)
    on(fab, GUIEvent.Click, function()
        if now() - sess.lastMove < 0.4 then return end  -- a drag is not a tap
        NovaMenu.toggle()
    end)

    homeFab()
    placeFab()

    -- idle pulse on the border (only while closed)
    local t = 0
    LuaTimer:scheduleTimer(function()
        if not S.pulse or S.prog > 0.01 then return end
        t = t + 0.12
        fab:SetBackgroundColor({C.accent[1], C.accent[2], C.accent[3], 0.45 + 0.55 * (0.5 + 0.5 * math.sin(t))})
    end, 50, -1)
end

----------------------------------------------------------------------
-- panel build
----------------------------------------------------------------------
local function buildPanel(guiRoot)
    root = win(GUIType.Layout, "Root", guiRoot)
    root:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    root:SetBackgroundColor(C.clear)
    root:SetTouchable(false)
    root:SetVisible(false)
    pcall(function() root:SetLevel(5) end)

    -- backdrop: swallows touches, optionally closes the menu
    dim = win(GUIType.Layout, "Dim", root)
    dim:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    dim:SetBackgroundColor({0, 0, 0, 0})
    dim:SetTouchable(true)
    on(dim, GUIEvent.Click, function() if S.closeOutside then NovaMenu.close() end end)

    frame = box(root, 0, 0, W, H, C.line, true)                 -- 1px border
    placePanel(0)
    local body = box(frame, 1, 1, W - 2, H - 2, C.bg)

    -- header
    local header = box(body, 0, 0, W - 2, HEAD, C.panel)
    box(body, 0, HEAD, W - 2, 1, C.line)
    box(body, 0, HEAD, 70, 2, C.accent)
    text(header, "NOVA", 18, 3, 140, 28, C.text, 1.2)
    text(header, "menu", 18, 31, 140, 16, C.accent2, 0.7)

    local closeBtn = button(header, "X", W - 2 - 46, 9, 34, 34, C.off, C.text, 0.95, function() NovaMenu.close() end)
    pressFx(closeBtn, C.off, C.danger)

    -- drag zone over the header
    local drag = box(header, 0, 0, W - 2 - 56, HEAD, C.clear, true)
    local lx, ly, lastT = 0, 0, -1
    on(drag, GUIEvent.TouchDown, function() lastT = -1 end)
    on(drag, GUIEvent.TouchMove, function(args)
        local pos = args and args.position
        if not pos then return end
        local t = now()
        if t - lastT > 0.3 then lx, ly = pos.x, pos.y end     -- new drag session
        lastT = t
        S.pdx = S.pdx + (pos.x - lx)                          -- move by finger delta
        S.pdy = S.pdy + (pos.y - ly)
        lx, ly = pos.x, pos.y
        placePanel(0); markDirty()
    end)

    -- sidebar
    sidebar = box(body, 0, HEAD + 1, SIDE, H - 2 - HEAD - 1, C.panel)
    box(sidebar, SIDE - 1, 0, 1, H, C.line)
    indicator = box(sidebar, 0, indY, 3, 46, C.accent)
    local foot = text(sidebar, "nova  v0.8", 14, 0, SIDE - 20, 20, C.muted, 0.7)
    foot:SetArea({0, 14}, {1, -26}, {0, SIDE - 20}, {0, 20})

    -- content
    content = box(body, SIDE, HEAD + 1, W - 2 - SIDE, H - 2 - HEAD - 1, C.bg)

    applyProg(0)
end

----------------------------------------------------------------------
-- Info tab: rotating character + profile, live stats, menu options
----------------------------------------------------------------------
local function infoTab(host)
    local PW, PH = W - 2 - SIDE - 12, H - 2 - HEAD - 1 - 12
    local LW = 210

    -- left: character card
    local card  = box(host, 0, 0, LW, PH, C.line)
    local inner = box(card, 1, 1, LW - 2, PH - 2, C.card)
    local stage = box(inner, 6, 6, LW - 14, PH - 90, C.panel)

    INFO.aw = GUIManager:createGUIWindow(GUIType.ActorWindow, nid("Actor"))
    INFO.aw:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    stage:AddChildWindow(INFO.aw)
    pcall(function() INFO.aw:SetActor1("boy.actor", "idle", 105) end)

    INFO.name = text(inner, "Unknown", 8, PH - 80, LW - 18, 26, C.accent2, 1.05, HorizontalAlignment.Center)
    INFO.id   = text(inner, "ID ?",    8, PH - 54, LW - 18, 22, C.muted, 0.8, HorizontalAlignment.Center)

    -- rotation: only while the menu is open and this tab is showing
    local rot = 0
    LuaTimer:scheduleTimer(function()
        if S.prog < 0.5 or S.cur ~= 1 then return end
        rot = (rot + 1.5) % 360
        pcall(function() INFO.aw:SetRotateY(rot) end)
    end, 20, -1)

    -- right: scrolling column
    local RX = LW + 12
    local RW = PW - RX - 28
    local ui = newPage(host, RW, { RX, 0, PW - RX, PH })

    ui:section("profile")
    INFO.sex = ui:kv("Gender", "Boy")
    ui:kv("Game version", gameVersion())
    ui:kv("Menu", "Nova v0.8")

    ui:section("live")
    INFO.fps  = ui:kv("FPS", "-")
    INFO.ping = ui:kv("Ping", "-")
    INFO.held = ui:kv("Held item id", "-")

    ui:section("menu")
    ui:toggle("FPS / Ping HUD", "Text under the button", S.hud, function(v) S.hud = v; setHudVisible(v); markDirty() end)
    ui:toggle("Close on outside tap", "Tap the dimmed area to close", S.closeOutside, function(v) S.closeOutside = v; markDirty() end)
    ui:toggle("Idle pulse", "Button border animation", S.pulse, function(v) S.pulse = v; markDirty() end)
    ui:stepper("Button size", "Floating button size", 48, 88, 4, S.fabSize, function(v)
        S.fabSize = v; placeFab(); markDirty()
    end)
    ui:action("Reset positions", function()
        homeFab(); placeFab()
        S.pdx, S.pdy = 0, 0; placePanel(0)
        markDirty()
    end)
    ui:action("Replay intro", function() NovaMenu.playIntro() end)
    ui:finish()
end

----------------------------------------------------------------------
-- GUI tab: scan every window, hide / show, copy, export
----------------------------------------------------------------------
local function wsafe(fn, default)
    local ok, v = pcall(fn)
    if ok and v ~= nil then return v end
    return default
end
local function wname(w)
    local n = tostring(wsafe(function() return w:GetName() end, ""))
    if n == "" then n = tostring(wsafe(function() return w:GetText() end, "")) end
    n = n:gsub("[\r\n]+", " ")
    return n ~= "" and n or "<?>"
end
local function wtext(w)
    local t = tostring(wsafe(function() return w:GetText() end, ""))
    t = t:gsub("[\r\n]+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if #t > 40 then t = t:sub(1, 37) .. "..." end
    return t
end
local function wvis(w)   return wsafe(function() return w:IsVisible() end, false) and true or false end
local function wtouch(w) return wsafe(function() return w:IsTouchable() end, false) and true or false end
local function wsize(w)
    local sz = wsafe(function() return w:GetPixelSize() end, nil)
    if sz and sz.x then return string.format("%dx%d", sz.x, sz.y) end
    return "?"
end

local MAX_NODES = 6000
local DUMP_FILES = {
    "/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/nova_gui_dump.txt",
    "nova_gui_dump.txt",
}

local function guiTab(host)
    local PW, PH = W - 2 - SIDE - 12, H - 2 - HEAD - 1 - 12
    local LISTW = PW - 44
    local ROWS, ROW_H = 11, 30
    local LIST_Y = 40
    local G = { tree = nil, flat = {}, open = {}, sel = nil, query = "", visOnly = false,
                top = 1, hidden = {}, total = 0 }
    local rowsW = {}
    local applyFilter, render

    ------------------------------------------------------------ scan
    local function scan()
        local rootW = wsafe(function() return GUISystem.Instance():GetRootWindow() end, nil)
        if not rootW then notify("GUI root not found", "bad"); return end
        local count = 0
        local function build(w, path, depth)
            count = count + 1
            local node = { win = w, path = path, depth = depth, name = wname(w), kids = {} }
            if count < MAX_NODES then
                local c = wsafe(function() return w:GetChildCount() end, 0) or 0
                for i = 0, c - 1 do
                    local ch = wsafe(function() return w:GetChildByIndex(i) end, nil)
                    if ch then
                        local nm = wname(ch)
                        if nm:sub(1, 3) ~= "NV_" then      -- hide the menu's own windows
                            node.kids[#node.kids + 1] = build(ch, path .. "/" .. i .. ":" .. nm, depth + 1)
                        end
                    end
                end
            end
            return node
        end
        G.tree, G.total, G.sel = build(rootW, "root", 0), count, nil
    end

    ------------------------------------------------------------ filter
    local function matches(n, q)
        if q == "" then return true end
        return n.name:lower():find(q, 1, true) ~= nil or wtext(n.win):lower():find(q, 1, true) ~= nil
    end
    local function hasMatch(n, q, memo)
        local m = memo[n]
        if m ~= nil then return m end
        local r = matches(n, q)
        if not r then
            for _, k in ipairs(n.kids) do
                if hasMatch(k, q, memo) then r = true; break end
            end
        end
        memo[n] = r
        return r
    end

    local function flatten()
        local out, memo, q = {}, {}, G.query:lower()
        if not G.tree then return out end
        local function walk(n)
            if n.depth > 0 then
                if q ~= "" and not hasMatch(n, q, memo) then return end
                if G.visOnly and not wvis(n.win) then return end
                out[#out + 1] = n
            end
            if n.depth == 0 or q ~= "" or G.open[n.path] then
                for _, k in ipairs(n.kids) do walk(k) end
            end
        end
        walk(G.tree)
        return out
    end

    ------------------------------------------------------------ export
    local function exportLines()
        local lines = { "# Nova GUI dump  windows scanned: " .. G.total
            .. (G.visOnly and "  (visible only)" or "")
            .. (G.query ~= "" and ("  filter: " .. G.query) or "") }
        local memo, q = {}, G.query:lower()
        if not G.tree then return lines end
        local function walk(n)
            if n.depth > 0 then
                if q ~= "" and not hasMatch(n, q, memo) then return end
                if G.visOnly and not wvis(n.win) then return end
                local t = wtext(n.win)
                lines[#lines + 1] = string.format("%s%s  [vis=%s touch=%s kids=%d size=%s]%s",
                    string.rep("  ", n.depth - 1), n.name, tostring(wvis(n.win)),
                    tostring(wtouch(n.win)), #n.kids, wsize(n.win), t ~= "" and ('  "' .. t .. '"') or "")
            end
            for _, k in ipairs(n.kids) do walk(k) end
        end
        walk(G.tree)
        return lines
    end

    local function doCopy()
        local lines = exportLines()
        local txt = table.concat(lines, "\n")
        local ok = pcall(function() ClientHelper.onSetClipboard(txt) end)
        notify(ok and ("Copied " .. #lines .. " lines") or "Clipboard not available", ok and "ok" or "bad")
    end

    local function doSave()
        local lines = exportLines()
        local txt = table.concat(lines, "\n")
        for _, path in ipairs(DUMP_FILES) do
            local ok = pcall(function()
                local f = io.open(path, "w")
                if not f then error("open failed") end
                f:write(txt); f:close()
            end)
            if ok then notify("Saved " .. #lines .. " lines: " .. path:match("[^/]+$"), "ok"); return end
        end
        notify("Could not write the file", "bad")
    end

    ------------------------------------------------------------ top bar
    text(host, "find", 0, 0, 36, 34, C.muted, 0.85)
    local edit = GUIManager:createGUIWindow(GUIType.Edit, nid("Edit"))
    host:AddChildWindow(edit)
    edit:SetArea({0, 40}, {0, 0}, {0, 214}, {0, 34})
    pcall(function() edit:SetBackgroundColor(C.card) end)
    pcall(function() edit:SetTextColor(C.text) end)
    local function onEdit()
        local q = tostring(wsafe(function() return edit:GetText() end, "") or "")
        if q ~= G.query then G.query, G.top = q, 1; applyFilter() end
    end
    on(edit, GUIEvent.EditTextInput, onEdit)
    on(edit, GUIEvent.WindowLostFocus, onEdit)

    local scanBtn = button(host, "Scan", 262, 0, 64, 34, C.accent, C.text, 0.9, function()
        scan(); G.top = 1; applyFilter(); notify("Scanned " .. G.total .. " windows", "ok")
    end)
    local visBtn
    visBtn = button(host, "All windows", 334, 0, 112, 34, C.off, C.text, 0.85, function()
        G.visOnly = not G.visOnly
        visBtn:SetText(G.visOnly and "Visible only" or "All windows")
        visBtn:SetBackgroundColor(G.visOnly and C.accent or C.off)
        G.top = 1; applyFilter()
    end)
    button(host, "Copy", 454, 0, 64, 34, C.off, C.text, 0.9, doCopy)
    button(host, "Save", 526, 0, 64, 34, C.off, C.text, 0.9, doSave)
    pressFx(scanBtn, C.accent, C.accent2)

    ------------------------------------------------------------ list
    local listFrame = box(host, 0, LIST_Y, LISTW, ROWS * ROW_H, C.card, true)

    local function scrollBy(d)
        G.top = clamp(G.top + d, 1, math.max(1, #G.flat - ROWS + 1))
        render()
    end

    local acc, lastY, lastT, lastScroll = 0, 0, -1, -10
    local function dragMove(args)
        local pos = args and args.position
        if not pos then return end
        local t = now()
        if t - lastT > 0.3 then lastY, acc = pos.y, 0 end
        lastT = t
        acc = acc + (lastY - pos.y)
        lastY = pos.y
        while acc >= ROW_H do scrollBy(1);  acc = acc - ROW_H; lastScroll = t end
        while acc <= -ROW_H do scrollBy(-1); acc = acc + ROW_H; lastScroll = t end
    end
    on(listFrame, GUIEvent.TouchMove, dragMove)

    local function select(node)
        G.sel = node
        render()
    end

    for r = 1, ROWS do
        local y = (r - 1) * ROW_H
        local row = {}
        row.bg    = box(listFrame, 0, y, LISTW, ROW_H - 1, (r % 2 == 0) and C.card or C.panel)
        row.arrow = button(listFrame, "", 0, y, 26, ROW_H - 1, C.clear, C.accent2, 0.9, function()
            local n = row.node
            if n and #n.kids > 0 then G.open[n.path] = not G.open[n.path]; applyFilter() end
        end)
        row.name  = button(listFrame, "", 28, y, LISTW - 28 - 70, ROW_H - 1, C.clear, C.text, 0.85, function()
            if now() - lastScroll < 0.4 then return end
            if row.node then select(row.node) end
        end)
        pcall(function() row.name:SetTextHorzAlign(HorizontalAlignment.Left) end)
        on(row.name, GUIEvent.TouchMove, dragMove)
        row.eye = button(listFrame, "", LISTW - 66, y + 3, 60, ROW_H - 7, C.off, C.text, 0.8, function()
            local n = row.node
            if not n then return end
            local v = wvis(n.win)
            pcall(function() n.win:SetVisible(not v) end)
            if v then G.hidden[n.win] = true else G.hidden[n.win] = nil end
            render()
        end)
        rowsW[r] = row
    end

    -- scroll buttons (always work, even if finger-drag does not)
    local function sbtn(label, y, d)
        local b = button(host, label, LISTW + 4, y, 40, 44, C.off, C.text, 0.9, function() scrollBy(d) end)
        pressFx(b, C.off, C.line)
    end
    sbtn("^^", LIST_Y,        -ROWS)
    sbtn("^",  LIST_Y + 62,   -1)
    sbtn("v",  LIST_Y + 124,  1)
    sbtn("vv", LIST_Y + 186,  ROWS)

    ------------------------------------------------------------ detail bar
    local DY = LIST_Y + ROWS * ROW_H + 6
    local d1 = text(host, "tap a window name to inspect it", 0, DY, 400, 18, C.text, 0.78)
    local d2 = text(host, "", 0, DY + 18, 400, 18, C.muted, 0.75)
    button(host, "Copy name", 406, DY + 2, 92, 32, C.off, C.text, 0.82, function()
        if G.sel then
            local ok = pcall(function() ClientHelper.onSetClipboard(G.sel.name) end)
            notify(ok and ("Copied: " .. G.sel.name) or "Clipboard not available", ok and "ok" or "bad")
        else
            notify("Select a window first")
        end
    end)
    button(host, "Restore", 504, DY + 2, 92, 32, C.accent, C.text, 0.82, function()
        local c = 0
        for w in pairs(G.hidden) do
            pcall(function() w:SetVisible(true) end)
            c = c + 1
        end
        G.hidden = {}
        render()
        notify(c > 0 and ("Restored " .. c .. " windows") or "Nothing hidden", c > 0 and "ok" or nil)
    end)

    ------------------------------------------------------------ render
    render = function()
        for r = 1, ROWS do
            local row, node = rowsW[r], G.flat[G.top + r - 1]
            row.node = node
            local show = node ~= nil
            row.bg:SetVisible(show); row.arrow:SetVisible(show)
            row.name:SetVisible(show); row.eye:SetVisible(show)
            if show then
                local vis = wvis(node.win)
                local label = string.rep("  ", math.min(node.depth - 1, 8)) .. node.name
                if #label > 56 then label = label:sub(1, 53) .. "..." end
                local selected = (G.sel == node)
                row.name:SetText(label)
                row.name:SetTextColor(selected and C.accent2 or (vis and C.text or C.muted))
                row.arrow:SetText(#node.kids > 0 and ((G.open[node.path] or G.query ~= "") and "v" or ">") or "")
                row.eye:SetText(vis and "HIDE" or "SHOW")
                row.eye:SetBackgroundColor(vis and C.off or C.accent)
                row.bg:SetBackgroundColor(selected and C.tabOn or ((r % 2 == 0) and C.card or C.panel))
            end
        end
        local n = #G.flat
        local last = math.min(n, G.top + ROWS - 1)
        d2:SetText(string.format("rows %d-%d of %d   |   scanned %d windows", n > 0 and G.top or 0, last, n, G.total))
        if G.sel then
            local w = G.sel.win
            local t = wtext(w)
            d1:SetText(string.format("%s  vis=%s touch=%s kids=%d size=%s%s", G.sel.name, tostring(wvis(w)),
                tostring(wtouch(w)), #G.sel.kids, wsize(w), t ~= "" and ('  "' .. t .. '"') or ""))
        else
            d1:SetText("tap a window name to inspect it")
        end
    end

    applyFilter = function()
        G.flat = flatten()
        G.top = clamp(G.top, 1, math.max(1, #G.flat - ROWS + 1))
        render()
    end

    return { onShow = function() scan(); applyFilter() end }
end

----------------------------------------------------------------------
-- Tweaks: hide the "bag full" tip popup (display only)
----------------------------------------------------------------------
-- The server sends HostApi.sendCommonTip(player, "bag_full"). The client shows it in the
-- "CommonTip" window (full-screen dim + message). We only hide that window when its
-- message text looks like the bag-full text. Nothing is sent to the server.
local TIP = { last = "", hidden = 0 }

local function tipIsBagFull(txt)
    local t = txt:lower()
    if t == "" then return false end
    if t:find("bag_full", 1, true) then return true end
    if t:find("едостаточно места", 1, true) then return true end   -- ru: bag_full = "Недостаточно места"
    if t:find("full", 1, true) and (t:find("bag", 1, true) or t:find("backpack", 1, true)
        or t:find("inventory", 1, true)) then return true end
    if t:find("полн", 1, true) and (t:find("юкзак", 1, true) or t:find("нвентар", 1, true)
        or t:find("умк", 1, true)) then return true end
    for item in tostring(S.learned or ""):gmatch("[^|]+") do
        if t == item then return true end
    end
    return false
end

local function findNamed(w, name, depth)
    if not w then return nil end
    if wname(w) == name then return w end
    if (depth or 0) >= 4 then return nil end
    local c = wsafe(function() return w:GetChildCount() end, 0) or 0
    for i = 0, c - 1 do
        local ch = wsafe(function() return w:GetChildByIndex(i) end, nil)
        local r = findNamed(ch, name, (depth or 0) + 1)
        if r then return r end
    end
    return nil
end

-- Windows that can show the bag-full text: the small "CommonTip" popup and the
-- wooden "TipDialog" (title "Подсказка", Cancel / OK) seen in the screenshot.
local GUARDED = { "CommonTip", "TipDialog" }

-- text of every visible "...Message" label inside a dialog (variant panels that are
-- hidden are skipped, so stale text from another skin does not count)
local function collectMessage(root)
    local parts = {}
    local function walk(w, d)
        if d > 6 or not wvis(w) then return end
        if wname(w):sub(-7) == "Message" then
            local t = tostring(wsafe(function() return w:GetText() end, ""))
            if t ~= "" then parts[#parts + 1] = t end
        end
        local c = wsafe(function() return w:GetChildCount() end, 0) or 0
        for i = 0, c - 1 do
            local ch = wsafe(function() return w:GetChildByIndex(i) end, nil)
            if ch then walk(ch, d + 1) end
        end
    end
    walk(root, 0)
    return table.concat(parts, " ")
end

-- Why it flickered: the server re-sends the tip over and over, the game shows the
-- dialog again each time, and hiding it a tick later is visible. So a matching dialog is
-- "parked": moved off screen and made transparent, then hidden. When the game shows it
-- again it appears off screen, so there is nothing to see and nothing to block taps.
-- Any other tip that appears is moved back (unparked) on the next check.
local function startTipGuard()
    local cache, parked, tick = {}, {}, 0
    TIP.found = {}

    local function park(w, name)
        pcall(function() w:SetArea({8, 0}, {8, 0}, {1, 0}, {1, 0}) end)
        setAlpha(w, 0)
        pcall(function() w:SetVisible(false) end)
        parked[name] = true
    end
    local function unpark(w, name)
        pcall(function() w:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0}) end)
        setAlpha(w, 1)
        parked[name] = nil
    end

    LuaTimer:scheduleTimer(function()
        tick = tick + 1
        for _, name in ipairs(GUARDED) do
            local w = cache[name]
            if not w then
                w = wsafe(function() return GUIManager:getWindowByName(name) end, nil)
                if not w and tick % 30 == 0 then          -- slow fallback: look through the tree
                    local rootW = wsafe(function() return GUISystem.Instance():GetRootWindow() end, nil)
                    w = findNamed(rootW, name, 0)
                end
                if w then cache[name] = w; TIP.found[name] = true end
            end
            if w then
                if parked[name] and not S.hideBagFull then
                    unpark(w, name)                       -- feature switched off: give it back
                elseif wvis(w) then
                    local txt = collectMessage(w)
                    if txt ~= "" then TIP.last = txt end
                    if S.hideBagFull and tipIsBagFull(txt) then
                        park(w, name)
                        TIP.hidden = TIP.hidden + 1
                    elseif parked[name] and txt ~= "" then
                        unpark(w, name)                   -- a different tip: show it normally
                    end
                end
            end
        end
    end, 16, -1)
end

local function tweaksTab(ui)
    ui:section("tips")
    ui:toggle("Hide 'bag full' tip", "Skip the popup when your bag is full", S.hideBagFull, function(v)
        S.hideBagFull = v; markDirty()
    end)
    ui:info("Only the popup is hidden. The game still cannot pick up items while the bag is full.")
    local seen  = ui:kv("Last tip text", "-")
    local count = ui:kv("Hidden this session", "0")
    local found = ui:kv("Dialog windows found", "-")
    ui:action("Always hide the last tip text", function()
        if TIP.last == "" then notify("No tip seen yet"); return end
        local t = TIP.last:lower()
        if not (("|" .. S.learned .. "|"):find("|" .. t .. "|", 1, true)) then
            S.learned = (S.learned == "") and t or (S.learned .. "|" .. t)
            markDirty()
        end
        notify("Will hide: " .. (#TIP.last > 30 and TIP.last:sub(1, 27) .. "..." or TIP.last), "ok")
    end)
    ui:action("Forget learned texts", function()
        S.learned = ""; markDirty(); notify("Learned texts cleared", "ok")
    end)
    return { onShow = function()
        local t = TIP.last
        seen.set(t == "" and "-" or (#t > 34 and t:sub(1, 31) .. "..." or t))
        count.set(tostring(TIP.hidden))
        local f = {}
        for _, n in ipairs(GUARDED) do f[#f + 1] = n .. (TIP.found and TIP.found[n] and ": yes" or ": no") end
        found.set(table.concat(f, "  "))
    end }
end

----------------------------------------------------------------------
-- intro: loading splash with a real step-by-step percentage
----------------------------------------------------------------------
local SP = { pct = 0, target = 0, BARW = 300, busy = false, shown = false, phase = 0 }

local function spSetPct(p)
    SP.pct = p
    local fw = SP.BARW * p
    SP.fill:SetArea({0, 0}, {0, 0}, {0, fw}, {0, 10})
    SP.pctTxt:SetText(string.format("%d%%", math.floor(p * 100 + 0.5)))
    local showShine = fw > 44
    SP.shine:SetVisible(showShine)
end

local function spSetTarget(t)
    SP.target = t
    local from = SP.pct
    tween("sp_bar", 280, ease.outCubic, function(p) spSetPct(lerp(from, t, p)) end)
end

local function buildSplash(guiRoot)
    local cw, ch = 380, 190

    SP.root = win(GUIType.Layout, "Splash", guiRoot)
    SP.root:SetArea({0, 0}, {0, 0}, {1, 0}, {1, 0})
    SP.root:SetBackgroundColor({0, 0, 0, 0})
    SP.root:SetTouchable(false)
    pcall(function() SP.root:SetLevel(20) end)

    SP.card = box(SP.root, 0, 0, cw, ch, C.accent)
    SP.card:SetArea({0.5, -cw / 2}, {0.5, -ch / 2}, {0, cw}, {0, ch})
    local inner = box(SP.card, 1, 1, cw - 2, ch - 2, C.panel)
    box(inner, 0, 0, cw - 2, 2, C.accent2)
    text(inner, "NOVA", 0, 16, cw - 2, 52, C.text, 2.0, HorizontalAlignment.Center)
    SP.sub = text(inner, "starting", 0, 70, cw - 2, 22, C.muted, 0.85, HorizontalAlignment.Center)

    SP.track = box(inner, (cw - 2 - SP.BARW) / 2, 108, SP.BARW, 10, C.off)
    SP.fill  = box(SP.track, 0, 0, 0, 10, C.accent)
    SP.shine = box(SP.fill, 0, 0, 36, 10, {1, 1, 1, 0.35})
    SP.pctTxt = text(inner, "0%", 0, 126, cw - 2, 28, C.text, 1.1, HorizontalAlignment.Center)
    SP.root:SetVisible(false)

    -- shine sweeps along the filled part while the splash is visible
    LuaTimer:scheduleTimer(function()
        if not SP.shown then return end
        SP.phase = (SP.phase + 0.035) % 1
        local fw = SP.BARW * SP.pct
        if fw > 44 then SP.shine:SetArea({0, SP.phase * (fw - 36)}, {0, 0}, {0, 36}, {0, 10}) end
    end, 30, -1)
end

local function spShow()
    SP.shown = true
    SP.pct, SP.target = 0, 0
    spSetPct(0)
    SP.sub:SetTextColor(C.muted)
    SP.root:SetVisible(true)
    tween("sp_show", 260, ease.outCubic, function(p)
        SP.root:SetBackgroundColor({0, 0, 0, 0.78 * p})
        SP.card:SetArea({0.5, -190}, {0.5, -95 + (1 - p) * 24}, {0, 380}, {0, 190})
        setAlpha(SP.card, p)
    end)
end

local function spHide(done)
    tween("sp_show", 320, ease.inCubic, function(p)
        SP.root:SetBackgroundColor({0, 0, 0, 0.78 * (1 - p)})
        SP.card:SetArea({0.5, -190}, {0.5, -95 - p * 18}, {0, 380}, {0, 190})
        setAlpha(SP.card, 1 - p)
    end, function()
        SP.root:SetVisible(false)
        SP.shown, SP.busy = false, false
        if done then pcall(done) end
    end)
end

-- steps = { { label = "...", fn = function() ... end }, ... }
local function runSplash(steps, done)
    if SP.busy then return end
    SP.busy = true
    spShow()
    local n = #steps
    local function step(i)
        if i > n then
            SP.sub:SetText("Ready")
            spSetTarget(1)
            LuaTimer:schedule(function() spHide(done) end, 500)
            return
        end
        SP.sub:SetText(steps[i].label)
        local ok, err = pcall(steps[i].fn)
        if ok then
            SP.sub:SetTextColor(C.muted)
        else
            SP.sub:SetText("failed: " .. steps[i].label)
            SP.sub:SetTextColor(C.danger)
            print("[Nova] " .. steps[i].label .. ": " .. tostring(err))
        end
        spSetTarget(i / n)
        LuaTimer:schedule(function() step(i + 1) end, 280)
    end
    LuaTimer:schedule(function() step(1) end, 320)       -- let the card fade in first
end

function NovaMenu.playIntro()
    if SP.busy then return end
    runSplash({
        { label = "Checking interface", fn = function() end },
        { label = "Syncing profile",    fn = refreshProfile },
        { label = "Reading live stats", fn = updateStats },
        { label = "Applying theme",     fn = function() applyProg(S.prog) end },
    })
end

----------------------------------------------------------------------
-- boot (waits for the GUI root)
----------------------------------------------------------------------
local booted = false
local function boot()
    if booted then return end
    local guiRoot
    pcall(function() guiRoot = GUISystem.Instance():GetRootWindow() end)
    if not guiRoot then LuaTimer:schedule(boot, 500); return end
    booted = true

    LuaTimer:scheduleTimer(function() clock = clock + 0.05 end, 50, -1)

    buildSplash(guiRoot)
    runSplash({
        { label = "Loading settings",    fn = loadSettings },
        { label = "Building panel",      fn = function() buildPanel(guiRoot) end },
        { label = "Creating button",     fn = function() buildFab(guiRoot); setHudVisible(S.hud) end },
        { label = "Loading notifications", fn = function() buildToasts(guiRoot) end },
        { label = "Loading Info tab",    fn = function() NovaMenu.addTab("Info", infoTab, true) end },
        { label = "Loading GUI tab",     fn = function() NovaMenu.addTab("GUI", guiTab, true) end },
        { label = "Loading tweaks",      fn = function() NovaMenu.addTab("Tweaks", tweaksTab); startTipGuard() end },
        { label = "Starting live stats", fn = function()
            LuaTimer:scheduleTimer(function() pcall(updateStats) end, 250, -1)
            LuaTimer:scheduleTimer(function()
                if S._dirty then S._dirty = false; pcall(saveSettings) end
            end, 1500, -1)
        end },
        { label = "Applying theme",      fn = function() applyProg(0) end },
    }, function() notify("Nova ready", "ok") end)
end

boot()
return NovaMenu
